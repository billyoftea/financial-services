# Portfolio Rebalance Recommendation

**Client:** J. Robertson | **Date:** May 8, 2026 | **Rebalance Threshold:** 5% drift

---

## Current vs. Target Allocation

| Asset Class | Target | Current | Drift | Market Value |
|-------------|--------|---------|-------|-------------|
| US Equity | 35% | 38% | +3% | $1,140,000 |
| International Equity | 15% | 12% | -3% | $360,000 |
| Fixed Income | 30% | 25% | -5% | $750,000 |
| Alternatives | 10% | 12% | +2% | $360,000 |
| Cash | 10% | 13% | +3% | $390,000 |
| **Total** | **100%** | **100%** | -- | **$3,000,000** |

**Current effective allocation: 65/30/5 (Equity/Fixed/Other) vs. Target: 60/30/10.**

---

## Recommended Trades

| Action | Security | Amount | Account | Tax Impact |
|--------|----------|--------|---------|-----------|
| Sell | SPY (US Equity ETF) | -$90,000 | Taxable | LTCG ~$32,000 est. |
| Sell | Alternative Fund A | -$60,000 | Taxable | LTCG ~$8,000 est. |
| Sell | Cash (money market) | -$90,000 | Taxable | Minimal interest |
| Buy | VXUS (Intl Equity ETF) | +$90,000 | Taxable | No immediate tax |
| Buy | BND (Core Bond ETF) | +$150,000 | Tax-deferred | No tax |
| **Net Cash Flow** | | **$0** | | |

---

## Tax Implications

| Item | Detail |
|------|--------|
| Realized LTCG (SPY) | ~$32,000 at 20% = **$6,400 tax** |
| Realized LTCG (Alt Fund) | ~$8,000 at 20% = **$1,600 tax** |
| Total Estimated Tax Cost | **$8,000** |
| Tax-Loss Harvesting Opportunity | None currently; all positions in gain |
| Recommendation | Execute bond purchases in tax-deferred account to avoid ongoing tax drag |

---

## Rebalance Rationale

- **Equity overweight (+5%):** Driven by US large cap appreciation; trimming reduces concentration risk ahead of potential market volatility.
- **International underweight (-3%):** International valuations more attractive (EAFE P/E: 14.2x vs. S&P 500: 21.5x); increasing exposure improves diversification.
- **Fixed income underweight (-5%):** Rates have stabilized; extending duration adds income and reduces portfolio volatility.
- **Cash overweight (+3%):** Deploying excess cash into fixed income improves yield without materially increasing risk.

---

## Implementation Notes

- Execute equity sales in taxable account first to capture favorable LTCG rates.
- Place all bond purchases in IRA/401(k) to shield income from taxes.
- Complete within 5 business days to minimize market timing risk.
- Next scheduled rebalance review: August 2026.
