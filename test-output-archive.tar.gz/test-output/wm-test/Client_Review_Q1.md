# Q1 2026 Client Review Preparation

**Client:** J. Robertson | **Review Date:** April 10, 2026 | **Advisor:** K. Williams

---

## Performance Summary

| Metric | Q1 2026 | YTD |
|--------|---------|-----|
| Portfolio Return | +8.2% | +8.2% |
| Benchmark (60/40 Blend) | +7.5% | +7.5% |
| Alpha | +0.7% | +0.7% |
| Portfolio Value | $3,246,000 | $3,246,000 |
| Volatility (Annualized) | 9.8% | 9.8% |

---

## Allocation Review

| Asset Class | Target | Actual | Drift | Notes |
|-------------|--------|--------|-------|-------|
| US Equity | 35% | 37% | +2% | Within tolerance; no action needed |
| International | 15% | 13% | -2% | Within tolerance; monitor |
| Fixed Income | 30% | 28% | -2% | Within tolerance; rates stable |
| Alternatives | 10% | 12% | +2% | REITs performed well; trim at 5% |
| Cash | 10% | 10% | 0% | On target |

---

## Key Talking Points

### Performance
- Portfolio outperformed benchmark by 70bps, driven by equity overweight and strong NVDA position (+15% Q1).
- Fixed income contributed steady income; core bond index returned +2.1%.
- International drag (-0.3% vs. benchmark) from EM weakness; thesis intact for long-term diversification.

### Market Commentary
- S&P 500 returned +9.2% in Q1; late-quarter pullback created buying opportunity.
- Fed held rates steady at 4.25-4.50%; two cuts still expected in H2 2026.
- Credit spreads remain tight; credit quality in bond portfolio is sound.

### Portfolio Actions Taken
- Rebalanced on Feb 15 (trimmed US equity, added international).
- Executed TLH on META (replaced with XLC); saved ~$6,300 in taxes.
- Increased 529 contributions to $3,333/month per plan.

---

## Discussion Items

| # | Topic | Priority |
|---|-------|----------|
| 1 | Rebalance recommendation -- equity trim after strong Q1 | High |
| 2 | College funding gap -- 529 on track but Child 1 enrollment in 5 years | High |
| 3 | Review umbrella insurance coverage ($3M assets now) | Medium |
| 4 | Charitable giving strategy -- DAF contribution timing | Medium |
| 5 | Consider municipal bonds in taxable account for tax efficiency | Low |

---

## Next Quarter Outlook

- Expect moderate returns; monitor Fed signals for rate cut timing.
- International allocation may benefit from dollar weakness cycle.
- Maintain current 60/40 target; schedule mid-quarter check-in for June.
- Begin Child 1 college financial aid planning (CSS Profile due Oct 2030).
