# Financial Plan: Client Profile -- Age 45

**Client:** J. Robertson | **Age:** 45 | **Target Retirement:** Age 60 (15 years)
**Annual Income:** $500,000 | **Current Portfolio:** $3,000,000 | **Dependents:** 2 children (ages 10, 13)

---

## Retirement Projection

| Metric | Current | Age 50 | Age 55 | Age 60 (Target) |
|--------|---------|--------|--------|-----------------|
| Portfolio Value | $3.0M | $5.1M | $7.8M | $11.2M |
| Annual Savings | $120K | $130K | $140K | -- |
| Retirement Income Need | -- | -- | -- | $200K/yr |
| Withdrawal Rate | -- | -- | -- | 1.8% |
| Probability of Success | -- | -- | -- | 94% |

*Assumes 7.0% average annual return, 2.5% inflation, salary growth 3%/yr.*

---

## College Funding

| Child | Age | Enrollment Year | Annual Cost | 5-Year Cost | Funded From |
|-------|-----|----------------|-------------|-------------|-------------|
| Child 1 | 13 | 2031 | $65,000 | $325,000 | 529 Plan ($180K) + taxable |
| Child 2 | 10 | 2034 | $70,000 | $350,000 | 529 Plan ($120K) + current savings |

**Total education need:** $675,000. Current 529 balance: $300,000. **Gap: $375,000** -- fund via annual 529 contributions of $40K/year for next 5 years.

---

## Recommended Asset Allocation

| Asset Class | Target | Current | Action |
|-------------|--------|---------|--------|
| US Large Cap Equity | 35% | 38% | Reduce |
| International Equity | 15% | 12% | Increase |
| US Small/Mid Cap | 10% | 8% | Increase |
| Fixed Income (Core) | 25% | 22% | Increase |
| Alternatives (RE/PE) | 10% | 12% | Reduce |
| Cash | 5% | 8% | Deploy |

**Overall allocation shift:** Move from aggressive (80/20) to moderate growth (70/30) as retirement horizon shortens.

---

## Savings Rate Analysis

| Category | Annual Amount | % of Gross Income |
|----------|---------------|-------------------|
| 401(k) (max) | $23,500 | 4.7% |
| Backdoor Roth IRA | $7,000 | 1.4% |
| After-Tax Brokerage | $60,000 | 12.0% |
| 529 Contributions | $40,000 | 8.0% |
| **Total Savings** | **$130,500** | **26.1%** |

---

## Action Items

1. Rebalance portfolio to 70/30 target allocation this quarter.
2. Increase 529 contributions to $40K/year ($3,333/month) starting immediately.
3. Max out 401(k) catch-up contributions starting in 2031 (age 50).
4. Review umbrella insurance -- increase to $5M given asset growth trajectory.
5. Establish donor-advised fund for charitable giving to capture deduction in high-income years.
6. Annual review of retirement projection with updated return assumptions.
7. Consider long-term care insurance evaluation at age 50.
