# Investment Proposal for Prospective Client

**Prepared for:** R. & L. Thompson | **Date:** May 8, 2026 | **Advisor:** K. Williams

---

## Client Profile

| Detail | Value |
|--------|-------|
| Age | 55 (R.), 53 (L.) |
| Primary Goal | Retirement at age 62 |
| Current Assets | $2,000,000 |
| Annual Income | $380,000 |
| Annual Savings | $80,000 |
| Risk Tolerance | Moderate |
| Time Horizon | 7 years to retirement; 30+ year distribution |

---

## Firm Overview

Williams Wealth Advisors is an independent, fee-only Registered Investment Advisor managing $1.2B in client assets. We provide comprehensive financial planning, investment management, tax strategy, and estate planning coordination.

**Our approach:** Evidence-based investing using institutional-grade diversification, disciplined rebalancing, and tax-aware portfolio management. No commissions, no proprietary products.

---

## Proposed Investment Strategy

### Target Allocation

| Asset Class | Target | Rationale |
|-------------|--------|-----------|
| US Large Cap | 28% | Core equity growth engine; low-cost index exposure |
| US Small/Mid Cap | 8% | Growth premium; diversification benefit |
| International Developed | 12% | Geographic diversification; valuation opportunity |
| Emerging Markets | 5% | Long-term growth; portfolio diversifier |
| Investment Grade Bonds | 20% | Income generation; stability; duration management |
| TIPS | 5% | Inflation protection for retirement income |
| High Yield / Credit | 5% | Yield enhancement; moderate risk |
| Real Estate (REITs) | 7% | Income; inflation hedge; low correlation |
| Alternatives | 5% | Diversified alternatives for downside protection |
| Cash | 5% | Liquidity buffer; opportunistic reserve |

### Expected Return Profile

| Metric | Conservative | Base Case | Optimistic |
|--------|-------------|-----------|-----------|
| Annual Return | 4.5% | 6.8% | 9.0% |
| Portfolio at Retirement (Age 62) | $2.8M | $3.4M | $4.1M |
| Sustainable Income (3.5% withdrawal) | $98,000 | $119,000 | $143,500 |
| Success Probability (Monte Carlo) | 85% | 92% | 97% |

---

## Historical Returns (Model Portfolio, Net of Fees)

| Period | Return | Benchmark |
|--------|--------|-----------|
| 1-Year | +13.8% | +13.1% |
| 3-Year (ann.) | +7.2% | +6.8% |
| 5-Year (ann.) | +8.1% | +7.6% |
| 10-Year (ann.) | +7.4% | +7.0% |

*Returns are hypothetical, based on actual model portfolio composition, net of our advisory fee.*

---

## Fee Schedule

| Tier | Annual Fee | Applicable To |
|------|-----------|---------------|
| First $1M | 0.85% | $8,500 |
| $1M - $2M | 0.70% | $7,000 |
| Above $2M | 0.55% | -- |
| **Effective Rate on $2M** | **0.775%** | **$15,500/year** |

**What is included:** Investment management, financial planning, tax-loss harvesting, rebalancing, quarterly reporting, annual plan review, estate planning coordination.

**No hidden fees:** No commissions, no transaction charges, no custodian fees passed through.

---

## Next Steps

1. Schedule introductory meeting to review this proposal and answer questions.
2. Complete risk tolerance questionnaire and financial data gathering.
3. Execute advisory agreement and account transfer paperwork.
4. Onboard accounts; implement proposed allocation within 5 business days.
5. Deliver initial comprehensive financial plan within 30 days.

---

*This proposal is for informational purposes and does not constitute a guarantee of future performance. Williams Wealth Advisors is a registered investment advisor. Please review our Form ADV Part 2 for complete disclosures.*
