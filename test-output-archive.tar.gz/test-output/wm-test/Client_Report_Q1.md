# Q1 2026 Client Report

**Prepared for:** J. Robertson | **Period:** January 1 -- March 31, 2026 | **Advisor:** K. Williams

---

## Performance Summary

Your portfolio returned **+8.2%** in Q1 2026, outperforming the blended benchmark return of +7.5%. Your portfolio value grew from $3,000,000 to **$3,246,000**.

| Period | Portfolio | Benchmark | Difference |
|--------|-----------|-----------|-----------|
| Q1 2026 | +8.2% | +7.5% | +0.7% |
| 1-Year (trailing) | +14.3% | +13.1% | +1.2% |
| Since Inception (2020) | +8.9% ann. | +8.1% ann. | +0.8% |

---

## Asset Allocation

| Asset Class | Value | % of Portfolio | Target | Status |
|-------------|-------|---------------|--------|--------|
| US Equity | $1,201,020 | 37% | 35% | Slightly Over |
| International | $421,980 | 13% | 15% | Slightly Under |
| Fixed Income | $908,880 | 28% | 30% | Slightly Under |
| Alternatives | $389,520 | 12% | 10% | Slightly Over |
| Cash | $324,600 | 10% | 10% | On Target |
| **Total** | **$3,246,000** | **100%** | **100%** | -- |

---

## Market Commentary

Q1 2026 was marked by resilient equity markets and stabilizing interest rates. The S&P 500 advanced 9.2%, led by technology and healthcare sectors. The Federal Reserve maintained the federal funds rate at 4.25-4.50%, signaling two potential cuts in the second half of the year.

International markets lagged, with emerging markets declining 1.5% on China growth concerns. Developed international markets (EAFE) returned +3.8%, supported by European manufacturing recovery signals.

The Bloomberg Aggregate Bond Index returned +2.1%, benefiting from stable rates and tightening credit spreads. High-quality intermediate-term bonds provided reliable income with modest price appreciation.

---

## Account Activity

| Date | Action | Details |
|------|--------|---------|
| Jan 15 | 529 Contribution | $3,333 to each child's 529 plan |
| Feb 1 | TLH Execution | Sold META; purchased XLC as replacement |
| Feb 15 | Rebalance | Trimmed US equity (+2%), added international |
| Mar 15 | 529 Contribution | $3,333 to each child's 529 plan |
| Mar 31 | Quarterly Fee | Advisory fee debited ($4,868 for Q1) |

---

## Forward Outlook

We maintain a constructive but measured outlook for Q2 and the remainder of 2026:

- **Equities:** Expect single-digit returns; earnings growth supportive but valuations elevated. Favor quality and dividend growth.
- **Fixed Income:** Attractive yields persist; positioned for potential rate cuts in H2 which would boost bond prices.
- **Alternatives:** REITs offer inflation protection; maintain allocation for portfolio diversification.
- **Risks:** Trade policy uncertainty, geopolitical tensions, and potential earnings deceleration in H2.

---

*This report is for informational purposes. Past performance does not guarantee future results. Please contact your advisor with any questions.*
