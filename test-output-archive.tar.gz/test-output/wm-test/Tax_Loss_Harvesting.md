# Tax Loss Harvesting Scan & Recommendation

**Client:** J. Robertson | **Date:** May 8, 2026 | **Tax Bracket:** 37% Federal + 5% State

---

## Current Position Summary

| Holding | Cost Basis | Market Value | Unrealized G/L | Holding Period |
|---------|-----------|-------------|----------------|---------------|
| AAPL | $180,000 | $230,000 | +$50,000 | Long-term |
| TSLA | $210,000 | $190,000 | -$20,000 | Long-term |
| META | $200,000 | $185,000 | -$15,000 | Short-term |
| NVDA | $120,000 | $200,000 | +$80,000 | Long-term |
| **Total** | **$710,000** | **$805,000** | **+$95,000** | -- |

---

## Harvesting Opportunities

### Positions to Sell (Capture Losses)

| Position | Loss | Tax Savings (37% + 5%) | Replacement | Replacement Rationale |
|----------|------|----------------------|-------------|----------------------|
| TSLA | -$20,000 | $8,400 | Invesco QQQ (QQQ) | Maintains large-cap tech exposure; diversified across sector |
| META | -$15,000 | $6,300 | Communication Services Select (XLC) | Same sector; captures digital advertising trend without single-name risk |

**Total Tax Savings: $14,700**

---

## Wash Sale Considerations

| Rule | Status |
|------|--------|
| 30-day window before/after sale | Must avoid repurchasing TSLA or META for 31 days |
| Substantially identical securities | Cannot buy META options, TSLA convertible notes |
| Replacement screening | QQQ and XLC are NOT substantially identical -- compliant |
| IRA transactions | Do NOT purchase TSLA or META in IRA during wash sale period |

---

## Strategy Notes

### Loss Application Order
1. **Short-term losses first** (META: -$15K) offset short-term gains taxed at ordinary income rates (37%).
2. **Long-term losses second** (TSLA: -$20K) offset long-term gains taxed at 20%.
3. **Excess losses** can offset up to $3,000 in ordinary income; remainder carries forward.

### After Harvesting
- **Net realized position:** +$95K gains - $35K harvested = +$60K net unrealized gain remaining.
- No immediate capital gains tax due (positions held, not sold).
- Harvested losses create $35K in loss carryforward for future use.

### Recommendations
1. Execute TSLA and META sales immediately; purchase QQQ and XLC replacements same day.
2. Set calendar reminder for June 8, 2026 (31 days) to reassess TSLA and META.
3. Monitor NVDA position for potential harvesting if it drops below cost basis during Q2 volatility.
4. Review total portfolio losses quarterly to capture additional opportunities.
