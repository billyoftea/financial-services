# KYC / AML Risk Assessment Report

**Record ID:** KYC-2026-00421
**Client Name:** John Michael Smith
**Assessment Date:** 2026-05-08
**Assessed By:** Compliance Operations
**Review Type:** Initial Onboarding

---

## Risk Rating Summary

| Dimension | Score | Weight | Weighted Score |
|---|---|---|---|
| Client Type Risk | Low (1) | 20% | 0.20 |
| Geographic Risk | Low (1) | 20% | 0.20 |
| Product / Service Risk | Low (1) | 15% | 0.15 |
| Transaction Risk | Low (1) | 15% | 0.15 |
| Source of Funds Risk | Low (1) | 20% | 0.20 |
| Enhanced Due Diligence Triggers | None (0) | 10% | 0.00 |
| **Composite Risk Score** | | | **0.90 / 5.00** |

**Overall Risk Rating: LOW**
**Recommended Due Diligence Level:** Standard Due Diligence (SDD)

---

## PEP / Sanctions / Adverse Media Checks

### Politically Exposed Persons (PEP) Screening

| Database | Result | Match Type | Status |
|---|---|---|---|
| World-Check (Refinitiv) | No match | -- | Clear |
| Dow Jones Risk & Compliance | No match | -- | Clear |
| Government PEP Lists (US) | No match | -- | Clear |
| PEP-by-Association | No match | -- | Clear |

**PEP Status:** Not a PEP. No PEP associations identified. No family members or close associates found in PEP databases.

### Sanctions Screening

| List | Result | Match Type | Status |
|---|---|---|---|
| OFAC SDN List (US Treasury) | No match | -- | Clear |
| OFAC Sectoral Sanctions | No match | -- | Clear |
| EU Consolidated Sanctions List | No match | -- | Clear |
| UN Security Council Sanctions | No match | -- | Clear |
| UK HMT Sanctions List | No match | -- | Clear |
| DFAT (Australia) | No match | -- | Clear |

**Sanctions Status:** Clear. No matches across all screened lists.

### Adverse Media Screening

| Source | Result | Category | Status |
|---|---|---|---|
| LexisNexis News Database | No adverse media | -- | Clear |
| Google News (90-day lookback) | No adverse media | -- | Clear |
| Court Records (PACER) | No litigation | -- | Clear |
| SEC EDGAR Enforcement | No actions | -- | Clear |
| FINRA BrokerCheck | No disclosures | -- | Clear |

**Adverse Media Status:** Clear. No negative news, enforcement actions, or civil litigation identified.

---

## Rule Outcomes

| Rule ID | Rule Description | Input | Result | Action |
|---|---|---|---|---|
| R-001 | Client age >= 18 | DOB: 1980-05-15 (age 45) | PASS | None |
| R-002 | Valid government ID provided | US Passport + NY License | PASS | None |
| R-003 | ID not expired | Passport exp. 2029; License exp. 2028 | PASS | None |
| R-004 | SSN format valid | XXX-XX-1234 (validated) | PASS | None |
| R-005 | US resident or valid visa | US Citizen, NYC resident | PASS | None |
| R-006 | Income matches investment | $350K income, $500K subscription | PASS | None |
| R-007 | Source of funds documented | Employment income confirmed | PASS | None |
| R-008 | Not on sanctions list | All lists clear | PASS | None |
| R-009 | Not PEP or PEP-associated | All databases clear | PASS | None |
| R-010 | No adverse media | All sources clear | PASS | None |
| R-011 | Employer verification | ABC Corp - active entity (SEC filing) | PASS | None |
| R-012 | Funding source verified | Wire from Chase personal account | PASS | None |
| R-013 | Investment amount within policy | $500K < $1M threshold for EDD | PASS | None |
| R-014 | CIP document requirements met | 2 forms of ID on file | PASS | None |
| R-015 | FATCA status confirmed | US Person, Form W-9 provided | PASS | None |

**Rules Passed: 15 / 15**

---

## Missing Documents / Follow-Up Items

| Item | Required | Status | Due Date |
|---|---|---|---|
| Completed W-9 (Request for Taxpayer ID) | Yes | On file | Complete |
| Signed Subscription Agreement | Yes | On file | Complete |
| Wire Transfer Confirmation | Yes | On file | Complete |
| Proof of Address (utility bill/statement) | Yes | On file | Complete |
| Investment Policy Statement | Optional | Not provided | N/A |
| Secondary ID (non-government) | Optional | Not provided | N/A |

**Missing Required Documents: 0**

---

## Disposition

| Decision | Detail |
|---|---|
| **Recommendation** | Approve - Standard Onboarding |
| **Risk Level** | Low |
| **EDD Required** | No |
| **CDD Review Cycle** | 3 years (standard for low-risk) |
| **Transaction Monitoring** | Standard thresholds apply |
| **Approved By** | Compliance Officer: K. Yamamoto |
| **Approval Date** | 2026-05-08 |

---

## Ongoing Monitoring Parameters

| Parameter | Threshold |
|---|---|
| Monthly Subscription Limit | $250,000 |
| Redemption Alert | Any redemption > $250,000 |
| Velocity Alert | >3 transactions in 30 days |
| Source of Funds Change | Trigger re-review |
| PEP / Sanctions Rescreen | Annual (next due: 2027-05-08) |
| Adverse Media Rescreen | Annual (next due: 2027-05-08) |
