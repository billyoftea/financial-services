# KYC Parsed Record - Structured Data Extraction

**Record ID:** KYC-2026-00421
**Extraction Date:** 2026-05-08
**Source Document:** Individual KYC Application Form (v4.2)
**Parser Version:** OCR Engine 3.1 / NLP Extractor 2.4

---

## Identity Information

| Field | Value | Confidence | Source |
|---|---|---|---|
| Full Legal Name | John Michael Smith | 99.2% | Form Field 1 |
| Known Aliases | None | 100% | Form Field 2 |
| Date of Birth | 1980-05-15 | 98.8% | Government ID |
| Place of Birth | New York, NY, USA | 97.5% | Government ID |
| Citizenship | United States | 99.5% | Passport / Form |
| SSN (masked) | XXX-XX-1234 | 99.1% | Form Field 4 |
| Gender | Male | 99.8% | Government ID |
| Nationality | American | 99.5% | Passport |

---

## Identification Documents

| Document Type | Number | Issuing Authority | Issue Date | Expiry Date | Jurisdiction |
|---|---|---|---|---|---|
| US Passport | XX1234567 | US Dept of State | 2019-03-20 | 2029-03-19 | United States |
| Driver License | NY-8052-1497 | NY DMV | 2021-08-10 | 2028-08-09 | New York |

**Document Verification:** Both documents passed automated authenticity checks. MRZ parsing successful. Photo match score: 96.4%.

---

## Contact Information

| Field | Value |
|---|---|
| Residential Address | 425 Park Avenue, Apt 18B, New York, NY 10022 |
| Mailing Address | Same as residential |
| Phone (Primary) | +1 (212) 555-0147 |
| Phone (Mobile) | +1 (917) 555-0382 |
| Email | j.smith@example.com |
| Country of Residence | United States |
| Country of Tax Residence | United States |
| TIN (Tax) | XX-XX1234 |

---

## Employment & Financial Profile

| Field | Value | Confidence |
|---|---|---|
| Employer | ABC Corp | 98.0% |
| Job Title | Senior Vice President, Corporate Development | 97.5% |
| Industry | Financial Services / Investment Management | 96.0% |
| Employment Status | Full-time (employed since 2015) | 99.0% |
| Annual Income | $350,000 | 95.5% |
| Net Worth (estimated) | $2,500,000 - $5,000,000 | 92.0% |
| Source of Wealth | Employment income, investment returns | 94.0% |
| Liquid Assets | $1,200,000 | 90.5% |

---

## Ownership & Control

| Field | Value |
|---|---|
| Politically Exposed Person (PEP) | No |
| PEP Association | No |
| Senior Foreign Political Figure | No |
| Beneficial Owner Of | N/A (individual account) |
| Acting on Behalf of Third Party | No |
| Power of Attorney Holder | No |
| Trustee / Fiduciary Role | No |

---

## Source of Funds

| Field | Value |
|---|---|
| Primary Source | Employment salary and bonus |
| Secondary Source | Dividend and interest income from personal portfolio |
| Investment Amount | $500,000 initial subscription |
| Funding Method | Wire transfer from personal bank account (Chase, acct ending 4471) |
| Purpose of Account | Long-term investment; capital appreciation |

---

## Account Details

| Field | Value |
|---|---|
| Account Type | Individual Investor |
| Risk Profile | Moderate Growth |
| Intended Investment Period | 5+ years |
| Expected Transaction Frequency | Quarterly subscriptions, annual redemptions |
| Relationship Manager | Sarah Thompson |

---

## Extraction Quality Summary

| Metric | Score |
|---|---|
| Overall Confidence | 97.3% |
| Fields Extracted | 38 / 40 (95%) |
| Fields Requiring Manual Review | 2 (net worth range, liquid assets) |
| OCR Read Errors | 0 |
| Handwritten Fields | 1 (signature block - not parsed) |
| Missing Fields | 0 required; 2 optional (LinkedIn, secondary email) |
