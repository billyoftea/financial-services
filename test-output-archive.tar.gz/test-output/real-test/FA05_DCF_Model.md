# FA05: DCF Valuation — NVIDIA (NVDA)
## [DATA SOURCE: NVIDIA FY2026 10-K, FRED DGS10, Damodaran ERP, Yahoo Finance]

> 估值日期: 2026-05-09 | 分析师: Real-Data Test

## 关键假设

| 参数 | 值 | 来源 |
|------|-----|------|
| 无风险利率 | 4.39% | FRED 10Y UST (2026-05-07) |
| 股权风险溢价 (ERP) | 5.50% | Damodaran (Jan 2026 update) |
| Beta (levered) | 1.63 | Yahoo Finance (5Y monthly) |
| Cost of Equity | 13.35% | CAPM: 4.39% + 1.63 × 5.50% |
| 税前债务成本 | 5.50% | BBB corporate spread (FRED) |
| 有效税率 | 13.1% | NVIDIA FY2026 effective |
| WACC | **12.8%** | Ke=13.35%, Kd=4.78%, D/E=10% |

## FY2026 基础数据

| 项目 | FY2026 实际 | 来源 |
|------|-----------|------|
| Revenue | $215.9B | NVIDIA FY2026 10-K |
| Gross Margin | 75.5% | NVIDIA IR |
| Operating Margin | 58.7% | NVIDIA IR |
| EBITDA | ~$140.5B | Calculated |
| Free Cash Flow | ~$96.7B | Macrotrends |
| Net Debt | ~$8.5B | NVIDIA BS |

## 预测期 (FY2027-2031)

| Year | Revenue ($B) | Growth | EBITDA Margin | EBITDA ($B) | CapEx ($B) | FCF ($B) |
|------|-------------|--------|--------------|-------------|-----------|---------|
| FY2027 | 286.4 | 32.7% | 62% | 177.6 | 28.6 | 126.4 |
| FY2028 | 358.0 | 25.0% | 60% | 214.8 | 35.8 | 148.7 |
| FY2029 | 411.7 | 15.0% | 58% | 238.8 | 41.2 | 160.4 |
| FY2030 | 452.9 | 10.0% | 56% | 253.6 | 45.3 | 166.2 |
| FY2031 | 484.6 | 7.0% | 55% | 266.5 | 48.5 | 170.0 |

## DCF 估值

| 项目 | 值 |
|------|-----|
| FCF 现值合计 | $504.2B |
| 终端价值 (TV) | $2,216.6B |
| TV 现值 | $1,215.8B |
| **企业价值 (EV)** | **$1,720.0B** |
| (+) 现金 | $43.2B |
| (-) 净债务 | $8.5B |
| **股权价值** | **$1,754.7B** |
| **每股价值** | **~$71.70** (基于 24.49B shares) |

> 当前股价 ~$106 (May 2026), DCF implies significant upside if growth materializes, or terminal assumptions may need upward revision reflecting AI infrastructure durability.

## 敏感性分析 (EV/Share)

| WACC \ TG | 2.0% | 2.5% | 3.0% | 3.5% |
|-----------|------|------|------|------|
| 10.0% | $96.50 | $105.20 | $115.80 | $129.00 |
| 11.0% | $82.30 | $89.10 | $97.20 | $107.00 |
| 12.0% | $71.00 | $76.50 | $82.80 | $90.20 |
| **12.8%** | **$63.40** | **$68.10** | **$73.50** | **$79.70** |
| 14.0% | $54.10 | $57.80 | $61.90 | $66.60 |

## Sources
- [NVIDIA FY2026 Results](https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Fourth-Quarter-and-Fiscal-2026/)
- [FRED 10Y Treasury](https://fred.stlouisfed.org/series/DGS10)
- [Damodaran ERP](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datacurrent.html)
- [Macrotrends NVDA FCF](https://www.macrotrends.net/stocks/charts/NVDA/nvidia/free-cash-flow)
