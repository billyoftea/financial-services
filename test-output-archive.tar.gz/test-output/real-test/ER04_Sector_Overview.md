# ER04: AI/ML Sector Overview
## [DATA SOURCE: Gartner, IDC, Statista, company filings — May 2026]

> 报告日期: 2026-05-09

## 市场规模与增长

| 层级 | 2024 | 2026E | 2028E | 2030E | CAGR |
|------|------|-------|-------|-------|------|
| Infrastructure | $120B | $210B | $350B | $520B | 34% |
| Models/Platforms | $45B | $95B | $180B | $310B | 47% |
| Applications | $80B | $165B | $320B | $540B | 46% |
| **Total AI Market** | **$245B** | **$470B** | **$850B** | **$1,370B** | **41%** |

Source: Gartner, IDC, Statista 综合估算

## 三层架构

### Layer 1: Infrastructure (基础设施)

| 公司 | 收入 ($B) | 份额 | 关键产品 | 增长 |
|------|----------|------|---------|------|
| NVIDIA | ~$186B (DC) | ~65% | H100/B200 GPU | +93% |
| Broadcom | ~$35B (custom) | ~12% | Custom ASIC (TPU) | +25% |
| AMD | ~$12B (DC GPU) | ~4% | MI300X | +50% |
| TSMC | ~$90B (代工) | 关键供应商 | CoWoS封装 | +35% |

### Layer 2: Models/Platforms (模型/平台)

| 公司 | 模型/平台 | 收入 ($B) | 竞争力 |
|------|---------|----------|--------|
| OpenAI | GPT-5/o3 | ~$10B (est) | 领先通用模型 |
| Google | Gemini 2.0 | ~$8B (Cloud AI) | 垂直整合优势 |
| Anthropic | Claude 4 | ~$3B (est) | 安全/企业定位 |
| Meta | Llama 4 | 开源 | 生态战略 |
| Microsoft | Azure OpenAI | ~$25B (Azure AI) | 分发优势 |

### Layer 3: Applications (应用)

| 公司 | 应用场景 | 收入 ($B) | 增长 |
|------|---------|----------|------|
| Salesforce | CRM AgentForce | ~$38B | +8% |
| ServiceNow | IT AI workflow | ~$12B | +22% |
| Palantir | Gov/Enterprise AI | ~$3.5B | +95% |
| CrowdStrike | AI Security | ~$4.2B | +33% |
| Databricks | Data+AI platform | ~$3B (private) | +40% |

## 竞争格局

### Infrastructure 层: NVIDIA 主导
- GPU 市场份额 >80%
- CUDA 生态护城河 (600万+ 开发者)
- 竞争来自: Google TPU, AMD MI400, Amazon Trainium

### Models 层: 寡头竞争
- Top 5 模型公司占 >70% 市场
- 开源 vs 闭源分歧持续
- 定价快速下降 (GPT-4 级别模型 token成本下降 90%+)

### Applications 层: 分散竞争
- 垂直领域应用机会最多
- AI Agent 是 2026 年核心主题
- 传统 SaaS 公司转型 AI-first

## 关键趋势

1. **推理成本下降** → AI 应用大规模普及
2. **AI Agent** → 从辅助到自主执行
3. **Edge AI** → 端侧部署加速
4. **Multimodal** → 文本/图像/视频/音频融合
5. **Regulation** → EU AI Act 执行，美国监管框架成形

## Sources
- [Gartner AI Market Forecast](https://www.gartner.com/en/information-technology)
- [IDC AI Tracker](https://www.idc.com/)
- [Statista AI Market](https://www.statista.com/topics/3104/artificial-intelligence-ai-worldwide/)
- Company 10-K/10-Q filings
