# FA16: WACC Calculator — NVIDIA (NVDA)
## [DATA SOURCE: FRED DGS10, Damodaran ERP, Yahoo Finance beta, NVIDIA FY2026]

> 计算日期: 2026-05-09

## Cost of Equity (Ke)

### CAPM 计算

| 参数 | 值 | 来源 |
|------|-----|------|
| Risk-free Rate (Rf) | 4.39% | FRED 10Y UST (2026-05-07) |
| Equity Risk Premium (ERP) | 5.50% | Damodaran (Jan 2026) |
| Levered Beta (β) | 1.63 | Yahoo Finance (5Y monthly) |
| **Cost of Equity** | **13.35%** | Rf + β × ERP |

### Beta 验证

| 方法 | Beta | 来源 |
|------|------|------|
| Yahoo Finance (5Y monthly) | 1.63 | Regression vs S&P 500 |
| Reuters (2W weekly) | 1.55 | Refinitiv |
| Bloomberg (RAW) | 1.71 | Bloomberg Terminal |
| **采用值** | **1.63** | Yahoo Finance |

### Size Premium

| 因素 | 调整 | 说明 |
|------|------|------|
| Size Premium | 0.0% | NVDA 为 mega-cap (> $1T), 无需调整 |
| Alpha (specific risk) | 0.0% | 无特殊公司特定风险 |

## Cost of Debt (Kd)

| 参数 | 值 | 来源 |
|------|-----|------|
| Risk-free Rate | 4.39% | FRED |
| Credit Spread (A+ rated) | 110 bp | Bloomberg |
| Pre-tax Cost of Debt | 5.49% | |
| Effective Tax Rate | 13.1% | NVIDIA FY2026 |
| **After-tax Cost of Debt** | **4.77%** | 5.49% × (1 - 13.1%) |

## Capital Structure

| 组成 | 市值 ($B) | 权重 |
|------|----------|------|
| Equity (Market Cap) | 2,610.0 | 99.7% |
| Net Debt | 8.5 | 0.3% |
| **Total Capital** | **2,618.5** | **100%** |

> NVDA 几乎全股权融资，债务权重极低。

## WACC 计算

```
WACC = (E/V) × Ke + (D/V) × Kd × (1-T)

WACC = 99.7% × 13.35% + 0.3% × 5.49% × (1 - 13.1%)
WACC = 13.31% + 0.01%
WACC = 13.32%
```

## WACC 敏感性 (Ke vs Capital Structure)

| E/V \ Ke | 11.0% | 12.0% | 13.35% | 14.0% | 15.0% |
|----------|-------|-------|--------|-------|-------|
| 95% E | 10.6% | 11.5% | 12.8% | 13.4% | 14.4% |
| 97% E | 10.8% | 11.7% | 13.1% | 13.7% | 14.7% |
| 99% E | 10.9% | 11.9% | 13.3% | 13.9% | 15.0% |
| **99.7% E** | **11.0%** | **12.0%** | **13.3%** | **14.0%** | **15.0%** |
| 100% E | 11.0% | 12.0% | 13.4% | 14.0% | 15.0% |

## 最终 WACC

| 指标 | 值 |
|------|-----|
| **WACC** | **13.3%** |
| 对 DCF 估值的影响 | 每1% WACC变化 → NVDA股价变化约$15-20 |

## Sources
- [FRED 10Y Treasury (DGS10)](https://fred.stlouisfed.org/series/DGS10)
- [Damodaran ERP (Jan 2026)](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datacurrent.html)
- [Yahoo Finance NVDA](https://finance.yahoo.com/quote/NVDA/)
- NVIDIA FY2026 10-K (tax rate, capital structure)
