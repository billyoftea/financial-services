[DATA SOURCE: CrowdStrike FY2026 IR (ir.crowdstrike.com), Palo Alto Networks FY2025 IR (paloaltonetworks.com), Zscaler FY2025 IR (ir.zscaler.com), Fortinet FY2025 IR (investor.fortinet.com), Datadog FY2025 IR (investors.datadoghq.com), Yahoo Finance, S&P Global Market Intelligence, Macrotrends]

# Deal Screening -- SaaS Cybersecurity Targets
## Investment Criteria: $100-500M Revenue | 20%+ Growth | 30%+ EBITDA Margin | $500M-$3B EV

**Screening Date:** May 9, 2026
**Fund:** Growth Equity Fund IV

---

## 1. Screening Criteria

| Criterion | Minimum | Target |
|-----------|---------|--------|
| Revenue (LTM) | $100M | $200-400M |
| Revenue Growth (YoY) | 20% | 25%+ |
| EBITDA Margin | 30% | 35%+ |
| Enterprise Value | $500M | $1-2.5B |
| Net Revenue Retention | 110% | 120%+ |
| Gross Margin | 70% | 80%+ |
| Rule of 40 | 40% | 55%+ |
| FCF Margin | 10% | 20%+ |

---

## 2. Public Market Comparable Screening

### CrowdStrike Holdings (CRWD)

| Metric | Value | Source |
|--------|-------|--------|
| TTM Revenue | ~$4.81B | CrowdStrike FY2026 IR |
| Revenue Growth (YoY) | ~22% | FY2026 results |
| ARR | $5.25B (+24% YoY) | FY2026 Q4 |
| Non-GAAP Subscription Gross Margin | ~80% | FY2025/FY2026 |
| GAAP Operating Margin | -2.6% | FY2026 (heavy SBC) |
| Non-GAAP Operating Margin | ~28% | FY2026 Q4 |
| Free Cash Flow | ~$1.24B | FY2026 |
| Net New ARR (FY2026) | $1.01B | FY2026 |
| Market Cap | ~$95B | Yahoo Finance (May 2026) |
| EV/Revenue | ~22x | Calculated |
| EV/EBITDA | ~75x (GAAP) | Calculated |

**Screen Result: FAILS SIZE FILTER.** Revenue at $4.8B is well above $500M target. Too large for Fund IV mandate. However, useful as public comp and potential strategic acquirer for portfolio companies.

---

### Palo Alto Networks (PANW)

| Metric | Value | Source |
|--------|-------|--------|
| FY2025 Revenue | $9.2B | PANW FY2025 Press Release |
| Revenue Growth (YoY) | 15% | FY2025 |
| GAAP Operating Margin | ~17.3% | FY2025 |
| Non-GAAP Operating Margin | ~28.8% | FY2025 Q4 |
| FCF Margin | ~38% | FY2025 (3rd consecutive year) |
| Market Cap | ~$125B | Yahoo Finance (May 2026) |
| EV/Revenue | ~14x | Calculated |

**Screen Result: FAILS SIZE FILTER.** Revenue at $9.2B is far above target range. Platform consolidator -- potential exit partner for mid-market cybersecurity assets.

---

### Zscaler (ZS)

| Metric | Value | Source |
|--------|-------|--------|
| FY2025 Revenue | $2,673M (+23% YoY) | Zscaler FY2025 IR |
| Q4 CY2025 Revenue | $815.8M (+25.9% YoY) | Yahoo Finance |
| GAAP Operating Margin | -4% (Q4 FY2025) | FY2025 Q4 |
| Calculated Billings Growth | +25% YoY | FY2025 Q3 |
| Market Cap | ~$30B | Yahoo Finance (May 2026) |
| EV/Revenue | ~10x | Calculated |

**Screen Result: FAILS SIZE FILTER.** Revenue at $2.7B exceeds target. GAAP operating margin still negative. SSE/SASE leader, potential acquirer of smaller security assets.

---

### Fortinet (FTNT)

| Metric | Value | Source |
|--------|-------|--------|
| FY2025 Revenue | ~$6.3B | Fortinet FY2025 IR |
| Q4 Revenue Growth | +15% YoY | FY2025 Q4 |
| Operating Margin | 35.5% | FY2025 |
| EBITDA (TTM) | ~$2,347M | ValueSense |
| Gross Margin | 80.5% | FY2025 |
| Free Cash Flow | $2.21B (37% margin) | FY2025 |
| Market Cap | ~$73B | Yahoo Finance (May 2026) |
| EV/Revenue | ~12x | Calculated |
| EV/EBITDA | ~31x | Calculated |

**Screen Result: FAILS SIZE FILTER.** Revenue at $6.3B is well above range. However, **industry-leading operating margin of 35.5%** and 80.5% gross margin represent best-in-class benchmarks for PE portfolio targets. Also the most profitable pure-play cybersecurity company.

---

### Datadog (DDOG)

| Metric | Value | Source |
|--------|-------|--------|
| FY2025 Revenue | $3,427M (+27.7% YoY) | Datadog FY2025 IR |
| Q4 Revenue Growth | +29% YoY | FY2025 Q4 |
| Non-GAAP Operating Margin | 22-23% | FY2025 Q4 |
| GAAP Operating Margin | ~1% (FY2025), ~4% TTM | CompaniesMarketCap |
| Q1 FY2026 Revenue Guidance | $951-961M (+25-26% YoY) | FY2025 Q4 Release |
| Market Cap | ~$42B | Yahoo Finance (May 2026) |
| EV/Revenue | ~12x | Calculated |

**Screen Result: FAILS SIZE FILTER.** Revenue at $3.4B exceeds range. Observability/monitoring market leader expanding into security. AI and security pivots cited as key growth catalysts for 2026.

---

## 3. Screening Summary

| Company | Ticker | Rev ($B) | Growth | EBITDA Margin | EV ($B) | Pass? |
|---------|--------|----------|--------|----------------|---------|-------|
| CrowdStrike | CRWD | 4.8 | 22% | ~28% non-GAAP | ~105 | NO (too large) |
| Palo Alto Networks | PANW | 9.2 | 15% | ~29% non-GAAP | ~130 | NO (too large) |
| Zscaler | ZS | 2.7 | 23% | Negative GAAP | ~32 | NO (too large) |
| Fortinet | FTNT | 6.3 | 14% | 35.5% | ~75 | NO (too large) |
| Datadog | DDOG | 3.4 | 28% | 22-23% non-GAAP | ~42 | NO (too large) |

**Conclusion:** All five screened public cybersecurity/observability companies significantly exceed the $100-500M revenue target range. This confirms the **mid-market cybersecurity segment is highly fragmented** with 3,500+ vendors, creating attractive PE roll-up opportunities at smaller scale ($100-400M revenue) where entry multiples of 12-18x EBITDA are achievable versus 20-75x for the large-caps.

---

## 4. Key Takeaways for PE Targeting

1. **Public comps set ceiling pricing**: Large-cap cybersecurity trades at 10-22x EV/Revenue, establishing valuation benchmarks
2. **Mid-market opportunity**: Companies at $100-400M revenue with 20%+ growth can be acquired at 6-10x EV/Revenue (40-60% discount to publics)
3. **Best-in-class margin benchmark**: Fortinet's 35.5% operating margin and 80.5% gross margin set the target for portfolio companies
4. **Growth rates decelerating at scale**: All five companies show growth deceleration as they scale, reinforcing the value of acquiring at $200-400M with 25%+ growth
5. **Platform consolidation thesis validated**: CrowdStrike ($5.25B ARR) and PANW ($9.2B revenue) are actively consolidating, creating both competitive risk and exit opportunities

---

## Sources

- CrowdStrike FY2026 Results (ir.crowdstrike.com) -- Revenue ~$4.81B, ARR $5.25B, FCF ~$1.24B
- Palo Alto Networks FY2025 Results (paloaltonetworks.com) -- Revenue $9.2B (+15%), FCF margin 38%
- Zscaler FY2025 Results (ir.zscaler.com) -- Revenue $2,673M (+23% YoY)
- Fortinet FY2025 Results (investor.fortinet.com) -- Revenue ~$6.3B, operating margin 35.5%, FCF $2.21B
- Datadog FY2025 Results (investors.datadoghq.com) -- Revenue $3,427M (+27.7%), non-GAAP op margin 22-23%
- Yahoo Finance: Current market capitalizations and trading data (May 2026)
- Macrotrends: Historical EBITDA and operating margins (macrotrends.net)
- ValueSense: Fortinet EBITDA data (valuesense.io)
- CompaniesMarketCap: Datadog operating margin data (companiesmarketcap.com)
