# FA10: Credit Analysis — NVIDIA (NVDA)
## [DATA SOURCE: NVIDIA FY2026 Balance Sheet, FRED corporate bond rates]

> 分析日期: 2026-05-09

## 资本结构

| 项目 | 金额 ($B) | 占比 |
|------|----------|------|
| 短期债务 | 0.0 | 0% |
| 长期债务 | 8.5 | 16.4% |
| 现金及等价物 | 43.2 | 83.6% |
| **净现金** | **(34.7)** | — |
| 总资产 | 86.7 | — |
| 股东权益 | 56.9 | — |

## 关键信用指标

| 指标 | NVDA | 投资级阈值 | 评估 |
|------|------|-----------|------|
| Net Debt / EBITDA | -0.25x | <2.0x (A) | 远优于AAA |
| Gross Debt / EBITDA | 0.06x | <1.5x (AA) | 远优于AAA |
| EBITDA / Interest | 234.2x | >8.0x (A) | 远优于AAA |
| FCF / Total Debt | 11.4x | >0.30x (A) | 远优于AAA |
| Net Debt / (EBITDA-CapEx) | -0.39x | <2.5x (A) | 远优于AAA |
| Current Ratio | 4.42x | >1.5x | 优秀 |

## 现金流覆盖

| 指标 | FY2024A | FY2025A | FY2026A |
|------|---------|---------|---------|
| Operating Cash Flow | $29.1B | $60.9B | $96.7B |
| CapEx | ($7.6B) | ($12.5B) | ($15.2B) |
| Free Cash Flow | $21.5B | $48.4B | $81.5B |
| FCF/Debt | 2.5x | 5.7x | 9.6x |

## 信用评级参考

| 评级机构 | NVDA 评级 | 展望 | 日期 |
|---------|----------|------|------|
| S&P | A+ | Positive | 2025 |
| Moody's | A1 | Stable | 2025 |
| Fitch | A+ | Stable | 2025 |

> NVDA 拥有净现金位置，是少数几家净现金为正的大型科技公司之一。信用指标远优于同业。

## 同业对比

| 公司 | 净债务/EBITDA | 评级 |
|------|-------------|------|
| NVDA | (0.25x) | A+/A1 |
| AAPL | 1.8x | AA+/Aa1 |
| MSFT | 0.4x | AAA/Aaa |
| INTC | 2.8x | BBB+/Baa1 |

## Sources
- NVIDIA FY2026 Balance Sheet
- [FRED BBB Corporate Bond Rate](https://fred.stlouisfed.org/series/BAMLC0A4CBBB)
- S&P Global Ratings, Moody's Investors Service
