[DATA SOURCE: Bain & Company "Global Private Equity Report 2026" (bain.com), McKinsey "Global Private Markets Report 2026" (mckinsey.com), Cherry Bekaert "PE Report 2025 Trends and 2026 Outlook" (cbh.com), Alvarez & Marsal "Software/Tech PE Outlook 2026" (alvarezandmarsal.com)]

# Value Creation Plan -- 3-Year Horizon
## CloudPeak Technologies (Cloud Management Platform)

**Date:** May 9, 2026
**Investment Period:** 2026-2029 (3-year hold)
**Current Investment:** $150M (35% equity stake, $429M implied EV)

---

## 1. Executive Summary

This value creation plan targets a **2.8-3.5x MOIC** over a 3-year hold period, generating returns through three pillars: (1) Revenue Growth, (2) Margin Improvement, and (3) Multiple Expansion. Consistent with Bain's 2026 finding that PE value creation must now come from genuine EBITDA growth (10-12% annually) rather than multiple expansion, this plan weights operational improvement at 65% of total value creation.

**Industry Context:** Bain's Global PE Report 2026 declares "12 is the new 5" -- deals now require ~10-12% annual EBITDA growth for a 2.5x MOIC, a dramatic shift from the ~5% required in prior years. The era of relying on multiple expansion and falling interest rates is over. Total unsold portfolio value sits at $3.8 trillion globally, increasing pressure on GPs to demonstrate genuine operational improvement.

---

## 2. Value Creation Target Summary

| Metric | Current (Q1 2026) | Target (Q1 2029) | Improvement |
|--------|-------------------|-------------------|-------------|
| Revenue | $143M (annualized) | $290M | +103% (21% CAGR) |
| EBITDA | $34M | $116M | +241% (35% CAGR) |
| EBITDA Margin | 24% | 40% | +1,600bps |
| Enterprise Value (est.) | $429M | $1,450M | +238% |
| Net Debt | $120M | $50M | -58% |
| Equity Value (est.) | $309M | $1,400M | +353% |
| **MOIC** | -- | **3.0x** | -- |
| **IRR** | -- | **45%** | -- |

---

## 3. Three Pillars of Value Creation

### Pillar 1: Revenue Growth (Target: +55% of total value creation)

#### 3.1.1 Organic Growth Initiatives

| Initiative | Rev Impact by Year 3 | Investment Required | Timeline |
|-----------|----------------------|---------------------|----------|
| **New market expansion** (EMEA and APAC) | +$45M ARR | $8M (sales team + offices) | 12-24 months |
| **Product expansion** (AI-powered cloud cost optimization) | +$35M ARR | $5M (R&D) | 6-18 months |
| **Upsell motion** (enterprise tier for existing mid-market) | +$25M ARR | $3M (sales enablement) | 6-12 months |
| **Partner channel development** (AWS, Azure marketplace) | +$20M ARR | $2M (partner team) | 12-24 months |
| **Usage-based pricing** (metered billing for compute) | +$15M ARR | $2M (billing infra) | 12-18 months |
| **Total Organic Growth** | **+$140M ARR** | **$20M** | |

#### 3.1.2 Inorganic Growth (M&A)

| Target Profile | Size | Est. Cost | EBITDA Impact | Timeline |
|---------------|------|-----------|---------------|----------|
| Cloud security monitoring bolt-on | $30M revenue | $80-100M | $5M EBITDA | Year 1 |
| FinOps / cloud cost management tool | $20M revenue | $60-80M | $4M EBITDA | Year 2 |
| **Total M&A** | **$50M revenue** | **$140-180M** | **$9M EBITDA** | |

### Pillar 2: Margin Improvement (Target: +30% of total value creation)

#### 3.2.1 Operational Efficiency Initiatives

| Initiative | EBITDA Impact | Investment | Timeline |
|-----------|--------------|------------|----------|
| **Sales force optimization** (quota capacity planning, territory redesign) | +$8M (S&M efficiency) | $1.5M | 6 months |
| **R&D efficiency** (AI-assisted development, offshore team for QA) | +$6M (R&D leverage) | $2.0M | 12 months |
| **Cloud infrastructure cost reduction** (reserved instances, spot optimization) | +$4M (COGS reduction) | $0.5M | 3 months |
| **G&A automation** (ERP consolidation, AI-powered finance) | +$3M (G&A reduction) | $1.0M | 12 months |
| **Customer success automation** (AI health scoring, churn prediction) | +$5M (reduced churn cost) | $1.5M | 9 months |
| **Procurement optimization** (vendor consolidation, negotiation) | +$2M (COGS reduction) | $0.3M | 3 months |
| **Total Margin Improvement** | **+$28M EBITDA** | **$6.8M** | |

#### 3.2.2 Margin Bridge

| Period | Gross Margin | S&M % Rev | R&D % Rev | G&A % Rev | EBITDA Margin |
|--------|-------------|-----------|-----------|-----------|---------------|
| Q1 2026 (Current) | 82% | 38% | 18% | 8% | 24% |
| Q1 2027 (Target) | 83% | 35% | 16% | 7% | 30% |
| Q1 2028 (Target) | 84% | 31% | 15% | 6% | 36% |
| Q1 2029 (Target) | 85% | 27% | 14% | 5% | 40% |

### Pillar 3: Multiple Expansion (Target: +15% of total value creation)

#### 3.3.1 Strategic Repositioning Initiatives

| Initiative | Multiple Impact | Action | Timeline |
|-----------|----------------|--------|----------|
| **Reposition as AI-native platform** | +1-2x EV/Revenue turns | Launch AI-powered product suite; rebrand as AI-first cloud management | 12-18 months |
| **Achieve "Rule of 40" leadership** | +0.5-1x EV/Revenue turns | Grow revenue 21% CAGR while expanding margins to 40% (combined 61% Rule of 40) | 24-36 months |
| **Build strategic acquirer optionality** | +1-2x EV/Revenue turns | Develop integration partnerships with ServiceNow, Datadog, CrowdStrike for potential exit | Ongoing |
| **Establish category leadership** | +0.5-1x EV/Revenue turns | Commission analyst coverage (Gartner Magic Quadrant, Forrester Wave) | 12 months |
| **Demonstrate AI revenue line** | +1-2x EV/Revenue turns | Report AI-specific revenue as separate metric (>15% of total by exit) | 18-24 months |

#### 3.3.2 Exit Multiple Scenarios

| Scenario | Exit EV/Revenue | Exit EV/EBITDA | Exit EV ($M) | MOIC |
|----------|----------------|----------------|-------------|------|
| Bear (no expansion) | 5.0x | 12.5x | 1,160 | 2.5x |
| Base (modest expansion) | 5.5x | 14.0x | 1,450 | 3.0x |
| Bull (strategic premium) | 6.5x | 16.3x | 1,740 | 3.5x |

---

## 4. Value Creation Bridge (Base Case)

| Value Driver | EBITDA Contribution | EV Contribution ($M) | % of Value Creation |
|-------------|--------------------|-----------------------|---------------------|
| **Revenue Growth (organic)** | +$42M EBITDA | +$580M | 35% |
| **Revenue Growth (M&A)** | +$9M EBITDA | +$126M | 10% |
| **Margin Improvement** | +$28M EBITDA | +$392M | 30% |
| **Multiple Expansion** | +0.5x EV/Revenue | +$145M | 10% |
| **Deleveraging** | Net debt reduction $70M | +$70M | 5% |
| **Cash Flow Build** | FCF reinvestment | +$80M | 10% |
| **Total** | EBITDA $34M to $116M | +$1,393M | 100% |

---

## 5. Detailed Financial Projections

| ($M) | Q1 2026 | Q1 2027 | Q1 2028 | Q1 2029 |
|------|---------|---------|---------|---------|
| **Revenue** | 143 | 185 | 237 | 290 |
| Revenue Growth (YoY) | 25% | 29% | 28% | 22% |
| **EBITDA** | 34 | 56 | 85 | 116 |
| EBITDA Margin | 24% | 30% | 36% | 40% |
| **Capex** | (14) | (17) | (19) | (20) |
| **Free Cash Flow** | 12 | 25 | 47 | 70 |
| FCF Margin | 8.4% | 13.5% | 19.8% | 24.1% |
| **Net Debt** | 120 | 95 | 72 | 50 |
| **Enterprise Value** | 429 | 830 | 1,160 | 1,450 |
| **Equity Value** | 309 | 735 | 1,088 | 1,400 |

---

## 6. Governance and Monitoring

### Monthly KPI Dashboard

| KPI | Current | Year 1 Target | Year 2 Target | Year 3 Target |
|-----|---------|---------------|---------------|---------------|
| ARR Growth | 25% | 29% | 28% | 22% |
| Net Revenue Retention | 118% | 122% | 125% | 125%+ |
| EBITDA Margin | 24% | 30% | 36% | 40% |
| FCF Conversion | 35% | 45% | 55% | 60% |
| LTV/CAC | 3.8x | 4.2x | 4.5x | 5.0x |
| CAC Payback (months) | 16 | 14 | 12 | 11 |
| Gross Margin | 82% | 83% | 84% | 85% |
| Rule of 40 | 43% | 59% | 64% | 62% |

### Board Reporting Cadence

| Meeting Type | Frequency | Participants | Key Agenda |
|-------------|-----------|-------------|------------|
| Board Meeting | Quarterly | Board, CEO, CFO | Full financial review, strategy update |
| Operating Committee | Monthly | Operating Partner, CEO, functional leads | KPI review, initiative tracking |
| Value Creation Workshop | Bi-annual | Deal team, operating partners, management | Strategic review, course correction |

---

## 7. Risk Factors

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| Revenue growth deceleration below 15% | Medium | High | Diversify revenue streams; accelerate M&A |
| Margin improvement slower than planned | Medium | Medium | Phase implementation; bring in external operations expertise |
| M&A integration challenges | High | Medium | Dedicated integration team; conservative deal structure |
| Competitive pressure from hyperscalers | High | High | Differentiate in multi-cloud management; vertical specialization |
| Talent market tightness | Medium | Medium | Competitive compensation; acqui-hire strategy |
| AI investment not translating to revenue | Medium | Medium | Stage-gate AI product development; customer validation before scaling |

---

## Sources

- Bain & Company: "Global Private Equity Report 2026" (bain.com) -- "12 is the new 5"; 10-12% annual EBITDA growth needed for 2.5x MOIC; $3.8T unsold portfolio value; multiple expansion era over
- McKinsey: "Global Private Markets Report 2026" (mckinsey.com) -- Median PE purchase multiple 11.8x EBITDA; buyout deal value $904B (+44% YoY)
- Cherry Bekaert: "Private Equity Report 2025 Trends and 2026 Outlook" (cbh.com) -- Cybersecurity and enterprise software saw meaningful PE deal flow
- Alvarez & Marsal: "Software/Tech PE Outlook 2026" (alvarezandmarsal.com) -- AI captured 2/3 of VC deal value in 2025; AI premium effect on multiples
- QuantPillar: "2025-2026 Private Market Valuation Multiples" (quantpillar.com) -- EV/EBITDA and EV/Revenue multiples across B2B SaaS sectors
- IB Interview Questions: "Current M&A Multiples Across Sectors 2025-2026" (ibinterviewquestions.com) -- Business services PE platform deals at 20-23x EBITDA
