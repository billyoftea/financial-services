[DATA SOURCE: Deloitte DD Framework (deloitte.com/nl), PwC Acquisitions DD Guide (pwc.com), Apex Leaders PE DD Best Practices (apexleaders.com), Affinity PE DD Checklist (affinity.co), NMS Consulting DD Checklist (nmsconsulting.com), McKinsey Global Private Markets Report 2026, Bain Global PE Report 2026]

# Private Equity Due Diligence Checklist
## $2B Enterprise Software Acquisition
### Prepared: May 2026

---

## Executive Summary

This due diligence checklist covers **84 discrete items** across seven workstreams for the proposed $2B acquisition of an enterprise software target. Aligned with industry-standard PE DD frameworks (Deloitte, PwC) and updated for 2026 market conditions including AI readiness, ESG compliance, and cybersecurity posture.

Reference: Median PE purchase multiple reached **11.8x EBITDA in 2025** (McKinsey Global Private Markets Report 2026), up from 11.3x in 2024. Enterprise software platform deals have commanded **20-23x EBITDA** (IB Interview Questions, 2026 M&A Multiples Guide). Global buyout deal value increased **44% in 2025 to $904B**, the second-highest year on record (McKinsey).

---

## 1. Financial Due Diligence (14 Items)

| # | Item | Priority | Status |
|---|------|----------|--------|
| 1.1 | Quality of Earnings analysis (adjusted EBITDA bridge) | Critical | |
| 1.2 | Revenue sustainability: recurring vs. non-recurring split, ARR trends | Critical | |
| 1.3 | Customer concentration analysis (top 10 customers as % of revenue) | Critical | |
| 1.4 | Revenue churn and net revenue retention rate analysis | Critical | |
| 1.5 | Working capital normalization and seasonal trends | High | |
| 1.6 | Capex requirements (maintenance vs. growth capex) | High | |
| 1.7 | Debt-like items: deferred revenue, unfunded pension, operating leases | High | |
| 1.8 | Cash flow quality: operating cash flow vs. net income reconciliation | Critical | |
| 1.9 | Historical and projected gross margin trajectory | High | |
| 1.10 | Revenue recognition policies (ASC 606 compliance) | Medium | |
| 1.11 | Management compensation and add-back adjustments | Medium | |
| 1.12 | Accounts receivable aging and DSO trends | Medium | |
| 1.13 | Deferred revenue composition and renewal rates | High | |
| 1.14 | Budget vs. actuals analysis (3-year historical) | Medium | |

## 2. Commercial Due Diligence (13 Items)

| # | Item | Priority | Status |
|---|------|----------|--------|
| 2.1 | Total addressable market (TAM) sizing and growth rate | Critical | |
| 2.2 | Competitive landscape mapping and win/loss analysis | Critical | |
| 2.3 | Customer reference calls (min. 15-20 accounts across segments) | Critical | |
| 2.4 | Sales pipeline quality and conversion rate analysis | High | |
| 2.5 | Pricing power and contract structure assessment | High | |
| 2.6 | Channel partner ecosystem evaluation | Medium | |
| 2.7 | Switching costs and customer stickiness assessment | High | |
| 2.8 | Product roadmap feasibility and R&D investment adequacy | High | |
| 2.9 | Market positioning relative to AI-native competitors | Critical | |
| 2.10 | Customer acquisition cost (CAC) and lifetime value (LTV) analysis | High | |
| 2.11 | Geographic revenue mix and international expansion potential | Medium | |
| 2.12 | Up-sell and cross-sell penetration rates | Medium | |
| 2.13 | Analyst reports and third-party market validation | Medium | |

## 3. Technology Due Diligence (12 Items)

| # | Item | Priority | Status |
|---|------|----------|--------|
| 3.1 | Software architecture review (monolith vs. microservices, cloud-native) | Critical | |
| 3.2 | Code quality assessment: technical debt, code coverage, testing practices | High | |
| 3.3 | Scalability and performance benchmarks | High | |
| 3.4 | Security posture: SOC 2 Type II, penetration testing results, vulnerability assessment | Critical | |
| 3.5 | AI/ML capabilities and data infrastructure readiness | Critical | |
| 3.6 | Open-source software inventory and license compliance (OSS audit) | High | |
| 3.7 | Cloud infrastructure costs (AWS/Azure/GCP) and optimization potential | High | |
| 3.8 | DevOps maturity: CI/CD pipelines, deployment frequency, MTTR | Medium | |
| 3.9 | Intellectual property portfolio: patents, trade secrets, proprietary data | High | |
| 3.10 | Third-party dependencies and vendor lock-in risk | Medium | |
| 3.11 | Engineering team assessment: retention, capabilities, key-person risk | High | |
| 3.12 | Data privacy compliance (GDPR, CCPA, SOC 2) | Critical | |

## 4. Legal Due Diligence (12 Items)

| # | Item | Priority | Status |
|---|------|----------|--------|
| 4.1 | Corporate structure and organizational documents | Critical | |
| 4.2 | Material contracts review (customer, vendor, partner agreements) | Critical | |
| 4.3 | Intellectual property ownership and assignment agreements | Critical | |
| 4.4 | Pending and threatened litigation | Critical | |
| 4.5 | Regulatory compliance assessment | High | |
| 4.6 | Employment agreements and non-compete clauses | High | |
| 4.7 | Change-of-control provisions in key contracts | Critical | |
| 4.8 | Data processing agreements and data transfer mechanisms | High | |
| 4.9 | Environmental and health & safety compliance | Medium | |
| 4.10 | Insurance coverage adequacy review | Medium | |
| 4.11 | Anti-bribery/FCPA compliance program | Medium | |
| 4.12 | Historical M&A and integration completeness | Low | |

## 5. Human Resources / Management Due Diligence (11 Items)

| # | Item | Priority | Status |
|---|------|----------|--------|
| 5.1 | Management team assessment: capability, retention risk, alignment | Critical | |
| 5.2 | Organizational structure and reporting lines | High | |
| 5.3 | Employee turnover analysis (voluntary vs. involuntary, by department) | High | |
| 5.4 | Compensation benchmarking vs. market (equity, bonus, benefits) | High | |
| 5.5 | Key-person risk and succession planning | Critical | |
| 5.6 | Employee satisfaction surveys and Glassdoor/culture indicators | Medium | |
| 5.7 | Pending or potential labor disputes | Medium | |
| 5.8 | Diversity, equity, and inclusion metrics | Medium | |
| 5.9 | Training and development programs | Low | |
| 5.10 | Remote/hybrid work policy and impact on culture | Medium | |
| 5.11 | Management incentive plan design for post-close retention | High | |

## 6. Tax Due Diligence (11 Items)

| # | Item | Priority | Status |
|---|------|----------|--------|
| 6.1 | Federal and state income tax compliance review (3-year lookback) | Critical | |
| 6.2 | Tax attribute analysis: NOLs, R&D credits, tax basis in assets | High | |
| 6.3 | Transfer pricing policies and documentation | High | |
| 6.4 | International tax structure and permanent establishment risk | High | |
| 6.5 | Sales/use tax compliance (especially for SaaS nexus issues) | High | |
| 6.6 | Payroll tax compliance across all jurisdictions | Medium | |
| 6.7 | Tax indemnification provisions in purchase agreement | High | |
| 6.8 | Section 174 R&D capitalization impact analysis | High | |
| 6.9 | Entity classification and structuring for tax efficiency | Medium | |
| 6.10 | Property tax assessments | Low | |
| 6.11 | Unclaimed property compliance | Low | |

## 7. ESG Due Diligence (11 Items)

| # | Item | Priority | Status |
|---|------|----------|--------|
| 7.1 | ESG policy framework and governance structure | High | |
| 7.2 | Carbon footprint measurement and reduction targets | Medium | |
| 7.3 | Data privacy and responsible AI governance | Critical | |
| 7.4 | Supply chain ESG risk assessment | Medium | |
| 7.5 | Board diversity and governance practices | Medium | |
| 7.6 | Anti-corruption and business ethics programs | High | |
| 7.7 | Community engagement and social impact initiatives | Low | |
| 7.8 | Climate risk exposure (physical and transition risks) | Medium | |
| 7.9 | Human rights policy and modern slavery compliance | Medium | |
| 7.10 | ESG reporting and disclosure practices (SASB, TCFD alignment) | Medium | |
| 7.11 | Product safety and responsible deployment of AI | High | |

---

## DD Timeline and Milestones

| Phase | Duration | Key Deliverables |
|-------|----------|------------------|
| Phase 1: Preliminary DD (Weeks 1-3) | 3 weeks | Financial QoE, commercial deep-dive, management interviews |
| Phase 2: Confirmatory DD (Weeks 4-7) | 4 weeks | Technology audit, legal review, tax structuring |
| Phase 3: Final DD (Weeks 8-9) | 2 weeks | ESG review, HR assessment, final risk matrix |
| Phase 4: Pre-Close (Week 10) | 1 week | DD report finalization, SPA negotiation support |

---

## Sources

- Deloitte Netherlands: "Prepare and Execute the Deal: Due Diligence" (deloitte.com/nl)
- PwC US: "Due Diligence for Mergers and Acquisitions" (pwc.com)
- Apex Leaders: "Private Equity Due Diligence: Best Practices for Investors" (apexleaders.com)
- Affinity: "The Complete Private Equity Due Diligence Checklist" (affinity.co)
- NMS Consulting: "PE DD Checklist: Value Levers, Risks" (nmsconsulting.com)
- E78 Partners: "Key Considerations for Private Equity Due Diligence" (e78partners.com)
- McKinsey Global Private Markets Report 2026 -- Median PE purchase multiple 11.8x EBITDA
- IB Interview Questions: "Current M&A Multiples Across Sectors: 2025-2026" (ibinterviewquestions.com)
