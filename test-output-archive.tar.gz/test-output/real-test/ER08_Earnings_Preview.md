# ER08: Earnings Preview — NVIDIA (NVDA) FQ1 FY2027
## [DATA SOURCE: NVIDIA guidance, analyst consensus, hyperscaler capex data]

> 预览日期: 2026-05-09 | 预计发布: ~May 28, 2026

## 共识预期

| 指标 | Consensus | 指引 | 上季度 (FQ4 FY26) | YoY |
|------|----------|------|-------------------|-----|
| Revenue | $43.5B | $43.0B ±2% | $68.1B | +62% |
| Data Center Revenue | $37.2B | — | $56.8B | +75% |
| Gaming Revenue | $3.2B | — | $4.1B | +5% |
| Gross Margin | 73.5% | ~73% | 73.2% | +1.5pp |
| Operating Margin | 65.0% | — | 67.1% | +3pp |
| EPS (GAAP) | $0.82 | — | $0.89 | +55% |

> Note: FQ1 is typically seasonally lower than FQ4

## 关键关注指标

### 1. Data Center 增速
- FQ4 FY26 Data Center $56.8B (+93% YoY)
- 关注: 增速是否开始 decelerate (从 93% 降至 75-80%)
- Blackwell (B200/B300) 出货量 vs Hopper (H200) 尾部

### 2. 供应链指标
- CoWoS 产能利用率 (>95%?)
- HBM3e 供应是否缓解
- Backlog 水平 (估计仍 >$50B)

### 3. 毛利率
- 指引 ~73%, 市场预期 73.5%
- 关注 HBM 成本对 margin 的影响
- Blackwell 定价 power 是否维持

### 4. 指引 (FQ2 FY2027)
- 市场预期 ~$46-48B
- 是否暗示持续 25%+ QoQ 增长
- 2026 下半年可见度

## Bull/Base/Bear 情景

| 情景 | Revenue | EPS | 关键假设 | 股价反应 |
|------|---------|-----|---------|---------|
| **Bull** | $45.5B | $0.90 | DC +85%, 指引 $49B | +8-12% |
| **Base** | $43.5B | $0.82 | DC +75%, 指引 $46B | ±2% |
| **Bear** | $40.5B | $0.72 | DC +60%, 指引 $42B | -8-12% |

## 催化剂分析

| 因素 | 影响 | 时间 |
|------|------|------|
| Hyperscaler capex confirmed | 正面 | MSFT $80B, GOOGL $75B, META $65B |
| Blackwell Ultra ramp | 正面 | 2H 2026 |
| China export restrictions | 负面 | Ongoing |
| AI ROI concerns | 负面 | Sequoia $600B gap |
| Custom ASIC competition | 负面 | Google TPU v6, Amazon Trainium2 |

## 期权市场暗示

| 指标 | 值 |
|------|-----|
| Implied Move (straddle) | ±8-10% |
| ATM Straddle Cost (~$105) | ~$9.50 |
| Max Pain | ~$100 |
| Call/Put Ratio | 1.8 (偏看多) |

## Sources
- [NVIDIA FY2026 Q4 Guidance](https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Fourth-Quarter-and-Fiscal-2026/)
- [MarketBeat Earnings Calendar](https://www.marketbeat.com/earnings/calendar/)
- Hyperscaler Q1 2026 earnings (MSFT, GOOGL, META)
