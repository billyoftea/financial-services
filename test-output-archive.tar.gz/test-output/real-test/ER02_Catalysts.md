# ER02: Catalyst Calendar — Tech Coverage Universe
## [DATA SOURCE: Company IR, MarketBeat, Nasdaq earnings calendar]

> 日历期间: 2026-05-09 至 2026-06-08

## 覆盖池

AAPL, NVDA, MSFT, GOOGL, META, AMZN

## 催化剂日历

### 盈余发布

| 日期 | 公司 | 事件 | 预期 | 上次结果 |
|------|------|------|------|---------|
| ~May 20 | **NVDA** | FQ1 FY2027 Earnings | Rev $42-45B est | FQ4: $68.1B (+73%) |
| ~Jun 4 | **AAPL** | WWDC 2026 Keynote | iOS 20, AI updates | WWDC 2025: Apple Intelligence |
| Late May | **AMZN** | AWS Summit | New AI services | re:Invent 2025 announcements |

### 产品/行业事件

| 日期 | 公司/行业 | 事件 | 影响 |
|------|---------|------|------|
| May 12-15 | MSFT | Microsoft Build 2026 | Copilot/Azure AI 更新 |
| May 20 | GOOGL | Google I/O 2026 | Gemini 2.0, Android 17 |
| ~May 28 | NVDA | FQ1 Earnings Call | Data center revenue, Blackwell Ultra |
| Jun 2-5 | AAPL | WWDC 2026 | iOS 20, macOS 16, AI features |
| ~Jun 4 | All | US Jobs Report (May) | 宏观影响 |

### 监管/宏观

| 日期 | 事件 | 影响公司 | 潜在影响 |
|------|------|---------|---------|
| May 14 | US CPI (Apr) | All | 利率预期 |
| May 21 | FOMC Minutes | All | 货币政策 |
| Jun 1 | EU AI Act enforcement | GOOGL, META, MSFT | 合规成本 |
| Jun 5 | US Jobs Report | All | 宏观环境 |

## NVDA 财报重点 (最关键催化剂)

| 指标 | 共识预期 | 关注点 |
|------|---------|--------|
| Revenue | ~$42-45B | Data center 分部增速 |
| Data Center Revenue | ~$36B+ | Blackwell 出货量 |
| Gross Margin | ~73-74% | HBM 成本影响 |
| EPS | ~$0.80 | Share buyback pace |
| Guidance (FQ2) | ~$46B+ | 供应链可见度 |

## Sources
- [MarketBeat Earnings Calendar](https://www.marketbeat.com/earnings/calendar/)
- [NVIDIA IR](https://investor.nvidia.com/)
- [Apple IR](https://investor.apple.com/)
- [Microsoft Events](https://news.microsoft.com/events/)
- [Google I/O](https://io.google/)
