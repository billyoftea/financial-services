# FA02: A-Share Data Skill Test

**[DATA SOURCE: akshare API + WebSearch (Investing.com, East Money, Sina Finance)]**
**Test Date: 2026-05-09**
**Skill: financial-analysis:ashare-data**

---

## Objective
Verify the ashare-data skill's ability to fetch real Chinese A-share market data via the akshare library for 贵州茅台 (600519) and other key A-share stocks.

---

## Real Data: 贵州茅台 (Kweichow Moutai, 600519.SH)

**Company:** Kweichow Moutai Co., Ltd.
**Exchange:** Shanghai Stock Exchange (SSE)
**Sector:** Consumer Staples / Liquor
**API Call:** `ak.stock_zh_a_hist(symbol='600519', period='daily', start_date='20260506', end_date='20260508')`

### Daily OHLCV Data (May 2026)

| Date | Open | Close | High | Low | Volume (lots) | Amount (CNY) |
|------|------|-------|------|-----|---------------|--------------|
| 2026-05-06 | 1365.10 | **1371.05** | 1382.77 | 1360.05 | 47,806 | 6.55B |
| 2026-05-07 | 1375.00 | **1371.05** | 1388.00 | 1370.01 | 40,461 | 5.57B |
| 2026-05-08 | 1371.66 | **1372.99** | 1382.77 | 1370.00 | 33,369 | 4.58B |

### Key Valuation Metrics

| Metric | Value | Source |
|--------|-------|--------|
| Latest Close | 1,372.99 CNY | akshare / East Money |
| P/E Ratio (TTM) | 20.92x | Sina Finance |
| 52-Week High | ~1,645 CNY | Investing.com |
| 52-Week Low | ~1,322.01 CNY | Investing.com |
| 3-Day Return | +0.14% (1371.05 -> 1372.99) | Calculated |

### Observations
- **Tight Range:** Moutai traded within a narrow 1,360-1,388 band over 3 sessions, reflecting typical low-volatility behavior for this mega-cap.
- **Declining Volume:** Volume dropped from 47,806 to 33,369 lots, suggesting waning short-term interest.
- **Valuation:** At a P/E of 20.92x, Moutai trades at a moderate premium relative to its historical range, supported by consistent earnings growth.
- **Distance from Highs:** Current price is ~16.5% below the 52-week high of 1,645, and ~3.8% above the 52-week low of 1,322.01.

---

## Real Data: 宁德时代 (CATL, 300750.SZ)

**Company:** Contemporary Amperex Technology Co., Limited
**Exchange:** Shenzhen Stock Exchange (SZSE) - ChiNext Board
**API Call:** `ak.stock_zh_a_hist(symbol='300750', period='daily', start_date='20260506', end_date='20260508')`

| Date | Open | Close | High | Low | Volume | Amount (CNY) |
|------|------|-------|------|-----|--------|--------------|
| 2026-05-06 | 457.50 | **460.00** | 465.88 | 448.63 | 473,727 | 21.68B |
| 2026-05-07 | 468.75 | **451.64** | 468.75 | 447.00 | 386,213 | 17.55B |
| 2026-05-08 | 449.00 | **437.00** | 455.50 | 436.20 | 366,049 | 16.22B |

**3-Day Return:** -5.00% (460.00 -> 437.00), showing significant bearish momentum with declining volume.

---

## API Reliability Notes

| Test | Result | Notes |
|------|--------|-------|
| First call (600519) | SUCCESS | 3 rows returned |
| Second call (300750) | SUCCESS | 3 rows returned |
| Subsequent rapid calls | FAILED | RemoteDisconnected error |
| Retry with delay | SUCCESS | Data retrieved |

**Recommendation:** The ashare-data skill should implement retry logic with exponential backoff when calling akshare, as East Money endpoints can drop connections under rapid successive calls.

---

## Skill Assessment

| Criteria | Rating | Notes |
|----------|--------|-------|
| Data Accuracy | PASS | OHLCV matches web sources |
| Data Completeness | PASS | All standard fields returned |
| Multiple Stocks | PASS | SSE (600519) and SZSE (300750) |
| Date Range Support | PASS | Custom start/end dates work |
| API Stability | PARTIAL | Retry logic required |

---

## Conclusion
The ashare-data skill successfully retrieves real A-share data for both Shanghai and Shenzhen listed stocks. akshare provides comprehensive OHLCV data with valuation metrics from cross-referenced sources (Investing.com, Sina Finance, East Money). API stability requires retry logic for production use.

**Sources:**
- akshare v1.18.53, `stock_zh_a_hist()` via East Money API
- [Investing.com - Moutai 600519](https://cn.investing.com/equities/kweichow-moutai-historical-data)
- [Sina Finance - 600519](https://finance.sina.com.cn/realstock/company/sh600519/nc.shtml)
- [East Money - 600519](https://quote.eastmoney.com/sh600519.html)
