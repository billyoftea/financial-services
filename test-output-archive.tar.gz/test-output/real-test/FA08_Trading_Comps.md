# FA08: Trading Comparables — Semiconductor Sector
## [DATA SOURCE: Yahoo Finance, Macrotrends, company filings — May 2026]

> 分析日期: 2026-05-09 | 目标: NVIDIA (NVDA)

## 可比公司选择

| # | 公司 | Ticker | 市值 ($B) | 行业 | 选为可比原因 |
|---|------|--------|----------|------|------------|
| 1 | NVIDIA Corp | NVDA | 2,610 | GPU/AI | 目标公司 |
| 2 | AMD | AMD | 265 | CPU/GPU | 直接竞争者 |
| 3 | Intel | INTC | 105 | CPU | 传统半导体 |
| 4 | Broadcom | AVGO | 1,050 | 定制芯片/网络 | AI定制ASIC |
| 5 | Qualcomm | QCOM | 195 | 移动芯片 | 无线半导体 |
| 6 | Marvell | MRVL | 95 | 定制芯片 | 数据中心定制 |
| 7 | TSMC | TSM | 920 | 代工 | 主要代工厂 |

## 估值倍数对比

### 收益倍数

| 公司 | P/E (TTM) | P/E (Fwd) | PEG | EV/EBITDA (TTM) |
|------|----------|----------|-----|-----------------|
| NVDA | 43.5x | 37.98x | 0.66x | 43.8x |
| AMD | 102.5x | 55.2x | 1.38x | 62.3x |
| INTC | N/M (loss) | 45.0x | N/M | 18.5x |
| AVGO | 65.2x | 42.0x | 0.93x | 38.2x |
| QCOM | 18.5x | 14.8x | 0.87x | 13.5x |
| MRVL | 75.0x | 45.5x | 1.25x | 52.8x |
| TSM | 28.5x | 22.0x | 0.85x | 20.5x |
| **中位数** | **65.2x** | **42.0x** | **0.93x** | **38.2x** |
| **均值** | **55.5x** | **37.5x** | **0.99x** | **35.7x** |

### 收入倍数

| 公司 | EV/Revenue (TTM) | EV/Revenue (Fwd) | Revenue Growth |
|------|-----------------|-----------------|----------------|
| NVDA | 20.8x | 15.5x | +65% |
| AMD | 8.5x | 6.8x | +14% |
| INTC | 2.8x | 2.5x | -8% |
| AVGO | 15.2x | 12.8x | +25% |
| QCOM | 3.5x | 3.2x | +10% |
| MRVL | 12.5x | 9.5x | +27% |
| TSM | 7.5x | 6.5x | +20% |
| **中位数** | **8.5x** | **6.8x** | **+20%** |

## NVDA 相对估值

| 方法 | 倍数 | 应用于 | 隐含股价 |
|------|------|--------|---------|
| Peer Median P/E (Fwd) | 42.0x | EPS $2.80 | $117.60 |
| Peer Median EV/EBITDA | 38.2x | EBITDA $140.5B | $143.50 |
| Peer Median EV/Rev (Fwd) | 6.8x | Rev $286.4B | $73.20 |
| AI-Premium P/E | 55.0x | EPS $2.80 | $154.00 |

## Sources
- [Yahoo Finance - NVDA](https://finance.yahoo.com/quote/NVDA/)
- [Yahoo Finance - AMD](https://finance.yahoo.com/quote/AMD/)
- Macrotrends - Historical multiples
- Company 10-K/10-Q filings
