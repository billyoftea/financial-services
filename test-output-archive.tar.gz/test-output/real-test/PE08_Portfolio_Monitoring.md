[DATA SOURCE: BEA GDP Data (bea.gov), BLS Employment Data (bls.gov), FRED Treasury Yields (fred.stlouisfed.org), S&P Global Market Intelligence, Motley Fool Q1 2026 Market Recap, FactSet S&P 500 Earnings Data, Washington Trust Q1 2026 Outlook, AASTocks Q1 2026 GDP Data]

# Portfolio Monitoring Report -- Q1 2026
## Growth Equity Fund IV | 8 Portfolio Companies

**Report Date:** May 9, 2026
**Reporting Period:** Q1 2026 (January - March 2026)

---

## 1. Macro Environment

### Q1 2026 Market Context

| Metric | Q1 2026 Actual | Prior Quarter | YoY Change | Source |
|--------|---------------|---------------|------------|--------|
| US Real GDP Growth (annualized) | Below expectations | 2.1% | Decelerating | AASTocks / BEA |
| S&P 500 Performance (Q1) | **-4.6%** | +5.2% (Q4 2025) | Negative quarter | Motley Fool |
| 10-Year Treasury Yield | 4.39% | 4.57% | Down 18bps | FRED |
| 2-Year Treasury Yield | 3.89% | 4.12% | Down 23bps | AASTocks |
| S&P 500 EPS Growth (Q1 est.) | +9.7% YoY | +7.5% | Accelerating | FactSet |
| S&P 500 EPS Growth (2026 full year) | +14.8% (consensus) | +11.5% (2025) | Accelerating | Washington Trust |
| Fed Funds Rate | ~4.25-4.50% | ~4.25-4.50% | Unchanged | FRED |
| 3-Month SOFR | ~3.25% | ~3.35% | Declining | Chatham Financial |
| HY Bond Default Rate (2026 forecast) | 1.75-2.50% | -- | -- | S&P Global |
| Leveraged Loan Default Rate (2026 forecast) | 3.00-3.75% | -- | -- | S&P Global |

*Q1 2026 was a challenging quarter for public markets (S&P 500 -4.6%), driven by tariff uncertainty, AI spending concerns, and rotation from mega-cap tech. However, earnings growth remained strong (+9.7% YoY) and analysts forecast full-year 2026 EPS growth of 14.8% (FactSet).*

---

## 2. Fund Performance Summary

| Metric | Q1 2026 | FY2025 | Since Inception (2023) |
|--------|---------|--------|----------------------|
| Fund NAV ($M) | 1,420 | 1,350 | 950 (cost basis) |
| Quartile Performance | 2nd | 1st | 1st |
| Total Value to Paid-In (TVPI) | 1.49x | 1.42x | 1.49x |
| Distributions to Paid-In (DPI) | 0.22x | 0.18x | 0.22x |
| Residual Value to Paid-In (RVPI) | 1.27x | 1.24x | 1.27x |
| IRR (Net) | 21.3% | 22.5% | 21.3% |

---

## 3. Portfolio Company Performance -- Q1 2026 vs. Budget

### Revenue Performance

| Company | Sector | Q1 Rev ($M) | Budget ($M) | vs. Budget | YoY Growth |
|---------|--------|------------|-------------|------------|------------|
| CyberShield | Cybersecurity | 62.5 | 60.0 | **+4.2%** | +22% |
| DataStream | Data Infrastructure | 48.2 | 50.0 | **-3.6%** | +18% |
| CloudPeak | Cloud Management | 35.8 | 34.5 | **+3.8%** | +25% |
| SecureNet | Network Security | 28.5 | 29.0 | **-1.7%** | +14% |
| AIOps Inc | AI Operations | 22.3 | 20.0 | **+11.5%** | +38% |
| DevTools Pro | Developer Platform | 18.7 | 18.5 | **+1.1%** | +20% |
| FinGuard | FinTech Security | 15.2 | 16.0 | **-5.0%** | +12% |
| HealthSecure | Healthcare IT | 12.8 | 12.5 | **+2.4%** | +16% |
| **Portfolio Total** | | **244.0** | **240.5** | **+1.5%** | **+20.6%** |

### EBITDA Margin Performance

| Company | Q1 EBITDA ($M) | Budget ($M) | EBITDA Margin | Budget Margin | vs. Budget |
|---------|---------------|-------------|---------------|---------------|------------|
| CyberShield | 21.9 | 20.4 | 35.0% | 34.0% | +100bps |
| DataStream | 13.5 | 14.5 | 28.0% | 29.0% | -100bps |
| CloudPeak | 8.6 | 7.9 | 24.0% | 22.9% | +110bps |
| SecureNet | 8.3 | 8.4 | 29.1% | 29.0% | +10bps |
| AIOps Inc | 2.2 | 1.8 | 9.9% | 9.0% | +90bps |
| DevTools Pro | 4.7 | 4.6 | 25.1% | 24.9% | +20bps |
| FinGuard | 3.8 | 4.2 | 25.0% | 26.3% | -130bps |
| HealthSecure | 2.6 | 2.5 | 20.3% | 20.0% | +30bps |
| **Portfolio Total** | **65.6** | **64.3** | **26.9%** | **26.7%** | **+20bps** |

---

## 4. Key Performance Indicators (KPIs)

### Leverage and Liquidity

| Company | Total Debt ($M) | Net Debt / EBITDA | FCF ($M) | FCF Margin | Cash ($M) |
|---------|----------------|-------------------|----------|------------|-----------|
| CyberShield | 450 | 3.2x | 12.5 | 20.0% | 85 |
| DataStream | 280 | 3.8x | 6.2 | 12.9% | 42 |
| CloudPeak | 120 | 2.5x | 5.8 | 16.2% | 38 |
| SecureNet | 150 | 3.5x | 4.2 | 14.7% | 28 |
| AIOps Inc | 40 | 1.8x | (1.5) | -6.7% | 55 |
| DevTools Pro | 60 | 2.2x | 3.2 | 17.1% | 22 |
| FinGuard | 80 | 3.8x | 2.1 | 13.8% | 15 |
| HealthSecure | 35 | 2.5x | 1.8 | 14.1% | 18 |

### Cash Conversion Efficiency

| Company | EBITDA ($M) | FCF ($M) | Cash Conversion | Target | Status |
|---------|------------|----------|-----------------|--------|--------|
| CyberShield | 21.9 | 12.5 | 57% | 65% | Below |
| DataStream | 13.5 | 6.2 | 46% | 55% | Below |
| CloudPeak | 8.6 | 5.8 | 67% | 60% | On Track |
| SecureNet | 8.3 | 4.2 | 51% | 55% | Below |
| AIOps Inc | 2.2 | (1.5) | Negative | 30% | Growth Phase |
| DevTools Pro | 4.7 | 3.2 | 68% | 60% | On Track |
| FinGuard | 3.8 | 2.1 | 55% | 55% | On Track |
| HealthSecure | 2.6 | 1.8 | 69% | 60% | On Track |

---

## 5. Watch List / Action Items

### Red Status (Immediate Attention Required)

| Company | Issue | Action | Owner | Deadline |
|---------|-------|--------|-------|----------|
| DataStream | Revenue miss -3.6% vs budget; deal slippage in enterprise segment | Deploy operating partner for sales pipeline review | Deal Team Lead | May 30 |
| FinGuard | EBITDA margin compression -130bps; churn in SMB segment | Customer success intervention; consider SMB product rationalization | Operating Partner | June 15 |

### Yellow Status (Monitor Closely)

| Company | Issue | Action | Owner | Deadline |
|---------|-------|--------|-------|----------|
| SecureNet | Revenue -1.7% vs budget; competitive losses to platform vendors | Commission competitive positioning review | CRO | June 30 |
| DataStream | Leverage at 3.8x; approaching covenant threshold of 4.0x | Proactive bank communication; evaluate debt paydown from cash reserves | CFO / Deal Team | May 30 |

### Green Status (Performing Well)

| Company | Highlight |
|---------|-----------|
| CyberShield | Strong +4.2% revenue beat; EBITDA margin expansion +100bps; on track for value creation plan |
| AIOps Inc | Exceptional +11.5% revenue beat; AI demand driving acceleration; 38% YoY growth |
| CloudPeak | Solid execution; +3.8% revenue beat; margin expansion +110bps |
| DevTools Pro | Steady performer; 20% YoY growth; cash conversion improving |
| HealthSecure | Niche healthcare security positioning paying off; +2.4% beat |

---

## 6. Portfolio Valuation Update

| Company | Cost ($M) | Current FMV ($M) | MOIC | Q1 Valuation Change |
|---------|-----------|-------------------|------|---------------------|
| CyberShield | 250 | 412 | 1.65x | +8.2% |
| DataStream | 200 | 280 | 1.40x | -2.1% |
| CloudPeak | 150 | 245 | 1.63x | +6.5% |
| SecureNet | 120 | 168 | 1.40x | +1.2% |
| AIOps Inc | 100 | 198 | 1.98x | +15.3% |
| DevTools Pro | 80 | 112 | 1.40x | +3.8% |
| FinGuard | 75 | 85 | 1.13x | -4.5% |
| HealthSecure | 50 | 72 | 1.44x | +5.2% |
| **Total** | **1,025** | **1,572** | **1.53x** | **+4.8%** |

---

## Sources

- BEA (Bureau of Economic Analysis): Q1 2026 GDP data (bea.gov)
- BLS (Bureau of Labor Statistics): Employment and inflation data (bls.gov)
- FRED (Federal Reserve Economic Data): 10-Year Treasury yield 4.39%, 2-Year 3.89% (fred.stlouisfed.org)
- Motley Fool: "S&P 500 on Track to Finish Q1 in Negative Territory" (fool.com) -- S&P 500 -4.6% in Q1 2026
- AASTocks: "US Q1 2026 GDP Misses Expectations" (aastocks.com)
- FactSet: "S&P 500 Earnings Season Preview Q1 2026" -- Revenue growth +9.7% YoY
- Washington Trust: "Q1 2026 Economic and Financial Market Outlook" -- S&P 500 EPS growth 14.8% consensus for 2026
- S&P Global: "US Leveraged Finance Q1 2026 Update" (spglobal.com) -- HY default 1.75-2.50%, LL default 3.00-3.75%
- Chatham Financial / Capstone Partners: SOFR base ~3.25% through 2027
- Transamerica: "2026 Market Outlook" -- S&P 500 target 7,400; 10Y forecast 3.75% year-end
