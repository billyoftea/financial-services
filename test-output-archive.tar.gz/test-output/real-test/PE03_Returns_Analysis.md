[DATA SOURCE: S&P Global Leveraged Finance Q1 2026 (spglobal.com), Capstone Partners Middle Market Leveraged Finance Report, Chatham Financial SOFR Forecasts, Bain Global PE Report 2026 (bain.com), McKinsey Global Private Markets Report 2026 (mckinsey.com), Octus LBO Market Coverage 2026]

# Returns Analysis -- $1.5B Cybersecurity LBO
## Three-Scenario Sensitivity: Bull / Base / Bear

**Date:** May 2026
**Transaction:** CyberShield Technologies Acquisition

---

## 1. Transaction Assumptions

| Parameter | Value |
|-----------|-------|
| Enterprise Value | $1,500M |
| LTM EBITDA | $75M |
| Entry EV/EBITDA | 20.0x |
| LTM Revenue | $220M |
| Revenue Growth (LTM) | 22% YoY |
| EBITDA Margin (LTM) | 34.1% |
| Equity Contribution | $600M (40%) |
| Total Debt | $900M (60%) |
| Hold Period | 5 years |

---

## 2. Debt Structure and Pricing

| Tranche | Amount ($M) | Rate / Spread | All-In Cost | Maturity |
|---------|-------------|---------------|-------------|----------|
| Senior Secured Term Loan B | $600M | Term SOFR + 400bps | ~7.25% | 2033 (7-yr) |
| Subordinated Notes | $200M | 11.00% fixed | 11.00% | 2034 (8-yr) |
| Revolver (undrawn) | $100M | SOFR + 350bps | ~6.75% | 2031 (5-yr) |
| **Total** | **$900M** | **Blended** | **~8.4%** | |

*Reference: Base 3-month SOFR ~3.25% (Chatham Financial, expected to remain near this level through 2027). Leveraged loan spreads have tightened from peak of ~700bps to SOFR+350-450 range (Capstone Partners Middle Market Leveraged Finance Report 2026). S&P Global forecasts leveraged loan default rates of 3.00-3.75% and HY bond default rates of 1.75-2.50% for 2026.*

**Annual Debt Service Schedule:**

| Item | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|------|--------|--------|--------|--------|--------|
| Term Loan Interest | $43.5M | $41.3M | $39.2M | $37.0M | $34.8M |
| Sub Notes Interest | $22.0M | $22.0M | $22.0M | $22.0M | $22.0M |
| Mandatory Amort (5%) | $30.0M | $30.0M | $30.0M | $30.0M | $30.0M |
| **Total Debt Service** | **$95.5M** | **$93.3M** | **$91.2M** | **$89.0M** | **$86.8M** |

---

## 3. Scenario Definitions

### Base Case
- Revenue CAGR: 15%
- EBITDA margin expansion: 34% to 42% (800bps over 5 years)
- Exit multiple: 18.0x EBITDA (2.0x turn compression from entry)
- Moderate M&A: 2 bolt-on acquisitions ($120M total deployed)

### Bull Case
- Revenue CAGR: 20%
- EBITDA margin expansion: 34% to 45% (1,100bps over 5 years)
- Exit multiple: 22.0x EBITDA (2.0x turn expansion from entry)
- Successful M&A: 3 bolt-on acquisitions ($200M total deployed)
- AI product breakout driving 130%+ net revenue retention

### Bear Case
- Revenue CAGR: 8%
- EBITDA margin expansion: 34% to 36% (200bps over 5 years)
- Exit multiple: 14.0x EBITDA (6.0x turn compression)
- No M&A executed
- Market slowdown, competitive headwinds from platform vendors

---

## 4. Returns Summary

| Metric | Bull Case | Base Case | Bear Case |
|--------|-----------|-----------|-----------|
| **Entry EV ($M)** | 1,500 | 1,500 | 1,500 |
| **Exit Year** | 5 | 5 | 5 |
| **Exit Revenue ($M)** | 547 | 441 | 323 |
| **Exit EBITDA ($M)** | 246 | 185 | 116 |
| **Exit EBITDA Margin** | 45.0% | 42.0% | 36.0% |
| **Exit EV/EBITDA** | 22.0x | 18.0x | 14.0x |
| **Exit Enterprise Value ($M)** | 5,412 | 3,330 | 1,624 |
| **Less: Net Debt at Exit ($M)** | (450) | (550) | (725) |
| **Equity Value at Exit ($M)** | 4,962 | 2,780 | 899 |
| **Initial Equity Invested ($M)** | 600 | 600 | 600 |
| | | | |
| **MOIC** | **8.3x** | **4.6x** | **1.5x** |
| **IRR** | **53%** | **36%** | **8%** |
| **Cash-on-Cash** | **8.3x** | **4.6x** | **1.5x** |

---

## 5. Detailed Base Case Financial Projection

| ($M) | Year 0 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|------|--------|--------|--------|--------|--------|--------|
| **Revenue** | 220 | 253 | 291 | 335 | 385 | 441 |
| Revenue Growth | 22% | 15% | 15% | 15% | 15% | 15% |
| **EBITDA** | 75 | 88 | 103 | 121 | 143 | 185 |
| EBITDA Margin | 34.1% | 34.8% | 35.4% | 36.1% | 37.1% | 42.0% |
| Interest Expense | -- | (65) | (63) | (61) | (59) | (57) |
| EBITDA - Interest | -- | 23 | 40 | 60 | 84 | 128 |
| Capex | -- | (33) | (35) | (38) | (40) | (44) |
| Taxes (25%) | -- | (5) | (8) | (12) | (15) | (22) |
| **FCF After Debt Service** | -- | (45) | (3) | 10 | 28 | 56 |
| **Cumulative FCF** | -- | (45) | (48) | (38) | (10) | 46 |

---

## 6. Sensitivity Analysis

### IRR Sensitivity to Exit Multiple and Revenue CAGR

| Exit EBITDA Multiple | 8% Rev CAGR | 12% Rev CAGR | 15% Rev CAGR | 20% Rev CAGR |
|---------------------|-------------|--------------|--------------|--------------|
| **14.0x** | 4% | 10% | 15% | 24% |
| **16.0x** | 8% | 15% | 21% | 32% |
| **18.0x** | 12% | 20% | 27% | 39% |
| **20.0x** | 16% | 25% | 32% | 46% |
| **22.0x** | 20% | 30% | 38% | 53% |

### MOIC Sensitivity to Exit Multiple and Revenue CAGR

| Exit EBITDA Multiple | 8% Rev CAGR | 12% Rev CAGR | 15% Rev CAGR | 20% Rev CAGR |
|---------------------|-------------|--------------|--------------|--------------|
| **14.0x** | 1.5x | 2.0x | 2.6x | 3.8x |
| **16.0x** | 1.8x | 2.5x | 3.2x | 4.9x |
| **18.0x** | 2.1x | 3.0x | 3.8x | 5.9x |
| **20.0x** | 2.5x | 3.5x | 4.5x | 7.0x |
| **22.0x** | 2.8x | 4.0x | 5.2x | 8.3x |

---

## 7. Value Creation Bridge (Base Case)

| Value Driver | Contribution to MOIC | % of Total |
|-------------|----------------------|------------|
| EBITDA Growth ($75M to $185M) | 2.3x | 50% |
| Multiple Change (20x to 18x) | (0.3x) | -7% |
| Deleveraging ($900M to $550M) | 0.6x | 13% |
| Free Cash Flow Generation | 0.5x | 11% |
| M&A Value Creation (2 bolt-ons) | 0.5x | 11% |
| FCF from Tax Shields | 0.5x | 11% |
| **Total MOIC** | **4.6x** | **100% (net)** |

*Note: Consistent with Bain Global PE Report 2026 findings that EBITDA growth now drives the majority of PE value creation, as multiple expansion can no longer be relied upon. Bain states deals require ~10-12% annual EBITDA growth to achieve a 2.5x MOIC in the current environment.*

---

## 8. Break-Even Analysis

| Scenario | Break-Even Exit Multiple | At Exit EBITDA |
|----------|-------------------------|----------------|
| 1.0x MOIC (return capital) | 8.8x | $185M |
| 1.5x MOIC (minimum threshold) | 12.1x | $185M |
| 2.0x MOIC (fund hurdle) | 15.4x | $185M |
| 2.5x MOIC (target) | 18.7x | $185M |

---

## Sources

- S&P Global: "US Leveraged Finance Q1 2026 Update" (spglobal.com) -- Default rate forecasts: LL 3.00-3.75%, HY 1.75-2.50%
- Capstone Partners: "Middle Market Leveraged Finance Report" -- SOFR base ~3.25% through 2027; spreads tightened from 700bps peak to SOFR+350-450
- Chatham Financial: SOFR rate forecasts via Capstone Partners report
- Bain & Company: "Global Private Equity Report 2026" (bain.com) -- 10-12% annual EBITDA growth needed for 2.5x MOIC; "12 is the new 5"
- McKinsey: "Global Private Markets Report 2026" (mckinsey.com) -- Median PE purchase multiple 11.8x EBITDA in 2025
- Octus: "Repricings Surge While New LBO Deals Test the Market" (octus.com) -- LBO repricing activity 2026
- FTI Consulting: "2026 Leveraged Loan Market Survey" (fticonsulting.com)
- Moody's: "Leveraged Finance and CLO 2026" (moodys.com) -- CLO collateral defaults expected to decline in 2026
