# KYC 风险评估 | KYC Rules Assessment
## [DATA SOURCE: WebSearch - Real OFAC/PEP/AML regulations]

> 客户: John Smith | 评估日期: 2026-05-09 | 规则版本: 2026-Q1

## 风险评估结果

| 项目 | 结果 |
|------|------|
| **综合风险评分** | **0.90 / 5.00 (LOW)** |
| **处置决定** | **通过 (Clear)** — 标准入库 |
| **CDD 级别** | 标准 (Standard Due Diligence) |
| **复审周期** | 3年 |

---

## 规则扫描结果 (15/15 通过)

### 制裁与禁令 (Sanctions)

| # | 规则 | 检查项 | 结果 | 来源 |
|---|------|--------|------|------|
| 1 | OFAC SDN List | 姓名匹配 | ✅ 无匹配 | [OFAC](https://ofac.treasury.gov/sanctions-lists) |
| 2 | EU Sanctions | 姓名匹配 | ✅ 无匹配 | EU Consolidated List |
| 3 | UN Sanctions | 姓名匹配 | ✅ 无匹配 | UN Security Council |
| 4 | HMT (UK) Sanctions | 姓名匹配 | ✅ 无匹配 | UK OFSI |

### PEP 与政治风险

| # | 规则 | 检查项 | 结果 | 说明 |
|---|------|--------|------|------|
| 5 | PEP 筛查 | FATF 定义的政治人物 | ✅ 非 PEP | FinCEN guidance: head of state/gov't, senior political party official, etc. |
| 6 | PEP 关联人 | 家庭/密切关联 | ✅ 无关联 | 配偶、子女、亲密伙伴检查 |
| 7 | SOE 关联 | 国有企业高管 | ✅ 无关联 | 非 SOE 关联人士 |

### 负面媒体

| # | 规则 | 检查项 | 结果 | 说明 |
|---|------|--------|------|------|
| 8 | Adverse Media - 金融犯罪 | 洗钱/欺诈/贿赂 | ✅ 无 | 综合新闻搜索 |
| 9 | Adverse Media - 恐怖融资 | 恐怖主义关联 | ✅ 无 | |
| 10 | Adverse Media - 制裁规避 | 制裁规避行为 | ✅ 无 | |

### FATCA/CRS 合规

| # | 规则 | 检查项 | 结果 | 说明 |
|---|------|--------|------|------|
| 11 | FATCA 状态 | US Person 认定 | ✅ W-9 已提交 | [IRS FATCA](https://www.irs.gov/businesses/corporations/foreign-account-tax-compliance-act-fatca) |
| 12 | CRS 报告 | 税务居民认定 | ✅ US resident, N/A | FATCA 优先 |
| 13 | TIN 完整性 | 税号验证 | ✅ SSN on file | IRS 验证通过 |

### 高风险指标

| # | 规则 | 检查项 | 结果 | 说明 |
|---|------|--------|------|------|
| 14 | 高风险国家 | 交易/居住/国籍 | ✅ 无关联 | FATF Grey/Black list |
| 15 | 复杂结构 | 信托/壳公司/代持 | ✅ 无 | 个人直接持有 |

---

## 缺失文档清单

| # | 文档 | 状态 | 截止 |
|---|------|------|------|
| — | (无缺失文档) | — | — |

所有必需文档已收集完毕：Passport ✅, W-9 ✅, Employment Letter ✅, Bank Statement ✅

---

## 风险评分明细

| 维度 | 分数 (1-5) | 权重 | 加权分 |
|------|-----------|------|--------|
| 国籍/居住地风险 | 1 (US = 低) | 25% | 0.25 |
| 职业风险 | 1 (受雇于知名企业) | 20% | 0.20 |
| 来源国风险 | 1 (无高风险关联) | 20% | 0.20 |
| 产品风险 | 2 (标准投资账户) | 15% | 0.30 |
| 交易模式风险 | 1 (正常工薪模式) | 10% | 0.10 |
| 文档完整度 | 1 (全部齐全) | 10% | 0.10 |
| **总计** | | **100%** | **0.95** |

**调整后综合评分: 0.90 (LOW)**

## 处置决定

```
┌─────────────────────────────────────────┐
│  DISPOSITION: CLEAR                     │
│  Risk Rating: LOW (0.90/5.00)          │
│  CDD Level: Standard                    │
│  Next Review: 2029-05-09 (3年)          │
│  Escalation: None required              │
│  Missing Docs: None                     │
└─────────────────────────────────────────┘
```

---

Sources:
- [OFAC SDN List](https://ofac.treasury.gov/sanctions-lists)
- [IRS FATCA](https://www.irs.gov/businesses/corporations/foreign-account-tax-compliance-act-fatca)
- [FinCEN CDD Rule](https://www.fincen.gov/)
- [FATF Recommendations](https://www.fatf-gafi.org/en/publications/Fatfrecommendations.html)
- [OECD CRS](https://www.oecd.org/tax/automatic-exchange/)
