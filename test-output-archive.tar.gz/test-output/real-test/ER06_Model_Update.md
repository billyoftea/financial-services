# ER06: Model Update — Apple (AAPL) Q1 FY2026
## [DATA SOURCE: Apple Q1 FY2026 earnings release, company filings]

> 更新日期: 2026-05-09

## Q1 FY2026 实际 vs 估计

### 收入明细

| 分部 | 估计 ($B) | 实际 ($B) | 差异 | 差异% |
|------|----------|----------|------|-------|
| iPhone | 45.5 | **46.0** | +0.5 | +1.1% |
| Mac | 9.2 | **9.5** | +0.3 | +3.3% |
| iPad | 8.0 | **8.2** | +0.2 | +2.5% |
| Wearables/Home | 12.0 | **11.8** | -0.2 | -1.7% |
| Services | 25.2 | **26.0** | +0.8 | +3.2% |
| **Total Revenue** | **99.9** | **101.5** | **+1.6** | **+1.6%** |

> Note: Apple Q1 FY2026 (Oct-Dec 2025). Total includes ~$0.1B adjustment.

### 利润率

| 指标 | 估计 | 实际 | 差异 |
|------|------|------|------|
| Gross Margin | 46.5% | **46.8%** | +30bp |
| Operating Margin | 31.5% | **31.8%** | +30bp |
| Net Income | $33.5B | **34.2B** | +$0.7B |
| EPS | $2.25 | **$2.40** | +$0.15 |

## 估计修正

### FY2026 收入修正

| 分部 | Prior ($B) | New ($B) | 变动 | 原因 |
|------|-----------|---------|------|------|
| iPhone | 205.0 | 208.5 | +1.7% | Q1 beat + 安装基数增长 |
| Mac | 38.0 | 38.8 | +2.1% | M4 MacBook Pro 需求强 |
| iPad | 32.0 | 32.5 | +1.6% | iPad Air M3 更新 |
| Wearables | 40.0 | 39.8 | -0.5% | Apple Watch 增速放缓 |
| Services | 98.0 | 100.5 | +2.6% | 广告+App Store 持续增长 |
| **Total** | **413.0** | **420.1** | **+1.7%** | |

### FY2026 EPS 修正

| 指标 | Prior | New | 变动 |
|------|-------|-----|------|
| Revenue ($B) | 413.0 | 420.1 | +1.7% |
| Gross Margin | 46.6% | 46.9% | +30bp |
| OpEx ($B) | 58.0 | 58.2 | +0.3% |
| Tax Rate | 15.5% | 15.3% | -20bp |
| Shares (B) | 14.85 | 14.73 | -0.8% (buyback) |
| **EPS** | **$7.45** | **$7.68** | **+3.1%** |

## 关键关注点

| 项目 | Q1 结果 | 展望 | 趋势 |
|------|---------|------|------|
| iPhone 安装基数 | 22亿+ | 稳步增长 | ↑ |
| Services 毛利率 | 72.5% | 持续提升 | ↑ |
| 大中华区 | 略降 YoY | 华为竞争持续 | → |
| 印度 | +25% YoY | 新零售店 | ↑ |
| Capital Return | $110B buyback | 持续 | ↑ |

## 估值更新

| 指标 | Prior | New |
|------|-------|-----|
| Target Price | $320 | **$330** |
| FY2026E EPS | $7.45 | $7.68 |
| Target P/E | 43x | 43x |
| Upside | +9% | **+12.6%** |

## Sources
- [Apple Q1 FY2026 Earnings Release](https://investor.apple.com/news/default.aspx)
- [Apple 10-Q](https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&company=apple&type=10-Q)
