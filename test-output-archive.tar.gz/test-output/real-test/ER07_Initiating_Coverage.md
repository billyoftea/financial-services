# ER07: Initiating Coverage Task 1 — Palantir (PLTR)
## [DATA SOURCE: Palantir 10-K, earnings releases, Yahoo Finance — May 2026]

> 报告日期: 2026-05-09

## 公司概况

| 项目 | 详情 |
|------|------|
| 公司名称 | Palantir Technologies Inc. |
| Ticker | PLTR (NYSE) |
| 总部 | Denver, Colorado |
| CEO | Alex Karp |
| 成立年份 | 2003 |
| IPO | 2020 (Direct Listing) |
| 市值 | ~$325B |
| 股价 | ~$132 |
| 员工数 | ~4,500 |

## 业务描述

Palantir 提供企业级数据分析与 AI 平台，两大核心产品:
- **Gotham**: 政府情报分析 (国防、情报机构)
- **Foundry**: 商业数据分析 (金融、医疗、制造)
- **AIP (Artificial Intelligence Platform)**: AI Agent 平台 (2023年推出)

## 关键财务数据

| 指标 | FY2024 | FY2025 | FY2026E | YoY |
|------|--------|--------|---------|-----|
| Revenue ($M) | 2,225 | 2,866 | 3,850 | +34% |
| Commercial Revenue | 1,080 | 1,462 | 2,855 | **+95%** |
| US Commercial | 640 | 960 | 2,240 | **+133%** |
| Government Revenue | 1,145 | 1,404 | 1,650 | +18% |
| Gross Margin | 80.4% | 81.2% | 82.0% | +80bp |
| Operating Margin | 18.5% | 24.5% | 30.0% | +550bp |
| FCF Margin | 22.0% | 26.0% | 30.0% | +400bp |

## 管理层

### Alex Karp — Co-Founder & CEO
- Stanford Law PhD, co-founded Palantir in 2003
- Visionary leader focused on AI/defense mission
- Unique management philosophy ("The Philosophical CEO")

### Shyam Sankar — CTO
- Early employee, oversees product strategy
- Drives AIP platform development
- Background: Stanford CS

### Ryan Taylor — CFO
- Focus on rule of 40+ performance
- Margin expansion track record

## 竞争格局

| 竞争者 | 定位 | 优势 | 劣势 |
|--------|------|------|------|
| Snowflake | Data Cloud | 规模+生态 | 不做AI Agent |
| Databricks | Lakehouse AI | 开源+ML | 缺少政府业务 |
| C3.ai | Enterprise AI | 先发者 | 规模较小 |
| Microsoft | Azure AI | 分发+规模 | 非垂直整合 |
| Accenture | AI Services | 咨询+实施 | 非产品公司 |

## 投资论点

### Bull Points
1. AIP 平台爆发式增长: US Commercial +133% YoY
2. 政府业务稳健: 国防预算增长 + AI 优先
3. 利润率快速提升: Operating margin 从 18% → 30%
4. Rule of 40: Growth + Margin > 64%

### Bear Points
1. 估值极高: P/E >200x, EV/Rev >85x
2. 客户集中: Top 10 客户占 >30% 收入
3. 限售股解禁风险: 内部人持续减持
4. AI Agent 竞争加剧: 大厂进入

## 估值

| 方法 | 隐含股价 | 说明 |
|------|---------|------|
| DCF (30x terminal Rev) | $145 | 假设5年50% CAGR |
| EV/Revenue (40x FY27E) | $125 | 成长股溢价 |
| P/S (35x FY27E) | $110 | SaaS premium |
| **目标价** | **$130** | |

## Sources
- [Palantir 10-K](https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&company=palantir&type=10-K)
- [Palantir IR](https://investors.palantir.com/)
- [Yahoo Finance PLTR](https://finance.yahoo.com/quote/PLTR/)
