# IB09: Data Pack — M&A Due Diligence
## [DATA SOURCE: NVIDIA FY2026 financials as example, standard DD checklist]

> Project: Project Atlas | 日期: 2026-05-09

## 数据包索引

### 1. 财务数据 (Financial)

| # | 类别 | 文件 | 页数/文件数 | 状态 |
|---|------|------|-----------|------|
| 1.1 | 审计财务报表 | 3年 audited P&L, BS, CF | 15 pages | ✅ |
| 1.2 | 月度管理报表 | LTM monthly P&L by segment | 36 files | ✅ |
| 1.3 | 收入明细 | By product, customer, geography | 10 files | ✅ |
| 1.4 | 成本结构 | COGS, OpEx, headcount detail | 5 files | ✅ |
| 1.5 | 资本支出 | 3Y history + 2Y budget | 3 files | ✅ |
| 1.6 | 营运资金 | Monthly WC schedule | 12 files | ✅ |
| 1.7 | 债务/融资 | Credit agreements, terms | 8 files | ✅ |
| 1.8 | 预算/预测 | FY2027-2028 management plan | 4 files | ✅ |

**示例数据 (NVDA FY2026 as reference):**

| 指标 | FY2024 | FY2025 | FY2026 |
|------|--------|--------|--------|
| Revenue ($B) | 60.9 | 130.5 | 215.9 |
| Gross Profit ($B) | 44.0 | 97.0 | 162.9 |
| Operating Income ($B) | 17.5 | 78.6 | 144.6 |
| Net Income ($B) | 29.8 | 72.8 | 126.2 |
| Total Assets ($B) | 65.3 | 86.7 | — |

### 2. 商业数据 (Commercial)

| # | 类别 | 内容 | 状态 |
|---|------|------|------|
| 2.1 | 客户名单 | Top 50 客户, 行业, ACV | ✅ |
| 2.2 | 合同摘要 | Top 20 合同, 条款, 到期 | ✅ |
| 2.3 | 管线 | Sales pipeline by stage | ✅ |
| 2.4 | 竞争分析 | Market share, positioning | ✅ |
| 2.5 | 定价策略 | Price list, discount matrix | ✅ |
| 2.6 | 渠道 | Partner agreements, economics | ✅ |

### 3. 技术/产品 (Technology)

| # | 类别 | 内容 | 状态 |
|---|------|------|------|
| 3.1 | 技术架构 | System architecture docs | ✅ |
| 3.2 | IP/专利 | Patent portfolio (12 patents) | ✅ |
| 3.3 | 产品路线图 | 2026-2028 roadmap | ✅ |
| 3.4 | 开发流程 | SDLC, CI/CD, DevOps | ✅ |
| 3.5 | 第三方依赖 | OSS licenses, vendor risk | ✅ |
| 3.6 | 安全/合规 | SOC2, ISO27001, pen tests | ✅ |

### 4. 法律 (Legal)

| # | 类别 | 内容 | 状态 |
|---|------|------|------|
| 4.1 | 公司文件 | Certificate of Inc, Bylaws | ✅ |
| 4.2 | 股权结构 | Cap table, option pool | ✅ |
| 4.3 | 重大合同 | Top 20 contracts | ✅ |
| 4.4 | 诉讼 | Active/threatened claims | ✅ |
| 4.5 | 监管 | Compliance status | ✅ |
| 4.6 | 知识产权 | Trademarks, copyrights | ✅ |

### 5. 人力 (Human Resources)

| # | 类别 | 内容 | 状态 |
|---|------|------|------|
| 5.1 | 组织架构 | Org chart, headcount by dept | ✅ |
| 5.2 | 关键员工 | Top 20 profiles, contracts | ✅ |
| 5.3 | 薪酬 | Compensation bands, equity | ✅ |
| 5.4 | 福利 | Benefits summary, 401k | ✅ |
| 5.5 | 离职率 | Voluntary/involuntary trends | ✅ |

### 6. 税务 (Tax)

| # | 类别 | 内容 | 状态 |
|---|------|------|------|
| 6.1 | 税务申报 | 3Y federal + state returns | ✅ |
| 6.2 | 转移定价 | Transfer pricing documentation | ✅ |
| 6.3 | 税务属性 | NOLs, credits, attributes | ✅ |
| 6.4 | 税务争议 | Open audits/issues | ✅ |

## Sources
- Standard IB due diligence data request list (bulge bracket format)
- [NVIDIA FY2026 10-K](https://investor.nvidia.com/) (as financial data example)
- Deloitte/PWC DD methodology guides
