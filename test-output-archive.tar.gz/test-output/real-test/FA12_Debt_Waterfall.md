# FA12: Debt Waterfall — Hypothetical NVDA Acquisition
## [DATA SOURCE: LCD, Bloomberg leveraged finance data, FRED rates]

> 分析日期: 2026-05-09 | 假设性 $200B LBO

## 债务层级 (Waterfall)

| 优先级 | 层级 | 金额 ($B) | 利率 | 年利息 ($B) | 偿还优先级 | 预期回收率 |
|--------|------|----------|------|-----------|-----------|-----------|
| 1 | Revolving Credit | 10.0 | SOFR+200 (6.4%) | 0.64 | First | 100% |
| 2 | Term Loan A | 40.0 | SOFR+300 (7.4%) | 2.96 | Second | 95-100% |
| 3 | First Lien Senior Secured | 80.0 | 6.50% fixed | 5.20 | Third | 80-90% |
| 4 | Senior Unsecured Notes | 30.0 | 7.50% fixed | 2.25 | Fourth | 40-60% |
| 5 | Subordinated Notes | 20.0 | 9.00% + PIK | 1.80 | Fifth | 20-40% |
| 6 | Mezzanine/Preferred | 20.0 | 11.00% + PIK | 2.20 | Last | 10-25% |
| **Total** | | **200.0** | **Blended 7.5%** | **15.05** | | |

## 利息覆盖倍数 (by tranche)

| 层级 | EBITDA/利息 | (EBITDA-CapEx)/利息 | 维持测试 |
|------|-----------|-------------------|---------|
| All Debt | 9.3x | 8.3x | 通过 (>2.0x) |
| Senior Secured (1-3) | 14.4x | 12.9x | 通过 (>2.5x) |
| Senior + Unsecured (1-4) | 11.7x | 10.4x | 通过 (>2.0x) |

## 违约情景 — 回收分析

### 情景: EBITDA 下降 50% (从 $140.5B 到 $70.3B)

| 层级 | 本金 ($B) | 累计覆盖 | 回收率 | 回收金额 ($B) | 损失 ($B) |
|------|----------|---------|--------|-------------|---------|
| Revolver | 10.0 | $70.3B | 100% | 10.0 | 0 |
| TLA | 40.0 | $60.3B | 100% | 40.0 | 0 |
| 1st Lien | 80.0 | ($59.7B) | 75% | 10.3 | 69.7 |
| Senior Unsec | 30.0 | — | 15% | 4.5 | 25.5 |
| Subordinated | 20.0 | — | 0% | 0 | 20.0 |
| Mezzanine | 20.0 | — | 0% | 0 | 20.0 |

## 债务偿还时间表

| Year | FCF ($B) | Mandatory Amort | 偿还层级 | 剩余总债务 ($B) |
|------|----------|----------------|---------|---------------|
| Year 1 | 50.0 | TLA 5% ($2B) | TLA → 1st Lien | 148.0 |
| Year 2 | 55.0 | TLA 5% ($2B) | 1st Lien | 91.0 |
| Year 3 | 60.0 | — | 1st Lien → Sr Unsec | 31.0 |
| Year 4 | 65.0 | — | Sr Unsec → Sub | 0 |
| Year 5 | 70.0 | — | All repaid | 0 |

## Sources
- [FRED SOFR](https://fred.stlouisfed.org/series/SOFR)
- LCD Leveraged Commentary & Data (S&P Global)
- Bloomberg Leveraged Finance
