[DATA SOURCE: ARM Holdings FY2026 Results (newsroom.arm.com), NVIDIA FY2026 10-K (sec.gov), Trading Economics, Yahoo Finance, Macrotrends -- All data as of May 2026]

# Merger Model: Hypothetical Acquisition of ARM Holdings by NVIDIA

## Transaction Overview

| Parameter | Value |
|---|---|
| **Acquirer** | NVIDIA Corporation (NASDAQ: NVDA) |
| **Target** | ARM Holdings plc (NASDAQ: ARM) |
| **Hypothetical Announcement Date** | May 2026 |
| **Transaction Type** | 100% Stock-for-Stock Merger |
| **Expected Close** | Q4 FY2027 (subject to regulatory approval) |

> **Note:** NVIDIA previously attempted to acquire ARM from SoftBank for $40B in September 2020; the deal was abandoned in February 2022 due to regulatory opposition. This hypothetical model uses current 2026 market data for illustrative M&A modeling purposes.

---

## Valuation Summary

| Metric | NVIDIA (Acquirer) | ARM Holdings (Target) |
|---|---|---|
| **Share Price (May 2026)** | ~$115.00 | ~$215.00 |
| **Shares Outstanding** | 24,490M | 1,043M |
| **Market Capitalization** | ~$2,816B | ~$224B |
| **FY Total Revenue** | $215.9B | $4.92B |
| **Revenue YoY Growth** | +65% | +23% |
| **P/E Ratio (TTM)** | ~41x | ~290x |
| **EV/Revenue** | ~13.0x | ~45.5x |
| **EV/EBITDA** | ~33x | ~155x |

## Offer Pricing

| Item | Value |
|---|---|
| **Offer Price per Share** | $260.00 (20.9% premium to market) |
| **Implied Equity Value** | $271.2B |
| **Implied Enterprise Value** | ~$263.5B (net of cash) |
| **Implied EV/Revenue (FY2026)** | 53.6x |
| **Implied EV/EBITDA** | ~175x |

## Exchange Ratio Analysis

| Scenario | Exchange Ratio | Implied Offer Price | Premium/(Discount) |
|---|---|---|---|
| Fixed Price @ $260 | 2.261x NVDA per ARM | $260.00 | +20.9% |
| Fixed Ratio (Median) | 2.000x NVDA per ARM | $230.00 | +7.0% |
| Fixed Ratio (High) | 2.400x NVDA per ARM | $276.00 | +28.4% |
| 52-Week High Collar | 1.90x - 2.35x | $218.50 - $270.25 | +1.6% to +25.7% |

## Pro Forma Financial Impact

### Revenue Synergy Assumptions

| Synergy Category | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|---|---|---|---|---|---|
| Cross-sell GPU+ARM bundles | $200M | $600M | $1,200M | $1,800M | $2,500M |
| Data Center TCO optimization | $100M | $350M | $700M | $1,100M | $1,500M |
| Automotive/Edge AI platform | $50M | $200M | $500M | $900M | $1,400M |
| License revenue uplift | $150M | $400M | $700M | $1,000M | $1,200M |
| **Total Revenue Synergies** | **$500M** | **$1,550M** | **$3,100M** | **$4,800M** | **$6,600M** |

### Cost Synergy Assumptions

| Category | Year 1 | Year 2 | Year 3 |
|---|---|---|---|
| SG&A consolidation | $100M | $250M | $350M |
| R&D efficiency (overlapping IP) | $80M | $200M | $300M |
| Infrastructure & G&A savings | $50M | $120M | $180M |
| **Total Cost Synergies** | **$230M** | **$570M** | **$830M** |

## Accretion / Dilution Analysis

### Pro Forma EPS Impact (100% Stock Deal)

| Metric | NVIDIA Standalone | Pro Forma Year 1 | Pro Forma Year 2 | Pro Forma Year 3 |
|---|---|---|---|---|
| **Net Income** | $74.3B | $71.8B | $80.5B | $92.1B |
| **Shares Outstanding** | 24,490M | 24,490M | 24,490M | 24,490M |
| **Diluted EPS** | $3.03 | $2.93 | $3.29 | $3.76 |
| **Accretion/(Dilution)** | -- | **-3.3%** | **+8.6%** | **+24.1%** |

### Breakeven Analysis

| Scenario | Required ROIC | Breakeven Year |
|---|---|---|
| Base Case (100% synergies) | 4.8% | Year 2 |
| No Revenue Synergies | 6.2% | Year 3 |
| No Synergies | 8.5% | Year 5+ |
| 50% Cash / 50% Stock (5% cost of debt) | 5.1% | Year 2 |

## Pro Forma Capital Structure

| Item | NVIDIA Standalone | Pro Forma (Stock Deal) |
|---|---|---|
| **Total Debt** | $8.5B | $8.5B |
| **Total Cash** | $43.0B | $46.5B |
| **Net Debt** | ($34.5B) | ($38.0B) |
| **Total Equity** | $157.3B | $428.5B |
| **Debt/Total Cap** | 5.1% | 1.9% |
| **Net Debt/EBITDA** | (0.4x) | (0.3x) |

## Key Regulatory & Risk Considerations

1. **Antitrust**: Prior FTC opposition to NVIDIA-ARM deal (2020-2022) remains key precedent
2. **China Regulatory**: SAMR approval uncertain; ARM licenses critical to Chinese semiconductor ecosystem
3. **UK National Security**: Investment & Security Act review likely; ARM is UK-headquartered
4. **EU Competition**: EC Phase II investigation expected; remedies may include ARM IP licensing commitments
5. **Customer Concentration Risk**: Qualcomm, Apple, Samsung as ARM licensees may object
6. **Integration Risk**: ARM's licensing model must remain perceived as neutral by licensees

## Sources

- ARM Holdings FY2026 Q4 Results: https://newsroom.arm.com/news/arm-holdings-plc-reports-results-for-the-fourth-quarter-and-fiscal-year-ended-2026
- NVIDIA FY2026 10-K Filing: https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm
- ARM Market Capitalization: https://tradingeconomics.com/arm:us:market-capitalization
- NVIDIA P/E Ratio: https://www.macrotrends.net/stocks/charts/NVDA/nvidia/pe-ratio
- ARM Shareholder Letter: https://investors.arm.com/static-files/344cbcfe-e28b-48ab-b272-c856e0755a91
- NVIDIA Q4 FY2026 Press Release: http://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-fourth-quarter-and-fiscal-2026
