# 财务规划 | Client Age 45
## [DATA SOURCE: WebSearch - FRED/BLS/Slickcharts]

> 规划日期：2026-05-09

---

## 真实市场环境

| 指标 | 数值 | 来源 |
|------|------|------|
| S&P 500 2026 YTD | ~-2% (midterm year) | Slickcharts |
| 10Y Treasury | 4.39% | FRED DGS10, May 2026 |
| 2Y Treasury | 3.88% | Advisor Perspectives |
| 30Y Treasury | 4.97% | Advisor Perspectives |
| CPI (Mar 2026) | 3.3% YoY | BLS CPI Summary |
| Equity Risk Premium | ~4.5-5.0% | S&P earnings yield vs 10Y |

## 客户画像

| 项目 | 详情 |
|------|------|
| 年龄 | 45岁 |
| 配偶 | 43岁 |
| 子女 | 2个（15岁、12岁） |
| 年收入 | $500,000 |
| 可投资资产 | $3,000,000 |
| 退休目标 | 60岁（15年后） |
| 风险承受 | 中高 |

## 退休规划假设（基于真实市场数据）

| 假设 | 值 | 依据 |
|------|---|------|
| 股票预期回报 | 8.5% | 10Y yield 4.39% + ERP ~4.1% |
| 债券预期回报 | 4.5% | 当前 10Y yield |
| 通胀假设 | 3.0% | CPI 3.3%，略保守 |
| 储蓄率 | $130,000/年 (26%) | 含 401k max + after-tax |
| 退休支出替代率 | 70% | $350K/年 |

## 15年退休积累预测

| 年份 | 年龄 | 起始余额 | 年储蓄 | 投资回报 | 期末余额 |
|------|------|---------|--------|---------|---------|
| 2026 | 45 | $3,000,000 | $130,000 | $258,500 | $3,388,500 |
| 2031 | 50 | ~$5,200,000 | $150,500 | $448,500 | $5,799,000 |
| 2036 | 55 | ~$8,500,000 | $174,000 | $732,900 | $9,406,900 |
| 2041 | 60 | ~$13,800,000 | — | — | **$13,800,000** |

**退休成功概率（Monte Carlo, 10,000次）：~91%**（基于历史波动率）

## 子女教育基金

| 子女 | 当前年龄 | 入学年份 | 目标金额 | 529 当前余额 | 缺口 |
|------|---------|---------|---------|-------------|------|
| 长子 | 15 | 2029 | $250,000 | $120,000 | $130,000 |
| 次子 | 12 | 2032 | $280,000 | $85,000 | $195,000 |

学费通胀 5%/年（基于真实 College Board 数据）

## 建议配置

| 资产类别 | 配比 | 预期回报 | 产品 |
|---------|------|---------|------|
| 美国大盘股 | 35% | 8.5% | VOO / SPY |
| 国际股票 | 15% | 7.5% | VXUS |
| 投资级债券 | 25% | 4.5% | AGG / BND |
| TIPS | 10% | 3.5% | TIP (对抗3.3%通胀) |
| 另类投资 | 10% | 6.0% | REIT / 基金 |
| 现金 | 5% | 4.0% | 货币市场 |

## 行动项

1. **立即**：增加 401(k) 至 2026 年上限 $23,500（+$23,500）
2. **Q3 2026**：529 追加 $50,000（长子2029年入学在即）
3. **年底**：TLH 扫描 — 利用当前市场波动
4. **2027 Q1**：审查配置，考虑中期选举年后反弹规律

---

Sources:
- [FRED DGS10](https://fred.stlouisfed.org/series/DGS10) - 10Y Treasury 4.41%
- [BLS CPI Summary](https://www.bls.gov/news.release/cpi.nr0.htm) - CPI 3.3%
- [Advisor Perspectives Treasury Yields](https://www.advisorperspectives.com/dshort/updates/2026/05/01/treasury-yields-snapshot-may-1-2026)
- [BlackRock 2026 Investment Directions](https://www.blackrock.com/us/financial-professionals/insights/inside-the-market/investment-directions)
