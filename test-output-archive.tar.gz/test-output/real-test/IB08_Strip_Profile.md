# IB08: Management Presentation Strip Profile
## [DATA SOURCE: Standard IB sell-side presentation format, bulge bracket template]

> 项目: Project Atlas | 日期: 2026-05-09

## 演示结构 (Sell-Side Management Presentation)

### Slide 1: 封面 (Title Slide)
- 公司名称 (保密)
- "管理团队演示"
- 日期: June 2026
- "Confidential — For Authorized Recipients Only"

### Slide 2: 议程 (Agenda)
1. 公司概述 (Company Overview)
2. 市场机会 (Market Opportunity)
3. 产品与技术 (Products & Technology)
4. 财务表现 (Financial Performance)
5. 增长战略 (Growth Strategy)
6. 投资亮点 (Investment Highlights)

### Slides 3-5: 公司概述 (Company Overview)
| 内容 | 要点 |
|------|------|
| 公司历史 | 里程碑时间线 (2018-2026) |
| 使命愿景 | "AI-first enterprise platform" |
| 业务模式 | SaaS订阅 (90%) + 服务 (10%) |
| 全球布局 | HQ San Jose, 办公室 London/Singapore/Tokyo |

### Slides 6-8: 市场机会 (Market Opportunity)
| 内容 | 要点 |
|------|------|
| TAM/SAM/SOM | TAM $210B → SAM $30B → SOM $5B |
| 市场驱动 | AI推理需求 + 多云部署 + 合规 |
| 竞争格局 | 碎片化市场, 前5名 <30% 份额 |

### Slides 9-12: 产品与技术 (Products & Technology)
| 内容 | 要点 |
|------|------|
| 产品架构 | 3层平台: Compute → Deploy → Edge |
| 技术壁垒 | 12项专利, 独有优化算法 |
| Roadmap | 2026 H2: Edge AI 2.0; 2027: Quantum-ready |
| Demo | Live product demonstration |

### Slides 13-18: 财务表现 (Financial Performance)

#### 关键财务摘要
| 指标 | FY2024 | FY2025 | FY2026E | FY2027E |
|------|--------|--------|---------|---------|
| Revenue ($M) | 155 | 220 | 320 | 450 |
| ARR ($M) | 180 | 260 | 380 | 530 |
| Gross Margin | 78% | 80% | 82% | 83% |
| EBITDA ($M) | (8) | 18 | 58 | 95 |
| FCF ($M) | (12) | 11 | 38 | 70 |

#### Unit Economics
- LTV: $1.4M (3.5yr avg life × $400K ARPU)
- CAC: $280K
- LTV/CAC: 5.0x
- CAC Payback: 14 months

### Slides 19-22: 增长战略 (Growth Strategy)
| 支柱 | FY2027-2029 目标 |
|------|----------------|
| 有机增长 | Product expansion + new segments |
| 地理扩张 | EMEA +40%, APAC +60% |
| 渠道建设 | MSSP partners → 30% of new ARR |
| M&A | 2-3个tuck-in acquisitions |

### Slides 23-25: 投资亮点 (Investment Highlights)
1. **市场定位**: AI基础设施赛道, 34% CAGR
2. **增长质量**: NRR 135% + 50% YoY
3. **利润路径**: Rule of 40 → 60+ (growth + margin)
4. **团队**: 连续创业者 + 业界顶级CTO
5. **退出路径**: 多个战略/PE买家已表达兴趣

## Sources
- Standard IB presentation template (Goldman Sachs / Morgan Stanley format)
- Real SaaS company financial benchmarks
- Gartner market sizing
