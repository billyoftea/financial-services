[DATA SOURCE: Preqin Global Reports 2026 (preqin.com), Bain & Company Global PE Report 2026 (bain.com), S&P Global Market Intelligence PE Dry Powder Data, McKinsey Global Private Markets Report 2026 (mckinsey.com), IQ-EQ Global Private Markets Predictions 2026, Chronograph PE Dealmaking Trends 2026]

# Deal Sourcing -- Pipeline Report
## Growth Equity Fund IV | AI Infrastructure Sector Thesis

**Report Date:** May 9, 2026

---

## 1. Market Context

### Global PE Industry Overview (Q1 2026)

| Metric | Value | Source |
|--------|-------|--------|
| Global PE dry powder | ~$2.18T (PE-specific) | S&P Global / Preqin, Q1 2025 |
| Total private capital dry powder | $4.63T | Preqin via Yahoo Finance, Q2 2025 |
| PE-specific dry powder | $1.66T | Preqin / Paul Weiss, Q1 2025 |
| Global buyout deal value (2025) | $904B (+44% YoY) | McKinsey |
| Median PE purchase multiple | 11.8x EBITDA (2025) | McKinsey |
| PE-backed companies globally | 8,000+ | Preqin estimate |
| 2026 dry powder outlook | Year-on-year increase expected | Preqin Global Reports 2026 |

*Note: PE dry powder has slightly receded from all-time highs amid slow fundraising, but total private capital dry powder continues to grow, surpassing $4.6T globally by mid-2025. Preqin predicts year-on-year increases in alternatives AUM and dry powder for 2026.*

### Key Industry Themes (Bain PE Report 2026)

- **"12 is the new 5"**: Deals now require ~10-12% annual EBITDA growth for 2.5x MOIC (vs. ~5% historically)
- **Multiple expansion era over**: Value creation shifted from financial engineering to operating excellence
- **$3.8 trillion** in unsold portfolio value sitting in PE portfolios globally
- **Hyper-competitive era**: GPs must generate genuine operational and EBITDA growth
- **Defense, AI infrastructure, carve-outs** are top PE deal themes for 2026 (Chronograph)

---

## 2. Sector Thesis: AI Infrastructure

### Why AI Infrastructure?

| Factor | Rationale |
|--------|-----------|
| Market size | AI infrastructure market growing 30%+ CAGR through 2030 |
| Structural demand | Data center buildout, GPU compute, AI networking, model training platforms |
| PE applicability | Recurring revenue models emerging; infrastructure assets have predictable cash flows |
| Exit potential | Strategic acquirers (hyperscalers, semiconductor companies) actively buying |
| Dry powder allocation | AI captured nearly two-thirds of all VC deal value in 2025 (Alvarez & Marsal) |
| Valuation window | Early-stage PE entry multiples (10-15x EBITDA) vs. later-stage (20-25x) |

---

## 3. Deal Flow Pipeline Summary

### Pipeline Overview (as of May 2026)

| Stage | Count | Aggregate EV Range | Avg. Revenue | Avg. EBITDA Margin |
|-------|-------|-------------------|--------------|---------------------|
| **Initial Review** | 12 | $300M-$2B | $180M | 18% |
| **Active Diligence** | 4 | $500M-$1.5B | $320M | 25% |
| **LOI / Negotiation** | 2 | $750M-$1.2B | $450M | 30% |
| **Under LOI** | 1 | $1.1B | $520M | 28% |
| **Closed (YTD 2026)** | 1 | $850M | $380M | 26% |

---

## 4. Proprietary Deal Flow Sources

### Source Classification

| Source Type | Deals Sourced (TTM) | Conversion Rate | Avg. Entry Multiple |
|-------------|-------------------|-----------------|---------------------|
| **Proprietary / Direct Outreach** | 8 | 12% | 11.5x EBITDA |
| **Management Referrals** | 5 | 20% | 12.0x EBITDA |
| **Portfolio Co. Networks** | 4 | 15% | 10.5x EBITDA |
| **Intermediary / Bank-led** | 15 | 8% | 13.5x EBITDA |
| **Auction / Broad Process** | 6 | 5% | 14.5x EBITDA |

### Key Intermediary Relationships

| Bank / Advisor | Relationship Tier | Deals Closed (3yr) | Active Mandates |
|---------------|-------------------|-------------------|-----------------|
| Goldman Sachs TMT | Tier 1 | 3 | 2 |
| JP Morgan Technology | Tier 1 | 2 | 1 |
| Lazard Mid-Market | Tier 1 | 2 | 3 |
| Houlihan Lokey | Tier 2 | 1 | 2 |
| William Blair | Tier 2 | 1 | 1 |
| Raymond James Tech | Tier 2 | 0 | 2 |
| Lincoln International | Tier 2 | 1 | 1 |

---

## 5. Active Pipeline (Top 5 Opportunities)

| Rank | Target (Codename) | Sector | EV ($M) | Revenue ($M) | EBITDA Margin | Stage | Source |
|------|-------------------|--------|---------|--------------|---------------|-------|--------|
| 1 | Project Nova | AI Infrastructure / Data Center | 1,100 | 520 | 28% | Under LOI | Proprietary |
| 2 | Project Mercury | Cybersecurity (Cloud-native) | 750 | 310 | 24% | LOI Negotiation | Intermediary |
| 3 | Project Atlas | Enterprise AI Platform | 1,200 | 480 | 22% | Active DD | Management Referral |
| 4 | Project Titan | AI Observability | 550 | 210 | 18% | Active DD | Direct Outreach |
| 5 | Project Apollo | AI Chip Design Tools | 900 | 350 | 32% | Initial Review | Auction |

---

## 6. Sector Coverage Map

| Sub-Sector | Targets Screened | Meetings Held | DD Initiated | LOI Submitted |
|------------|-----------------|---------------|--------------|---------------|
| AI Infrastructure / Compute | 35 | 12 | 3 | 1 |
| Cloud-Native Security | 28 | 8 | 2 | 1 |
| AI Observability / Monitoring | 22 | 6 | 1 | 0 |
| Enterprise AI Platforms | 18 | 5 | 1 | 0 |
| AI Chip Design / Semis | 12 | 3 | 0 | 0 |
| **Total** | **115** | **34** | **7** | **2** |

---

## 7. Funnel Metrics (TTM)

| Metric | Value |
|--------|-------|
| Total companies screened | 340 |
| Management meetings held | 62 |
| Confidential Information Memorandum (CIM) reviewed | 85 |
| Preliminary indications of interest submitted | 14 |
| Active due diligence processes | 7 |
| Letters of intent submitted | 4 |
| Deals closed | 2 |
| **Pipeline conversion rate** (screened to closed) | **0.6%** |
| **LOI to close rate** | **50%** |

---

## 8. Fund Deployment Status

| Metric | Amount ($M) | % of Fund |
|--------|-------------|-----------|
| Total Fund Size | 3,000 | 100% |
| Capital Called | 1,200 | 40% |
| Deployed (Investments) | 950 | 32% |
| Committed (Under LOI) | 300 | 10% |
| Dry Powder (Available) | 1,800 | 60% |
| Management Fees (Reserve) | 250 | 8% |

---

## Sources

- Preqin: "Global Private Capital Outlook 2026" and "PE Global Report 2025" (preqin.com) -- PE-specific dry powder $1.66-1.68T; total private capital dry powder $4.63T
- S&P Global Market Intelligence: "PE Dry Powder Recedes from All-Time Highs" (Dec 2025) -- $2.184T as of Q1 2025
- Paul Weiss: "PE Fundraising at a Glance Q3 2025" -- PE dry powder $1.658T, 25% of AUM
- Bain & Company: "Global Private Equity Report 2026" (bain.com) -- "12 is the new 5"; $3.8T unsold portfolio value
- McKinsey: "Global Private Markets Report 2026" (mckinsey.com) -- Median PE purchase multiple 11.8x; buyout deal value $904B (+44%)
- IQ-EQ: "Global Private Markets Predictions for 2026" (iqeq.com)
- Chronograph: "Top Private Equity Dealmaking Trends in 2026" (chronograph.pe)
- Alvarez & Marsal: "Software/Tech PE Outlook 2026" (alvarezandmarsal.com) -- AI captured 2/3 of VC deal value in 2025
