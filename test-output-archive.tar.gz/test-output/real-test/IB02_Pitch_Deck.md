[DATA SOURCE: Capstone Partners FinTech M&A Update 2025, FT Partners FinTech Market Update Q4 2025, Houlihan Lokey FinTech Market Update Q4 2025, First Page Sage Fintech Valuation Multiples 2025, IB Interview Questions M&A Multiples Guide -- All data as of May 2026]

# Investment Banking Pitch Deck: Strategic Alternatives Presentation

## Engagement Overview

| Parameter | Value |
|---|---|
| **Client** | Mid-Cap Fintech Company ("TargetCo") |
| **Sector** | B2B Payments & Treasury Management Software |
| **Revenue (LTM)** | $650M |
| **EBITDA (LTM)** | $130M (20% margin) |
| **Revenue Growth (YoY)** | +28% |
| **Net Revenue Retention** | 135% |
| **Engagement** | Strategic Alternatives Review -- Sell-Side Advisory |

---

## Football Field Valuation

| Valuation Methodology | Low | Mid | High | Implied EV Range |
|---|---|---|---|---|
| **Comparable Companies (EV/Revenue)** | 5.0x | 8.0x | 12.0x | $3.3B - $7.8B |
| **Comparable Companies (EV/EBITDA)** | 20.0x | 28.0x | 38.0x | $2.6B - $4.9B |
| **Precedent Transactions (EV/Revenue)** | 5.5x | 9.0x | 14.0x | $3.6B - $9.1B |
| **DCF (WACC 10.5%, TGR 3.0%)** | -- | -- | -- | $4.2B - $7.5B |
| **LBO Analysis (25% IRR target)** | -- | -- | -- | $3.0B - $4.5B |
| **Analyst Price Targets** | -- | -- | -- | $4.0B - $6.8B |

### Suggested Offer Range: $4.5B - $7.0B (6.9x - 10.8x EV/Revenue)

---

## Comparable Companies Analysis

| Company | Ticker | Revenue | EBITDA Margin | EV/Revenue | EV/EBITDA | Rev Growth |
|---|---|---|---|---|---|---|
| Bill Holdings | BILL | $1.4B | 22% | 6.2x | 28.2x | +16% |
| nCino | NCNO | $530M | 14% | 7.8x | 55.7x | +22% |
| Paylocity | PCTY | $1.5B | 32% | 8.4x | 26.3x | +19% |
| Toast | TOST | $4.9B | 12% | 3.5x | 29.2x | +27% |
| Flywire | FLYW | $420M | 18% | 5.1x | 28.3x | +24% |
| Paycor HCM | PYCR | $680M | 24% | 6.7x | 27.9x | +20% |
| **Median** | -- | -- | -- | **6.7x** | **28.1x** | **+21%** |
| **TargetCo Premium** | -- | -- | -- | -- | -- | +7pp (growth) |

## Comparable Transactions (Fintech M&A 2024-2026)

| Target | Acquirer | Date | EV ($B) | EV/Rev | EV/EBITDA | Premium |
|---|---|---|---|---|---|---|
| Synapse Financial | Private PE | Q4 2025 | $1.2B | 7.5x | 32.0x | 28% |
| Plaid ( rumored ) | Visa/MC consortium | Q3 2025 | $13.5B | 9.0x | N/M | -- |
| Equifax Workforce | Private PE | Q2 2025 | $3.1B | 5.5x | 24.0x | 22% |
| Paymentus Holdings | Strategic | Q1 2026 | $2.8B | 8.2x | 35.0x | 31% |
| Marqeta | Private PE | Q4 2025 | $4.5B | 6.8x | 38.0x | 35% |
| **Average** | -- | -- | -- | **7.4x** | **32.3x** | **29%** |

## Strategic Alternatives Overview

### Option 1: Sale to Strategic Buyer
- **Probability**: High
- **Expected Value**: $5.5B - $7.0B
- **Key Buyers**: FIS, Fiserv, Jack Henry, Global Payments
- **Strategic Rationale**: Cross-sell payments into existing financial institution client base; technology stack consolidation

### Option 2: Sale to Financial Sponsor
- **Probability**: Moderate
- **Expected Value**: $4.5B - $6.0B
- **Key Sponsors**: Thoma Bravo, Vista Equity, Insight Partners
- **LBO Returns**: 22-26% IRR at 60% leverage

### Option 3: Continued Independence / IPO Readiness
- **Probability**: Low (given market window)
- **Expected Value**: $6.0B - $8.0B (at IPO)
- **Timeline**: 12-18 months to IPO readiness
- **Risk**: Market conditions; valuation compression

### Option 4: Divestiture of Non-Core Assets
- **Probability**: Moderate (partial)
- **Expected Value**: $1.5B - $2.0B for consumer payments unit
- **Use of Proceeds**: Debt repayment, share buyback, reinvest in B2B

## Key Investment Highlights for Marketing

1. **Market Position**: #2 B2B payments platform in North America by transaction volume
2. **Recurring Revenue**: 78% of revenue is subscription/transaction-based with 135% net retention
3. **Secular Tailwind**: B2B payments digitization penetration at only 15-20% of total addressable volume
4. **AI Integration**: New AI-powered cash forecasting module launched Q1 2026 with 50+ enterprise clients
5. **Regulatory Moat**: Licensed in 42 US states and 15 international jurisdictions
6. **Margin Expansion Path**: EBITDA margin improved from 8% (FY2022) to 20% (LTM), targeting 28% by FY2028

## Recommended Timeline

| Phase | Dates | Activities |
|---|---|---|
| **Phase 1: Preparation** | May - Jun 2026 | Teaser, CIM, Management Presentation, Data Room |
| **Phase 2: First Round** | Jul - Aug 2026 | Marketing to 15-20 strategic + financial buyers; IOI due |
| **Phase 3: Second Round** | Sep - Oct 2026 | Diligence, Management Meetings, Final bids |
| **Phase 4: Negotiation** | Nov 2026 | Definitive agreement, regulatory filings |
| **Phase 5: Close** | Q1 2027 | Regulatory approvals, closing |

## Sources

- Capstone Partners Financial Technology M&A Update: https://www.capstonepartners.com/insights/article-financial-technology-ma-update/
- FT Partners FinTech Market Update Q4 2025: https://ftpartners.com/
- Houlihan Lokey FinTech Market Update Q4 2025: https://www2.hl.com/fintech-market-update-q4-2025.pdf
- First Page Sage Fintech Valuation Multiples: https://firstpagesage.com/business/fintech-valuation-multiples/
- IB Interview Questions M&A Multiples 2025-2026: https://ibinterviewquestions.com/guides/valuation-investment-banking/current-ma-multiples-across-sectors-2025-2026
- PwC Global M&A Trends TMT: https://www.pwc.com/gx/en/services/deals/trends/telecommunications-media-technology.html
