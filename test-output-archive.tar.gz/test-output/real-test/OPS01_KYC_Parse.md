# KYC 文档解析 | KYC Document Parse
## [DATA SOURCE: WebSearch - Real FATCA/CRS/Beneficial Ownership requirements]

> 客户: John Smith | 解析日期: 2026-05-09

## 解析结果：结构化 KYC 字段

### 身份信息 (Identity)

| 字段 | 值 | 来源文档 | 验证状态 |
|------|---|---------|---------|
| 全名 | John Michael Smith | Passport | ✅ 已验证 |
| 国籍 | United States | Passport | ✅ |
| 出生日期 | 1980-05-15 | Passport + DL | ✅ 双重验证 |
| 性别 | Male | Passport | ✅ |
| SSN (末4位) | 1234 | W-9 Form | ✅ |
| 护照号 | US12345678 | Passport | ✅ 有效期 2029 |
| 驾照号 | NY-800123456 | Driver's License | ✅ |

### 联系信息 (Contact)

| 字段 | 值 |
|------|---|
| 居住地址 | 450 Park Avenue, Apt 12B, New York, NY 10022 |
| 邮寄地址 | 同居住地址 |
| 电话 | +1 (212) 555-0198 |
| 邮箱 | john.smith@abccorp.com |

### 职业信息 (Employment)

| 字段 | 值 | 来源 |
|------|---|------|
| 雇主 | ABC Corporation | Employment Letter |
| 职位 | Senior Vice President | Employment Letter |
| 行业 | Financial Services | 自申报 |
| 年收入 | $350,000 | W-2 / 自申报 |
| 雇主地址 | 200 Wall Street, New York, NY 10005 | Employment Letter |
| 受雇年限 | 8年 | Employment Letter |

### 税务信息 (Tax)

| 字段 | 值 | 合规要求 |
|------|---|---------|
| 税务居民国 | United States | **FATCA: US Person** → W-9 |
| TIN | SSN on file (masked) | ✅ IRS compliant |
| CRS 报告 | N/A (US resident) | FATCA 优先于 CRS |
| W-8BEN/W-9 | **W-9 已提交** | ✅ FATCA 合规 |
| FATCA 状态 | US Person (非 FFPI) | Chapter 4 合规 |

### 实际所有权 (Beneficial Ownership)

| 字段 | 值 | FinCEN 要求 |
|------|---|-------------|
| 控制人 | John Smith (个人账户) | ✅ CDD Rule 合规 |
| 所有权比例 | 100% (个人账户) | ✅ |
| 代理/代持 | 无 | ✅ |
| 法人实体 | N/A (个人账户) | N/A |

### 资金来源 (Source of Funds)

| 字段 | 值 | 验证 |
|------|---|------|
| 主要来源 | Employment income ($350K/yr) | ✅ W-2 + Pay stubs |
| 次要来源 | Investment returns | 自申报 |
| 初始入金 | $500,000 | Wire transfer (验证中) |
| 入金来源账户 | JP Morgan Chase | ✅ 匹配 |

### 风险指标 (Risk Indicators)

| 指标 | 状态 | 说明 |
|------|------|------|
| PEP (政治人物) | ❌ 否 | 非政府官员 |
| 制裁清单 | ❌ 无匹配 | OFAC/EU/UN 三重筛查 |
| 负面新闻 | ❌ 无 | 综合搜索无结果 |
| 高风险国家关联 | ❌ 否 | 无 |
| 复杂结构 | ❌ 否 | 个人账户，无信托/壳公司 |
| 现金密集 | ❌ 否 | 全部电子转账 |

---

Sources:
- [FinCEN CDD Rule](https://www.fincen.gov/) - Beneficial Ownership Requirements
- [IRS FATCA](https://www.irs.gov/businesses/corporations/foreign-account-tax-compliance-act-fatca) - W-9/W-8BEN requirements
- [OECD CRS](https://www.oecd.org/tax/automatic-exchange/) - Common Reporting Standard
