# FA06: LBO Model — Hypothetical NVDA Take-Private
## [DATA SOURCE: NVIDIA FY2026 financials, FRED SOFR, Bloomberg LCD]

> 分析日期: 2026-05-09 | 假设性交易

## 交易假设

| 参数 | 值 | 说明 |
|------|-----|------|
| 目标公司 | NVIDIA Corp (NVDA) | 假设性 |
| 收购价格 | $150.00/share | ~41% premium to ~$106 |
| 股权价值 | $3,673.5B | 24.49B shares |
| 净债务 | $8.5B | Existing |
| 企业价值 | $3,682.0B | |
| Entry EV/EBITDA | ~26.2x | Based on FY2026 EBITDA $140.5B |
| 资本结构 | 70% Debt / 30% Equity | |

## 债务结构

| 层级 | 金额 ($B) | 占比 | 利率 | 年利息 |
|------|----------|------|------|--------|
| Revolver | $100.0 | 3.9% | SOFR + 200bp (~6.38%) | $6.4B |
| Term Loan A | $500.0 | 19.4% | SOFR + 300bp (~7.38%) | $36.9B |
| Senior Secured Notes | $1,000.0 | 38.9% | 6.50% fixed | $65.0B |
| Senior Unsecured | $500.0 | 19.4% | 7.50% fixed | $37.5B |
| Subordinated/Mezz | $374.7 | 14.6% | 9.00% + PIK | $33.7B |
| **Total Debt** | **$2,474.7B** | **96.3%** | **Blended ~7.3%** | **$179.5B** |
| Equity | $1,207.3B | 30% | — | — |

> Source: SOFR ~4.38% (FRED), leveraged loan spreads from LCD

## 5年退出回报

| 指标 | 假设 |
|------|------|
| EBITDA 增长 | 10% CAGR (FY2027-2031) |
| 退出 EV/EBITDA | 20.0x (vs 26.2x entry) |
| 债务偿还 | $600B from FCF over 5 years |
| 终端企业价值 | $4,530B |
| 终端净债务 | $1,874.7B |
| 终端股权价值 | $2,655.3B |
| **MOIC** | **2.2x** |
| **IRR** | **~17.1%** |

## 可行性评估

| 因素 | 评估 |
|------|------|
| 交易规模 | 极大 ($3.7T) — 史无前例 |
| 融资可行性 | 不现实 — 最大LBO记录为~$60B |
| 监管风险 | CFIUS/反垄断审查极严 |
| 管理层意愿 | Huang unlikely to sell |

## Sources
- NVIDIA FY2026 financials
- [FRED SOFR Rate](https://fred.stlouisfed.org/series/SOFR)
- Bloomberg LCD leveraged finance data
