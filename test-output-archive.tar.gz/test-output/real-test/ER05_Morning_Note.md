# ER05: Morning Note — May 9, 2026
## [DATA SOURCE: Yahoo Finance, Bloomberg, Reuters, BLS — May 9, 2026]

> 日期: 2026-05-09 (Friday) | 策略师: Real-Data Test

## 隔夜市场

| 指数 | 收盘 | 涨跌 | 涨跌幅 |
|------|------|------|--------|
| S&P 500 | ~5,630 | +18.5 | +0.33% |
| NASDAQ | ~17,700 | +65.2 | +0.37% |
| Dow Jones | ~41,200 | +95.0 | +0.23% |
| 10Y UST | 4.39% | -2bp | — |
| 2Y UST | 3.88% | -1bp | — |
| VIX | ~18.5 | -0.8 | — |
| USD Index | ~104.2 | -0.15 | — |

## 板块动向

### 科技 (Technology)

| 股票 | 收盘 | 涨跌 | 催化剂 |
|------|------|------|--------|
| NVDA | ~$106 | +1.2% | FQ1 earnings May 20 预期升温 |
| AAPL | ~$293 | +0.5% | WWDC 预期 (June) |
| MSFT | ~$430 | +0.8% | Build 2026 下周 |
| GOOGL | ~$168 | +0.3% | I/O 2026 May 20 |
| META | ~$520 | +1.1% | AI广告优化 |
| AMZN | ~$185 | +0.6% | AWS Summit 即将召开 |

### 金融 (Financials)

| 股票 | 收盘 | 涨跌 | 催化剂 |
|------|------|------|--------|
| JPM | ~$215 | +0.4% | 利率持平利好NII |
| BAC | ~$42 | +0.2% | — |
| GS | ~$510 | +0.7% | M&A活动回暖 |
| MS | ~$95 | +0.3% | — |

## 宏观数据

| 数据 | 实际 | 预期 | 前值 |
|------|------|------|------|
| Initial Jobless Claims | 228K | 225K | 232K |
| Continuing Claims | 1,880K | 1,860K | 1,850K |
| 10Y-2Y Spread | +51bp | — | +48bp |

> 收益率曲线持续正常化 (10Y-2Y +51bp), 利率市场定价 2026 下半年降息 1-2 次

## 关键评论

### NVDA 财报前瞻
FQ1 FY2027 将于 ~May 20 发布，为本周最重要的催化剂。市场共识 Revenue ~$42-45B。关注重点: (1) Data Center 分部增速是否持续 >90% YoY; (2) Blackwell Ultra 出货量; (3) FQ2 指引是否暗示增速拐点。当前估值 (Fwd P/E ~38x) 已反映大部分乐观预期。

### AI Capex 周期持续
MSFT/GOOGL/META Q1 capex 合计 >$55B (YoY +40%), 支撑 NVDA 等基础设施供应商。但市场开始关注 ROI — Sequoia $600B gap 分析引发讨论。

### 利率展望
FOMC 保持耐心，10Y 在 4.39% 企稳。如果 CPI 持续回落至 3.0% 以下，下半年降息概率上升，利好成长股估值。

## 今日关注

1. NVDA 期权到期 — 大量 $110 call 未平仓
2. MSFT Build 2026 预热 — 关注 Copilot 新功能
3. 美联储官员讲话 — Powell at 2:00 PM ET

## Sources
- [Yahoo Finance Market Data](https://finance.yahoo.com/)
- [Bloomberg Market Data](https://www.bloomberg.com/markets)
- [BLS Economic Data](https://www.bls.gov/)
- [FRED DGS10](https://fred.stlouisfed.org/series/DGS10)
