# FA15: Sum-of-the-Parts Valuation — NVIDIA (NVDA)
## [DATA SOURCE: NVIDIA FY2026 segment reporting, real market multiples]

> 分析日期: 2026-05-09

## 业务分部拆分

### FY2026 分部收入

| 分部 | 收入 ($B) | 占比 | YoY Growth | 描述 |
|------|----------|------|-----------|------|
| Data Center | 186.4 | 86.3% | +93% | GPU/AI训练+推理 |
| Gaming | 12.8 | 5.9% | +8% | GeForce GPU |
| Professional Visualization | 8.5 | 3.9% | +15% | RTX/Quadro |
| Automotive | 3.8 | 1.8% | +55% | Drive platform |
| OEM & Other | 4.4 | 2.0% | +5% | Chipset/IP |
| **Total** | **215.9** | **100%** | **+65%** | |

## 分部估值

| 分部 | 收入 ($B) | EBITDA ($B) | 适用倍数 | 倍数来源 | 分部EV ($B) |
|------|----------|------------|---------|---------|-----------|
| Data Center | 186.4 | 130.5 | 20x EV/EBITDA | AI infra peers | 2,610.0 |
| Gaming | 12.8 | 7.7 | 14x EV/EBITDA | Gaming peers (ATVI/TTWO) | 107.8 |
| Prof. Visualization | 8.5 | 5.5 | 18x EV/EBITDA | Enterprise SW peers | 99.0 |
| Automotive | 3.8 | 1.5 | 25x EV/Rev | Auto tech peers (MBLY) | 95.0 |
| OEM & Other | 4.4 | 1.0 | 12x EV/EBITDA | Commodity semi | 12.0 |
| **企业价值合计** | | | | | **2,923.8** |

## SOTP 估值汇总

| 项目 | 金额 ($B) |
|------|----------|
| (+) Data Center | 2,610.0 |
| (+) Gaming | 107.8 |
| (+) Prof. Visualization | 99.0 |
| (+) Automotive | 95.0 |
| (+) OEM & Other | 12.0 |
| **企业价值** | **2,923.8** |
| (+) 现金 | 43.2 |
| (-) 净债务 | (8.5) |
| **股权价值** | **2,958.5** |
| Shares outstanding | 24.49B |
| **每股价值** | **$120.8** |

## 分部溢价/折价分析

| 分部 | 独立可比 | 适用理由 |
|------|---------|---------|
| Data Center | AVGO, MRVL | AI定制芯片最高增长 |
| Gaming | Sony, AMD gaming | 成熟但稳定 |
| Prof. Vis | ADSK, DASSY | 专业工具软件 |
| Automotive | MBLY, ALV | 高增长自动驾驶 |
| Corporate | - | (-$15B HQ/overhead调整) |

## 与其他估值方法对比

| 方法 | 隐含股价 |
|------|---------|
| SOTP | $120.8 |
| DCF (Base) | $66.5 |
| Trading Comps (Median) | $117.6 |
| Precedent Transactions | $143.5 |
| **当前股价** | **~$106** |

## Sources
- NVIDIA FY2026 segment reporting (10-K)
- Yahoo Finance comparable multiples
- Dell'Oro data center market data
