[DATA SOURCE: Yahoo Finance, SaaS M&A Report 2026 (LinkedIn/SaasRise), PitchBook Q4 2025 Enterprise SaaS M&A Review, ClearlyAcquired EBITDA Multiples 2025-2026, Aventis Advisors SaaS Valuation Multiples, PwC US Deals 2026 Outlook -- All data as of May 2026]

# Strategic Buyer List: $5B Enterprise SaaS Target

## Target Profile

| Parameter | Value |
|---|---|
| **Target** | "CloudScale Inc." (Hypothetical) |
| **Sector** | Enterprise SaaS -- IT Operations Management |
| **Enterprise Value** | $5.0B (estimated) |
| **LTM Revenue** | $650M |
| **EBITDA** | $163M (25% margin) |
| **Revenue Growth** | +32% YoY |
| **Net Revenue Retention** | 140% |
| **Customers** | 2,800+ enterprise accounts |
| **ARR** | $710M |
| **Implied EV/Revenue** | 7.7x |
| **Implied EV/EBITDA** | 30.7x |

---

## Strategic Buyers

### 1. Microsoft Corporation (NASDAQ: MSFT)

| Metric | Value |
|---|---|
| **Market Cap** | ~$3.1T |
| **FY Revenue (LTM)** | $278B |
| **Operating Margin** | 44% |
| **Cash & Equivalents** | ~$78B |
| **Strategic Rationale** | Integration into Azure/Microsoft 365 ecosystem; expand IT operations management; bolster Dynamics/Intune platform |
| **Synergy Estimate** | $200-400M revenue synergies within 3 years via enterprise cross-sell |
| **Deal Size Feasibility** | Highly digestible ($5B = 0.2% of market cap) |
| **Likelihood** | HIGH -- Active SaaS acquirer (Nuance $19.7B, Activision $69B) |
| **Regulatory Risk** | Low-Moderate |

### 2. Oracle Corporation (NYSE: ORCL)

| Metric | Value |
|---|---|
| **Market Cap** | ~$440B |
| **FY Revenue (LTM)** | $57.4B |
| **Operating Margin** | 38% |
| **Cash & Equivalents** | ~$20B |
| **Strategic Rationale** | Bolster Oracle Cloud Infrastructure (OCI); expand SaaS portfolio beyond ERP/DB; compete with ServiceNow |
| **Synergy Estimate** | $150-300M via OCI integration and database cross-sell |
| **Deal Size Feasibility** | Manageable ($5B = 1.1% of market cap) |
| **Likelihood** | HIGH -- Acquired Cerner $28B, NetSuite $9.3B |
| **Regulatory Risk** | Low |

### 3. Salesforce Inc. (NYSE: CRM)

| Metric | Value |
|---|---|
| **Market Cap** | ~$265B |
| **FY Revenue (LTM)** | $38.6B |
| **Operating Margin** | 20% |
| **Cash & Equivalents** | ~$14B |
| **Strategic Rationale** | Expand beyond CRM into IT operations; enhance Service Cloud; compete with ServiceNow in ITSM |
| **Synergy Estimate** | $120-250M via Service Cloud integration |
| **Deal Size Feasibility** | Manageable ($5B = 1.9% of market cap) |
| **Likelihood** | MODERATE -- Focus on margin expansion post-activist investor pressure |
| **Regulatory Risk** | Low |

### 4. SAP SE (NYSE: SAP)

| Metric | Value |
|---|---|
| **Market Cap** | ~$310B |
| **FY Revenue (LTM)** | $38.2B |
| **Operating Margin** | 28% |
| **Cash & Equivalents** | ~$12B |
| **Strategic Rationale** | Enhance cloud IT operations; complement Rise with SAP; expand enterprise platform breadth |
| **Synergy Estimate** | $100-200M via S/4HANA and BTP integration |
| **Deal Size Feasibility** | Manageable ($5B = 1.6% of market cap) |
| **Likelihood** | MODERATE -- Acquired Qualtrics $8B (later spun), LeanIX $1.2B |
| **Regulatory Risk** | Low |

### 5. ServiceNow (NYSE: NOW)

| Metric | Value |
|---|---|
| **Market Cap** | ~$195B |
| **FY Revenue (LTM)** | $11.2B |
| **Operating Margin** | 30% |
| **Cash & Equivalents** | ~$8.5B |
| **Strategic Rationale** | Expand IT operations management depth; acquire complementary technology; defend against MSFT/ORCL encroachment |
| **Synergy Estimate** | $180-350M via platform integration and cross-sell |
| **Deal Size Feasibility** | Stretch ($5B = 2.6% of market cap), may require stock-heavy consideration |
| **Likelihood** | MODERATE-HIGH -- Strategic necessity to defend turf |
| **Regulatory Risk** | Low |

---

## Financial Sponsors

### 6. KKR & Co. Inc. (NYSE: KKR)

| Metric | Value |
|---|---|
| **AUM** | $624B |
| **PE Dry Powder** | ~$65B |
| **Recent SaaS Deals** | Barracuda Networks ($4.0B, 2022); EAB Group |
| **LBO Model** | 55% debt / 45% equity; target 22-25% IRR over 5-year hold |
| **Likelihood** | HIGH -- Active technology investor; large dry powder |

### 7. Blackstone Inc. (NYSE: BX)

| Metric | Value |
|---|---|
| **AUM** | $1.1T |
| **PE Dry Powder** | ~$75B |
| **Recent SaaS Deals** | Aon's benefits administration ($4.8B); Psifact Capital |
| **LBO Model** | 50% debt / 50% equity; target 20-24% IRR |
| **Likelihood** | MODERATE-HIGH -- Increasing tech/SaaS focus |

### 8. Thoma Bravo

| Metric | Value |
|---|---|
| **AUM** | $166B |
| **Recent SaaS Deals** | SailPoint ($6.9B, 2022); ForgeRock ($2.3B, 2022); Coupa ($6.2B, 2023) |
| **LBO Model** | 55-60% debt; target 25-30% IRR over 4-5 year hold |
| **Likelihood** | HIGH -- Premier SaaS-focused PE; strong track record in $3-10B range |

### 9. Vista Equity Partners

| Metric | Value |
|---|---|
| **AUM** | $100B+ |
| **Recent SaaS Deals** | Citrix ($16.5B, 2022); Avalara ($8.4B, 2022) |
| **LBO Model** | 50-55% debt; target 20-25% IRR; operational value creation playbook |
| **Likelihood** | HIGH -- Enterprise SaaS is core competency; strong operational model |

---

## Buyer Prioritization Matrix

| Buyer | Strategic Fit | Financial Capacity | Likelihood | Expected Valuation | Priority |
|---|---|---|---|---|---|
| Microsoft | Excellent | Unlimited | High | $5.5-7.0B | Tier 1 |
| Oracle | Excellent | Strong | High | $5.0-6.5B | Tier 1 |
| ServiceNow | Very Good | Good | Moderate-High | $5.0-6.0B | Tier 1 |
| Thoma Bravo | Good | Strong | High | $4.5-5.5B | Tier 1 |
| Vista Equity | Good | Strong | High | $4.5-5.5B | Tier 1 |
| KKR | Good | Very Strong | High | $4.5-5.5B | Tier 2 |
| Salesforce | Moderate | Good | Moderate | $5.0-6.0B | Tier 2 |
| SAP | Moderate | Good | Moderate | $4.5-5.5B | Tier 2 |
| Blackstone | Moderate | Unlimited | Moderate | $4.0-5.0B | Tier 2 |

## Current SaaS M&A Market Context (2026)

| Metric | Value |
|---|---|
| **Total SaaS M&A Deals (2025)** | 2,698 (+28% YoY) |
| **Total SaaS Deal Value (2025)** | ~$180B |
| **Mega-Deals (>$2.5B) in 2025** | 17 |
| **Public SaaS EV/Revenue Median** | 6.1x |
| **Private SaaS EV/Revenue** | 4.7x |
| **Private SaaS EBITDA Multiple** | 22.4x |
| **NTM Revenue Multiple (Current)** | 5.4x |
| **PE Dry Powder (Global)** | $2.6T |

## Sources

- Yahoo Finance -- MSFT, ORCL, CRM, SAP, NOW stock data: https://finance.yahoo.com/
- SaaS M&A Report 2026: https://www.saasmag.com/saas-consolidation-ma-wave-2026/
- PitchBook Q4 2025 Enterprise SaaS M&A Review: https://pitchbook.com/news/reports/q4-2025-enterprise-saas-ma-review
- ClearlyAcquired EBITDA Multiples 2025-2026: https://www.clearlyacquired.com/blog/ebitda-multiples-for-saas-and-software-companies-2025-2026
- Aventis Advisors SaaS Valuation Multiples: https://aventis-advisors.com/saas-valuation-multiples/
- PwC US Deals 2026 Outlook: https://www.pwc.com/us/en/services/consulting/deals/outlook.html
- SaasRise Private SaaS M&A Q1 2026: https://www.saasrise.com/blog/private-saas-m-a-deals-q1-2026-report
