# FA11: Credit Rating Assessment — NVIDIA (NVDA)
## [DATA SOURCE: S&P Global rating criteria, NVIDIA FY2026 financials]

> 评估日期: 2026-05-09

## S&P 评级框架对比

### 经营风险评估

| 因素 | NVDA 评分 | 说明 |
|------|----------|------|
| 行业风险 | 低 (1) | 半导体增长行业，AI驱动 |
| 国家风险 | 低 (1) | 美国，制度完善 |
| 竞争地位 | 极强 (1) | GPU市场>80%份额 |
| 规模 | 极大 | $215.9B revenue |
| **经营风险 Profile** | **Excellent** | |

### 财务风险评估

| S&P 指标 | NVDA实际 | AAA阈值 | AA阈值 | A阈值 | BBB阈值 |
|----------|---------|---------|--------|-------|---------|
| FFO/Debt | >1,000% | >60% | 45-60% | 30-45% | 20-30% |
| Debt/EBITDA | 0.06x | <0.5x | 0.5-1.0x | 1.0-2.0x | 2.0-3.0x |
| Debt/Debt+Equity | 13% | <15% | 15-25% | 25-35% | 35-45% |
| FCF/Debt | >900% | >40% | 25-40% | 15-25% | 10-15% |
| Interest Coverage | 234x | >25x | 15-25x | 8-15x | 4-8x |

### 隐含评级结果

| 框架 | 隐含评级 |
|------|---------|
| 经营风险 | "aaa" range |
| 财务风险 | "aaa" range |
| **综合锚定** | **AA+** |
| 可比评级 | **A+ (实际)** |

## 评级差异分析

| 因素 | 影响 | 说明 |
|------|------|------|
| 盈利波动性 | 负面 | 半导体周期性，历史上收入波动大 |
| 客户集中度 | 负面 | Top 5客户占收入>40% |
| 技术迭代风险 | 负面 | AI硬件竞争加剧 |
| 净现金位置 | 正面 | $34.7B net cash |
| FCF增长 | 正面 | FY2026 FCF $96.7B |

## 评级展望

| 情景 | 概率 | 目标评级 |
|------|------|---------|
| AI需求持续强劲 | 60% | AA- (upgrade) |
| 增长放缓至15-20% | 30% | A+ (maintain) |
| 半导体下行周期 | 10% | A (downgrade) |

## Sources
- [S&P Global Ratings Criteria](https://www.spglobal.com/ratings/en/criteria)
- NVIDIA FY2026 financials
- S&P RatingsDirect research
