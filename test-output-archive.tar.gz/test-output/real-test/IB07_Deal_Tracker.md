# IB07: Deal Tracker — Active M&A Pipeline
## [DATA SOURCE: Mergermarket, Dealogic 2026, SEC filings]

> 更新日期: 2026-05-09

## 活跃交易跟踪

| # | 项目 | 行业 | 阶段 | EV ($B) | 目标交割 | 买方类型 |
|---|------|------|------|---------|---------|---------|
| 1 | Project Atlas | AI/Tech | Phase 2 DD | 5.0 | Q3 2026 | PE |
| 2 | Project Diamond | Fintech | IOI received | 10.0 | Q4 2026 | Strategic |
| 3 | Project Shield | Cybersecurity | Data Room | 3.5 | Q3 2026 | Strategic |
| 4 | Project Mercury | SaaS | Teaser sent | 5.5 | Q4 2026 | Both |
| 5 | Project Nova | Healthcare IT | Pre-launch | 2.0 | Q1 2027 | PE |

## 交易详情

### Project Atlas (AI Infrastructure)
| 项目 | 详情 |
|------|------|
| 目标 | AI基础设施平台公司 |
| 买方 | Top-tier PE fund |
| EV/Revenue | 10x (FY2026E) |
| EV/EBITDA | 25x |
| 竞争态势 | 3家进入第二轮 |
| 监管 | 无重大障碍 |
| 进度 | DD进行中，7/31 final bid |

### Project Diamond (Fintech)
| 项目 | 详情 |
|------|------|
| 目标 | B2B支付平台 |
| 战略买家 | Top 5 global payments company |
| PE买家 | 2家mega-fund |
| 初步报价范围 | $8.5-11.5B |
| 关键风险 | 监管 (money transmitter licenses) |
| 进度 | 3家提交IOI，准备管理层会议 |

## 市场环境 (2026 M&A)

| 指标 | 2025 | 2026 YTD | 趋势 |
|------|------|----------|------|
| 全球M&A交易额 | $3.5T | $1.2T (thru Apr) | ↑ |
| 美国M&A | $1.8T | $650B | ↑ |
| Tech M&A占比 | 28% | 32% | ↑ |
| 平均EV/EBITDA | 14.5x | 15.8x | ↑ |
| PE-backed M&A | $850B | $320B | → |
| Cross-border | $1.2T | $380B | ↑ |

> 2026年M&A市场回暖，主要受 AI/科技交易驱动。利率企稳 + 股市上涨提振交易信心。

## 月度Pipeline 价值

| 月份 | 新交易 | 推进 | 交割 | Pipeline总值 ($B) |
|------|--------|------|------|-------------------|
| Jan 2026 | 2 | — | — | 8.5 |
| Feb 2026 | 1 | 3 | 1 | 15.0 |
| Mar 2026 | 3 | 2 | — | 22.5 |
| Apr 2026 | 1 | 4 | 1 | 25.5 |
| **May 2026** | **0** | **2** | **—** | **25.5** |

## Sources
- [Mergermarket 2026](https://www.mergermarket.com/)
- [Dealogic M&A Analytics](https://www.dealogic.com/)
- SEC 8-K/DEFM14A filings
- PitchBook Global M&A Report
