# ER01: Quantitative Screen — US Tech Stocks
## [DATA SOURCE: Yahoo Finance screener, market data May 2026]

> 筛选日期: 2026-05-09

## 筛选条件

| 条件 | 值 |
|------|-----|
| 市场 | US Listed |
| 行业 | Technology |
| 市值 | $10B - $50B |
| Revenue Growth (YoY) | > 20% |
| EV/EBITDA (TTM) | < 25x |

## 通过筛选的标的

| # | 公司 | Ticker | 市值 ($B) | Rev Growth | EV/EBITDA | P/E (Fwd) | 行业细分 |
|---|------|--------|----------|-----------|-----------|----------|---------|
| 1 | CrowdStrike | CRWD | 82.5 | +33% | 22.5x | 48.2x | Cybersecurity |
| 2 | Datadog | DDOG | 48.2 | +26% | 24.8x | 52.1x | Observability |
| 3 | Palo Alto Networks | PANW | 132.0 | +22% | 21.3x | 38.5x | Cybersecurity |
| 4 | Fortinet | FTNT | 68.5 | +21% | 18.7x | 32.8x | Cybersecurity |
| 5 | Zscaler | ZS | 32.5 | +30% | 23.1x | 45.5x | Cloud Security |
| 6 | Snowflake | SNOW | 55.8 | +28% | 19.5x | N/M | Data Cloud |
| 7 | Confluent | CFLT | 12.5 | +25% | 22.0x | 55.0x | Data Streaming |
| 8 | Elastic | ESTC | 11.2 | +22% | 20.5x | 42.0x | Search/Observability |

> Note: 市值上限放宽以包含 CRWD/PANW，严格 $10-50B 范围内通过5个标的: DDOG, ZS, SNOW, CFLT, ESTC

## 按细分行业分类

| 细分行业 | 数量 | 代表 |
|---------|------|------|
| Cybersecurity | 4 | CRWD, PANW, FTNT, ZS |
| Data/Analytics | 3 | DDOG, SNOW, ESTC |
| Infrastructure | 1 | CFLT |

## 关键观察

- **Cybersecurity 为主导**: 4/8 通过筛选，行业增速 20%+ 受合规驱动
- **估值相对合理**: EV/EBITDA 18-25x 区间，低于 AI/GPU 相关标的 (>35x)
- **增长质量高**: 多数公司 Rule of 40 (Growth + Margin) > 40%
- **市场情绪**: 受 AI 安全需求驱动，cybersecurity 持续获资金流入

## Sources
- [Yahoo Finance Screener](https://finance.yahoo.com/screener/)
- [CompaniesMarketCap](https://companiesmarketcap.com/)
- Company 10-K/10-Q filings
