[DATA SOURCE: McKinsey PE Practice DD Frameworks, Deloitte "Prepare and Execute the Deal" DD Guide, PwC "Due Diligence for Mergers and Acquisitions", Alexander Group "PE DD Checklist", Apex Leaders "PE DD Best Practices", E78 Partners "Key Considerations for PE DD"]

# Due Diligence Meeting Preparation
## Management Meeting with Target Company -- Project Shield

**Meeting Date:** June 2, 2026
**Target:** CyberShield Technologies (cybersecurity platform)
**Deal Stage:** Confirmatory Due Diligence
**Attendees:** Deal Team, Operating Partners, Target CEO, CFO, CTO, CRO

---

## 1. Meeting Objectives

1. Validate investment thesis on market positioning and competitive moat
2. Assess management team capability, alignment, and retention risk
3. Deep-dive on revenue quality, customer dynamics, and growth levers
4. Understand technology architecture, AI roadmap, and technical debt
5. Identify red flags and key risks requiring follow-up diligence
6. Gauge cultural fit and change management readiness

---

## 2. Key Questions by Workstream

### 2.1 Financial Questions (CEO + CFO)

| # | Question | What to Listen For |
|---|----------|-------------------|
| F1 | Walk us through the EBITDA bridge from FY2024 to FY2025. What drove the margin expansion? | Quality of earnings; sustainability of improvements vs. one-time items |
| F2 | What is your net revenue retention rate by customer cohort (Enterprise, Mid-Market, SMB)? | Cohort degradation = red flag; target 115%+ for enterprise |
| F3 | How do you think about the Rule of 40 trade-off between growth and profitability? | Balanced approach; should demonstrate path to 45%+ |
| F4 | What is the average contract length, and what percentage of ARR is multi-year? | Visibility and predictability; target 60%+ multi-year |
| F5 | Walk us through your top 10 customers. What is the revenue concentration risk? | No single customer >10% of revenue; diversification trend |
| F6 | What is your FCF conversion rate, and how should we think about capex going forward? | Target 70%+ FCF conversion; growth vs. maintenance capex clarity |
| F7 | How do you model the impact of AI investment on your P&L over the next 3 years? | Should show ROI timeline; watch for open-ended spend commitments |

### 2.2 Commercial / Growth Questions (CEO + CRO)

| # | Question | What to Listen For |
|---|----------|-------------------|
| C1 | How do you win against CrowdStrike and Palo Alto Networks in competitive deals? | Clear differentiation; should not claim to "outspend" platforms |
| C2 | What is your CAC by channel, and which channels have the highest LTV? | CAC payback <18 months; direct sales vs. partner mix |
| C3 | Describe your land-and-expand motion. What is the average time to $1M ARR for a new customer? | Time-to-expand metric; watch for overly optimistic claims |
| C4 | What percentage of your pipeline is generated inbound vs. outbound? | Inbound >40% indicates market pull; pure outbound = execution risk |
| C5 | How are you responding to the trend toward platform consolidation (CRWD, PANW acquiring point solutions)? | Should have vertical or mid-market niche strategy |
| C6 | What is your pricing model, and when did you last increase prices? | Pricing power evidence; should show ability to raise without churn |
| C7 | Walk us through your international expansion strategy. What % of revenue is international today? | Growth optionality; watch for over-reliance on single geography |

### 2.3 Technology Questions (CTO)

| # | Question | What to Listen For |
|---|----------|-------------------|
| T1 | Describe your software architecture. How much technical debt exists, and what is the remediation plan? | Microservices orientation preferred; >20% eng time on tech debt = concern |
| T2 | What is your AI/ML strategy? How are you integrating AI into the product today? | Concrete use cases (not aspirational); data moat narrative |
| T3 | How do you handle cloud infrastructure costs? What is your COGS trajectory? | Should show cloud cost optimization path; margin expansion from infra efficiency |
| T4 | What is your security posture? Walk us through your last SOC 2 audit and pen test results. | Zero critical vulnerabilities; clean SOC 2 report |
| T5 | How do you manage open-source dependencies and license compliance? | OSS inventory maintained; no copyleft license risk |
| T6 | What is your engineering team turnover rate, and who are the irreplaceable technical leaders? | Eng turnover <15%; identify 2-3 key persons requiring retention packages |
| T7 | How does your product roadmap align with customer demand and competitive dynamics? | Customer-driven roadmap (not tech-for-tech's-sake); 18-month visibility |

### 2.4 People / Culture Questions (CEO)

| # | Question | What to Listen For |
|---|----------|-------------------|
| P1 | How would you describe the company culture? How has it changed as you scaled from $50M to $200M+ revenue? | Self-awareness about scaling challenges; not just "we're a family" |
| P2 | What is your voluntary turnover rate by department? Where are the retention challenges? | Overall <12% voluntary; sales turnover <20% |
| P3 | How do you plan to operate under PE ownership? What concerns do you have? | Openness to change; operational rigor mindset |
| P4 | If you had an additional $50M to invest in the business, where would you allocate it? | Alignment with PE value creation thesis |
| P5 | Who on your team would you NOT want to lose, and what are you doing to retain them? | Honest assessment; concrete retention strategies |

---

## 3. Red Flags to Watch

### Critical Red Flags (Potential Deal-Breakers)

| Category | Red Flag | Severity |
|----------|----------|----------|
| **Financial** | EBITDA propped up by unsustainable cost cuts or one-time items | High |
| **Financial** | Customer churn accelerating in recent quarters | High |
| **Commercial** | Losing >40% of competitive bake-offs to CRWD/PANW | High |
| **Commercial** | Revenue growth entirely dependent on a single product | High |
| **Technology** | Monolithic architecture requiring full rewrite to scale | High |
| **Technology** | No AI roadmap or capability in a market demanding AI-native solutions | Medium |
| **People** | CEO/CFO reluctant to commit to 5-year plan under PE ownership | High |
| **People** | Key engineering leaders have competing offers or expressed intent to leave | Medium |
| **Culture** | Defensive or evasive responses to probing questions | High |
| **Governance** | Undisclosed related-party transactions or conflicts of interest | High |

### Yellow Flags (Require Follow-Up)

| Category | Flag | Follow-Up Action |
|----------|------|------------------|
| Revenue | 2-3 large enterprise deals account for >30% of new bookings | Request customer-level detail |
| Margins | Gross margin compression in most recent quarter | Assess COGS drivers |
| Competition | New entrant winning deals in core segment | Commission competitive DD |
| Talent | Sales leadership turnover in last 12 months | Reference calls with departed leaders |
| Product | Major product release delayed by >6 months | Technical DD deep-dive |

---

## 4. Meeting Agenda

| Time | Session | Participants | Duration |
|------|---------|-------------|----------|
| 9:00-9:30 | Welcome and introductions | Full group | 30 min |
| 9:30-10:30 | Company overview and strategy | CEO | 60 min |
| 10:30-11:30 | Financial deep-dive | CFO | 60 min |
| 11:30-12:00 | Break | -- | 30 min |
| 12:00-1:00 | Working lunch: Product demo | CTO + Product | 60 min |
| 1:00-2:00 | Commercial strategy and sales pipeline | CRO | 60 min |
| 2:00-2:30 | Technology and AI roadmap | CTO | 30 min |
| 2:30-3:00 | People, culture, and organization | CEO + CHRO | 30 min |
| 3:00-3:30 | Break | -- | 30 min |
| 3:30-4:30 | Q&A with deal team (all executives) | Full group | 60 min |
| 4:30-5:00 | Closing remarks and next steps | CEO + Deal Lead | 30 min |

---

## 5. Follow-Up Items Template

| # | Request | Owner | Deadline | Status |
|---|---------|-------|----------|--------|
| 1 | Customer-level revenue and retention detail (cohort analysis) | Target CFO | June 6 | |
| 2 | Full cap table and option grant history | Target CFO | June 6 | |
| 3 | Technical architecture documentation and tech debt assessment | Target CTO | June 6 | |
| 4 | Top 20 customer reference list (with contact authorization) | Target CRO | June 4 | |
| 5 | Employee engagement survey results (most recent) | Target CHRO | June 6 | |
| 6 | Competitive win/loss analysis (last 4 quarters) | Target CRO | June 6 | |
| 7 | Product roadmap with resource allocation and timeline | Target CTO | June 6 | |
| 8 | Full list of pending and threatened litigation | Target GC | June 4 | |
| 9 | Third-party security audit reports (SOC 2, pen test) | Target CISO | June 4 | |
| 10 | Detailed monthly financials (3-year historical + current year) | Target CFO | June 4 | |

---

## Sources

- McKinsey PE Practice: Due diligence frameworks and management meeting best practices (mckinsey.com)
- Deloitte Netherlands: "Prepare and Execute the Deal: Due Diligence" (deloitte.com/nl)
- PwC: "Due Diligence for Mergers and Acquisitions" (pwc.com)
- Alexander Group: "A Guide to Conducting Private Equity Due Diligence" (alexandergroup.com)
- Apex Leaders: "Private Equity Due Diligence: Best Practices for Investors" (apexleaders.com)
- E78 Partners: "Key Considerations for Private Equity Due Diligence" (e78partners.com)
- NMS Consulting: "PE DD Checklist: Value Levers, Risks" (nmsconsulting.com)
