# ER03: Investment Thesis Update — Apple (AAPL)
## [DATA SOURCE: Apple Q1 FY2026 earnings, market data May 2026]

> 更新日期: 2026-05-09 | 股价: ~$293

## 投资评级: OVERWEIGHT

| 指标 | 值 |
|------|-----|
| 当前股价 | ~$293 |
| 目标价 | $330 (+12.6% upside) |
| 市值 | ~$4.3T |
| P/E (Fwd) | ~34.8x |
| 股息率 | 0.5% |

## Bull Case (看多论点)

### 1. Apple Intelligence 推动 iPhone 升级超级周期
- iPhone 17 预计 2025年9月发布，深度整合 Apple Intelligence
- 安装基数 >22亿设备，大量 iPhone 12/13 用户进入升级窗口
- AI 功能 (Siri 2.0, Writing Tools, Image Playground) 成为差异化卖点

### 2. Services 持续高增长
- Q1 FY2026 Services 收入 $26B (+14% YoY)
- App Store, Apple Music, iCloud, Apple TV+, Apple Pay
- Services 毛利率 ~72% (vs Products ~37%), 利润率提升引擎
- 广告业务潜力巨大 (类似 GOOGL 模式)

### 3. 印度市场扩张
- 印度 iPhone 出货量 +25% YoY
- Mumbai/Delhi 零售店扩张
- TAM: 印度 14亿人口，智能手机渗透率 ~60%

## Bear Case (看空风险)

| 风险 | 影响 | 概率 |
|------|------|------|
| 中国市场竞争 | 华为/小米挤压份额 | 高 |
| EU DMA 合规成本 | App Store 收入受损 | 中 |
| AI 功能延迟/不足 | Siri 落后于 ChatGPT | 中 |
| 反垄断调查 (DOJ) | 搜索默认协议受限 | 低-中 |
| Vision Pro 销售低迷 | 新品类验证失败 | 低 |

## 估值

| 方法 | 目标价 | 权重 |
|------|--------|------|
| DCF (WACC 10%, TG 3.5%) | $345 | 40% |
| Trading Comps (P/E 35x) | $320 | 30% |
| SOTP (Services 40x + Products 22x) | $325 | 30% |
| **加权目标** | **$330** | |

## 关键催化剂

1. WWDC 2026 (Jun 2026) — iOS 20 / Apple Intelligence 2.0
2. iPhone 17 发布 (Sep 2026) — 升级周期验证
3. Q2 FY2026 财报 (Apr 2026) — Services 增长持续性
4. 印度市场数据 — 出货量/份额趋势

## 业绩追踪

| 指标 | Q1 FY2026 | vs 预期 | 趋势 |
|------|----------|---------|------|
| Revenue | $124.3B | Beat +2% | ↑ |
| iPhone Revenue | $46B | In-line | → |
| Services Revenue | $26B | Beat +4% | ↑ |
| EPS | $2.40 | Beat +3% | ↑ |
| Gross Margin | 46.8% | Beat +20bp | ↑ |

## Sources
- [Apple Q1 FY2026 Earnings](https://investor.apple.com/news/default.aspx)
- [Yahoo Finance AAPL](https://finance.yahoo.com/quote/AAPL/)
- Counterpoint Research India smartphone data
