[DATA SOURCE: SaaS Capital "Benchmarking Metrics for Bootstrapped SaaS Companies" 2026 (saas-capital.com), Bessemer Cloud Index, SaaS Hero "B2B SaaS LTV/CAC Benchmarks 2026" (saashero.net), Prospeo "SaaS CAC LTV Ratio 2026" (prospeo.io), G2 CFO "SaaS Benchmarks 2026" (gsquaredcfo.com), Averi "15 Essential SaaS Metrics 2026" (averi.ai), Eagle Rock CFO "SaaS Metrics Benchmarks" (eaglerockcfo.com)]

# Unit Economics Analysis -- SaaS Portfolio Company
## CloudPeak Technologies (Cloud Management Platform)

**Analysis Date:** May 9, 2026
**Parent Fund:** Growth Equity Fund IV
**Investment Date:** March 2024 | Investment: $150M (35% stake)

---

## 1. Executive Summary

CloudPeak demonstrates strong unit economics with an **LTV/CAC ratio of 3.8x**, above the 3.0x threshold for sustainable SaaS businesses. Net revenue retention of **118%** and gross margin of **82%** position the company in the top quartile of comparable SaaS companies. The primary improvement opportunity is CAC payback period, currently at 16 months vs. the elite benchmark of under 12 months.

**Key Benchmark Reference (2026 SaaS Industry):**
- LTV/CAC ratio: Minimum 3:1; Elite = 4:1-5:1 (SaaS Hero, Prospeo)
- Net Revenue Retention: Median ~102-103%; Top quartile ~111% (SaaS Capital)
- Gross Margin: 75%+ target; 80%+ elite (G2 CFO, Averi)
- CAC Payback: Under 12 months = survives downturns (Averi)

---

## 2. Core Unit Economics

### Current Metrics (Q1 2026)

| Metric | Current | Industry Benchmark | Top Quartile | Status |
|--------|---------|-------------------|-------------|--------|
| **LTV/CAC Ratio** | 3.8x | 3.0x minimum | 4.0-5.0x | Above Average |
| **CAC (Customer Acquisition Cost)** | $48,500 | Varies by ACV | <$35K | Needs Improvement |
| **LTV (Customer Lifetime Value)** | $184,300 | Varies | >$150K | Strong |
| **CAC Payback Period** | 16 months | <18 months | <12 months | Average |
| **Gross Margin** | 82% | 75%+ | 80%+ | Top Quartile |
| **Net Revenue Retention (NRR)** | 118% | 101%+ | 111%+ | Top Quartile |
| **Logo Churn (Annual)** | 8.2% | <10% | <5% | Average |
| **Revenue Churn (Annual)** | Net negative (NRR >100%) | -- | -- | Positive |
| **ARPU (Monthly)** | $4,850 | Varies | Growing | On Track |
| **Magic Number** | 0.85 | >0.75 | >1.0 | Average |

### Unit Economics Bridge

| Component | Value | Calculation |
|-----------|-------|-------------|
| ARPU (Monthly) | $4,850 | Revenue / Customers |
| Gross Margin | 82% | (Revenue - COGS) / Revenue |
| Monthly Churn Rate | 0.68% | 8.2% annual / 12 |
| Customer Lifetime (months) | 147 | 1 / 0.68% |
| LTV (Gross) | $584,690 | ARPU x Lifetime x Gross Margin |
| LTV (Net of Churn Cost) | $184,300 | Discounted at 10% for time value |
| CAC | $48,500 | S&M spend / New customers acquired |
| **LTV/CAC** | **3.8x** | LTV / CAC |

---

## 3. Cohort Analysis

### Annual Cohort Revenue Retention

| Cohort Year | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 | NRR (3-Year) |
|-------------|--------|--------|--------|--------|--------|-------------|
| 2021 | 100% | 112% | 118% | 115% | 110% | 118% |
| 2022 | 100% | 115% | 122% | 118% | -- | 122% |
| 2023 | 100% | 118% | 120% | -- | -- | 120% |
| 2024 | 100% | 116% | -- | -- | -- | 116% |
| 2025 | 100% | 120% (est.) | -- | -- | -- | -- |

**Key Insight:** Cohorts from 2022-2024 show improving NRR, reflecting successful land-and-expand motion and product improvements. The 2025 cohort is on track for 120%+ NRR driven by new AI-powered product features.

### Cohort by Customer Segment

| Segment | Logo Churn | NRR | Avg. ACV | CAC Payback | LTV/CAC |
|---------|-----------|-----|----------|-------------|---------|
| Enterprise (>$250K ACV) | 3.5% | 132% | $420K | 20 months | 5.2x |
| Mid-Market ($50-250K ACV) | 7.2% | 118% | $125K | 14 months | 3.6x |
| SMB ($10-50K ACV) | 18.5% | 95% | $28K | 10 months | 1.8x |
| **Blended** | **8.2%** | **118%** | **$105K** | **16 months** | **3.8x** |

**Key Insight:** Enterprise segment delivers exceptional economics (5.2x LTV/CAC, 132% NRR) but has the longest payback period. SMB segment has the worst unit economics with negative NRR (95%) and logo churn of 18.5%. Recommendation: Shift mix toward Enterprise and Mid-Market.

---

## 4. Margin Expansion Path

### Gross Margin Waterfall (Q1 2026)

| Component | % of Revenue | Trend |
|-----------|-------------|-------|
| Revenue | 100% | -- |
| Cloud Infrastructure (AWS/Azure/GCP) | -8.5% | Improving (optimization program) |
| Hosting & Data Center | -3.2% | Stable |
| Customer Support (Tier 1/2/3) | -4.8% | Improving (AI chatbot rollout) |
| Third-Party Licensing | -1.5% | Stable |
| **Gross Margin** | **82.0%** | **+200bps YoY** |

### Operating Margin Expansion Roadmap

| Period | Gross Margin | S&M % Rev | R&D % Rev | G&A % Rev | EBITDA Margin |
|--------|-------------|-----------|-----------|-----------|---------------|
| Q1 2026 (Actual) | 82.0% | 38% | 18% | 8% | 18% |
| Q4 2026 (Target) | 83.0% | 35% | 17% | 7% | 24% |
| Q4 2027 (Target) | 84.0% | 32% | 16% | 6% | 30% |
| Q4 2028 (Target) | 85.0% | 28% | 15% | 5% | 37% |

### Margin Expansion Drivers

| Driver | Gross Margin Impact | Timeline |
|--------|-------------------|----------|
| Cloud cost optimization (reserved instances, spot usage) | +150bps | 6 months |
| AI-powered customer support (reducing Tier 1 headcount) | +100bps | 12 months |
| Vendor consolidation and procurement negotiation | +50bps | 3 months |
| Product usage-based pricing (metered billing) | +200bps | 18 months |
| **Total Targeted Improvement** | **+500bps** | **18 months** |

---

## 5. SaaS Benchmarks Comparison

| Metric | CloudPeak | SaaS Capital Median | Top Quartile | Peer Average |
|--------|-----------|-------------------|-------------|-------------|
| Gross Margin | 82% | 75% | 82%+ | 78% |
| NRR | 118% | 102-103% | 111%+ | 108% |
| LTV/CAC | 3.8x | 3.0x | 4.0-5.0x | 3.2x |
| CAC Payback | 16 mo | 18 mo | <12 mo | 17 mo |
| Logo Churn | 8.2% | 10% | <5% | 9.5% |
| Rule of 40 | 43% | 30% | 50%+ | 35% |

---

## 6. Action Items for Unit Economics Improvement

| Priority | Initiative | Expected Impact | Timeline | Owner |
|----------|-----------|----------------|----------|-------|
| 1 | Reduce SMB customer mix from 25% to 15% of revenue | +200bps NRR, -3% logo churn | 12 months | CRO |
| 2 | Implement AI-powered onboarding to reduce time-to-value | -3 months CAC payback | 6 months | VP Product |
| 3 | Launch usage-based pricing for cloud management modules | +200bps gross margin | 12 months | VP Product / CFO |
| 4 | Optimize cloud infrastructure with reserved instances | -150bps COGS | 3 months | VP Engineering |
| 5 | Expand enterprise sales team (5 net new reps) | +$15M pipeline, +120bps NRR | 9 months | CRO |
| 6 | Deploy AI customer success tool for churn prediction | -2% logo churn | 6 months | VP CS |

---

## Sources

- SaaS Capital: "2026 Benchmarking Metrics for Bootstrapped SaaS Companies" (saas-capital.com) -- Median NRR 102-103%; top quartile 111%
- SaaS Hero: "Best LTV to CAC Ratio Benchmarks for B2B SaaS in 2026" (saashero.net) -- Minimum 3:1; elite 4:1+
- Prospeo: "SaaS CAC LTV Ratio: 2026 Benchmarks & Pitfalls" (prospeo.io) -- SaaS Capital NRR benchmarks by ACV
- G2 CFO: "SaaS Benchmarks: 5 Performance Benchmarks for 2026" (gsquaredcfo.com) -- Gross margin 75%+; NDR 101%+
- Averi: "3 SaaS Metrics That Matter More Than MRR in 2026" (averi.ai) -- CAC payback <12 months; 75%+ gross margin
- Eagle Rock CFO: "SaaS Metrics Benchmarks" (eaglerockcfo.com) -- LTV formula methodology
- Bessemer Cloud Index: BVP Nasdaq Emerging Cloud Index (cloudindex.bvp.com)
