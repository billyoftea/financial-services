# ER09: Earnings Analysis — Tesla (TSLA) Q1 2025
## [DATA SOURCE: Tesla Q1 2025 earnings release, 10-Q, Reuters, Bloomberg]

> 报告日期: 2026-05-09 | Q1 2025 (截至 Mar 2025)

## 结果摘要

| 指标 | 共识预期 | 实际 | 差异 | Beat/Miss |
|------|---------|------|------|-----------|
| Revenue | $21.5B | **$19.34B** | -$2.16B | **MISS (-10%)** |
| Automotive Revenue | $18.2B | **$16.8B** | -$1.4B | MISS (-7.7%) |
| Energy Revenue | $2.5B | **$2.73B** | +$0.23B | BEAT (+9.2%) |
| Services Revenue | $2.1B | **$2.25B** | +$0.15B | BEAT (+7.1%) |
| EPS (Non-GAAP) | $0.22 | **$0.27** | +$0.05 | **BEAT (+23%)** |
| Automotive GM | 16.0% | **14.6%** | -140bp | MISS |
| Total GM | 15.5% | **16.4%** | +90bp | BEAT |

## 分部分析

### Automotive

| 指标 | Q1 2025 | Q4 2024 | Q1 2024 | YoY |
|------|---------|---------|---------|-----|
| Revenue ($B) | 16.8 | 20.2 | 17.4 | -3.4% |
| Deliveries | 386,810 | 495,570 | 386,810 | 0% |
| ASP (est) | ~$43,500 | ~$40,700 | ~$45,000 | -3.3% |
| Automotive GM | 14.6% | 16.6% | 17.4% | -280bp |

**关键问题**: 交付量持平 YoY，降价 + Model Y 切换期影响

### Energy Storage

| 指标 | Q1 2025 | Q4 2024 | Q1 2024 | YoY |
|------|---------|---------|---------|-----|
| Revenue ($B) | 2.73 | 3.05 | 1.64 | +66.5% |
| Deployments (GWh) | 10.8 | 11.0 | 4.1 | +163% |

**亮点**: Energy 业务是最大惊喜，YoY +67%，成为增长引擎

## 盈利能力

| 指标 | Q1 2025 | Q4 2024 | YoY Change |
|------|---------|---------|-----------|
| Total GM | 16.4% | 16.6% | +20bp |
| Operating Margin | 5.2% | 7.8% | -180bp |
| R&D as % Rev | 4.3% | 4.1% | +40bp |
| SG&A as % Rev | 6.8% | 6.5% | +100bp |
| FCF ($B) | 0.5 | 3.2 | -84% |

## 管理层指引

| 项目 | 指引/评论 |
|------|---------|
| 2025 Deliveries | 回归增长 (+5-10% implied) |
| New Models | More affordable model on track (H1 2025) |
| FSD | Unsupervised FSD progress, robotaxi "June Austin" |
| Energy | Megapack demand > supply |
| Optimus | Limited production 2025, scale 2026+ |

## 投资论点影响

| 因素 | 影响 | 评级 |
|------|------|------|
| Auto margin 压缩 | 负面 | ⬇ |
| Energy 高增长 | 正面 | ⬆ |
| EPS beat (cost control) | 正面 | ⬆ |
| 交付量持平 | 负面 | ⬇ |
| Robotaxi 时间表 | 混合 | → |
| Affordable model | 正面 (如兑现) | ⬆ |

## 估值

| 方法 | 值 |
|------|-----|
| 当前股价 | ~$280 |
| Market Cap | ~$900B |
| EV/EBITDA (NTM) | ~55x |
| EV/Revenue (NTM) | ~7.5x |
| P/E (NTM) | ~95x |

> 估值高度依赖 FSD/Robotaxi 叙事。纯汽车业务不值当前估值。

## Sources
- [Tesla Q1 2025 Earnings Release](https://ir.tesla.com/)
- [Tesla Q1 2025 10-Q](https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&company=tesla&type=10-Q)
- [Reuters Tesla Coverage](https://www.reuters.com/business/autos-transportation/)
- [Bloomberg Tesla Analysis](https://www.bloomberg.com/quote/TSLA:US)
