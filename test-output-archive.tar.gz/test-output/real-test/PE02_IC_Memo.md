[DATA SOURCE: Gartner Cybersecurity Spending Forecast (gartner.com), McKinsey Global Private Markets Report 2026 (mckinsey.com), PitchBook PE Deal Data, Bain Global PE Report 2026 (bain.com), S&P Global Leveraged Finance Q1 2026 (spglobal.com), Chatham Financial SOFR Forecasts, CrowdStrike IR FY2026, Fortinet IR FY2025, Palo Alto Networks IR FY2025]

# Investment Committee Memorandum
## Proposed Acquisition: CyberShield Technologies
### $1.5B Leveraged Buyout | Cybersecurity Sector

**Date:** May 2026
**Classification:** Confidential -- Investment Committee Only

---

## 1. Transaction Summary

| Parameter | Detail |
|-----------|--------|
| **Target** | CyberShield Technologies (cybersecurity platform) |
| **Enterprise Value** | $1,500M |
| **Equity Check** | $600M (40% of EV) |
| **Total Debt** | $900M (60% of EV) |
| **Entry EV/EBITDA** | 20.0x (on LTM EBITDA of $75M) |
| **Entry EV/Revenue** | 6.8x (on LTM Revenue of $220M) |
| **Fund Allocation** | Fund IV (20% of $3B fund) |
| **Hold Period** | 5 years (exit 2031) |

**Financing Structure:**

| Tranche | Amount ($M) | Rate | Key Terms |
|---------|-------------|------|-----------|
| Senior Secured Term Loan B | $600M | Term SOFR + 400bps (~7.25% all-in) | 7-year, 5% annual amort |
| Subordinated Notes | $200M | 11.0% fixed | 8-year, bullet |
| Revolver (undrawn) | $100M | SOFR + 350bps | 5-year |
| **Total Debt** | **$900M** | **Blended ~8.4%** | |

*Reference: Base 3-month SOFR ~3.25% (Chatham Financial), expected to remain near this level through 2027. Typical LBO spreads SOFR+350-450bps per Capstone Partners Middle Market Leveraged Finance Report. Leveraged loan default rates forecast at 3.0-3.75% for 2026 (S&P Global Q1 2026 Update).*

---

## 2. Industry Overview

The global cybersecurity market is estimated at **$215B+ in 2025** with projected growth of 12-14% CAGR through 2028 (Gartner). Key structural drivers:

| Driver | Detail |
|--------|--------|
| **AI-powered threats** | Increasing attack sophistication, driving enterprise security spending 12-14% annually |
| **Regulatory tailwinds** | SEC cyber disclosure rules (effective 2024), EU NIS2 Directive, DORA |
| **Cloud migration** | Accelerating demand for cloud-native security (SASE, SSE frameworks) |
| **Zero Trust adoption** | 67% of enterprises implementing zero-trust architectures (Gartner) |
| **Talent shortage** | 3.4M unfilled cybersecurity positions globally (ISC2 2025) |

**72% of CIOs** plan to increase security budgets in 2026 (Gartner CIO Survey). The cybersecurity sector saw meaningful PE deal flow in 2025 (Cherry Bekaert PE Report 2025-2026 Outlook).

### Public Market Comparables

| Company | TTM Revenue | Revenue Growth | Non-GAAP Op Margin | EV ($B) | EV/Revenue |
|---------|------------|----------------|---------------------|---------|------------|
| CrowdStrike (CRWD) | ~$4.8B | ~22% | ~28% | ~$105B | ~22x |
| Palo Alto (PANW) | $9.2B | 15% | ~29% | ~$130B | ~14x |
| Zscaler (ZS) | ~$3.2B | ~24% | ~18% | ~$32B | ~10x |
| Fortinet (FTNT) | ~$6.3B | ~14% | ~36% | ~$75B | ~12x |

*Source: Company IR filings, CrowdStrike FY2026 (ir.crowdstrike.com), PANW FY2025 (paloaltonetworks.com), Fortinet FY2025 (investor.fortinet.com), Zscaler FY2025 (ir.zscaler.com)*

---

## 3. Investment Thesis

### Core Thesis: Platform Consolidation in a Fragmented Cybersecurity Market

1. **Market Tailwind**: Cybersecurity spending growing 12-14% annually, providing organic revenue uplift of 15%+ per year
2. **Margin Expansion Opportunity**: Current EBITDA margin of 34% has pathway to 42%+ through operating leverage, R&D efficiency, and sales force optimization
3. **M&A Roll-Up Strategy**: Fragmented market with 3,500+ cybersecurity vendors enables accretive bolt-on acquisitions at 8-12x EBITDA
4. **Recurring Revenue Model**: 88% of revenue is subscription/ARR, providing high visibility and customer stickiness
5. **AI-Enhanced Product Roadmap**: Integration of AI for automated threat detection and response can drive 300-500bps of net retention improvement

---

## 4. Returns Analysis

| Metric | Base Case | Bull Case | Bear Case |
|--------|-----------|-----------|-----------|
| **Exit Year** | 2031 | 2030 | 2032 |
| **Exit EBITDA ($M)** | 158 | 192 | 115 |
| **Exit EV/EBITDA** | 18.0x | 22.0x | 14.0x |
| **Exit Enterprise Value ($M)** | 2,844 | 4,224 | 1,610 |
| **Net Debt at Exit ($M)** | (550) | (400) | (700) |
| **Equity Value ($M)** | 2,294 | 3,824 | 910 |
| **MOIC** | **3.0x** | **4.6x** | **1.2x** |
| **IRR** | **25%** | **36%** | **4%** |

### Value Creation Bridge (Base Case)

| Driver | Contribution |
|--------|-------------|
| EBITDA growth ($75M to $158M) | 52% |
| Multiple maintenance (20x to 18x) | -8% |
| Deleveraging ($900M to $550M) | 24% |
| Cash flow build | 6% |
| FCF sweep / dividend recap | 26% |

*Reference: Bain Global PE Report 2026 notes deals now require ~10-12% annual EBITDA growth for a 2.5x MOIC, shifting from multiple expansion to operating excellence as the primary value driver.*

---

## 5. Key Risk Factors

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| **Competitive pressure** from CRWD/PANW platform consolidation | High | High | Differentiate in mid-market; vertical specialization |
| **Customer concentration** (top 5 = 28% of revenue) | Medium | High | Accelerate new customer acquisition; diversify end markets |
| **Key talent retention** | Medium | High | Retention packages; equity roll-over for C-suite |
| **Interest rate risk** on floating-rate debt | Medium | Medium | 60% floating; hedge 50% via interest rate swaps |
| **Integration risk** of bolt-on acquisitions | Medium | Medium | Dedicated integration team; proven playbook |
| **AI disruption** to current product set | Low | High | Accelerate AI product development; partner with AI-native firms |
| **Regulatory changes** (export controls, data localization) | Low | Medium | Proactive compliance program; geographic diversification |

---

## 6. Key Investment Metrics

| Metric | Target | Industry Benchmark |
|--------|--------|--------------------|
| Revenue CAGR (hold period) | 15%+ | Market growing 12-14% |
| EBITDA Margin (exit year) | 42% | CRWD ~28% non-GAAP; FTNT ~36% |
| Net Revenue Retention | 125%+ | Top-quartile SaaS: 120%+ |
| Rule of 40 | 50%+ | Best-in-class cybersecurity: 45-55% |
| Free Cash Flow Conversion | 80%+ | Industry avg: 65-75% |

---

## Comparable Transactions

| Transaction | Year | EV ($B) | EV/Revenue | EV/EBITDA |
|-------------|------|---------|------------|-----------|
| Thoma Bravo / Splunk | 2024 | $28.0 | 7.1x | 28x |
| Advent / Barracuda Networks | 2024 | ~$4.0 | 5.5x | 22x |
| Permira / Mimecast | 2022 | $5.8 | 6.2x | 24x |
| PE cybersecurity median (2024-25) | -- | -- | 5.0-7.5x | 18-24x |

---

## Recommendation

The Investment Committee is requested to **APPROVE** the acquisition of CyberShield Technologies at an enterprise value of $1,500M. The transaction offers a compelling risk-adjusted return profile with a base-case **3.0x MOIC and 25% IRR**, driven by strong market tailwinds, a clear margin expansion pathway, and an actionable M&A bolt-on strategy.

---

## Sources

- Gartner: Worldwide Security and Risk Management End-User Spending Forecast (gartner.com)
- McKinsey Global Private Markets Report 2026 (mckinsey.com) -- Median PE purchase multiple 11.8x EBITDA; global buyout deal value $904B in 2025
- Bain & Company: Global Private Equity Report 2026 (bain.com) -- 10-12% annual EBITDA growth needed for 2.5x MOIC
- S&P Global: US Leveraged Finance Q1 2026 Update (spglobal.com) -- Loan default rates 3.0-3.75%
- Chatham Financial / Capstone Partners: SOFR base ~3.25% through 2027; spreads SOFR+350-450bps
- CrowdStrike FY2026 Results (ir.crowdstrike.com) -- Revenue ~$4.8B, ARR $5.25B, FCF ~$1.24B
- Palo Alto Networks FY2025 Results (paloaltonetworks.com) -- Revenue $9.2B (+15% YoY), FCF margin 38%
- Fortinet FY2025 Results (investor.fortinet.com) -- Revenue ~$6.3B, operating margin 35.5%, FCF $2.21B
- Zscaler FY2025 Results (ir.zscaler.com) -- Revenue $2.67B (+23% YoY)
- Cherry Bekaert: "Private Equity Report 2025 Trends and 2026 Outlook" (cbh.com)
