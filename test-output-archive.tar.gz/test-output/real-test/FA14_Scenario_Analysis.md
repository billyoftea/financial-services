# FA14: Scenario Analysis — NVIDIA (NVDA)
## [DATA SOURCE: Dell'Oro, Gartner, NVIDIA FY2026, hyperscaler capex data]

> 分析日期: 2026-05-09 | 预测期间: FY2027-2031

## 三种情景假设

### 宏观背景

| 因素 | Bull | Base | Bear |
|------|------|------|------|
| AI Capex周期 | 持续加速 | 温和增长 | 放缓 |
| 全球GDP增长 | 3.0% | 2.5% | 1.8% |
| 半导体周期 | 上行 | 平稳 | 下行 |
| 利率环境 | 降息 | 持平 | 加息 |

## 收入预测 ($B)

| Year | Bull | Base | Bear |
|------|------|------|------|
| FY2027 | 323.9 (+50%) | 286.4 (+33%) | 237.5 (+10%) |
| FY2028 | 453.4 (+40%) | 358.0 (+25%) | 261.3 (+10%) |
| FY2029 | 544.1 (+20%) | 411.7 (+15%) | 274.3 (+5%) |
| FY2030 | 598.5 (+10%) | 452.9 (+10%) | 287.6 (+5%) |
| FY2031 | 646.4 (+8%) | 484.6 (+7%) | 293.3 (+2%) |

## EBITDA Margin 趋势

| Year | Bull | Base | Bear |
|------|------|------|------|
| FY2027 | 65% | 62% | 52% |
| FY2028 | 67% | 60% | 48% |
| FY2029 | 68% | 58% | 45% |
| FY2030 | 68% | 56% | 43% |
| FY2031 | 67% | 55% | 42% |

## 终端估值

| 指标 | Bull | Base | Bear |
|------|------|------|------|
| Terminal EBITDA ($B) | 433.1 | 266.5 | 123.2 |
| Exit EV/EBITDA | 25x | 20x | 14x |
| Terminal EV ($B) | 10,828 | 5,330 | 1,725 |
| Net Debt ($B) | (50.0) | (20.0) | 30.0 |
| Equity Value ($B) | 10,878 | 5,350 | 1,695 |
| **Implied Share Price** | **$444** | **$218** | **$69** |
| **Upside/Downside** | **+319%** | **+106%** | **-35%** |

## 情景概率加权

| 情景 | 概率 | 股价 | 加权贡献 |
|------|------|------|---------|
| Bull | 25% | $444 | $111.0 |
| Base | 50% | $218 | $109.0 |
| Bear | 25% | $69 | $17.3 |
| **概率加权目标** | | | **$237.3** |

## 关键驱动因素

### Bull Case 支持
- Hyperscaler AI capex: MSFT $80B, GOOGL $75B, META $65B (2026)
- Dell'Oro: Data center market to $400B+ by 2028
- NVDA Blackwell Ultra/Rubin 架构持续领先

### Bear Case 风险
- AI ROI 质疑 (Sequoia $600B gap memo)
- AMD MI400 竞争加剧
- 出口管制扩大 (China限制)

## Sources
- [Dell'Oro Data Center Forecast](https://www.delloro.com/)
- [Gartner Semiconductor Forecast](https://www.gartner.com/)
- NVIDIA FY2026 earnings call
- Microsoft/Google/Meta capex guidance (Q1 2026 earnings)
