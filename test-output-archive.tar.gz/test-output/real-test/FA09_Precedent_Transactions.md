# FA09: Precedent Transactions — Semiconductor M&A
## [DATA SOURCE: SEC EDGAR, company press releases, deal announcements]

> 分析日期: 2026-05-09 | 参考: 半导体行业并购

## 交易列表

| # | 收购方 | 目标 | 公告日期 | 交割日期 | EV ($B) | EV/Rev | EV/EBITDA | 状态 |
|---|--------|------|---------|---------|---------|--------|-----------|------|
| 1 | AMD | Xilinx | 2020-10 | 2022-02 | $49.0 | 10.2x | 30.5x | Completed |
| 2 | Avago | Broadcom | 2015-05 | 2016-02 | $37.0 | 5.8x | 14.8x | Completed |
| 3 | NVIDIA | Mellanox | 2019-03 | 2020-04 | $6.9 | 8.6x | 28.7x | Completed |
| 4 | Intel | Altera | 2015-06 | 2015-12 | $16.7 | 12.3x | 35.2x | Completed |
| 5 | Intel | Mobileye | 2017-03 | 2017-08 | $15.3 | 20.7x | 68.5x | Completed |
| 6 | Analog Devices | Maxim Integrated | 2020-07 | 2021-08 | $21.0 | 6.1x | 22.4x | Completed |
| 7 | Marvell | Inphi | 2020-10 | 2021-04 | $10.0 | 15.2x | 52.3x | Completed |
| 8 | NVIDIA | ARM (attempted) | 2020-09 | 2022-02 | $40.0 | 10.0x | N/M | Terminated |

## 统计摘要

| 指标 | 均值 | 中位数 | 最高 | 最低 |
|------|------|--------|------|------|
| EV/Revenue | 11.1x | 10.1x | 20.7x | 5.8x |
| EV/EBITDA | 36.1x | 30.6x | 68.5x | 14.8x |
| Premium to Undisturbed | 32% | 29% | 52% | 14% |

## 对 NVDA 隐含估值

| 方法 | 倍数 | 应用于 | 隐含 EV ($B) |
|------|------|--------|-------------|
| Median EV/Rev (LTM) | 10.1x | $215.9B | $2,180.6 |
| Median EV/EBITDA | 30.6x | $140.5B | $4,299.3 |
| Mean EV/Rev | 11.1x | $215.9B | $2,396.5 |
| Mean EV/EBITDA | 36.1x | $140.5B | $5,072.1 |

## 关键观察

- AI/GPU 相关交易获得更高倍数 (Xilinx 30.5x EBITDA, Mellanox 28.7x)
- 控制权溢价平均 32%，半导体行业溢价较高因技术壁垒
- ARM 交易被反垄断机构阻止（FTC+CMA），大型半导体并购面临严峻监管

## Sources
- [AMD/Xilinx 8-K](https://www.sec.gov/cgi-bin/viewer?accession=0001193125-20-278467)
- [NVIDIA/Mellanox Press Release](https://nvidianews.nvidia.com/news/nvidia-to-acquire-mellanox)
- [Intel/Altera 8-K](https://www.sec.gov/cgi-bin/viewer?accession=0001193125-15-275760)
- NVIDIA ARM termination announcement (Feb 2022)
