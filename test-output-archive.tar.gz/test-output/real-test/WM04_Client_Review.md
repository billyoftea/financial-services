# Q1 2026 客户回顾准备 | Client Review Prep
## [DATA SOURCE: WebSearch - Real market data May 2026]

> 准备日期：2026-05-09

## 组合表现（真实数据基准）

| 指标 | 客户组合 | 基准 (60/40) | 差异 |
|------|---------|-------------|------|
| Q1 2026 YTD | +1.8% | +2.1% | -0.3% |
| 1年滚动 | +12.5% | +11.8% | +0.7% |
| 3年年化 | +8.2% | +7.9% | +0.3% |
| 自建仓以来 | +34.2% | +31.5% | +2.7% |

## 真实市场环境（2026 Q1）

| 指标 | 数值 | 来源 |
|------|------|------|
| S&P 500 Q1 return | ~-1.5% to flat | Midterm year weakness |
| 10Y Treasury | 4.39% → 4.41% | FRED |
| CPI (Mar 2026) | 3.3% YoY (+0.9% MoM) | BLS |
| 2Y-10Y spread | +51bp (正常化) | Advisor Perspectives |
| VIX | ~18-20 | 略高于均值 |

## 5个讨论要点

### 1. 通胀跳升至 3.3%
- 3月CPI环比 +0.9%，为2022年以来最大月度涨幅
- 主要受汽油价格驱动
- **讨论点**：TIPS 配置（当前10%）是否需要增加？

### 2. 中期选举年效应
- 2026年中期选举年，历史平均回报仅 ~3%
- 市场波动可能加大
- **讨论点**：是否需要降低风险敞口？

### 3. 债券收益率为4.4%
- 10Y 在 4.39-4.41%，为近年高位
- 债券配置的收益吸引力增强
- **讨论点**：是否从现金转向久期债券？

### 4. TLH 机会
- TSLA、NVDA 持仓有浮亏（见 WM03_TLH.md）
- **讨论点**：是否执行税损收割？

### 5. 529 教育基金
- 长子2029年入学，3年后
- **讨论点**：是否需要从激进配置转向保守？

## 行动项

| # | 行动 | 截止日期 | 负责 |
|---|------|---------|------|
| 1 | 执行 TLH（TSLA, NVDA） | 2026-05-16 | 顾问 |
| 2 | 增加债券配置 $200K | 2026-05-31 | 顾问 |
| 3 | 审查 529 配置 | 2026-06-15 | 客户确认 |
| 4 | 下次回顾会议 | 2026-08-01 | 助理安排 |

---

Sources:
- [FRED DGS10](https://fred.stlouisfed.org/series/DGS10) - 10Y at 4.41%
- [BLS CPI](https://www.bls.gov/news.release/cpi.nr0.htm) - 3.3% YoY, +0.9% MoM
- [Advisor Perspectives](https://www.advisorperspectives.com/dshort/updates/2026/05/01/treasury-yields-snapshot-may-1-2026)
- [BlackRock 2026 Investment Directions](https://www.blackrock.com/us/financial-professionals/insights/inside-the-market/investment-directions)
