# Deal Screening Report

## SaaS Platform CIM Evaluation against Growth PE Fund Criteria

**Date:** May 8, 2026
**Prepared by:** Deal Sourcing Team
**Fund:** Growth Equity Fund IV
**CIM Received:** April 20, 2026
**Classification:** Confidential

---

## 1. Target Overview (from CIM)

| Metric | Value |
|--------|-------|
| **Company** | [TargetCo] (anonymized in CIM) |
| **Sector** | Enterprise SaaS - Workflow Automation |
| **ARR (TTM)** | $100M |
| **Revenue Growth (YoY)** | 30% |
| **Gross Margin** | 78% |
| **EBITDA Margin** | 20% ($20M) |
| **Net Revenue Retention** | 115% |
| **Total Customers** | 850 |
| **Enterprise Customers (> $250K)** | 32 |
| **FTEs** | 420 |
| **Asking Price (Indicative)** | $800-900M (8-9x Revenue) |
| **Headquarters** | United States |

---

## 2. Fund Investment Criteria

| Criterion | Fund Threshold | TargetCo Metric | Pass/Fail |
|-----------|---------------|-----------------|-----------|
| **Revenue Size** | ARR $50M - $300M | $100M | PASS |
| **Revenue Growth** | > 20% YoY | 30% | PASS |
| **Gross Margin** | > 70% | 78% | PASS |
| **EBITDA Margin** | > 10% | 20% | PASS |
| **Net Revenue Retention** | > 110% | 115% | PASS |
| **Recurring Revenue Mix** | > 80% | 92% | PASS |
| **Customer Concentration (Top-10)** | < 30% of ARR | 22% | PASS |
| **Market Size (TAM)** | > $5B | $12B | PASS |
| **Rule of 40** | > 30 | 50 (30 + 20) | PASS |

**Hard Criteria Result: 9/9 PASS**

---

## 3. Detailed Scoring Matrix

### Scoring Scale: 1-5 (5 = Best-in-class)

---

### A. Growth Profile (Weight: 25%)

| Factor | Score (1-5) | Commentary |
|--------|-------------|------------|
| Revenue Growth Rate | 4 | 30% growth is strong for a $100M ARR company. Median for peer group is 22%. |
| Growth Durability | 4 | Large TAM ($12B) with <1% penetration. Greenfield opportunity in healthcare and government verticals. |
| Growth Efficiency | 3 | CAC payback of 18 months is acceptable but above top-quartile benchmark of 12 months. |
| Expansion Revenue | 4 | 115% NRR is above median; driven by seat expansion (50%) and module upsell (35%). |
| New Logo Pipeline | 3 | Sales pipeline growing 15% QoQ but conversion rates could improve (22% SQL-to-close). |

**Growth Score: 3.6 / 5.0** | **Weighted: 0.90**

---

### B. Margin Quality (Weight: 20%)

| Factor | Score (1-5) | Commentary |
|--------|-------------|------------|
| Gross Margin Level | 3 | 78% is below top-quartile SaaS (85%+) but acceptable given professional services component. |
| Gross Margin Trend | 4 | Improving from 74% (FY2023) to 78% (FY2025) as cloud infrastructure scales. |
| EBITDA Margin | 4 | 20% at $100M ARR is impressive; signals operating discipline and efficient go-to-market. |
| FCF Conversion | 3 | FCF margin of 14% is below EBITDA margin due to working capital dynamics and capex. |
| Margin Expansion Potential | 4 | Clear path to 30%+ EBITDA margin at $200M ARR through operating leverage. |

**Margin Score: 3.6 / 5.0** | **Weighted: 0.72**

---

### C. Market Position (Weight: 20%)

| Factor | Score (1-5) | Commentary |
|--------|-------------|------------|
| Market Size (TAM) | 4 | $12B TAM growing at 13% CAGR provides ample runway. |
| Competitive Position | 3 | Mid-pack positioning. No single dominant competitor but fragmented landscape with 15+ players. |
| Barriers to Entry | 4 | Deep workflow integrations with ERP systems create meaningful switching costs (avg 6-month implementation). |
| Market Tailwinds | 5 | Regulatory complexity, digital transformation, and AI adoption are multi-year secular tailwinds. |
| Segment Leadership | 3 | Recognized as a "Challenger" by Gartner; not yet a "Leader" but trajectory is positive. |

**Market Score: 3.8 / 5.0** | **Weighted: 0.76**

---

### D. Competitive Position (Weight: 15%)

| Factor | Score (1-5) | Commentary |
|--------|-------------|------------|
| Product Differentiation | 4 | Vertical-specific workflows (healthcare compliance, financial reporting) are hard to replicate. |
| Switching Costs | 4 | High: 6-month avg implementation, deep API integrations, customer-specific workflow configuration. |
| Technology Moat | 3 | No patents; competitive advantage is data (usage patterns) and integration depth rather than IP. |
| Customer Satisfaction | 4 | CIM reports NPS of 62; our independent research confirms above-average satisfaction. |
| Pricing Power | 3 | Modest annual price increases of 3-5%; some discounting pressure in enterprise segment. |

**Competitive Score: 3.6 / 5.0** | **Weighted: 0.54**

---

### E. Management & Team (Weight: 10%)

| Factor | Score (1-5) | Commentary |
|--------|-------------|------------|
| CEO / Founder Quality | 4 | Second-time founder with prior successful exit. 12 years in the space. Strong vision. |
| Management Depth | 3 | C-suite is strong but thin on bench. VP-level turnover of 15% in last 2 years is a concern. |
| Engineering Talent | 3 | 140 engineers; attrition at 16% is above industry average. Key architect retention risk. |
| Culture & Alignment | 4 | Strong culture scores; remote-first with effective async communication. |
| Willingness to Partner | 4 | Management indicated openness to majority recap with continued equity rollover. |

**Management Score: 3.6 / 5.0** | **Weighted: 0.36**

---

### F. Deal Dynamics (Weight: 10%)

| Factor | Score (1-5) | Commentary |
|--------|-------------|------------|
| Valuation Reasonableness | 3 | 8-9x revenue is at the upper end of our range. Requires growth to sustain for multiple support. |
| Process Competitiveness | 3 | Wide auction with 8-10 parties invited. We are one of 4-5 strategic/financial parties advancing. |
| Financing Availability | 4 | Strong lender appetite for SaaS at 3-4x leverage; multiple banks have expressed interest. |
| Integration Complexity | 5 | Platform acquisition; minimal integration required. Current infrastructure and team stay in place. |
| Exit Visibility | 3 | Multiple potential exit paths (strategic sale, secondary, IPO) but 5-year horizon is required. |

**Deal Dynamics Score: 3.6 / 5.0** | **Weighted: 0.36**

---

## 4. Scoring Summary

| Category | Weight | Raw Score | Weighted Score |
|----------|--------|-----------|----------------|
| Growth Profile | 25% | 3.60 | 0.90 |
| Margin Quality | 20% | 3.60 | 0.72 |
| Market Position | 20% | 3.80 | 0.76 |
| Competitive Position | 15% | 3.60 | 0.54 |
| Management & Team | 10% | 3.60 | 0.36 |
| Deal Dynamics | 10% | 3.60 | 0.36 |
| **Total** | **100%** | **3.63 avg** | **3.64 / 5.00** |

---

## 5. Overall Assessment

### Composite Score: 3.64 / 5.00

| Rating | Score Range | Interpretation |
|--------|-------------|---------------|
| Strong Pass | 4.0 - 5.0 | Clear conviction; prioritize aggressively |
| **Pass** | **3.5 - 3.9** | **Meets criteria; advance to detailed evaluation** |
| Conditional | 3.0 - 3.4 | Marginal; advance only if specific concerns addressed |
| Fail | Below 3.0 | Does not meet fund criteria |

### Verdict: PASS - Advance to Detailed Evaluation

---

## 6. Key Strengths

1. **Exceptional Rule of 40 performance** (50 = 30% growth + 20% margin) positions the company in the top decile of SaaS peers at this scale.
2. **Profitable growth** at $100M ARR with 20% EBITDA margin is rare and demonstrates capital-efficient execution.
3. **Strong unit economics** with 18-month CAC payback and 115% NRR support a sustainable growth model.
4. **Secular tailwinds** in workflow automation and regulatory compliance create multi-year demand visibility.

## 7. Key Concerns

1. **Valuation stretch:** At 8-9x revenue ($800-900M EV), the deal requires sustained 25%+ growth and successful margin expansion to achieve target returns. Any growth deceleration compresses the multiple significantly.
2. **Gross margin below top-quartile:** 78% gross margin limits profitability ceiling. Needs investigation into COGS structure (hosting, support, third-party costs) for expansion path.
3. **Engineering attrition:** 16% attrition in the engineering team is above the SaaS industry average of 11-12%. Key-person risk for core architecture.
4. **Competitive auction dynamics:** Wide process with 8-10 parties increases risk of bid escalation. Need clear walk-away discipline.

## 8. Conditions for Advancement

If the IC approves advancement, the deal team recommends:

1. **Phase I DD** focused on validating revenue quality (cohort analysis, churn by vintage), margin sustainability, and engineering team retention
2. **Management meetings** to assess CEO and C-suite readiness for PE partnership
3. **Competitive deep-dive** to validate differentiation claims and win/loss data
4. **Valuation stress test** at 7.0x revenue (our preferred entry) with downside scenario modeling

---

## 9. Appendix: Peer Benchmarking

| Company | ARR | Growth | EBITDA Margin | EV/Revenue |
|---------|-----|--------|---------------|------------|
| Peer A (Public) | $180M | 22% | 15% | 6.5x |
| Peer B (Public) | $120M | 28% | 12% | 8.2x |
| Peer C (PE-backed) | $90M | 25% | 18% | N/A |
| **TargetCo** | **$100M** | **30%** | **20%** | **8.0-9.0x** |
| Peer D (Private) | $150M | 18% | 22% | N/A |

TargetCo trades at a premium to most peers, justified by the combination of above-average growth AND profitability. However, the asking multiple assumes continued premium positioning that must be validated in diligence.

---

*This screening report is confidential and prepared for internal use by the deal team and Investment Committee of Growth Equity Fund IV.*
