# Investment Committee Memorandum

## Acquisition of TechCorp, Inc.

**Date:** May 8, 2026
**Classification:** Confidential - For IC Use Only
**Prepared by:** Deal Team Alpha
**Fund:** Growth Equity Fund IV

---

## 1. Executive Summary

### Transaction Overview

We recommend the acquisition of TechCorp, Inc. ("TechCorp" or the "Company"), a leading enterprise SaaS platform providing cloud-based workflow automation and data analytics solutions. The proposed transaction is structured as a platform acquisition for Growth Equity Fund IV.

| Metric | Value |
|--------|-------|
| **Enterprise Value** | $3,200M |
| **ARR (Annual Recurring Revenue)** | $400M |
| **EV / Revenue** | 8.0x |
| **Revenue Growth (YoY)** | 25% |
| **Gross Margin** | 82% |
| **EBITDA Margin** | 18% ($72M) |
| **Net Revenue Retention** | 122% |
| **Estimated Equity Check** | $1,600M |
| **Target IRR** | 22-25% |
| **Target MOIC** | 2.8-3.2x |

**Recommendation:** PROCEED to Phase II due diligence. The Company exhibits best-in-class SaaS metrics, operates in a large and growing TAM, and presents a compelling value creation opportunity through organic growth acceleration and margin expansion.

---

## 2. Company Overview

### Business Description

TechCorp is a vertically-focused enterprise SaaS company founded in 2012, headquartered in Austin, TX, with additional offices in London and Singapore. The Company provides an integrated platform for workflow automation, process mining, and business intelligence serving mid-market and enterprise customers across financial services, healthcare, and technology verticals.

### Key Metrics (FY2025)

| Metric | FY2023 | FY2024 | FY2025 |
|--------|--------|--------|--------|
| ARR | $256M | $320M | $400M |
| YoY Growth | 30% | 25% | 25% |
| Gross Margin | 79% | 81% | 82% |
| EBITDA | $26M | $45M | $72M |
| EBITDA Margin | 10% | 14% | 18% |
| Net Revenue Retention | 119% | 120% | 122% |
| Customers (> $100K ARR) | 185 | 240 | 310 |
| FTEs | 620 | 780 | 950 |

### Product Suite

1. **TechCorp Automate** (55% of ARR) - Core workflow automation engine with drag-and-drop builder and 200+ pre-built connectors
2. **TechCorp Insights** (30% of ARR) - AI-powered process mining and analytics dashboard
3. **TechCorp Govern** (15% of ARR) - Compliance, audit trail, and governance module

### Customer Profile

- **Total customers:** 1,850
- **Enterprise (> $1M ARR):** 45 customers (35% of ARR)
- **Mid-market ($100K-$1M):** 265 customers (40% of ARR)
- **SMB (< $100K):** 1,540 customers (25% of ARR)
- **Top-10 customer concentration:** 18% of ARR
- **Average contract length:** 2.3 years
- **Logo churn rate:** 4.5%

---

## 3. Market Analysis

### Total Addressable Market

The enterprise workflow automation market is estimated at $18B in 2025 and projected to grow at 14% CAGR to reach $35B by 2030 (source: Gartner, IDC). Key growth drivers include:

- Accelerating digital transformation across regulated industries
- Increasing demand for AI-powered process optimization
- Growing regulatory complexity driving compliance automation
- Shift from on-premise to cloud-based solutions

### Competitive Landscape

| Competitor | Est. ARR | Growth | Positioning |
|-----------|----------|--------|-------------|
| Competitor A (Public) | $1.2B | 20% | Horizontal platform; enterprise focus |
| Competitor B (PE-backed) | $600M | 18% | IT service management adjacent |
| Competitor C (Public) | $450M | 22% | Process mining specialist |
| **TechCorp** | **$400M** | **25%** | **Vertical workflow + analytics** |
| Competitor D (Private) | $200M | 30% | Niche healthcare automation |

### TechCorp Competitive Advantages

1. **Vertical depth:** Purpose-built solutions for financial services and healthcare with pre-configured compliance workflows
2. **Superior NRR:** 122% net revenue retention indicates strong expansion within existing accounts, outpacing competitors averaging 110-115%
3. **Platform stickiness:** Average of 7.2 modules deployed per enterprise customer; deep API integrations with ERP systems
4. **AI differentiation:** Proprietary process mining algorithms trained on 5B+ process events provide defensible data advantage

---

## 4. Financial Analysis

### Revenue Quality

TechCorp's revenue exhibits high-quality SaaS characteristics:

- **Recurring revenue mix:** 94% subscription, 4% professional services, 2% other
- **Annual contract value (ACV) distribution:** Healthy mix with growing enterprise cohort
- **Expansion drivers:** Module upsell (45%), seat expansion (30%), price increases (25%)
- **Deferred revenue:** $185M (providing 46% of ARR as revenue visibility)

### Margin Expansion Path

The Company has demonstrated consistent margin improvement:

| Metric | FY2025 (Actual) | FY2026E | FY2027E | FY2028E |
|--------|-----------------|---------|---------|---------|
| Gross Margin | 82% | 83% | 84% | 85% |
| Sales & Marketing (% Rev) | 35% | 33% | 30% | 28% |
| R&D (% Rev) | 22% | 21% | 20% | 19% |
| G&A (% Rev) | 7% | 6% | 5% | 5% |
| **EBITDA Margin** | **18%** | **23%** | **29%** | **33%** |

Margin expansion is driven by:
- Operating leverage on fixed cloud infrastructure costs
- Improving sales efficiency as brand recognition grows
- G&A scale benefits from current overinvestment in corporate functions

### Cash Flow Profile

| Metric | FY2025 | FY2026E | FY2027E | FY2028E |
|--------|--------|---------|---------|---------|
| EBITDA | $72M | $92M | $139M | $198M |
| Capex | ($11M) | ($13M) | ($15M) | ($17M) |
| FCF | $61M | $79M | $124M | $181M |
| FCF Margin | 15% | 18% | 24% | 29% |

---

## 5. Valuation

### Transaction Structure

| Component | Amount |
|-----------|--------|
| Enterprise Value | $3,200M |
| Less: Existing Net Debt | ($50M) |
| Equity Value | $3,250M |
| Less: Management Rollover (15%) | ($488M) |
| **Fund Equity Contribution** | **$2,762M** |
| Debt Financing (4.0x EBITDA) | $288M |
| **Equity Check (after debt)** | **$1,600M** |

### Valuation Benchmarks

| Benchmark | Multiple | Implied EV | Premium / (Discount) |
|-----------|----------|------------|---------------------|
| TechCorp at 8.0x Revenue | 8.0x | $3,200M | - |
| Public SaaS Comps Median | 7.5x | $3,000M | (6%) |
| Recent SaaS M&A (median) | 9.2x | $3,680M | 15% |
| Growth SaaS (>20% growth) | 10.5x | $4,200M | 31% |

The 8.0x entry multiple represents a 15% discount to recent M&A transactions and a 24% discount to high-growth SaaS peers, reflecting a favorable entry point for a market-leading asset.

---

## 6. Due Diligence Summary

### Status: Phase I Complete - Phase II Recommended

| Workstream | Key Findings | Risk Level |
|-----------|-------------|------------|
| **Financial** | Revenue quality confirmed; QoE identified $8M in normalization adjustments (stock comp, one-time legal). Cash conversion slightly below EBITDA due to working capital timing. | Medium |
| **Commercial** | NRR of 122% validated. Top-10 concentration at 18% is healthy. Customer interviews indicate high satisfaction (NPS 68). Win rate vs. top 3 competitors is 45%. | Low |
| **Technology** | Modern microservices architecture on AWS. Minimal technical debt. 99.97% uptime SLA met. SOC 2 Type II certified. Key risk: Stripe dependency for billing. | Low-Medium |
| **Legal** | One pending IP litigation ($5M claim, deemed without merit by counsel). Clean corporate structure. 14 key employees identified for retention packages. | Low |
| **Operational** | 950 FTEs with planned growth to 1,200. Co-founder CEO intends to transition within 18 months post-close; succession plan needed. | Medium |

### Open Items for Phase II

1. Deep-dive customer cohort analysis (churn by vintage and segment)
2. Independent technology architecture assessment
3. Management interview and retention package design
4. Detailed synergy and value creation plan development
5. Insurance and regulatory deep-dive for healthcare vertical

---

## 7. Returns Analysis

### Base Case Scenario

| Assumption | Value |
|-----------|-------|
| Entry Multiple | 8.0x Revenue (55x EBITDA) |
| Exit Multiple | 7.0x Revenue (21x EBITDA at 33% margin) |
| Revenue CAGR (5-year) | 20% |
| EBITDA Margin at Exit | 33% |
| Hold Period | 5 years |
| Leverage at Entry | 4.0x EBITDA |

### Returns Summary

| Scenario | Exit Year | Exit EV | Equity Value | IRR | MOIC |
|----------|-----------|---------|-------------|-----|------|
| **Downside** | Year 5 | $5,200M | $4,300M | 16% | 2.7x |
| **Base Case** | Year 5 | $7,800M | $6,800M | 23% | 4.3x |
| **Upside** | Year 5 | $11,200M | $10,200M | 32% | 6.4x |

### Value Creation Bridge (Base Case)

| Driver | Contribution |
|--------|-------------|
| EBITDA Growth | 45% |
| Multiple Expansion | 5% |
| Debt Paydown | 10% |
| Margin Expansion | 40% |

---

## 8. Key Risks and Mitigants

### Risk 1: CEO Transition (HIGH)
**Risk:** Co-founder CEO plans to step down within 18 months. Leadership transition could disrupt execution.
**Mitigant:** Strong bench of 3 internal CEO candidates. Engage executive search firm for external options. Structured transition with founder remaining on board for 12 months.

### Risk 2: Customer Concentration in Financial Services (MEDIUM)
**Risk:** 42% of ARR concentrated in financial services vertical; regulatory changes or sector downturn could impact.
**Mitigant:** Actively expanding healthcare (28% of ARR, growing 35% YoY) and technology verticals. Healthcare expected to surpass financial services within 2 years.

### Risk 3: Competitive Pressure (MEDIUM)
**Risk:** Well-funded public competitors (Competitor A) increasing investment in vertical solutions.
**Mitigant:** TechCorp has 3+ year head start in vertical-specific workflows. High switching costs (avg 7.2 modules per customer). NRR of 122% demonstrates continued value delivery.

### Risk 4: AI Disruption (LOW-MEDIUM)
**Risk:** Rapid advancement in AI could commoditize workflow automation capabilities.
**Mitigant:** TechCorp is investing $80M annually in AI R&D (22% of revenue). Proprietary process mining data moat (5B+ events) creates barrier to entry. AI capabilities are additive to, not disruptive of, current platform.

### Risk 5: Integration and Operational Complexity (LOW)
**Risk:** Post-acquisition integration challenges given distributed workforce (Austin, London, Singapore).
**Mitigant:** Platform acquisition with light integration. Current management team to remain. Established remote-first culture since 2020.

---

## 9. Recommendation

### DEAL TEAM RECOMMENDATION: PROCEED TO PHASE II

We recommend advancing to Phase II due diligence and signing an exclusivity agreement. The investment thesis is compelling based on:

1. **High-quality SaaS business** with 25% growth, 122% NRR, and clear margin expansion path
2. **Attractive entry point** at 8.0x revenue (15% discount to recent M&A)
3. **Strong value creation levers:** organic growth acceleration, margin expansion from 18% to 33%, and potential add-on acquisitions
4. **Favorable risk/return profile:** Base case IRR of 23% and MOIC of 4.3x with downside protection at 16% IRR

### Requested IC Actions

1. Approve Phase II due diligence budget of $3.5M
2. Approve engagement of investment bank for financing (target: 4.0x leverage)
3. Authorize submission of indicative offer at $3,200M enterprise value
4. Approve exclusivity period of 60 days

### Timeline

| Milestone | Target Date |
|-----------|------------|
| IC Approval | May 15, 2026 |
| Phase II DD Kickoff | May 19, 2026 |
| Exclusivity Signed | June 1, 2026 |
| Phase II DD Complete | July 15, 2026 |
| Final IC Meeting | July 25, 2026 |
| Signing | August 8, 2026 |
| Closing | September 15, 2026 |

---

*This memorandum is confidential and prepared solely for the Investment Committee of Growth Equity Fund IV. Distribution is restricted to IC members and authorized advisors.*
