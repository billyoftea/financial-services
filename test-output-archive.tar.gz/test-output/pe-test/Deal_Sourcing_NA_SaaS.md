# Deal Sourcing Memorandum

## North American Mid-Market SaaS Targets

**Date:** May 8, 2026
**Prepared by:** Deal Sourcing Team
**Fund:** Growth Equity Fund IV
**Target Geography:** United States and Canada
**Classification:** Confidential - Internal Use Only

---

## 1. Search Criteria

| Parameter | Criteria |
|-----------|----------|
| **Sector** | Enterprise SaaS (B2B) |
| **ARR Range** | $50M - $200M |
| **Revenue Growth** | > 15% YoY |
| **Gross Margin** | > 70% |
| **Net Revenue Retention** | > 110% |
| **EBITDA Margin** | Positive preferred; > 10% for $100M+ ARR |
| **Geography** | United States and Canada (HQ or significant operations) |
| **Business Model** | Subscription / recurring revenue > 80% |
| **Deal Type** | Majority recapitalization or growth equity |

### Priority Sub-Sectors

1. **Vertical SaaS** - Industry-specific platforms (healthcare, financial services, construction, property management)
2. **Infrastructure Software** - DevOps, cybersecurity, data management, observability
3. **Workflow Automation** - Process orchestration, document management, compliance
4. **Data & Analytics** - Business intelligence, data integration, AI/ML platforms

---

## 2. Target Universe Overview

After screening 145 companies against our criteria, we identified 38 candidates meeting minimum thresholds. The following 10 targets represent the highest-priority opportunities based on scoring against growth, margin, market position, and deal feasibility.

---

## 3. Target Profiles

### Target 1: Meridian HealthTech

| Attribute | Detail |
|-----------|--------|
| **HQ** | Nashville, TN |
| **Sub-Sector** | Vertical SaaS - Healthcare |
| **ARR** | $85M |
| **Growth** | 22% YoY |
| **Gross Margin** | 76% |
| **NRR** | 118% |
| **EBITDA Margin** | 15% |
| **Customers** | 320 hospital systems and physician groups |
| **Founded** | 2011 |
| **FTEs** | 380 |
| **Key Products** | EHR integration platform, revenue cycle management, patient engagement suite |
| **Ownership** | Founder-owned (65%), VC (35%) - Series D in 2020 |
| **Thesis** | Strong position in mid-market hospital segment. NRR of 118% driven by module expansion. Opportunities in value-based care analytics and telehealth integration. Founder seeking liquidity after 15 years. |
| **Estimated EV Range** | $600-750M |

### Target 2: Atlas DataWorks

| Attribute | Detail |
|-----------|--------|
| **HQ** | Denver, CO |
| **Sub-Sector** | Data & Analytics |
| **ARR** | $65M |
| **Growth** | 28% YoY |
| **Gross Margin** | 82% |
| **NRR** | 124% |
| **EBITDA Margin** | 8% (investing heavily in AI) |
| **Customers** | 280 enterprise accounts |
| **Founded** | 2014 |
| **FTEs** | 290 |
| **Key Products** | Cloud data integration platform, ETL/ELT tools, reverse ETL connectors |
| **Ownership** | Founder-owned (55%), Growth equity (45%) - Series C in 2022 |
| **Thesis** | Best-in-class NRR of 124% indicates exceptional product-market fit. AI-powered data transformation features launching Q3 2026 could accelerate growth. Near break-even but clear path to 25%+ margin. |
| **Estimated EV Range** | $550-700M |

### Target 3: Sentinel Cyber

| Attribute | Detail |
|-----------|--------|
| **HQ** | Arlington, VA |
| **Sub-Sector** | Infrastructure - Cybersecurity |
| **ARR** | $110M |
| **Growth** | 18% YoY |
| **Gross Margin** | 80% |
| **NRR** | 116% |
| **EBITDA Margin** | 22% |
| **Customers** | 1,200 mid-market enterprises, 15 federal agencies |
| **Founded** | 2009 |
| **FTEs** | 450 |
| **Key Products** | Cloud security posture management, threat detection, compliance automation |
| **Ownership** | PE-backed (current sponsor acquired 2019) |
| **Thesis** | Mature, profitable cybersecurity platform with federal clearance (FedRAMP High). Current PE sponsor approaching end of hold period. Strong recurring revenue with government contracts providing stability. Cross-sell opportunity into commercial base. |
| **Estimated EV Range** | $900-1,100M |

### Target 4: Blueprint PM

| Attribute | Detail |
|-----------|--------|
| **HQ** | Toronto, ON, Canada |
| **Sub-Sector** | Vertical SaaS - Construction / Property Management |
| **ARR** | $75M |
| **Growth** | 25% YoY |
| **Gross Margin** | 74% |
| **NRR** | 112% |
| **EBITDA Margin** | 18% |
| **Customers** | 2,100 property management firms, 450 general contractors |
| **Founded** | 2013 |
| **FTEs** | 320 |
| **Key Products** | Project management suite, bid management, facility maintenance platform |
| **Ownership** | Founder-owned (80%), angel investors (20%) |
| **Thesis** | Leading mid-market construction PM platform with dual revenue streams (property management + general contracting). Founder-led with limited institutional oversight creating operational improvement opportunity. Cross-border (US/Canada) presence provides expansion template. |
| **Estimated EV Range** | $500-650M |

### Target 5: FinEdge Systems

| Attribute | Detail |
|-----------|--------|
| **HQ** | Charlotte, NC |
| **Sub-Sector** | Vertical SaaS - Financial Services |
| **ARR** | $130M |
| **Growth** | 16% YoY |
| **Gross Margin** | 79% |
| **NRR** | 114% |
| **EBITDA Margin** | 25% |
| **Customers** | 180 banks and credit unions, 45 insurance carriers |
| **Founded** | 2008 |
| **FTEs** | 510 |
| **Key Products** | Loan origination system, regulatory reporting, anti-money laundering compliance |
| **Ownership** | PE-backed (secondary buyout in 2020) |
| **Thesis** | Highly profitable vertical SaaS serving regulated financial institutions with mission-critical compliance software. High switching costs due to regulatory nature of product. Strong free cash flow generation. Potential bolt-on acquisition strategy for adjacent compliance tools. |
| **Estimated EV Range** | $1,000-1,300M |

### Target 6: Vertex Commerce

| Attribute | Detail |
|-----------|--------|
| **HQ** | Austin, TX |
| **Sub-Sector** | Workflow Automation - E-commerce Operations |
| **ARR** | $55M |
| **Growth** | 35% YoY |
| **Gross Margin** | 83% |
| **NRR** | 120% |
| **EBITDA Margin** | -2% (growth stage) |
| **Customers** | 3,500 e-commerce brands |
| **Founded** | 2017 |
| **FTEs** | 210 |
| **Key Products** | Multi-channel order management, inventory optimization, returns automation |
| **Ownership** | Founder-owned (70%), VC (30%) - Series B in 2023 |
| **Thesis** | Fastest-growing target in the pipeline at 35% ARR growth. Capitalizing on explosive e-commerce operations complexity. Still investing for growth but proven unit economics at customer level (LTV/CAC of 4.5x). AI-powered inventory optimization feature could be a breakout product. |
| **Estimated EV Range** | $450-600M |

### Target 7: OmniFlow

| Attribute | Detail |
|-----------|--------|
| **HQ** | San Francisco, CA |
| **Sub-Sector** | Workflow Automation - Enterprise Operations |
| **ARR** | $95M |
| **Growth** | 20% YoY |
| **Gross Margin** | 81% |
| **NRR** | 119% |
| **EBITDA Margin** | 17% |
| **Customers** | 420 enterprise accounts across manufacturing, logistics, and energy |
| **Founded** | 2012 |
| **FTEs** | 400 |
| **Key Products** | Process orchestration engine, supply chain workflow, RPA integration hub |
| **Ownership** | Founder-owned (50%), Growth equity (30%), Employees (20%) |
| **Thesis** | Enterprise-grade process automation with deep integrations into SAP, Oracle, and Workday. High average contract value ($225K) with 7.8 modules per customer demonstrates platform breadth. Founder seeking to transition to Chairman role; opportunity to bring in operator CEO. |
| **Estimated EV Range** | $750-950M |

### Target 8: Clarify AI

| Attribute | Detail |
|-----------|--------|
| **HQ** | Seattle, WA |
| **Sub-Sector** | Data & Analytics - AI/ML Platform |
| **ARR** | $60M |
| **Growth** | 42% YoY |
| **Gross Margin** | 85% |
| **NRR** | 130% |
| **EBITDA Margin** | -5% (hypergrowth) |
| **Customers** | 180 enterprise accounts |
| **Founded** | 2019 |
| **FTEs** | 180 |
| **Key Products** | MLOps platform, model monitoring, AI governance and explainability tools |
| **Ownership** | Founder-owned (60%), VC (40%) - Series B in 2024 |
| **Thesis** | Exceptional growth (42%) and best-in-class NRR (130%) driven by explosive enterprise AI adoption. MLOps and AI governance are emerging categories with limited direct competition. Product is becoming infrastructure-grade for AI-first enterprises. Requires growth-oriented capital to scale before market consolidates. |
| **Estimated EV Range** | $600-800M |

### Target 9: FieldServ Pro

| Attribute | Detail |
|-----------|--------|
| **HQ** | Dallas, TX |
| **Sub-Sector** | Vertical SaaS - Field Service Management |
| **ARR** | $70M |
| **Growth** | 19% YoY |
| **Gross Margin** | 75% |
| **NRR** | 113% |
| **EBITDA Margin** | 20% |
| **Customers** | 680 field service organizations (HVAC, plumbing, electrical, telecom) |
| **Founded** | 2010 |
| **FTEs** | 280 |
| **Key Products** | Scheduling and dispatch, mobile workforce management, parts inventory, invoicing |
| **Ownership** | Founder-owned (85%), angel investors (15%) |
| **Thesis** | Bootstrapped, profitable vertical SaaS with dominant position in mid-market field service. Founder has built a capital-efficient business with minimal outside investment. Significant opportunity to accelerate growth through expanded sales effort and IoT integration. Classic buy-and-build thesis with fragmented market ripe for consolidation. |
| **Estimated EV Range** | $450-550M |

### Target 10: TrustLayer

| Attribute | Detail |
|-----------|--------|
| **HQ** | Chicago, IL |
| **Sub-Sector** | Infrastructure - DevOps / Developer Tools |
| **ARR** | $90M |
| **Growth** | 24% YoY |
| **Gross Margin** | 84% |
| **NRR** | 121% |
| **EBITDA Margin** | 14% |
| **Customers** | 520 technology companies, 85 SaaS vendors |
| **Founded** | 2015 |
| **FTEs** | 340 |
| **Key Products** | API security testing, dependency management, software composition analysis |
| **Ownership** | VC-backed (Series C in 2023; lead investor seeking liquidity) |
| **Thesis** | Developer-focused security tools riding the software supply chain security wave (driven by recent high-profile breaches). Product-led growth motion with strong bottom-up adoption. Lead VC investor approaching fund end-of-life creating timing opportunity. Open-source community of 12,000 contributors provides organic demand engine. |
| **Estimated EV Range** | $700-900M |

---

## 4. Prioritization Matrix

| Rank | Target | ARR | Growth | EBITDA Margin | Priority | Rationale |
|------|--------|-----|--------|---------------|----------|-----------|
| 1 | Clarify AI | $60M | 42% | -5% | HIGH | Exceptional growth and NRR; AI tailwind; emerging category leader |
| 2 | Atlas DataWorks | $65M | 28% | 8% | HIGH | Strong NRR and growth; clear margin path; AI catalyst |
| 3 | Meridian HealthTech | $85M | 22% | 15% | HIGH | Vertical depth; healthcare tailwind; founder liquidity |
| 4 | FinEdge Systems | $130M | 16% | 25% | MEDIUM-HIGH | Highly profitable; regulated moat; bolt-on potential |
| 5 | OmniFlow | $95M | 20% | 17% | MEDIUM-HIGH | Enterprise platform; deep integrations; leadership transition opportunity |
| 6 | TrustLayer | $90M | 24% | 14% | MEDIUM | DevSecOps tailwind; VC liquidity; PLG motion |
| 7 | Vertex Commerce | $55M | 35% | -2% | MEDIUM | Fast growth but unproven profitability; e-commerce cyclicality risk |
| 8 | Sentinel Cyber | $110M | 18% | 22% | MEDIUM | Profitable but lower growth; secondary buyout; government dependency |
| 9 | FieldServ Pro | $70M | 19% | 20% | MEDIUM-LOW | Solid but lower growth; limited TAM expansion; buy-and-build thesis |
| 10 | Blueprint PM | $75M | 25% | 18% | MEDIUM-LOW | Good metrics but cross-border complexity; smaller TAM |

---

## 5. Outreach Strategy

### Phase 1: Warm Introductions (Weeks 1-4)

**Priority Targets:** Clarify AI, Atlas DataWorks, Meridian HealthTech

| Activity | Details |
|----------|---------|
| Investment banker relationships | Engage 3 banks (Houlihan Lokey, William Blair, Raymond James) for warm introductions to Targets 1, 2, 5, 7 |
| VC/GP network | Leverage existing LP relationships with Atlas DataWorks and Clarify AI investors for introductions |
| Industry events | Attend SaaStr Annual (May 2026), where Targets 2, 6, 8, 10 are exhibitors or speakers |
| Advisory board | Engage 2-3 operating advisors with SaaS expertise to facilitate introductions |

### Phase 2: Direct Outreach (Weeks 3-8)

**Priority Targets:** FinEdge Systems, OmniFlow, TrustLayer, Vertex Commerce

| Activity | Details |
|----------|---------|
| CEO/Founder letters | Personalized letters from our Managing Partner to founders of Targets 3, 4, 9 highlighting shared vision and partnership approach |
| Cold outreach | Partner-led LinkedIn and email outreach to CEOs of Targets 6, 7, 8 with brief thesis and value proposition |
| Board-level approach | For PE-backed targets (3, 5), approach through board members or sponsor relationships |
| Conference meetings | Schedule 1-on-1 meetings at upcoming conferences (Gartner IT Symposium, DevOps Enterprise Summit) |

### Phase 3: Sector Building (Ongoing)

| Activity | Details |
|----------|---------|
| Market mapping | Complete detailed market map of each sub-sector with 50+ companies tracked |
| Proprietary deal flow | Publish thought leadership on vertical SaaS and infrastructure software to attract inbound interest |
| Operating advisor network | Recruit 3 former SaaS CEOs as operating advisors to enhance sourcing credibility |
| Data room preparation | Maintain pre-built CIM templates and financial models to accelerate diligence on inbound opportunities |

### Key Messaging Themes

For all outreach, emphasize:

1. **Partnership approach:** "We are operator-friendly, governance-light investors who preserve founder culture while providing growth capital and strategic support."
2. **Sector expertise:** "We have completed 12 SaaS investments across Funds I-III with a median MOIC of 2.8x and median hold IRR of 24%."
3. **Value creation capability:** "Our operating team includes former SaaS CROs and CTOs who have scaled companies from $50M to $500M ARR."
4. **Flexibility:** "We structure transactions to meet founder needs: majority recapitalizations, growth equity, secondary purchases, and continuation vehicles."

---

## 6. Budget and Resources

| Item | Amount |
|------|--------|
| Sourcing team (2 associates, 1 VP) | Funded |
| Travel and entertainment budget | $75,000 |
| Data subscriptions (PitchBook, Grata, ZoomInfo) | $45,000 / year |
| Advisory board retainers (3 advisors) | $150,000 / year |
| External sourcing support (bankers) | Success-based |
| **Total Annual Sourcing Budget** | **$270,000** |

---

## 7. Next Steps

| Action | Owner | Target Date |
|--------|-------|-------------|
| IC approval of sourcing criteria and priority list | IC | May 15, 2026 |
| Initiate banker outreach for Targets 1, 2, 5, 7 | VP Sourcing | May 19, 2026 |
| Draft personalized CEO letters for Targets 3, 4, 9 | Associate | May 22, 2026 |
| Schedule SaaStr meetings with Targets 2, 6, 8, 10 | Associate | May 30, 2026 |
| Recruit first operating advisor (vertical SaaS focus) | Managing Partner | June 15, 2026 |
| First pipeline review with IC | VP Sourcing | June 30, 2026 |

---

*This sourcing memorandum is confidential and prepared for internal use by the deal sourcing team and Investment Committee of Growth Equity Fund IV.*
