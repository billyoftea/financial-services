# Buyer List - Medical Device Company Acquisition

**Target Company:** MedTech Solutions Inc.
**Target Profile:** $500M Revenue | $100M EBITDA | 20% EBITDA Margin
**Sector:** Medical Devices (Orthopedic & Surgical Instruments)
**Engagement:** Sell-Side M&A Advisory
**Date:** May 2026

---

## Executive Summary

MedTech Solutions Inc. is a leading manufacturer of orthopedic implants, surgical instruments, and minimally invasive surgical devices with $500M in annual revenue and $100M EBITDA (20% margin). The company has a strong portfolio of FDA-cleared products, a diversified customer base across 3,500+ hospitals and outpatient surgical centers, and a robust product pipeline in robotic-assisted surgery accessories.

This buyer list identifies 15 potential acquirers categorized as **Strategic Buyers** (9) and **Financial Buyers** (6), with rationale for each.

---

## STRATEGIC BUYERS

### 1. Stryker Corporation (SYK)

| Attribute | Detail |
|---|---|
| **HQ** | Kalamazoo, MI |
| **Revenue** | ~$22B |
| **EV/EBITDA** | ~22x |
| **Type** | Public - Strategic |

**Rationale:** Stryker is a global leader in orthopedic implants and medical devices. MedTech's orthopedic product line would complement Stryker's existing joint reconstruction and trauma portfolios. Stryker has an active M&A strategy (recently acquired Wright Medical for $5.4B) and seeks to expand its presence in the ambulatory surgical center (ASC) market, where MedTech has 40% of its revenue. Geographic footprint overlap is minimal (MedTech strong in Midwest and Southeast US), providing regional expansion.

**Strategic Fit:** High - Product complementarity, ASC market expansion, regional distribution synergy.

---

### 2. Zimmer Biomet Holdings (ZBH)

| Attribute | Detail |
|---|---|
| **HQ** | Warsaw, IN |
| **Revenue** | ~$7.5B |
| **EV/EBITDA** | ~16x |
| **Type** | Public - Strategic |

**Rationale:** Zimmer Biomet is a pure-play orthopedic device company actively seeking to diversify beyond its core hip and knee reconstruction business. MedTech's portfolio of specialty orthopedic implants and surgical instruments would provide immediate revenue diversification. ZBH has articulated a strategy to grow in faster-growing segments (extremities, sports medicine, robotics), aligning with MedTech's pipeline in robotic-assisted surgery accessories. Synergy potential of $25-40M in SG&A and distribution cost savings.

**Strategic Fit:** High - Product diversification, pipeline complementarity, operational synergies.

---

### 3. Johnson & Johnson (MedTech Division) (JNJ)

| Attribute | Detail |
|---|---|
| **HQ** | New Brunswick, NJ |
| **Revenue** | ~$30B (MedTech segment) |
| **EV/EBITDA** | ~20x |
| **Type** | Public - Strategic |

**Rationale:** J&J's MedTech division (formerly DePuy Synthes) is one of the largest orthopedic and surgical device franchises globally. MedTech's product portfolio would strengthen J&J's offerings in extremities and niche orthopedic segments where they have been underweight relative to Stryker and Zimmer. J&J's massive global distribution network could accelerate MedTech's international expansion (currently 90% domestic revenue). The Bolt-on acquisition size ($500M revenue) fits J&J's typical tuck-in acquisition profile.

**Strategic Fit:** High - Distribution leverage, product gap fill, global expansion platform.

---

### 4. Smith & Nephew (SNN)

| Attribute | Detail |
|---|---|
| **HQ** | London, UK |
| **Revenue** | ~$5.5B |
| **EV/EBITDA** | ~15x |
| **Type** | Public - Strategic |

**Rationale:** Smith & Nephew has been undergoing a portfolio transformation under new leadership and is actively seeking acquisitions to close the revenue gap with larger peers (Stryker, ZBH). MedTech's orthopedic implant portfolio would strengthen S&N's orthopedics franchise, particularly in the US market where S&N has been losing share. Cross-selling MedTech products through S&N's established international distribution could unlock significant revenue synergies ($30-50M over 3 years).

**Strategic Fit:** Medium-High - Share recovery strategy, US market strengthening, international cross-sell.

---

### 5. Becton Dickinson (BDX)

| Attribute | Detail |
|---|---|
| **HQ** | Franklin Lakes, NJ |
| **Revenue** | ~$20B |
| **EV/EBITDA** | ~18x |
| **Type** | Public - Strategic |

**Rationale:** BD has been actively expanding its surgical and interventional device portfolio. MedTech's surgical instruments and minimally invasive device capabilities align with BD's strategic focus on high-growth procedural segments. BD's strong relationships with hospital procurement departments (GPO and IDN contracts) would provide immediate distribution scale for MedTech's products. BD has demonstrated willingness to execute mid-size acquisitions ($2-5B range).

**Strategic Fit:** Medium-High - Surgical portfolio expansion, GPO/IDN distribution leverage.

---

### 6. Medtronic plc (MDT)

| Attribute | Detail |
|---|---|
| **HQ** | Dublin, Ireland (Operational HQ: Minneapolis, MN) |
| **Revenue** | ~$32B |
| **EV/EBITDA** | ~17x |
| **Type** | Public - Strategic |

**Rationale:** Medtronic's Surgical Robotics and Surgical Innovations group could benefit from MedTech's pipeline of robotic-assisted surgery accessories and instruments. As Medtronic scales its Hugo robotic surgery platform, having a proprietary accessories portfolio would improve per-procedure economics. MedTech's surgical instrument line also complements Medtronic's existing surgical portfolio. However, Medtronic's large size may limit strategic priority for a $500M target.

**Strategic Fit:** Medium - Robotic surgery accessory pipeline, surgical instrument complement.

---

### 7. Conmed Corporation (CNMD)

| Attribute | Detail |
|---|---|
| **HQ** | Largo, FL |
| **Revenue** | ~$1.3B |
| **EV/EBITDA** | ~17x |
| **Type** | Public - Strategic |

**Rationale:** Conmed is a surgical devices company of sufficient scale to make a transformative acquisition. MedTech's surgical instrument and orthopedic portfolio would nearly double Conmed's revenue, creating a more diversified and scaled competitor. Conmed has been actively pursuing growth through acquisitions and has publicly stated interest in orthopedic and surgical device assets. Revenue and cost synergies estimated at $40-60M.

**Strategic Fit:** High - Transformative scale, product diversification, significant synergy potential.

---

### 8. Globus Medical (GMED)

| Attribute | Detail |
|---|---|
| **HQ** | Audubon, PA |
| **Revenue** | ~$2.5B (post-NEO merger) |
| **EV/EBITDA** | ~20x |
| **Type** | Public - Strategic |

**Rationale:** Following its merger with NuVasive, Globus Medical is a top-5 spine and orthopedic device company. MedTech's orthopedic implant portfolio would complement Globus's spine-focused product line, providing diversification into joint reconstruction and extremities. Globus's strong US sales force and surgeon relationships could accelerate MedTech product adoption. Globus has a history of acquisitive growth and integration capability.

**Strategic Fit:** Medium-High - Product diversification beyond spine, sales force leverage.

---

### 9. Arthrex Inc.

| Attribute | Detail |
|---|---|
| **HQ** | Naples, FL |
| **Revenue** | ~$5B (est.) |
| **EV/EBITDA** | N/A (Private) |
| **Type** | Private - Strategic |

**Rationale:** Arthrex is the global leader in sports medicine and minimally invasive orthopedic surgery. As a privately held company with strong cash flows, Arthrex has the financial capacity for acquisitions. MedTech's minimally invasive surgical device portfolio and sports medicine-adjacent products would be highly complementary to Arthrex's core franchise. Arthrex's direct sales model and surgeon education platform would enhance MedTech's go-to-market effectiveness. Limited regulatory overlap concerns.

**Strategic Fit:** High - Sports medicine adjacency, private company strategic flexibility, complementary distribution.

---

## FINANCIAL BUYERS

### 10. KKR (Kohlberg Kravis Roberts)

| Attribute | Detail |
|---|---|
| **AUM** | ~$550B |
| **Notable Healthcare Deals** | Envision Healthcare, Cotiviti, Zeus Company |
| **Type** | Private Equity - Mega-Cap |

**Rationale:** KKR has a dedicated Global Health Care industry group and has completed $40B+ in healthcare investments. KKR has experience with medical device platform investments and typically targets companies with $50M+ EBITDA. MedTech's $100M EBITDA and 20% margin provide an attractive base for a buy-and-build strategy. KKR could combine MedTech with existing or future healthcare portfolio companies to create a scaled platform. Typical hold period of 4-6 years with target 2.5-3.0x MOIC.

**Thesis:** Buy-and-build platform in fragmented orthopedic/surgical device market; margin expansion through operational improvements and add-on acquisitions.

---

### 11. Warburg Pincus

| Attribute | Detail |
|---|---|
| **AUM** | ~$83B |
| **Notable Healthcare Deals** | Bausch + Lomb, Santen Pharmaceutical, Silk Road Medical |
| **Type** | Private Equity - Growth |

**Rationale:** Warburg Pincus has a long history of healthcare investing across medical devices, pharma services, and healthcare IT. They take a growth-oriented approach, often investing in companies with strong organic growth trajectories and investing additional capital for expansion. MedTech's growth profile (pipeline in robotic accessories, ASC market penetration) aligns with Warburg's investment thesis. Warburg has demonstrated ability to support international expansion, which could accelerate MedTech's geographic diversification.

**Thesis:** Growth equity approach; invest in R&D pipeline, accelerate ASC channel penetration, fund international expansion, target 3-4x return over 5-7 year hold.

---

### 12. Bain Capital

| Attribute | Detail |
|---|---|
| **AUM** | ~$185B |
| **Notable Healthcare Deals** | Fogo de Chao (non-healthcare notable), Guidant (legacy), Olympus stake |
| **Type** | Private Equity - Mega-Cap |

**Rationale:** Bain Capital has been actively rebuilding its healthcare device and medtech portfolio. With experience in complex carve-outs and operational transformations, Bain could acquire MedTech and implement best-in-class operational improvements. Bain's consulting heritage provides strong value creation capabilities in supply chain optimization, commercial excellence, and R&D portfolio management. Target acquisition price of 10-12x EBITDA ($1.0-1.2B) fits within Bain's typical check size of $500M-$2B equity.

**Thesis:** Operational transformation play; supply chain optimization, commercial excellence program, tuck-in acquisitions to build scale, 5-year hold targeting 2.5-3.0x return.

---

### 13. Elliott Investment Management (with strategic partner)

| Attribute | Detail |
|---|---|
| **AUM** | ~$65B |
| **Notable Healthcare Deals** | Syneos Health, Hemacare (various activist positions) |
| **Type** | Activist / Private Equity Hybrid |

**Rationale:** Elliott has increasingly participated in healthcare take-private transactions, often partnering with experienced healthcare operators. MedTech's strong cash flow profile and margin expansion opportunity make it an attractive candidate for a structured acquisition with operational partner involvement. Elliott would bring governance discipline and focus on margin improvement (targeting 25%+ EBITDA margins within 2 years).

**Thesis:** Margin expansion focused; bring in experienced medtech operating partner, optimize product portfolio rationalization, streamline SG&A, target exit within 4 years.

---

### 14. GTCR

| Attribute | Detail |
|---|---|
| **AUM** | ~$40B |
| **Notable Healthcare Deals** | ADT (security), Veradigm, Cision (diverse platform approach) |
| **Type** | Private Equity - Middle Market |

**Rationale:** GTCR employs a "Leaders Strategy" approach, partnering with experienced industry executives to identify and acquire companies in fragmented industries. GTCR has raised dedicated healthcare funds and is actively seeking medical device platform investments. MedTech's market position and financial profile match GTCR's typical investment criteria ($50-200M EBITDA). GTCR would likely combine MedTech with 2-3 complementary add-on acquisitions to build a scaled platform company before exit.

**Thesis:** Platform company for medtech roll-up; partner with industry CEO, execute 2-3 add-on acquisitions in adjacent device categories, build $1B+ revenue platform, exit to strategic or IPO within 5 years.

---

### 15. Linden Capital Partners

| Attribute | Detail |
|---|---|
| **AUM** | ~$5B |
| **Notable Healthcare Deals** | Envigo, Surmodics, RBM (various medtech/pharma services) |
| **Type** | Private Equity - Healthcare Specialist |

**Rationale:** Linden is a healthcare-specialized private equity firm that focuses exclusively on medical device, pharma services, and healthcare technology companies. Their deep sector expertise and extensive network of healthcare operating advisors make them uniquely qualified to identify and execute value creation opportunities at MedTech. Linden's typical investment of $100-500M equity per deal is well-suited for a $1.0-1.2B transaction. They have experience navigating FDA regulatory pathways and optimizing medical device commercial models.

**Thesis:** Specialist healthcare PE approach; leverage deep medtech operating network, optimize commercial model (shift from direct sales to hybrid), rationalize SKU portfolio, invest in high-margin product lines, target 2.5-3.5x return over 5-year hold.

---

## Buyer Prioritization Summary

### Tier 1 - Highest Probability & Strategic Value
| Rank | Buyer | Type | Estimated EV Range | Probability |
|---|---|---|---|---|
| 1 | Stryker (SYK) | Strategic | $1.1B - $1.3B | High |
| 2 | J&J MedTech (JNJ) | Strategic | $1.0B - $1.2B | Medium-High |
| 3 | Zimmer Biomet (ZBH) | Strategic | $1.0B - $1.2B | Medium-High |
| 4 | Arthrex | Strategic (Private) | $1.1B - $1.4B | Medium-High |
| 5 | Conmed (CNMD) | Strategic | $1.2B - $1.5B | Medium |

### Tier 2 - Strong Interest with Execution Considerations
| Rank | Buyer | Type | Estimated EV Range | Probability |
|---|---|---|---|---|
| 6 | Smith & Nephew (SNN) | Strategic | $1.0B - $1.2B | Medium |
| 7 | Globus Medical (GMED) | Strategic | $1.0B - $1.3B | Medium |
| 8 | Becton Dickinson (BDX) | Strategic | $1.0B - $1.2B | Medium |
| 9 | Medtronic (MDT) | Strategic | $950M - $1.1B | Low-Medium |

### Tier 3 - Financial Buyers (Competitive Process)
| Rank | Buyer | Type | Estimated EV Range | Probability |
|---|---|---|---|---|
| 10 | KKR | Financial (PE) | $1.0B - $1.2B | Medium |
| 11 | Bain Capital | Financial (PE) | $1.0B - $1.2B | Medium |
| 12 | Warburg Pincus | Financial (PE) | $1.0B - $1.3B | Medium |
| 13 | GTCR | Financial (PE) | $950M - $1.1B | Medium |
| 14 | Linden Capital | Financial (PE) | $900M - $1.1B | Medium |
| 15 | Elliott (w/ partner) | Financial (Activist/PE) | $950M - $1.1B | Low-Medium |

---

## Valuation Context

**Indicative Valuation Range:**
- Enterprise Value: $900M - $1.5B
- EV/EBITDA Multiple: 9.0x - 15.0x
- EV/Revenue Multiple: 1.8x - 3.0x

**Key Valuation Drivers:**
- Revenue scale ($500M) with defensible market position
- Strong EBITDA margin (20%) with expansion trajectory
- Diversified customer base (3,500+ accounts, no single customer >5%)
- Robust product pipeline (robotic-assisted surgery accessories)
- FDA regulatory clearance portfolio providing barriers to entry

---

*This document is strictly confidential and prepared for discussion purposes only. Not an offer to sell or solicitation to purchase any securities.*
