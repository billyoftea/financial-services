# A-Share Data Sample

## Fetching Chinese A-Share Market Data

---

## Overview

The `ashare-data` skill retrieves Chinese A-share stock market data. This sample demonstrates fetching data for Kweichow Moutai (600519.SH) using the akshare library, with baostock as a fallback.

---

## Sample Code: akshare (Primary)

```python
import akshare as ak
import pandas as pd
from datetime import datetime, timedelta

# ============================================
# Stock: Kweichow Moutai (600519)
# ============================================
stock_code = "600519"

# --- Daily Price Data ---
print("=== Daily Price Data: 600519 (Moutai) ===")
end_date = datetime.now().strftime("%Y%m%d")
start_date = (datetime.now() - timedelta(days=365)).strftime("%Y%m%d")

df_price = ak.stock_zh_a_hist(
    symbol=stock_code,
    period="daily",
    start_date=start_date,
    end_date=end_date,
    adjust="qfq"  # Forward-adjusted prices
)

print(df_price.columns.tolist())
# ['日期', '开盘', '收盘', '最高', '最低', '成交量', '成交额', '振幅', '涨跌幅', '涨跌额', '换手率']
print(df_price.tail())

# --- Real-time Quote ---
print("\n=== Real-time Quote ===")
df_rt = ak.stock_zh_a_spot_em()
moutai_rt = df_rt[df_rt['代码'] == stock_code]
print(moutai_rt.to_string())

# Key fields in real-time data:
# 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低,
# 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌

# --- Financial Indicators ---
print("\n=== Key Financial Indicators ===")
try:
    df_fin = ak.stock_financial_abstract_ths(symbol=stock_code, indicator="按年度")
    print(df_fin.head())
except Exception as e:
    print(f"Financial data error: {e}")

# --- Company Profile ---
print("\n=== Company Profile ===")
try:
    df_info = ak.stock_individual_info_em(symbol=stock_code)
    print(df_info.to_string())
except Exception as e:
    print(f"Info error: {e}")

# --- Index Data (CSI 300) ---
print("\n=== CSI 300 Index Data ===")
df_index = ak.index_zh_a_hist(symbol="000300", period="daily",
                               start_date=start_date, end_date=end_date)
print(df_index.tail())
```

---

## Sample Code: baostock (Fallback)

```python
import baostock as bs
import pandas as pd

# Login
lg = bs.login()

# Fetch daily data for Moutai
rs = bs.query_history_k_data_plus(
    "sh.600519",
    "date,open,high,low,close,volume,amount,turn,pctChg",
    start_date="2025-01-01",
    end_date="2026-05-08",
    frequency="d",
    adjustflag="2"  # Forward-adjusted
)

data_list = []
while (rs.error_code == '0') and rs.next():
    data_list.append(rs.get_row_data())

df = pd.DataFrame(data_list, columns=rs.fields)
print(df.tail())

# Logout
bs.logout()
```

---

## Data Structure

### akshare Historical Price Data

| Column (Chinese) | Column (English) | Type | Description |
|-----------------|------------------|------|-------------|
| 日期 | Date | str | Trading date YYYY-MM-DD |
| 开盘 | Open | float | Opening price (CNY) |
| 收盘 | Close | float | Closing price (CNY) |
| 最高 | High | float | Daily high price |
| 最低 | Low | float | Daily low price |
| 成交量 | Volume | int | Trading volume (shares) |
| 成交额 | Amount | float | Trading value (CNY) |
| 振幅 | Amplitude | float | (High-Low)/PrevClose % |
| 涨跌幅 | Change% | float | Daily return % |
| 涨跌额 | Change | float | Price change (CNY) |
| 换手率 | Turnover% | float | Turnover rate % |

### Real-time Quote Fields

| Field | Description |
|-------|-------------|
| 最新价 | Current/last price |
| 涨跌幅 | Price change % |
| 市盈率-动态 | Dynamic P/E ratio |
| 市净率 | Price-to-Book ratio |
| 总市值 | Total market cap (CNY) |
| 流通市值 | Tradable market cap (CNY) |

---

## Example Output

### Moutai (600519) Sample
```
=== Daily Price Data: 600519 (Moutai) ===
            日期      开盘      收盘      最高      最低     成交量        成交额   振幅   涨跌幅  涨跌额   换手率
150  2026-05-06  1550.00  1562.50  1568.00  1545.00  3,250,000  5,062,500,000  1.48  0.81  12.50  0.26
151  2026-05-07  1563.00  1570.80  1575.00  1558.00  2,890,000  4,534,000,000  1.09  0.53  8.30   0.23

=== Real-time Quote ===
代码      名称      最新价    涨跌幅   成交量        市盈率-动态   总市值
600519   贵州茅台   1570.80   +0.53%   2,890,000    23.5         1,970,000,000,000
```

---

## Common A-Share Tickers

| Code | Name | Sector |
|------|------|--------|
| 600519 | Kweichow Moutai (贵州茅台) | Consumer Staples |
| 601318 | Ping An Insurance (中国平安) | Financials |
| 600036 | China Merchants Bank (招商银行) | Financials |
| 000858 | Wuliangye Yibin (五粮液) | Consumer Staples |
| 300750 | CATL (宁德时代) | Industrials / EV |
| 002594 | BYD Company (比亚迪) | Consumer Discretionary / EV |
| 600900 | CYPC (长江电力) | Utilities |
| 601012 | LONGi Green Energy (隆基绿能) | Renewables |

---

## Limitations

1. **Data Latency:** Real-time data has ~3 second delay during trading hours
2. **akshare Stability:** API endpoints may change; always wrap in try/except
3. **Financial Data Depth:** Less comprehensive than Wind or Choice terminals
4. **Historical Data:** Free APIs typically provide data from 1990 onwards
5. **Adjustment:** Use `adjust="qfq"` for forward-adjusted or `"hfq"` for backward-adjusted prices
6. **Rate Limiting:** Some akshare functions have daily request limits
7. **Currency:** All prices are in CNY (Chinese Yuan)
8. **Trading Hours:** A-share market trades 9:30-11:30 and 13:00-15:00 Beijing time

---

*This sample is generated for testing the ashare-data skill.*
