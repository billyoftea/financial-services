# Crypto Data Sample

## Fetching Cryptocurrency Market Data

---

## Overview

The `crypto-data` skill retrieves cryptocurrency market data for trading pairs like BTC/USDT and ETH/USDT using the ccxt library, which provides a unified API across 100+ exchanges.

---

## Sample Code

```python
import ccxt
import pandas as pd
from datetime import datetime, timedelta

# ============================================
# Initialize Exchange: Binance
# ============================================
exchange = ccxt.binance({
    'apiKey': 'YOUR_API_KEY',        # Optional for public data
    'secret': 'YOUR_SECRET',         # Optional for public data
    'enableRateLimit': True,
})

# ============================================
# Fetch OHLCV Data: BTC/USDT
# ============================================
symbol = "BTC/USDT"
timeframe = "1d"  # Daily candles
limit = 365       # 1 year of data

print(f"=== {symbol} Daily OHLCV Data ===")
ohlcv = exchange.fetch_ohlcv(symbol, timeframe, limit=limit)

df_btc = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
df_btc['timestamp'] = pd.to_datetime(df_btc['timestamp'], unit='ms')
df_btc['symbol'] = symbol
df_btc.set_index('timestamp', inplace=True)

print(f"Data points: {len(df_btc)}")
print(f"Date range: {df_btc.index[0]} to {df_btc.index[-1]}")
print(df_btc.tail())

# ============================================
# Fetch OHLCV Data: ETH/USDT
# ============================================
symbol_eth = "ETH/USDT"
ohlcv_eth = exchange.fetch_ohlcv(symbol_eth, timeframe, limit=limit)

df_eth = pd.DataFrame(ohlcv_eth, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
df_eth['timestamp'] = pd.to_datetime(df_eth['timestamp'], unit='ms')
df_eth.set_index('timestamp', inplace=True)

print(f"\n=== {symbol_eth} Daily OHLCV Data ===")
print(f"Data points: {len(df_eth)}")
print(df_eth.tail())

# ============================================
# Current Ticker / Price
# ============================================
print("\n=== Current Ticker ===")
btc_ticker = exchange.fetch_ticker("BTC/USDT")
eth_ticker = exchange.fetch_ticker("ETH/USDT")

print(f"BTC/USDT: ${btc_ticker['last']:,.2f}")
print(f"  24h Change: {btc_ticker['percentage']:.2f}%")
print(f"  24h Volume: ${btc_ticker['quoteVolume']:,.0f}")
print(f"  24h High: ${btc_ticker['high']:,.2f}")
print(f"  24h Low: ${btc_ticker['low']:,.2f}")

print(f"\nETH/USDT: ${eth_ticker['last']:,.2f}")
print(f"  24h Change: {eth_ticker['percentage']:.2f}%")
print(f"  24h Volume: ${eth_ticker['quoteVolume']:,.0f}")

# ============================================
# Order Book (Depth)
# ============================================
print("\n=== BTC/USDT Order Book (Top 5) ===")
orderbook = exchange.fetch_order_book("BTC/USDT", limit=5)
print("Asks (Sell):")
for ask in orderbook['asks'][:5]:
    print(f"  ${ask[0]:,.2f} x {ask[1]:.4f}")
print("Bids (Buy):")
for bid in orderbook['bids'][:5]:
    print(f"  ${bid[0]:,.2f} x {bid[1]:.4f}")

# ============================================
# Calculate Technical Indicators
# ============================================
df_btc['returns'] = df_btc['close'].pct_change()
df_btc['volatility_30d'] = df_btc['returns'].rolling(30).std() * (365**0.5)  # Annualized
df_btc['sma_50'] = df_btc['close'].rolling(50).mean()
df_btc['sma_200'] = df_btc['close'].rolling(200).mean()

print("\n=== BTC Technical Summary ===")
print(f"Current Price: ${df_btc['close'].iloc[-1]:,.2f}")
print(f"50-day SMA: ${df_btc['sma_50'].iloc[-1]:,.2f}")
print(f"200-day SMA: ${df_btc['sma_200'].iloc[-1]:,.2f}")
print(f"30-day Annualized Volatility: {df_btc['volatility_30d'].iloc[-1]*100:.1f}%")
print(f"YTD Return: {(df_btc['close'].iloc[-1] / df_btc['close'].iloc[0] - 1)*100:.1f}%")
```

---

## Data Structure

### OHLCV DataFrame

| Column | Type | Description |
|--------|------|-------------|
| timestamp | datetime | Candle start time (UTC) |
| open | float | Opening price (USDT) |
| high | float | Highest price in period |
| low | float | Lowest price in period |
| close | float | Closing price (USDT) |
| volume | float | Trading volume (in base asset) |

### Ticker Object Fields

| Field | Description |
|-------|-------------|
| symbol | Trading pair (e.g., "BTC/USDT") |
| last | Last traded price |
| bid / ask | Best bid/ask price |
| high / low | 24h high/low |
| percentage | 24h price change % |
| quoteVolume | 24h volume in quote currency |

---

## Example Output

### BTC/USDT Sample
```
=== BTC/USDT Daily OHLCV Data ===
Data points: 365
Date range: 2025-05-08 to 2026-05-08

timestamp            open      high      low       close     volume
2026-05-06           98,500    99,200    97,800    98,800    15,234
2026-05-07           98,800    100,100   98,200    99,500    18,567
2026-05-08           99,500    101,200   99,000    100,800   16,890

=== Current Ticker ===
BTC/USDT: $100,800.00
  24h Change: +1.31%
  24h Volume: $1,856,700,000
  24h High: $101,200.00
  24h Low: $99,000.00

ETH/USDT: $2,450.00
  24h Change: +2.15%
  24h Volume: $892,000,000
```

---

## Supported Exchanges (ccxt)

| Exchange | ID | Spot | Futures | Notes |
|----------|-----|------|---------|-------|
| Binance | `binance` | Yes | Yes | Largest volume, USDT pairs |
| Coinbase | `coinbase` | Yes | Yes | US-regulated, USD pairs |
| OKX | `okx` | Yes | Yes | Popular in Asia |
| Bybit | `bybit` | Yes | Yes | Derivatives focus |
| Kraken | `kraken` | Yes | Yes | US/EU, strong compliance |
| Bitget | `bitget` | Yes | Yes | Copy trading |
| Gate.io | `gate` | Yes | Yes | Wide altcoin selection |
| Huobi (HTX) | `htx` | Yes | Yes | Asia-focused |

### Common Trading Pairs

| Pair | Description |
|------|-------------|
| BTC/USDT | Bitcoin vs Tether (most liquid) |
| ETH/USDT | Ethereum vs Tether |
| BTC/USD | Bitcoin vs US Dollar |
| ETH/BTC | Ethereum vs Bitcoin ratio |
| SOL/USDT | Solana vs Tether |
| BNB/USDT | Binance Coin vs Tether |

---

## Supported Timeframes

| Timeframe | ccxt code | Description |
|-----------|-----------|-------------|
| 1 minute | `1m` | Intraday scalping |
| 5 minutes | `5m` | Short-term analysis |
| 15 minutes | `15m` | Day trading |
| 1 hour | `1h` | Swing trading |
| 4 hours | `4h` | Medium-term |
| 1 day | `1d` | Daily analysis |
| 1 week | `1w` | Weekly overview |
| 1 month | `1M` | Monthly overview |

---

## Limitations

1. **API Keys:** Required for private endpoints (balances, trading); public data works without keys
2. **Rate Limits:** Each exchange has different rate limits; use `enableRateLimit: True`
3. **Data Availability:** Not all exchanges support all timeframes or all trading pairs
4. **Historical Depth:** Varies by exchange; Binance typically provides 1000 candles per request
5. **Stablecoin Pairs:** USDT pairs most common; some exchanges use BUSD, USDC, or DAI
6. **No Fundamental Data:** ccxt provides market data only; on-chain data requires separate APIs
7. **Delisting:** Exchanges may delist pairs; always handle errors gracefully

---

*This sample is generated for testing the crypto-data skill.*
