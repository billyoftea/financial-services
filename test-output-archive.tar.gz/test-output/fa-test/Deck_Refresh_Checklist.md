# Pitch Deck Refresh Checklist

## Quarterly Data Update Process

**Deck:** Q3 2025 Earnings Update Deck
**Refresh Target:** Q4 2025
**Analyst:** Financial Analysis Skill - Deck Refresh

---

## Step 1: Identify Stale Data

| Data Point | Current Value (Q3) | Source | Status |
|-----------|-------------------|--------|--------|
| Revenue | $12.5B | 10-Q | Needs Update |
| EBITDA | $3.8B | 10-Q | Needs Update |
| Net Income | $2.1B | 10-Q | Needs Update |
| EPS | $3.45 | Press Release | Needs Update |
| Market Cap | $285B | Bloomberg | Auto-updates |
| EV/EBITDA | 14.2x | Calculation | Needs Update |
| Guidance FY25 | $52B rev | IR | Check for revision |
| Employee Count | 45,000 | 10-Q | Needs Update |
| Debt/EBITDA | 2.5x | Calculation | Needs Update |

---

## Step 2: Pull New Numbers

### Data Sources Checklist
- [ ] Latest 10-Q / 10-K filing (SEC EDGAR)
- [ ] Earnings press release
- [ ] Investor presentation (if available)
- [ ] Consensus estimates (Bloomberg/FactSet)
- [ ] Management guidance / transcript
- [ ] Market data (stock price, market cap)

### Key Metrics to Update

| Metric | Q3 2025 (Old) | Q4 2025 (New) | Delta |
|--------|--------------|--------------|-------|
| Revenue | $12,500M | $13,200M | +5.6% |
| Gross Profit | $8,750M | $9,108M | +4.1% |
| EBITDA | $3,800M | $3,960M | +4.2% |
| Net Income | $2,100M | $2,246M | +7.0% |
| EPS | $3.45 | $3.70 | +7.2% |
| Free Cash Flow | $2,400M | $2,650M | +10.4% |

---

## Step 3: Update Charts

### Charts Requiring Data Refresh
1. **Revenue Trend (Bar Chart):** Add Q4 bar, update trailing twelve months
2. **Margin Trend (Line Chart):** Update gross, operating, net margins for Q4
3. **Market Share (Pie Chart):** Verify latest market data, update if changed
4. **Stock Price Performance (Line Chart):** Extend date range to include Q4
5. **Debt Maturity Profile (Stacked Bar):** Update for any new issuances/repayments

### Chart Update Steps
- [ ] Right-click chart -> Select Data -> Update data range
- [ ] Verify axis labels reflect new periods
- [ ] Check that data labels are accurate
- [ ] Ensure legend is still correct
- [ ] Confirm chart title reflects current period

---

## Step 4: Verify Totals

### Cross-Check Calculations

| Check | Formula | Expected | Actual | Status |
|-------|---------|----------|--------|--------|
| TTM Revenue = Sum of Qs | Q1+Q2+Q3+Q4 | $52,300M | $52,300M | OK |
| Gross Margin | GP/Rev | 69.0% | 69.0% | OK |
| EBITDA Margin | EBITDA/Rev | 30.1% | 30.1% | OK |
| Revenue Growth YoY | (Q4/Q4_prev)-1 | 8.5% | 8.5% | OK |
| FCF Conversion | FCF/NI | 118% | 118% | OK |
| Net Debt | Total Debt - Cash | $8,500M | $8,500M | OK |
| EV | MktCap + Net Debt | $293.5B | $293.5B | OK |
| EV/EBITDA | EV/TTM EBITDA | 14.8x | 14.8x | OK |

---

## Step 5: Format Check

### Visual Consistency
- [ ] All fonts consistent (Calibri 10pt body, 14pt headers)
- [ ] Color scheme matches template (primary: #1F4E79, accent: #2E75B6)
- [ ] Number formatting consistent ($M with commas, % with 1 decimal)
- [ ] Date stamps updated to current quarter
- [ ] Page numbers correct after any additions/deletions
- [ ] Headers and footers reflect current period
- [ ] Logo placement consistent across all slides

### Content Quality
- [ ] Footnotes updated for new data sources
- [ ] Disclaimer reflects current date
- [ ] Contact information current
- [ ] No references to outdated guidance
- [ ] Acronyms defined on first use

---

## Sample Data Table: Q3 to Q4 Transition

### Quarterly Financial Summary ($M)

| Metric | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | TTM 2025 |
|--------|---------|---------|---------|---------|----------|
| Revenue | 12,100 | 12,500 | 12,500 | **13,200** | **50,300** |
| Cost of Revenue | 3,800 | 3,750 | 3,750 | **4,092** | **15,392** |
| Gross Profit | 8,300 | 8,750 | 8,750 | **9,108** | **34,908** |
| Operating Expenses | 4,500 | 4,650 | 4,650 | **4,800** | **18,600** |
| Operating Income | 3,800 | 4,100 | 4,100 | **4,308** | **16,308** |
| Net Income | 2,000 | 2,150 | 2,100 | **2,246** | **8,496** |
| EPS | $3.30 | $3.54 | $3.45 | **$3.70** | **$13.99** |
| Free Cash Flow | 2,100 | 2,300 | 2,400 | **2,650** | **9,450** |

### Margins

| Metric | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | TTM 2025 |
|--------|---------|---------|---------|---------|----------|
| Gross Margin | 68.6% | 70.0% | 70.0% | **69.0%** | **69.4%** |
| Operating Margin | 31.4% | 32.8% | 32.8% | **32.6%** | **32.4%** |
| Net Margin | 16.5% | 17.2% | 16.8% | **17.0%** | **16.9%** |
| FCF Margin | 17.4% | 18.4% | 19.2% | **20.1%** | **18.8%** |

*Bold values indicate updated Q4 figures.*

---

## Refresh Timeline

| Step | Duration | Owner |
|------|----------|-------|
| Identify stale data | 30 min | Analyst |
| Pull new numbers | 1-2 hours | Analyst |
| Update charts | 1-2 hours | Associate |
| Verify totals | 30 min | Analyst |
| Format check | 30 min | Associate |
| Senior review | 1 hour | VP/Director |
| **Total** | **5-7 hours** | |

---

*This checklist is generated for testing the deck-refresh skill.*
