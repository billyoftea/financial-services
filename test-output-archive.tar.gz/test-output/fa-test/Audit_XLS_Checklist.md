# Spreadsheet Audit Checklist

## Financial Model Audit Report

**Model Name:** Sample LBO Model v3.2
**Auditor:** Financial Analysis Skill - Audit XLS
**Date:** May 2026
**Scope:** Full model review (all tabs)

---

## 10 Common Issues to Check

### 1. Formula Errors (#REF!, #VALUE!, #DIV/0!)
- [ ] Scan all cells for error values
- [ ] Check formulas referencing deleted rows/columns
- [ ] Verify division operations have denominator checks
- **Common Fix:** Wrap with IFERROR() or add conditional checks

### 2. Hard-Coded Numbers in Formula Cells
- [ ] Identify cells mixing formulas with hardcoded values
- [ ] Flag any number in a formula that is not a cell reference
- **Common Fix:** Move constants to dedicated assumption cells

### 3. Circular References
- [ ] Check for circular dependency warnings
- [ ] Trace precedents/dependents on key output cells
- **Common Fix:** Break the loop with an iterative calculation or manual input

### 4. Broken Links to External Workbooks
- [ ] Identify any external workbook references
- [ ] Verify linked files are accessible and current
- **Common Fix:** Embed data or use Power Query connections

### 5. Inconsistent Formulas Across Rows
- [ ] Compare formulas in adjacent cells (e.g., same column across years)
- [ ] Flag cells where formulas differ from the pattern
- **Common Fix:** Copy consistent formula across the range

### 6. Number Stored as Text
- [ ] Check for green triangle indicators in cells
- [ ] Verify numeric cells are not left-aligned (text indicator)
- **Common Fix:** Use Text-to-Columns or multiply by 1

### 7. Missing or Incorrect Sign Convention
- [ ] Verify cash outflows are consistently negative
- [ ] Check that Sources = Uses in LBO models
- **Common Fix:** Standardize sign convention across the model

### 8. Balance Sheet Does Not Balance
- [ ] Verify Total Assets = Total Liabilities + Equity for all periods
- [ ] Check that the balancing formula is correct
- **Common Fix:** Trace the imbalance by checking each BS line item

### 9. Incorrect Cell References (Off-by-One)
- [ ] Spot-check that formulas reference the correct time period
- [ ] Verify sum ranges include all required cells
- **Common Fix:** Use named ranges to reduce reference errors

### 10. Missing or Outdated Assumptions
- [ ] Verify all assumption cells have reasonable values
- [ ] Check that input cells are clearly formatted/colored
- **Common Fix:** Create a dedicated assumptions tab with color coding

---

## Sample Audit Report

### Model: Sample LBO Acquisition Model

| # | Finding | Sheet | Cell | Severity | Description |
|---|---------|-------|------|----------|-------------|
| 1 | Hard-coded number in formula | Sources & Uses | C8 | Major | Cell contains `=B8-150` where 150 should reference a fee assumption cell |
| 2 | #REF! error | Debt Schedule | F15 | Critical | Formula references deleted column for Year 4 interest payment |
| 3 | Inconsistent formula | Income Statement | D12 | Minor | Revenue growth formula differs from pattern in adjacent columns |
| 4 | Number stored as text | Assumptions | B5 | Minor | Tax rate "25%" stored as text, not 0.25 as number |
| 5 | Balance sheet imbalance | Balance Sheet | H20 | Critical | Year 4 balance sheet off by $12M; traced to incorrect WC formula |
| 6 | Missing sign convention | Cash Flow | C18 | Major | CapEx shown as positive; should be negative per convention |
| 7 | Broken external link | Summary | B3 | Major | References deleted file "Market_Data_2025.xlsx" |
| 8 | Circular reference | DCF | D25 | Critical | WACC calculation references itself via implied share price loop |
| 9 | Off-by-one reference | Revenue | E8 | Minor | SUM range includes header row, inflating total by $50M |
| 10 | Outdated assumption | Assumptions | B10 | Minor | Risk-free rate still showing 3.5%, current rate is 4.3% |

### Severity Distribution
- **Critical:** 3 findings (must fix before distribution)
- **Major:** 3 findings (should fix, impacts reliability)
- **Minor:** 4 findings (recommended fix, cosmetic or low-risk)

### Recommendations
1. **Immediate:** Fix all Critical findings before sharing with stakeholders
2. **Short-term:** Address Major findings and update all assumptions to current market data
3. **Process:** Implement color-coding standard (blue = input, black = formula, green = link)
4. **Prevention:** Add automated balance check formulas on all balance sheet tabs

---

## Audit Pass/Fail Criteria

| Criteria | Threshold | Result |
|----------|-----------|--------|
| Zero #REF! or #VALUE! errors | 0 | FAIL (1 found) |
| Balance sheet balances within $1 | < $1 | FAIL ($12M off) |
| No hard-coded numbers in formulas | 0 | FAIL (1 found) |
| All assumptions clearly labeled | 100% | PASS |
| Consistent sign convention | 100% | FAIL |
| **Overall Verdict** | | **FAIL - Requires Remediation** |

---

*This audit checklist is generated for testing the audit-xls skill. In production, the skill would scan an actual Excel file and auto-detect these issues.*
