# Data Cleaning Guide for Financial Spreadsheets

## clean-data-xls Skill Reference

---

## 1. Trim Whitespace

### Problem
Leading/trailing spaces cause VLOOKUP failures and matching errors.

### Before
| Company | Revenue |
|---------|---------|
| "  Apple" | 395000 |
| "Microsoft  " | 245000 |
| " Google " | 350000 |

### After
| Company | Revenue |
|---------|---------|
| Apple | 395000 |
| Microsoft | 245000 |
| Google | 350000 |

### Python Code
```python
import openpyxl

wb = openpyxl.load_workbook("data.xlsx")
ws = wb.active

for row in ws.iter_rows(min_row=2, max_col=ws.max_column):
    for cell in row:
        if isinstance(cell.value, str):
            cell.value = cell.value.strip()

wb.save("data_cleaned.xlsx")
```

---

## 2. Fix Numbers Stored as Text

### Problem
Values like "$1,000" or "1,000" are stored as text, breaking SUM and calculations.

### Before
| Revenue | Growth |
|---------|--------|
| "$395,000" | "12.5%" |
| "$245,000" | "15.3%" |
| "N/A" | "-" |

### After
| Revenue | Growth |
|---------|--------|
| 395000 | 0.125 |
| 245000 | 0.153 |
| None | None |

### Python Code
```python
import re

def clean_number(val):
    if val is None or val in ["N/A", "-", "", "n/a"]:
        return None
    if isinstance(val, (int, float)):
        return val
    if isinstance(val, str):
        # Remove currency symbols, commas, parentheses for negatives
        val = val.replace("$", "").replace(",", "")
        if val.startswith("(") and val.endswith(")"):
            val = "-" + val[1:-1]
        try:
            if "%" in val:
                return float(val.replace("%", "")) / 100
            return float(val)
        except ValueError:
            return val
    return val

for row in ws.iter_rows(min_row=2, max_col=ws.max_column):
    for cell in row:
        cell.value = clean_number(cell.value)
```

---

## 3. Standardize Casing

### Problem
Inconsistent casing breaks lookups and grouping: "AAPL" vs "aapl" vs "Apple Inc."

### Before
| Ticker | Company Name |
|--------|-------------|
| aapl | apple inc. |
| MSFT | MICROSOFT CORPORATION |
| Googl | Google LLC |

### After
| Ticker | Company Name |
|--------|-------------|
| AAPL | Apple Inc. |
| MSFT | Microsoft Corporation |
| GOOGL | Google LLC |

### Python Code
```python
def standardize_ticker(val):
    if isinstance(val, str):
        return val.strip().upper()
    return val

def standardize_name(val):
    if isinstance(val, str):
        # Title case, handle special cases
        val = val.strip().title()
        # Common abbreviations
        for abbr in ["Llc", "Inc.", "Corp.", "Ltd.", "Co."]:
            val = val.replace(abbr, abbr)
        return val
    return val

# Apply to specific columns
for row in ws.iter_rows(min_row=2):
    row[0].value = standardize_ticker(row[0].value)  # Ticker column
    row[1].value = standardize_name(row[1].value)    # Name column
```

---

## 4. Date Format Normalization

### Problem
Mixed date formats: "01/15/2025", "2025-01-15", "Jan 15, 2025", "15-Jan-2025"

### Before
| Date | Revenue |
|------|---------|
| 01/15/2025 | 50000 |
| 2025-02-15 | 52000 |
| Mar 15, 2025 | 48000 |
| 15-Apr-2025 | 51000 |

### After
| Date | Revenue |
|------|---------|
| 2025-01-15 | 50000 |
| 2025-02-15 | 52000 |
| 2025-03-15 | 48000 |
| 2025-04-15 | 51000 |

### Python Code
```python
from datetime import datetime
import openpyxl

def normalize_date(val):
    if isinstance(val, datetime):
        return val
    if isinstance(val, str):
        formats = [
            "%m/%d/%Y", "%Y-%m-%d", "%b %d, %Y",
            "%d-%b-%Y", "%m-%d-%Y", "%d/%m/%Y",
        ]
        for fmt in formats:
            try:
                return datetime.strptime(val.strip(), fmt)
            except ValueError:
                continue
    return val

for row in ws.iter_rows(min_row=2):
    date_cell = row[0]  # Date column
    date_cell.value = normalize_date(date_cell.value)
    date_cell.number_format = "YYYY-MM-DD"
```

---

## 5. Duplicate Row Detection

### Problem
Duplicate entries inflate totals and distort analysis.

### Before
| Company | Quarter | Revenue |
|---------|---------|---------|
| AAPL | Q1 2025 | 395000 |
| AAPL | Q1 2025 | 395000 |
| MSFT | Q1 2025 | 245000 |

### After
| Company | Quarter | Revenue |
|---------|---------|---------|
| AAPL | Q1 2025 | 395000 |
| MSFT | Q1 2025 | 245000 |

### Python Code
```python
def remove_duplicates(ws, key_columns=[0, 1]):
    seen = set()
    rows_to_delete = []
    for row_idx, row in enumerate(ws.iter_rows(min_row=2), start=2):
        key = tuple(row[c].value for c in key_columns)
        if key in seen:
            rows_to_delete.append(row_idx)
        else:
            seen.add(key)

    for row_idx in reversed(rows_to_delete):
        ws.delete_rows(row_idx)
```

---

## 6. Column Name Standardization

### Problem
Inconsistent headers: "Revenue ($M)", "revenue_m", "Rev. ($ Millions)"

### Python Code
```python
def standardize_headers(ws):
    header_map = {
        "revenue": "Revenue ($M)",
        "rev": "Revenue ($M)",
        "revenue_m": "Revenue ($M)",
        "ebitda": "EBITDA ($M)",
        "net income": "Net Income ($M)",
        "margin": "Margin (%)",
    }

    for cell in ws[1]:
        if cell.value:
            key = cell.value.lower().replace("(", "").replace(")", "").replace("$", "").strip()
            for pattern, standard in header_map.items():
                if pattern in key:
                    cell.value = standard
                    break
```

---

## Summary: Cleaning Pipeline

```python
def full_clean_pipeline(input_path, output_path):
    wb = openpyxl.load_workbook(input_path)
    ws = wb.active

    # Step 1: Standardize headers
    standardize_headers(ws)

    # Step 2: Trim whitespace
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, str):
                cell.value = cell.value.strip()

    # Step 3: Fix numbers-as-text
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.value = clean_number(cell.value)

    # Step 4: Normalize dates
    for row in ws.iter_rows(min_row=2):
        if row[0].value:
            row[0].value = normalize_date(row[0].value)

    # Step 5: Remove duplicates
    remove_duplicates(ws)

    wb.save(output_path)
    print(f"Cleaned data saved to {output_path}")
```

---

*This guide is generated for testing the clean-data-xls skill.*
