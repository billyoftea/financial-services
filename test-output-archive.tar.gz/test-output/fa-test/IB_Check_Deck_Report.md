# IB Pitch Deck Quality Check Report

## ib-check-deck Skill Output

**Deck Name:** Q4 2025 M&A Advisory Pitch - Tech Target Co.
**Reviewer:** Financial Analysis Skill - IB Check Deck
**Date:** May 2026
**Pages:** 42

---

## Summary

| Severity | Count | Description |
|----------|-------|-------------|
| Critical | 3 | Must fix before client delivery |
| Major | 6 | Should fix, impacts credibility |
| Minor | 6 | Recommended fix, cosmetic issues |
| **Total** | **15** | |

---

## Detailed Findings

### Finding 1 - CRITICAL
**Page:** 5 (Financial Overview)
**Issue:** Revenue numbers inconsistent between slides
- Slide 5 shows revenue as "$2.4B" in the summary box
- Slide 12 shows revenue as "$2.38B" in the detailed table
- Footnote on slide 12 references "calendar year" while slide 5 uses "fiscal year"
**Fix:** Standardize to fiscal year figures ($2,382M) and add footnote clarifying the basis

### Finding 2 - CRITICAL
**Page:** 18 (Valuation Summary)
**Issue:** EV/EBITDA multiple calculation error
- EBITDA shown as $485M, EV shown as $5,820M
- Calculated multiple: 5,820 / 485 = 12.0x
- Deck shows 11.5x (appears to use old EBITDA of $506M)
**Fix:** Recalculate all multiples with current EBITDA figure

### Finding 3 - CRITICAL
**Page:** 25 (Transaction Comps)
**Issue:** Wrong date on comparable transaction
- Transaction listed as "Announced: January 2025"
- Actual announcement date was October 2024 per press release
**Fix:** Update to correct announcement date and verify all other transaction dates

### Finding 4 - MAJOR
**Page:** 3 (Table of Contents)
**Issue:** Page numbers do not match actual layout
- Section 3 listed as starting on page 8, actually starts on page 10
- Two additional slides were inserted but TOC not updated
**Fix:** Update all page numbers in table of contents

### Finding 5 - MAJOR
**Page:** 7 (Market Size)
**Issue:** TAM/SAM/SOM chart uses inconsistent year labels
- Chart title says "2024-2028E"
- X-axis labels show 2023-2027
- Data in table appears to be 2025-2029 based on growth rates
**Fix:** Align all references to the same projection period (2025-2029)

### Finding 6 - MAJOR
**Page:** 15 (Sources & Uses)
**Issue:** Sources do not equal Uses
- Total Sources: $5,150M
- Total Uses: $5,250M
- $100M discrepancy (financing fees excluded from sources but included in uses)
**Fix:** Add financing fees to sources or remove from uses

### Finding 7 - MAJOR
**Page:** 22 (Pro Forma Financials)
**Issue:** Pro forma balance sheet does not balance for Year 1
- Total Assets: $8,450M
- Total Liabilities + Equity: $8,350M
- $100M imbalance traced to goodwill calculation
**Fix:** Recalculate goodwill = Purchase Price - Book Value of Net Assets

### Finding 8 - MAJOR
**Page:** 30 (IRR Analysis)
**Issue:** IRR sensitivity table uses wrong base case entry multiple
- Base case entry multiple is 8.0x per Sources & Uses
- Sensitivity table centers on 7.5x
**Fix:** Re-center sensitivity table around 8.0x entry multiple

### Finding 9 - MAJOR
**Page:** 35 (Management Bios)
**Issue:** Outdated management information
- CEO bio references "20 years of experience" but was written 3 years ago
- CFO left the company in March 2026; interim CFO not listed
**Fix:** Update all bios with current information and verify management team

### Finding 10 - MINOR
**Page:** 2 (Cover)
**Issue:** Subtitle font is Calibri 14pt instead of template standard Calibri 16pt
**Fix:** Update font to match template standard

### Finding 11 - MINOR
**Page:** 9 (Industry Overview)
**Issue:** Chart legend overlaps with data points on the right side
**Fix:** Reposition legend to bottom of chart area

### Finding 12 - MINOR
**Page:** 14 (Competitive Landscape)
**Issue:** Company logo for Competitor C appears stretched/distorted
**Fix:** Re-insert logo image at correct aspect ratio

### Finding 13 - MINOR
**Page:** 28 (Risk Factors)
**Issue:** Bullet point alignment inconsistent - 3 bullets use 0.5" indent, others use 0.25"
**Fix:** Standardize all bullet indentation to 0.25" per template

### Finding 14 - MINOR
**Page:** 38 (Appendix - Legal Disclaimer)
**Issue:** Disclaimer text references "2024" instead of "2026"
**Fix:** Update year in disclaimer text

### Finding 15 - MINOR
**Page:** All
**Issue:** Slide master footer shows "Confidential - Draft" but deck is being finalized for client
**Fix:** Update footer to "Confidential" (remove "Draft") or as per team preference

---

## Formatting Standards Checklist

| Check | Status |
|-------|--------|
| Consistent font (Calibri) across all slides | FAIL - Slide 2 subtitle |
| Consistent color scheme (#1F4E79 primary) | PASS |
| All numbers in same format ($M with commas) | FAIL - Mixed $B and $M |
| Charts have clear titles and axis labels | PASS |
| No orphan lines (single line at top of page) | PASS |
| Footer/disclaimer on every page | PASS |
| Slide numbers consistent | FAIL - TOC mismatch |
| Image quality acceptable (no pixelation) | FAIL - Logo on pg 14 |
| Grid alignment (all boxes aligned) | PASS |
| No typos in key financial figures | FAIL - 3 instances |

---

## Recommendations

1. **Immediate Actions (before delivery):**
   - Fix all 3 Critical findings
   - Reconcile all financial figures across the deck
   - Update management bios for accuracy

2. **Quality Improvements:**
   - Implement a standardized financial data sheet as single source of truth
   - Add automated cross-reference checks for key metrics
   - Use named ranges in Excel to avoid manual transcription errors

3. **Process Improvements:**
   - Establish a peer review step before final QA
   - Create a deck template with locked formatting styles
   - Maintain a change log for version tracking

---

*This report is generated for testing the ib-check-deck skill.*
