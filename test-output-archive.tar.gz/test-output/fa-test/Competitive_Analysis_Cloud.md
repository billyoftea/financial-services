# Cloud Computing Competitive Analysis

## AWS vs Azure vs GCP

**Report Date:** May 2026
**Analyst:** Financial Analysis Skill Test

---

## 1. Market Share Overview

| Provider | 2024 Revenue ($B) | Market Share | YoY Growth |
|----------|-------------------|-------------|-----------|
| AWS (Amazon) | $107.6 | 31% | 19% |
| Azure (Microsoft) | $96.8 | 28% | 29% |
| GCP (Google) | $41.2 | 12% | 28% |
| Alibaba Cloud | $16.5 | 5% | 12% |
| Others | $83.9 | 24% | 15% |
| **Total Market** | **$346.0** | **100%** | **21%** |

---

## 2. Capability Comparison Matrix

| Capability | AWS | Azure | GCP |
|-----------|-----|-------|-----|
| **Compute (IaaS)** | Excellent (EC2, Lambda) | Excellent (VMs, Functions) | Very Good (GCE, Cloud Functions) |
| **Storage** | Excellent (S3, EBS) | Excellent (Blob, Disk) | Excellent (GCS, Persistent Disk) |
| **Databases** | Excellent (RDS, DynamoDB) | Excellent (Cosmos DB, SQL) | Very Good (Cloud SQL, Spanner) |
| **AI/ML** | Very Good (SageMaker, Bedrock) | Excellent (Azure AI, OpenAI) | Excellent (Vertex AI, TPU) |
| **Kubernetes** | Very Good (EKS) | Very Good (AKS) | Excellent (GKE - originated K8s) |
| **Networking** | Excellent (VPC, CloudFront) | Excellent (VNet, CDN) | Very Good (VPC, Cloud CDN) |
| **Security/Compliance** | Excellent | Excellent | Very Good |
| **Hybrid/Multi-cloud** | Good (Outposts) | Excellent (Arc, Stack) | Good (Anthos) |
| **Serverless** | Excellent (Lambda) | Excellent (Functions) | Very Good (Cloud Functions) |
| **Data Analytics** | Excellent (Redshift, Athena) | Excellent (Synapse, Databricks) | Excellent (BigQuery, Dataflow) |

---

## 3. Pricing Comparison (General Purpose Compute)

| Instance Type | AWS (m6i.xlarge) | Azure (D4s v5) | GCP (n2-standard-4) |
|--------------|-------------------|-----------------|---------------------|
| vCPUs | 4 | 4 | 4 |
| RAM (GB) | 16 | 16 | 16 |
| On-Demand ($/hr) | $0.192 | $0.184 | $0.190 |
| 1-Year RI ($/hr) | $0.122 | $0.115 | $0.119 |
| 3-Year RI ($/hr) | $0.080 | $0.076 | $0.078 |
| Spot ($/hr) | $0.058 | $0.055 | $0.057 |

*Note: Prices are approximate and vary by region.*

---

## 4. SWOT Analysis

### AWS (Amazon Web Services)

| | Positive | Negative |
|---|---------|----------|
| **Internal** | **Strengths:** Largest market share, broadest service portfolio, deepest partner ecosystem, strong enterprise adoption | **Weaknesses:** Complex pricing, steep learning curve, premium pricing vs peers |
| **External** | **Opportunities:** Generative AI growth (Bedrock), edge computing, industry-specific solutions | **Threats:** Azure gaining in enterprise, anti-trust scrutiny, commoditization of core services |

### Azure (Microsoft)

| | Positive | Negative |
|---|---------|----------|
| **Internal** | **Strengths:** Enterprise integration (Office 365, Dynamics), OpenAI partnership, hybrid cloud leadership, strong compliance | **Weaknesses:** Second-largest but not dominant in any single category, portal UX can be confusing |
| **External** | **Opportunities:** OpenAI/AI monopoly advantage, government contracts, GitHub developer ecosystem | **Threats:** Dependency on OpenAI relationship, AWS price competition, GCP gaining mindshare |

### GCP (Google Cloud Platform)

| | Positive | Negative |
|---|---------|----------|
| **Internal** | **Strengths:** Data/AI/ML leadership (BigQuery, Vertex AI), Kubernetes leadership, competitive pricing, sustainability | **Weaknesses:** Third-place market share, smaller partner ecosystem, fewer enterprise features |
| **External** | **Opportunities:** AI-first positioning, data-driven enterprises, cost-conscious mid-market | **Threats:** Enterprise conservatism favoring AWS/Azure, limited government clearance, talent retention |

---

## 5. Key Financial Metrics

| Metric | AWS | Azure (Intelligent Cloud) | GCP (Google Cloud) |
|--------|-----|--------------------------|-------------------|
| Revenue TTM ($B) | $107.6 | $96.8 | $41.2 |
| Revenue Growth | 19% | 29% | 28% |
| Operating Margin | ~38% | ~45%* | Turning profitable |
| CapEx ($B) | $45.0 | $35.0 | $30.0 |
| Employees | ~120K | ~110K | ~45K |
| Data Centers | 33 regions | 60+ regions | 40 regions |

*Azure margin includes other Microsoft cloud products.*

---

## 6. Investment Implications

### Bull Case
- Cloud infrastructure spending projected to reach $600B by 2028 (14% CAGR)
- AI/ML workloads driving incremental demand for compute and storage
- Hybrid and multi-cloud adoption expanding the addressable market
- Enterprise digital transformation still in early innings (only ~30% of workloads migrated)

### Bear Case
- Hyperscaler CapEx unsustainable at current levels ($100B+ combined annually)
- Price wars eroding margins as services commoditize
- Regulatory risk (data sovereignty, antitrust)
- AI may reduce compute demand long-term through efficiency gains

### Key Watchpoints
1. **AWS:** Monitor AI service adoption rates (Bedrock revenue contribution)
2. **Azure:** Track OpenAI dependency and enterprise AI deployment pipelines
3. **GCP:** Watch for profitability inflection and large enterprise deal wins
4. **Industry:** Cloud spending growth rate vs. GDP growth (cycle sensitivity)

---

*Disclaimer: This analysis is generated for testing purposes and should not be used for investment decisions.*
