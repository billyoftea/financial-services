# Skill Creator Output

## Meta-Skill: Generating New Skill Definitions

---

## Overview

The `skill-creator` skill generates new skill definitions (SKILL.md files) based on user requirements. This document shows a sample output: a hypothetical "ESG Scoring" skill definition.

---

## Sample Generated Skill: ESG Scoring

### SKILL.md

```markdown
---
name: esg-scoring
description: Analyze a company's Environmental, Social, and Governance (ESG) performance by aggregating data from multiple rating agencies, filing disclosures, and news sources to produce a comprehensive ESG scorecard with peer comparison.
trigger: User requests an ESG analysis, ESG scoring, sustainability assessment, or ESG peer comparison for a specific company.
tools:
  - xlsx-author
  - pptx-author
inputs:
  - name: ticker
    type: string
    required: true
    description: Stock ticker symbol of the company to analyze (e.g., "AAPL")
  - name: peer_group
    type: list
    required: false
    description: List of peer tickers for comparison (e.g., ["MSFT", "GOOGL", "META"])
    default: []
  - name: framework
    type: string
    required: false
    description: ESG framework to use for scoring
    options: ["MSCI", "SASB", "GRI", "TCFD", "Custom"]
    default: "SASB"
  - name: output_format
    type: string
    required: false
    description: Output format for the ESG report
    options: ["xlsx", "pptx", "both"]
    default: "both"
outputs:
  - type: xlsx
    description: ESG Scorecard Excel workbook with detailed scoring, peer comparison, and trend analysis
  - type: pptx
    description: ESG Summary presentation for stakeholder review
---

# ESG Scoring Analysis

## Task 1: Data Collection (Est: 3-5 minutes)

### Environmental Data
- Carbon emissions (Scope 1, 2, 3) from CDP filings and sustainability reports
- Energy consumption and renewable energy percentage
- Water usage and waste generation metrics
- Environmental violations and penalties

### Social Data
- Employee diversity metrics (gender, ethnicity at various levels)
- Employee safety record (LTIR, fatalities)
- Community investment and philanthropic spending
- Supply chain labor practices and audits
- Customer privacy and data security incidents

### Governance Data
- Board composition (independence, diversity, tenure)
- Executive compensation alignment with ESG targets
- Shareholder rights and proxy voting analysis
- Business ethics and anti-corruption policies
- Related party transactions

### Data Sources
- Company sustainability reports (PDF/web)
- SEC filings (10-K, proxy statements)
- CDP questionnaires and scores
- MSCI, Sustainalytics, ISS ESG ratings (if accessible)
- News and controversy screening

## Task 2: Scoring Methodology (Est: 2-3 minutes)

### Scoring Framework
Score each dimension on a 0-100 scale:

| Dimension | Weight | Sub-Categories |
|-----------|--------|---------------|
| Environmental | 33% | Carbon (30%), Energy (25%), Water (15%), Waste (15%), Biodiversity (15%) |
| Social | 33% | Diversity (25%), Safety (25%), Community (20%), Supply Chain (20%), Privacy (10%) |
| Governance | 34% | Board Quality (30%), Compensation (25%), Shareholder Rights (25%), Ethics (20%) |

### Scoring Rules
- Score = weighted average of sub-category scores
- Each sub-category scored 0-100 based on percentile rank vs. industry peers
- Controversy adjustment: -5 to -20 points per material controversy
- Trend adjustment: +5 for improving trend, -5 for declining trend

## Task 3: Excel Scorecard Generation (Est: 2-3 minutes)

### Tab 1: Executive Summary
- Overall ESG Score with gauge chart description
- E/S/G pillar scores with radar chart description
- Peer comparison table with quartile rankings
- Key strengths and concerns (top 3 each)

### Tab 2: Environmental Scorecard
- Detailed E metrics with scores and raw data
- 3-year trend for each metric
- Peer benchmark comparison
- Carbon emissions breakdown (Scope 1/2/3)
- Targets vs. actuals tracking

### Tab 3: Social Scorecard
- Detailed S metrics with scores and raw data
- Diversity dashboard (leadership composition)
- Safety performance trend
- Community investment summary

### Tab 4: Governance Scorecard
- Board composition analysis
- Compensation analysis (pay ratio, ESG-linked %)
- Shareholder rights scorecard
- Ethics and compliance summary

### Tab 5: Peer Comparison
- Comprehensive peer comparison matrix
- Percentile rankings across all metrics
- Strengths/weaknesses vs. peers

### Tab 6: Trend Analysis
- 3-year ESG score trajectory
- Score movement by pillar
- Key drivers of score changes

## Task 4: PPTX Summary Generation (Est: 2-3 minutes)

### Slide 1: Title
- Company name, ticker, ESG overall score
- Report date and framework used

### Slide 2: ESG Score Summary
- E/S/G pillar scores with visual gauges
- Peer comparison bar chart
- Key highlights (2-3 bullets)

### Slide 3: Environmental Analysis
- Carbon emissions trend chart
- Key environmental metrics table
- Notable strengths and concerns

### Slide 4: Social Analysis
- Diversity metrics visualization
- Safety performance trend
- Community impact summary

### Slide 5: Governance Analysis
- Board composition pie chart
- Compensation alignment assessment
- Shareholder rights overview

### Slide 6: Peer Benchmarking
- ESG score comparison bar chart
- Peer ranking table
- Relative strengths and weaknesses

### Slide 7: Recommendations
- Top 3 areas for improvement
- Quick wins vs. long-term initiatives
- Expected score impact of each recommendation

## Task 5: Quality Assurance (Est: 1-2 minutes)

- [ ] All scores are within 0-100 range
- [ ] Weights sum to 100% for each pillar
- [ ] Peer comparison uses consistent time periods
- [ ] Controversy data is current (within last 12 months)
- [ ] No missing scores without explanation
- [ ] Formatting consistent across all tabs/slides
- [ ] Disclaimer and methodology notes included
```

---

## SKILL.md Anatomy

### Frontmatter Fields

| Field | Required | Description |
|-------|----------|-------------|
| name | Yes | Unique skill identifier (kebab-case) |
| description | Yes | 1-2 sentence description of what the skill does |
| trigger | Yes | Natural language description of when to invoke the skill |
| tools | Yes | List of tools the skill uses |
| inputs | Yes | Array of input parameters with name, type, required, description |
| outputs | Yes | Array of output specifications with type and description |
| template | No | Path to template file if applicable |
| version | No | Skill version number |
| author | No | Original author |

### Body Sections

1. **Task Breakdown:** Numbered tasks with time estimates
2. **Data Collection:** Sources and methodology
3. **Processing Logic:** Step-by-step instructions
4. **Output Generation:** Format and content specifications
5. **Quality Assurance:** Validation checklist

---

## Creating a New Skill: Workflow

1. **User describes the desired skill** in natural language
2. **Skill Creator analyzes** the request and identifies:
   - Required inputs
   - Necessary tools (xlsx, pptx, web search, etc.)
   - Output format
   - Task decomposition
3. **Skill Creator generates** a complete SKILL.md file
4. **User reviews** and provides feedback
5. **Skill Creator iterates** on the definition
6. **Final SKILL.md** is saved to the skills directory

---

*This output is generated for testing the skill-creator skill.*
