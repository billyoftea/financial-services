# Global Equity Data Sample

## Fetching HK and US Stock Data via yfinance

---

## Overview

The `global-equity-data` skill retrieves equity market data from global exchanges using the yfinance library. This sample demonstrates fetching data for Hong Kong and US listed stocks.

---

## Sample Code

```python
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta

# ============================================
# US Stock: Apple (AAPL)
# ============================================
aapl = yf.Ticker("AAPL")

# Get current price and key stats
aapl_info = aapl.info

print("=== AAPL Key Statistics ===")
print(f"Company: {aapl_info.get('longName', 'N/A')}")
print(f"Sector: {aapl_info.get('sector', 'N/A')}")
print(f"Market Cap: ${aapl_info.get('marketCap', 0):,.0f}")
print(f"Current Price: ${aapl_info.get('currentPrice', 0):.2f}")
print(f"52-Week High: ${aapl_info.get('fiftyTwoWeekHigh', 0):.2f}")
print(f"52-Week Low: ${aapl_info.get('fiftyTwoWeekLow', 0):.2f}")
print(f"Trailing P/E: {aapl_info.get('trailingPE', 0):.1f}")
print(f"Forward P/E: {aapl_info.get('forwardPE', 0):.1f}")
print(f"EV/EBITDA: {aapl_info.get('enterpriseToEbitda', 0):.1f}")
print(f"Dividend Yield: {aapl_info.get('dividendYield', 0)*100:.2f}%")

# Historical price data (1 year)
end_date = datetime.now()
start_date = end_date - timedelta(days=365)
aapl_hist = aapl.history(start=start_date, end=end_date)
print(f"\nHistorical data rows: {len(aapl_hist)}")
print(aapl_hist.tail())

# ============================================
# HK Stock: Tencent (0700.HK)
# ============================================
tencent = yf.Ticker("0700.HK")
tencent_info = tencent.info

print("\n=== 0700.HK (Tencent) Key Statistics ===")
print(f"Company: {tencent_info.get('longName', 'N/A')}")
print(f"Sector: {tencent_info.get('sector', 'N/A')}")
print(f"Market Cap: HK${tencent_info.get('marketCap', 0):,.0f}")
print(f"Current Price: HK${tencent_info.get('currentPrice', 0):.2f}")
print(f"52-Week High: HK${tencent_info.get('fiftyTwoWeekHigh', 0):.2f}")
print(f"52-Week Low: HK${tencent_info.get('fiftyTwoWeekLow', 0):.2f}")
print(f"Trailing P/E: {tencent_info.get('trailingPE', 0):.1f}")
print(f"Forward P/E: {tencent_info.get('forwardPE', 0):.1f}")

# Historical price data
tencent_hist = tencent.history(start=start_date, end=end_date)
print(f"\nHistorical data rows: {len(tencent_hist)}")
print(tencent_hist.tail())

# ============================================
# Multi-stock comparison
# ============================================
tickers = ["AAPL", "MSFT", "0700.HK", "9988.HK"]
data = yf.download(tickers, period="1mo")
print("\n=== Recent Closing Prices ===")
print(data['Close'].tail())
```

---

## Data Structure

### yfinance Ticker.info Fields

| Field | Description | Example (AAPL) |
|-------|-------------|----------------|
| longName | Company full name | Apple Inc. |
| sector | Industry sector | Technology |
| marketCap | Market capitalization | 3,500,000,000,000 |
| currentPrice | Last traded price | 225.50 |
| trailingPE | Trailing 12-month P/E | 37.2 |
| forwardPE | Forward consensus P/E | 32.5 |
| enterpriseToEbitda | EV/EBITDA ratio | 28.5 |
| dividendYield | Annual dividend yield | 0.005 |
| fiftyTwoWeekHigh | 52-week high price | 260.00 |
| fiftyTwoWeekLow | 52-week low price | 165.00 |
| totalRevenue | Annual revenue | 395,000,000,000 |
| grossMargins | Gross margin % | 0.46 |
| operatingMargins | Operating margin % | 0.32 |
| returnOnEquity | ROE % | 1.60 |

### Historical Price DataFrame Columns

| Column | Description |
|--------|-------------|
| Open | Opening price |
| High | Daily high |
| Low | Daily low |
| Close | Closing price |
| Volume | Trading volume |
| Dividends | Dividend paid |
| Stock Splits | Stock split ratio |

---

## Example Output

### AAPL Sample Output
```
=== AAPL Key Statistics ===
Company: Apple Inc.
Sector: Technology
Market Cap: $3,450,000,000,000
Current Price: $228.50
52-Week High: $260.10
52-Week Low: $165.67
Trailing P/E: 37.2
Forward P/E: 32.1
EV/EBITDA: 28.5
Dividend Yield: 0.52%

Historical data rows: 252
            Open    High     Low   Close      Volume  Dividends  Stock Splits
2026-05-07  227.30  229.50  226.80  228.50  52,345,678        0.0           0.0
```

### 0700.HK (Tencent) Sample Output
```
=== 0700.HK (Tencent) Key Statistics ===
Company: Tencent Holdings Limited
Sector: Communication Services
Market Cap: HK$4,200,000,000,000
Current Price: HK$495.00
52-Week High: HK$520.00
52-Week Low: HK$310.00
Trailing P/E: 22.5
Forward P/E: 18.3

Historical data rows: 248
            Open    High     Low   Close      Volume  Dividends  Stock Splits
2026-05-07  490.00  498.00  488.00  495.00  18,234,567        0.0           0.0
```

---

## Supported Exchanges (Common Ticker Suffixes)

| Exchange | Suffix | Example |
|----------|--------|---------|
| NYSE/NASDAQ (US) | (none) | AAPL, MSFT |
| Hong Kong | .HK | 0700.HK, 9988.HK |
| Tokyo | .T | 7203.T (Toyota) |
| London | .L | SHEL.L (Shell) |
| Shanghai | .SS | 600519.SS (Moutai) |
| Shenzhen | .SZ | 000858.SZ (Wuliangye) |
| Taiwan | .TW | 2330.TW (TSMC) |
| Singapore | .SI | D05.SI (DBS) |
| Australia | .AX | BHP.AX |

---

## Limitations and Notes

1. **Data Delay:** yfinance provides 15-minute delayed data during market hours
2. **Historical Data:** Maximum ~50 years of daily data; intraday limited to 60 days
3. **HK Stocks:** Prices in HKD; volume may include off-exchange trades
4. **Fundamental Data:** Not all fields are available for international stocks
5. **Rate Limiting:** Excessive requests may result in temporary IP blocks
6. **Accuracy:** Always cross-reference with official exchange data for production use
7. **Currency:** All prices are in the local currency of the exchange

---

*This sample is generated for testing the global-equity-data skill.*
