# PPT Template Creator Guide

## Creating Skills from User-Provided PowerPoint Templates

---

## Overview

The `ppt-template-creator` skill generates new presentation skills based on user-provided PowerPoint templates. This guide outlines the process for analyzing a template and creating the corresponding SKILL.md definition.

---

## Step 1: Template Analysis Checklist

When a user provides a PPTX template, analyze the following:

### Layout Analysis
- [ ] Identify all slide layouts (title, content, section, divider, etc.)
- [ ] Count the number of unique layout types
- [ ] Note master slide elements (logos, footers, page numbers)
- [ ] Identify color theme (primary, secondary, accent colors)
- [ ] Document font scheme (heading font, body font, sizes)

### Content Structure
- [ ] Identify placeholder types (title, body, chart, image, table)
- [ ] Map which layouts are used for which content types
- [ ] Note fixed elements vs. variable elements
- [ ] Identify recurring patterns (e.g., KPI slides always have 4 metrics)

### Variable Identification
- [ ] List all text that changes between presentations (company names, dates, numbers)
- [ ] Categorize variables: single-value (company name), tabular (financial data), chart data
- [ ] Identify conditional elements (show/hide sections based on deal type)
- [ ] Note formatting requirements for each variable (currency, percentage, date format)

### Chart Requirements
- [ ] Document chart types used (bar, line, pie, waterfall, etc.)
- [ ] Identify data source for each chart
- [ ] Note chart styling (colors, labels, legends)
- [ ] Map chart data structure (rows/columns needed)

---

## Step 2: SKILL.md Structure

Create a SKILL.md file following this structure:

```markdown
---
name: [skill-name]
description: [1-2 sentence description]
trigger: [when to use this skill]
tools:
  - pptx-author
  - xlsx-author (if data preparation needed)
inputs:
  - name: company_name
    type: string
    required: true
    description: Target company name
  - name: financial_data
    type: table
    required: true
    description: Financial metrics in tabular format
  - name: chart_data
    type: object
    required: false
    description: Data for chart generation
outputs:
  - type: pptx
    description: Generated presentation file
template: [path or reference to template file]
---

# [Skill Name]

## Instructions

1. **Data Collection**
   - Gather [specific data points]
   - Validate inputs against requirements

2. **Slide Generation**
   - Slide 1: Title slide using [layout-name]
     - Set [variable-1] to title placeholder
     - Set [variable-2] to subtitle placeholder
   - Slide 2: Executive Summary using [layout-name]
     - Populate KPI boxes with [data-source]
     - Generate chart using [chart-type]

3. **Formatting Rules**
   - All numbers: "#,##0" format
   - All currency: "$#,##0" with dollar sign
   - All percentages: "0.0%" format
   - Font: [font-name] [size]pt
   - Primary color: [hex-code]
   - Secondary color: [hex-code]

4. **Quality Checks**
   - Verify all placeholders are filled
   - Check chart data accuracy
   - Ensure consistent formatting
```

---

## Step 3: Variable Identification Template

### Example: M&A Pitch Deck Template

| Variable Name | Type | Source | Format | Example |
|--------------|------|--------|--------|---------|
| target_name | string | User input | Plain text | "TechCorp Inc." |
| buyer_name | string | User input | Plain text | "Acme Holdings" |
| deal_value | number | User input | $#,##0M | "$5,200M" |
| ev_ebitda | number | Calculation | 0.0x | "8.5x" |
| revenue | table | Financial data | $#,##0M | See below |
| irr | number | Calculation | 0.0% | "22.5%" |
| report_date | date | System | Month YYYY | "May 2026" |
| comps_table | table | Market data | See format | See below |

### Table Variable Format

```json
{
  "headers": ["Metric", "FY2024", "FY2025E", "FY2026E"],
  "rows": [
    ["Revenue ($M)", 2450, 2800, 3200],
    ["EBITDA ($M)", 650, 750, 880],
    ["Net Income ($M)", 320, 380, 450]
  ]
}
```

---

## Step 4: Chart Mapping Template

| Slide | Chart Type | Data Source | X-axis | Y-axis | Series |
|-------|-----------|-------------|--------|--------|--------|
| 5 | Bar | Revenue data | Year | Revenue ($M) | Revenue |
| 8 | Line | Margin data | Year | Margin (%) | Gross, Operating, Net |
| 12 | Pie | Market share | - | Share (%) | Competitors |
| 15 | Waterfall | Bridge | Category | Value ($M) | EBITDA to FCF |
| 20 | Scatter | Comps | EV/Revenue | EV/EBITDA | Peer companies |

---

## Step 5: Sample SKILL.md (Generated)

Here is a sample generated skill definition for a hypothetical "Quarterly Earnings Update" template:

```markdown
---
name: earnings-update
description: Generate a quarterly earnings update presentation from a standardized template
trigger: User requests a quarterly earnings update deck or post-earnings presentation
tools:
  - pptx-author
inputs:
  - name: ticker
    type: string
    required: true
    description: Stock ticker symbol
  - name: quarter
    type: string
    required: true
    description: Quarter identifier (e.g., Q1 2026)
  - name: financial_data
    type: table
    required: true
    description: Quarterly financial metrics
outputs:
  - type: pptx
    description: Quarterly earnings update presentation
template: templates/earnings_update_template.pptx
---

# Quarterly Earnings Update

## Instructions

1. Load template from templates/earnings_update_template.pptx
2. Replace all {{TICKER}} placeholders with the company ticker
3. Replace all {{QUARTER}} placeholders with the quarter identifier
4. Replace all {{DATE}} placeholders with current date
5. Populate financial tables on slides 3-5 with input data
6. Generate charts:
   - Revenue trend (bar chart, slides 3)
   - Margin analysis (line chart, slide 4)
   - Segment breakdown (pie chart, slide 5)
7. Update KPI boxes on slide 2 with key metrics
8. Apply number formatting per template standards
9. Save to output directory
```

---

## Best Practices

1. **Template Naming:** Use descriptive names like `ma_pitch_deck` or `quarterly_earnings`
2. **Variable Naming:** Use snake_case, prefix with type (e.g., `str_company_name`, `tbl_financials`)
3. **Layout Mapping:** Document which template layout corresponds to which content type
4. **Error Handling:** Define fallback behavior when data is missing
5. **Version Control:** Track template versions in the SKILL.md frontmatter
6. **Testing:** Generate a test deck with sample data for each new template skill

---

*This guide is generated for testing the ppt-template-creator skill.*
