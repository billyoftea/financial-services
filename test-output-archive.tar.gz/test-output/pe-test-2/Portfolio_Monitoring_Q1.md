# Portfolio Monitoring Report -- Q1 2026

**Fund:** Growth Partners IV | **Report Date:** April 15, 2026 | **Quarter:** Q1 2026

---

## Executive Summary

Portfolio revenue of $1.42B came in 3% above budget; EBITDA of $285M was 1% below plan due to Atlas Logistics cost overruns. Two companies on watch list for margin deterioration.

---

## Performance Overview

| Company | Revenue ($M) | Budget ($M) | Var % | EBITDA ($M) | Budget ($M) | Var % | Status |
|---------|-------------|-------------|-------|-------------|-------------|-------|--------|
| NovaTech | 310 | 295 | +5.1% | 78 | 76 | +2.6% | Green |
| Meridian Health | 195 | 190 | +2.6% | 22 | 24 | -8.3% | Yellow |
| Atlas Logistics | 280 | 278 | +0.7% | 35 | 40 | -12.5% | Red |
| Pinnacle Retail | 340 | 330 | +3.0% | 85 | 84 | +1.2% | Green |
| CoreFin Solutions | 295 | 280 | +5.4% | 65 | 61 | +6.6% | Green |
| **Total** | **1,420** | **1,373** | **+3.4%** | **285** | **285** | **0.0%** | -- |

---

## Company Highlights

### NovaTech -- Green
- ARR grew 28% YoY to $420M; net retention at 125%.
- Landed 3 enterprise deals >$5M ACV.
- R&D spend on track; new AI copilot feature driving pipeline.

### Meridian Health -- Yellow
- Revenue beat driven by one-time regulatory consulting revenue ($8M).
- Core recurring revenue missed by 2%; patient volume soft in Northeast region.
- EBITDA shortfall from accelerated hiring in data science team.

### Atlas Logistics -- Red
- Revenue in-line but EBITDA missed by $5M due to fuel cost spike (+18%).
- Driver wage inflation running 12% above budget; pricing lagging by 1 quarter.
- Customer churn ticked up to 8% annualized (vs. 5% target).

### Pinnacle Retail -- Green
- Strong holiday carryover; e-commerce channel +15% YoY.
- Gross margin expanded 40bps from private label mix shift.
- New distribution center on schedule for Q3 opening.

### CoreFin Solutions -- Green
- Transaction volume +22% YoY; fraud loss rate reduced to 0.04%.
- Signed partnership with 2 regional banks; pipeline at record levels.
- ML model accuracy improvements driving operating leverage.

---

## Action Items

| # | Company | Action Item | Owner | Due Date |
|---|---------|------------|-------|----------|
| 1 | Atlas Logistics | Implement fuel surcharge mechanism; present to board | CFO | May 30 |
| 2 | Atlas Logistics | Conduct customer retention deep-dive; propose loyalty program | CRO | Jun 15 |
| 3 | Meridian Health | Assess recurring revenue trajectory; adjust FY forecast | Deal Team | May 15 |
| 4 | NovaTech | Review AI copilot monetization model and pricing | Operating Partner | Jun 1 |
| 5 | CoreFin Solutions | Prepare bank partnership expansion plan | CEO | Jun 30 |
| 6 | All | Submit updated FY2026 forecasts by May 20 | Each CFO | May 20 |
