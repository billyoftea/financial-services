# Unit Economics Analysis: SaaS Business Deep-Dive

**Target Company:** NovaTech Inc. | **Sector:** Enterprise SaaS | **ARR:** $420M | **Date:** May 2026

---

## ARR Cohort Analysis

| Cohort Year | Starting ARR ($M) | Year 1 Retention | Year 2 Retention | Year 3 Retention | Net Expansion | Current ARR ($M) |
|-------------|-------------------|------------------|------------------|------------------|---------------|------------------|
| FY2023 | 95 | 94% | 108% | 115% | +15% | 109 |
| FY2024 | 140 | 95% | 112% | -- | +12% | 157 |
| FY2025 | 180 | 96% | -- | -- | +8% | 194 |
| **Total** | -- | -- | -- | -- | -- | **420** |

*Net Revenue Retention (NRR): 122% blended across all cohorts.*

---

## LTV/CAC Analysis

| Segment | ARPA ($K) | Gross Margin | CAC ($K) | Payback (mo) | LTV ($K) | LTV:CAC |
|---------|-----------|-------------|----------|---------------|----------|---------|
| Enterprise | 280 | 82% | 210 | 11 | 1,820 | 8.7x |
| Mid-Market | 85 | 78% | 55 | 10 | 410 | 7.5x |
| SMB | 24 | 72% | 14 | 9 | 72 | 5.1x |
| **Blended** | **130** | **79%** | **93** | **11** | **767** | **8.3x** |

*LTV calculated using: ARPA x Gross Margin x (Retention / (1 + Discount - Retention)). Discount rate: 10%.*

---

## Net Retention Trends

| Metric | FY2023 | FY2024 | FY2025 | LTM |
|--------|--------|--------|--------|-----|
| Gross Retention | 88% | 90% | 92% | 93% |
| Net Revenue Retention | 112% | 118% | 122% | 125% |
| Logo Retention | 85% | 87% | 89% | 91% |
| Expansion Rate | 27% | 31% | 34% | 35% |
| Contraction Rate | 8% | 6% | 5% | 4% |
| Churn Rate | 12% | 10% | 8% | 7% |

---

## Revenue Quality Scorecard

| Dimension | Score (1-5) | Assessment |
|-----------|-------------|-----------|
| Recurring Revenue % | 5 | 94% of total revenue is subscription |
| Retention Quality | 5 | NRR >120% for 3 consecutive years |
| Customer Concentration | 4 | Top 10 = 22% of ARR; well-diversified |
| Contract Visibility | 4 | RPO of $580M (1.4x ARR); 68% cRPO |
| Margin Profile | 4 | 79% gross margin; 25% EBITDA margin |
| Growth Durability | 4 | 28% YoY growth; expanding TAM |
| Pricing Power | 3 | 5-8% annual price increases; some resistance |
| Cohort Consistency | 5 | All cohorts show improving retention |
| **Overall Score** | **4.3 / 5** | **High-quality recurring revenue** |

---

## Key Takeaways

- **LTV:CAC of 8.3x** is best-in-class for enterprise SaaS (benchmark: >3x).
- **Payback period of 11 months** indicates efficient sales motion; enterprise at 11 months is exceptional.
- **Improving retention** across all cohorts suggests strong product-market fit and customer success execution.
- **Risk to monitor:** SMB segment LTV:CAC of 5.1x is lower; contraction in this segment could compress margins. Consider tiered pricing or strategic upsell motions for SMB-to-mid-market migration.
