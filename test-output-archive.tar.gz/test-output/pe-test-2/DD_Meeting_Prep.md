# Due Diligence Meeting Prep: TechCorp Management Interview

**Date:** May 12, 2026 | **Deal Team:** J. Harris (MD), S. Park (VP), R. Chen (Assoc.)
**Company:** TechCorp Inc. | **Sector:** Enterprise SaaS | **ARR:** $400M

---

## Meeting Agenda (90 min)

| Time | Topic | Lead |
|------|-------|------|
| 9:00-9:15 | Opening & company vision | CEO |
| 9:15-9:30 | Revenue model & growth drivers | CFO |
| 9:30-9:45 | Customer acquisition & retention | CRO |
| 9:45-10:00 | Product roadmap & R&D | CTO |
| 10:00-10:15 | Competitive landscape | CEO |
| 10:15-10:30 | Financial deep-dive & adj. EBITDA walk | CFO |

---

## Key Questions (15+)

### Revenue & Growth
1. What is the net revenue retention rate (NRR) by cohort year for the past 3 years?
2. Walk us through the $400M ARR breakout: new logo vs. expansion vs. renewal.
3. What is the average contract length and how has renewal pricing trended?
4. How much of ARR is consumed vs. committed (remaining performance obligations)?

### Unit Economics
5. What is the blended CAC and CAC payback period by customer segment?
6. How does gross margin trend as you scale infrastructure costs?
7. What is the LTV:CAC ratio for enterprise vs. mid-market customers?

### Product & Technology
8. What percentage of revenue comes from products shipped in the last 24 months?
9. Describe the technical architecture and any single points of failure.
10. What is the R&D spend allocation between maintenance and new features?

### Customer & Market
11. Who are the top 10 customers by ARR and what is their satisfaction score (NPS)?
12. What is the competitive win rate against the top 3 competitors?
13. How concentrated is revenue -- top 10 customers as % of total ARR?

### Operations & Team
14. What is the management team's tenure and any recent departures?
15. Describe the sales comp structure and quota attainment distribution.
16. What are the biggest operational risks you see in scaling to $600M ARR?

---

## Data Requests

| Priority | Item | Format |
|----------|------|--------|
| High | Monthly ARR bridge (last 24 months) | Excel |
| High | Customer cohort retention table | Excel |
| High | Detailed P&L (last 3 years + LTM) | Excel |
| Medium | Net dollar retention by vintage | Excel |
| Medium | Sales pipeline by stage | Report |
| Low | Employee headcount by function | Spreadsheet |

---

## Red Flags to Watch

- **Revenue quality:** Watch for multi-year upfront deals inflating new ARR; verify expansion vs. price increases.
- **Churn signals:** Any customers >$1M ARR with declining seat counts or usage metrics.
- **Gross margin pressure:** SaaS companies at scale should show 75%+ gross margin; flag if declining.
- **Customer concentration:** If top 5 > 25% of ARR, assess contractual lock-in and renewal risk.
- **Management alignment:** Check if key executives have meaningful equity vesting beyond the transaction.
- **Technical debt:** Probe for legacy code dependencies that could slow product velocity post-acquisition.
