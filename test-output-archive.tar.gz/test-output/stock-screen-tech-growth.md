# 股票筛选报告 | Stock Screen
## 条件：市值 $10-50B | 收入增速 >20% | EV/EBITDA <25x | 科技板块

> 日期：2026-05-08

---

## 筛选条件

| 参数 | 条件 |
|------|------|
| 市值 | $10B - $50B |
| 收入增速 (YoY) | > 20% |
| EV/EBITDA (NTM) | < 25x |
| 行业 | 科技 (Software, Semiconductor, IT Services) |
| 交易所 | US-listed |

---

## 筛选结果

| 排名 | 股票 | 市值 | 收入增速 | EV/EBITDA | 行业 | 亮点 |
|------|------|------|---------|-----------|------|------|
| 1 | **MSTR** (MicroStrategy) | $42B | +120% | 18x | 数据分析/BTC | Bitcoin 杠杆 + AI 分析平台转型 |
| 2 | **SNOW** (Snowflake) | $48B | +28% | 22x | 云数据平台 | 产品转型加速，净留存率回升 |
| 3 | **DDOG** (Datadog) | $45B | +24% | 20x | 可观测性 | AI 工作负载监控需求爆发 |
| 4 | **NET** (Cloudflare) | $38B | +27% | 21x | 网络安全/CDN | Workers AI 平台增长 |
| 5 | **ZS** (Zscaler) | $32B | +22% | 19x | 零信任安全 | AI 驱动安全需求 |
| 6 | **CRWD** (CrowdStrike) | $88B* | +26% | 24x | 端点安全 | *略超上限，但值得纳入 |
| 7 | **MDB** (MongoDB) | $22B | +21% | 18x | 数据库 | Atlas 云增长 + AI 向量搜索 |
| 8 | **TTD** (The Trade Desk) | $35B | +25% | 22x | 广告科技 | CTV + UID 2.0 驱动 |
| 9 | **PATH** (UiPath) | $12B | +22% | 16x | RPA/AI | AI Agent 自动化转型 |
| 10 | **VEEV** (Veeva Systems) | $28B | +20% | 17x | 生命科学SaaS | Vault 平台 + AI 临床试验 |

---

## Top 3 深度分析

### 1. DDOG — Datadog | 最具吸引力
- **论点**: AI 工作负载的监控需求是结构性的，Datadog 从基础设施监控扩展到应用性能和安全
- **催化剂**: Q1 财报显示 AI 原生客户 ARPU 是传统客户的 3x
- **估值**: 20x NTM EBITDA，在 25%+ 增长率下估值合理

### 2. NET — Cloudflare | 高增长低估值的罕见组合
- **论点**: Workers AI 平台将 Cloudflare 从 CDN 安全公司转型为边缘计算平台
- **催化剂**: AI 推理工作负载向边缘迁移趋势
- **估值**: 21x EBITDA，增速超过估值隐含要求

### 3. MDB — MongoDB | 转折点标的
- **论点**: Atlas 云数据库增速回升 + AI 向量搜索打开新 TAM
- **催化剂**: 非关系型数据库在 AI 应用中的结构性优势
- **估值**: 18x EBITDA，为筛选结果中最低

---

## 筛选局限性

- 数据基于最新公开信息和共识预期
- 市值和估值随市场波动可能变化
- 建议进一步深入个股基本面验证

---

*Sources: Bloomberg, Yahoo Finance, Company Filings, FactSet Estimates*
