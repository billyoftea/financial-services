# CONFIDENTIAL

## Process Letter — Indication of Interest (IOI) Submission

**Project Code Name:** Project Thunder
**Date:** March 1, 2026
**Issued By:** [Investment Bank Name] — Exclusive Financial Advisor to the Seller

---

### 1. Introduction

On behalf of our client (the "Company" or the "Seller"), we are pleased to invite you to participate in the current phase of the sale process for a highly attractive industrial manufacturing platform (the "Target"). This letter sets forth the procedures and guidelines for the submission of Indications of Interest ("IOIs").

### 2. Process Timeline

| Phase                     | Milestone                          | Date                |
|---------------------------|------------------------------------|---------------------|
| **Phase I**               | Teaser Distribution                | February 15, 2026   |
| **Phase I**               | NDA Execution & Process Letter     | February 28, 2026   |
| **Phase I**               | Confidential Information Memorandum (CIM) & Management Access | March 1–31, 2026 |
| **Phase I**               | **IOI Submission Deadline**        | **April 15, 2026**  |
| **Phase II**              | Shortlist Notification             | April 30, 2026      |
| **Phase II**              | Management Presentations & Site Visits | May 5–23, 2026 |
| **Phase II**              | Data Room Access (Full)            | May 1 – June 15, 2026 |
| **Phase III**             | Final Bid Submission               | June 20, 2026       |
| **Phase III**             | Exclusivity & Definitive Agreement | July 2026           |
| **Phase IV**              | Signing & Announcement             | July / August 2026  |
| **Phase IV**              | Closing                            | Q3 2026             |

*All dates are subject to adjustment at the discretion of the Seller and its advisors.*

### 3. IOI Submission Requirements

All Indications of Interest must be submitted in writing no later than **5:00 PM Eastern Time on April 15, 2026** to the undersigned at the contact details provided below. Each IOI should address the following:

#### 3.1 Proposed Transaction Structure

- **Enterprise Value Range** — Indicate a proposed range for the total enterprise value of the Target on a cash-free, debt-free basis, including any assumed liabilities
- **Equity Value** — Implied equity value after adjusting for net debt, working capital, and transaction-related adjustments
- **Form of Consideration** — Cash, stock, or a combination; specify any contingent consideration or earnout structures
- **Financing** — Describe the anticipated sources and availability of financing (cash on hand, committed debt financing, equity co-investment, etc.)

#### 3.2 Transaction Rationale & Strategic Fit

- Brief description of the strategic rationale for the acquisition
- Key synergies anticipated (quantitative estimates where possible)
- Integration approach and timeline

#### 3.3 Proof of Capacity / Confirmatory Diligence

- Evidence of financial capacity to complete the transaction at the indicated value range
- Confirmation of internal approvals obtained or required
- Names of key deal team members and legal counsel

#### 3.4 Assumptions & Conditions

- Key assumptions underlying the proposed valuation range
- Any material conditions precedent to a binding offer
- Required regulatory or third-party consents
- Any proposed reservations of rights (e.g., financing contingency, confirmatory due diligence)

### 4. Confidentiality Obligations

By participating in this process, each prospective buyer acknowledges and agrees to the following:

1. **Non-Disclosure** — All information provided in connection with this process (whether marked confidential or not) constitutes confidential information. No such information may be disclosed to any third party without the prior written consent of the Seller's financial advisor.

2. **Limited Internal Distribution** — Information shall be shared only with those representatives, directors, officers, employees, and advisors who have a strict need to know for purposes of evaluating a potential transaction.

3. **No Public Discussion** — No party shall make any public statement, press release, or communication regarding the Target, the Seller, or the existence of this process without prior written approval.

4. **Standstill** — Each participant agrees that, for a period of 12 months from the date of this letter, it will not (a) acquire or agree to acquire any securities or assets of the Target or the Seller outside of this process, (b) make any unsolicited proposal or approach to the Target or the Seller, or (c) form a group with any other party for the purpose of acquiring the Target.

5. **Non-Solicitation** — No participant shall, for a period of 24 months, directly or indirectly solicit, recruit, or hire any officer, director, or key employee of the Target or the Seller with whom they have had contact during this process.

6. **Return of Materials** — Upon written request, or if a participant withdraws from the process, all confidential materials must be returned or permanently destroyed within 5 business days, with written confirmation provided to the Seller's advisor.

### 5. Process Conduct Guidelines

- **No Contact** — Participants shall not contact the Target, its management, employees, customers, or suppliers without the express prior written consent of the financial advisor.
- **Cooperation** — Participants are expected to proceed expeditiously and in good faith throughout the process.
- **Reservation of Rights** — The Seller and its advisors reserve the right to (a) modify or terminate the process at any time, (b) negotiate with one or more parties exclusively, (c) reject any or all IOIs, and (d) alter the timeline without prior notice.

### 6. Evaluation Criteria

IOIs will be evaluated based on the following factors (not necessarily in order of priority):

1. **Value** — Total enterprise value and certainty of value
2. **Certainty of Closing** — Financial capacity, regulatory risk, and conditionality
3. **Speed** — Ability to complete the transaction expeditiously
4. **Strategic Fit** — Compatibility with the Target's business and stakeholders
5. **Treatment of Stakeholders** — Approach to employees, management retention, and community impact

### 7. Contact Information

All IOIs and correspondence should be directed to:

| Role                  | Contact                          |
|-----------------------|----------------------------------|
| **Lead Advisor**      | [Banker Name], Managing Director |
| **Email**             | [email@bank.com]                 |
| **Phone**             | [+1 (XXX) XXX-XXXX]              |
| **Secondary Contact** | [Associate Name], Vice President |
| **Email**             | [associate@bank.com]             |

---

*This process letter is for informational purposes only and does not constitute a commitment by the Seller to enter into any transaction. The Seller reserves all rights in connection with the sale process.*

**[Investment Bank Name]**
*Exclusive Financial Advisor*
