# CONFIDENTIAL — PROJECT THUNDER

## Indicative Teaser — Industrial Manufacturing Platform

---

**Date:** May 2026
**Advisor:** [Investment Bank Name] — Exclusive Financial Advisor
**Reference:** Project Thunder

---

### Company Overview

The Company ("Project Thunder" or the "Target") is a leading North American industrial manufacturing platform serving diversified end markets including aerospace & defense, energy infrastructure, and general industrial applications. With over 40 years of operating history, the Target has established itself as a preferred supplier to blue-chip OEMs and Tier 1 customers.

### Investment Highlights

- **Leading Market Position** — #1 or #2 market share in three of its four core product lines, with deep contractual relationships spanning 10+ years with key customers
- **Diversified Revenue Base** — No single customer represents more than 8% of revenue; balanced exposure across aerospace (35%), energy (30%), and general industrial (35%) end markets
- **Strong Margin Profile** — 20% EBITDA margins, approximately 300 basis points above peer median, driven by proprietary process technology and operational excellence
- **Growth Runway** — Significant organic growth opportunities through new product introductions, geographic expansion (particularly in the Southeast U.S.), and aftermarket penetration currently at only 25% of installed base
- **Operational Scalability** — Under-invested facility network with capacity to absorb 40%+ revenue growth without major capital expenditure; estimated maintenance CapEx of only 1.5–2.0% of revenue
- **Experienced Management Team** — Tenured leadership team with average industry experience of 20+ years; key executives have expressed willingness to remain post-transaction

### Summary Financial Profile ($USD millions)

| Metric              | FY2024A | FY2025A | FY2026E |
|---------------------|---------|---------|---------|
| **Revenue**         | $270    | $300    | $330    |
| **Gross Profit**    | $108    | $120    | $135    |
| **Gross Margin**    | 40.0%   | 40.0%   | 40.9%   |
| **EBITDA**          | $51     | $60     | $69     |
| **EBITDA Margin**   | 18.9%   | 20.0%   | 20.9%   |
| **Capital Expenditure** | $5  | $6      | $7      |

### Transaction Considerations

The Company's shareholders are exploring strategic alternatives, which may include a majority recapitalization, full sale, or continued partnership with a like-minded strategic or financial sponsor. The Target is well-positioned for a transaction in the near term.

### Key Attributes

| Attribute               | Detail                          |
|-------------------------|---------------------------------|
| **Headquarters**        | Midwest United States           |
| **Employees**           | ~1,200                          |
| **Facilities**          | 6 manufacturing plants          |
| **Revenue TTM**         | ~$300M                          |
| **EBITDA TTM**          | ~$60M (20% margin)             |
| **Revenue CAGR (3-yr)** | ~8%                             |
| **Customer Retention**  | >95%                            |

---

*This document is provided for informational purposes only and does not constitute an offer to sell or a solicitation of an offer to buy any securities. All information is confidential and proprietary. Recipients agree to maintain the confidentiality of this information and not to distribute it to any third party without prior written consent.*

**Contact:** [Banker Name] | [Email] | [Phone]
