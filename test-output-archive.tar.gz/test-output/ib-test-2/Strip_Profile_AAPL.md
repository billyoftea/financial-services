# Company Strip Profile

## Apple Inc. (AAPL)

**As of:** May 8, 2026 | **Currency:** USD

---

## Company Snapshot

| Attribute | Detail |
|-----------|--------|
| **Company** | Apple Inc. |
| **Ticker** | AAPL (NASDAQ) |
| **Sector** | Technology |
| **Sub-Industry** | Consumer Electronics / Hardware |
| **Headquarters** | Cupertino, California, USA |
| **Founded** | 1976 |
| **CEO** | Tim Cook |
| **Employees** | ~164,000 (full-time) |
| **Fiscal Year End** | September |
| **Market Cap** | ~$3.45T |
| **Enterprise Value** | ~$3.37T |
| **Dividend Yield** | 0.5% |
| **Beta** | 1.18 |
| **Credit Rating** | Aaa / AA+ (Moody's / S&P) |

---

## Business Description

Apple Inc. designs, manufactures, and markets smartphones, personal computers, tablets, wearables, and accessories, and sells a variety of related services. The Company operates through five reportable segments:

1. **iPhone** (~46% of revenue) — Flagship smartphone product line; premium market positioning with industry-leading ASPs of ~$950; install base of 1.5B+ active devices globally
2. **Mac** (~8% of revenue) — Personal computers spanning MacBook, iMac, Mac Pro, and Mac Studio; full transition to Apple Silicon (M-series chips) completed
3. **iPad** (~6% of revenue) — Tablet computing devices; dominant market share in premium tablet segment
4. **Wearables, Home & Accessories** (~10% of revenue) — Apple Watch, AirPods, Apple TV, HomePod, and Beats; fastest-growing hardware category
5. **Services** (~30% of revenue) — App Store, iCloud, Apple Music, Apple TV+, Apple Pay, AppleCare, Apple Arcade, and licensing; highest-margin segment with 72% gross margin

**Key Competitive Advantages:** Ecosystem lock-in through iOS/macOS integration, proprietary silicon (M-series, A-series chips), brand equity (consistently ranked #1 global brand), $100B+ annual R&D investment, and services flywheel tied to 2.2B active installed device base.

---

## Key Financials ($ billions)

### Income Statement

| Metric | FY2023A | FY2024A | FY2025A | FY2026E (NTM) |
|--------|---------|---------|---------|---------------|
| **Total Revenue** | $383.3 | $391.0 | $425.5 | $455.0 |
| Product Revenue | $298.4 | $299.6 | $314.9 | $331.2 |
| Services Revenue | $84.9 | $91.4 | $110.6 | $123.8 |
| **Cost of Revenue** | $224.1 | $222.5 | $234.0 | $247.5 |
| **Gross Profit** | $159.2 | $168.5 | $191.5 | $207.5 |
| **Gross Margin** | 41.5% | 43.1% | 45.0% | 45.6% |
| Operating Expenses | ($52.3) | ($54.8) | ($57.8) | ($61.4) |
| **Operating Income** | $106.9 | $113.7 | $133.7 | $146.1 |
| **Operating Margin** | 27.9% | 29.1% | 31.4% | 32.1% |
| **Net Income** | $97.0 | $104.2 | $122.5 | $135.0 |
| **Net Margin** | 25.3% | 26.6% | 28.8% | 29.7% |
| **EPS (Diluted)** | $6.13 | $6.72 | $7.98 | $8.85 |

### Cash Flow & Balance Sheet

| Metric | FY2023A | FY2024A | FY2025A |
|--------|---------|---------|---------|
| **Operating Cash Flow** | $110.5 | $118.3 | $135.0 |
| **CapEx** | ($10.7) | ($11.8) | ($13.2) |
| **Free Cash Flow** | $99.8 | $106.5 | $121.8 |
| **FCF Margin** | 26.0% | 27.2% | 28.6% |
| Cash & Investments | $61.6 | $67.4 | $73.0 |
| Total Debt | $111.1 | $105.0 | $98.0 |
| Net Debt | $49.5 | $37.6 | $25.0 |

---

## Valuation Metrics

### Trading Multiples

| Metric | Current | 5-Year Avg | Sector Median |
|--------|---------|------------|---------------|
| **P/E (NTM)** | 25.5x | 24.8x | 22.0x |
| **EV/Revenue (NTM)** | 7.4x | 6.9x | 4.5x |
| **EV/EBITDA (NTM)** | 23.1x | 22.0x | 16.5x |
| **EV/FCF (NTM)** | 27.7x | 25.5x | 20.0x |
| **P/B** | 48.5x | 45.0x | 5.5x |
| **PEG Ratio** | 2.1x | 1.9x | 1.8x |
| **Dividend Yield** | 0.5% | 0.6% | 1.2% |

### Return Metrics

| Metric | FY2023 | FY2024 | FY2025 |
|--------|--------|--------|--------|
| **ROE** | 160% | 157% | 175% |
| **ROIC** | 55% | 58% | 63% |
| **ROA** | 28% | 29% | 32% |

### Capital Returns (TTM)

| Program | Amount | Yield |
|---------|--------|-------|
| Dividends | $15.8B | 0.5% |
| Share Repurchases | $95.0B | 2.8% |
| **Total Capital Return** | **$110.8B** | **3.2%** |
| Shares Outstanding | 15.3B | — |
| Avg. Daily Volume | 52M shares | — |

---

## Growth Metrics

| Metric | FY2023 | FY2024 | FY2025 | FY2026E |
|--------|--------|--------|--------|---------|
| Revenue Growth | -2.8% | +2.0% | +8.8% | +6.9% |
| Services Growth | +13.6% | +7.7% | +21.0% | +12.0% |
| EPS Growth | -0.5% | +9.6% | +18.8% | +10.9% |
| EBITDA Growth | -1.5% | +7.8% | +17.5% | +9.0% |

---

## Consensus Estimates

| Metric | FY2026E | FY2027E | FY2028E |
|--------|---------|---------|---------|
| Revenue | $455.0B | $488.0B | $522.0B |
| EPS | $8.85 | $9.65 | $10.50 |
| EBITDA | $160.0B | $173.0B | $187.0B |
| Gross Margin | 45.6% | 46.0% | 46.5% |
| Operating Margin | 32.1% | 32.5% | 33.0% |

**Buy / Hold / Sell:** 28 / 12 / 2
**Consensus Target Price:** $235 (range: $185–$280)
**52-Week Range:** $165 – $245
**Current Price:** ~$225

---

## Stock Chart Description

**5-Year Price Chart (May 2021 – May 2026):**

Apple shares have appreciated approximately 95% over the past five years, rising from ~$115 (split-adjusted) to ~$225. Key technical levels and patterns:

- **2021–2022:** Rallied from $115 to a peak of $182 in January 2022, driven by iPhone 13 supercycle and Services acceleration. Declined to $124 by June 2022 amid broader tech selloff and China production disruptions.
- **2023:** Steady recovery from $130 to $195, fueled by iPhone 15 launch, Services margin expansion, and aggressive buybacks. Broke above 50-day and 200-day moving averages in Q2 2023, establishing a bullish trend.
- **2024:** Strong momentum from $185 to $235. Apple Intelligence (AI) announcement at WWDC 2024 catalyzed a 15% rally in 6 weeks. Services revenue crossing $100B annualized milestone drove re-rating.
- **2025:** Consolidated in $220–$250 range. Brief pullback to $210 in Q1 on tariff concerns, but recovered on strong Services growth and Vision Pro adoption. Currently trading near $225.
- **Current Technicals:** Trading above 200-day MA ($205) and 50-day MA ($218). RSI at 55 (neutral). MACD positive but converging. Support at $215–$220; resistance at $245–$250. Volume trending slightly below average.

---

## Recent Developments & Catalysts

1. **Apple Intelligence 2.0** — Next-generation on-device AI platform launching at WWDC 2026 (June); expected to drive iPhone upgrade cycle
2. **Services Margin Expansion** — Gross margin trajectory toward 75% on Services mix shift and App Store pricing power
3. **Capital Allocation** — $110B+ annual buyback authorization maintained; $0.25/quarter dividend
4. **Regulatory** — EU Digital Markets Act compliance costs estimated at $2–3B annually; App Store commission changes in select markets
5. **Vision Pro** — Second-generation headset expected H2 2026 at lower price point; potential TAM expansion
6. **India & Southeast Asia** — Manufacturing diversification accelerating; India now represents 8% of iPhone production vs. <2% in 2022

---

## Comparable Companies

| Company | Ticker | Mkt Cap | EV/Rev (NTM) | EV/EBITDA (NTM) | P/E (NTM) | Rev Growth |
|---------|--------|---------|-------------|-----------------|-----------|------------|
| **Apple** | AAPL | $3.45T | 7.4x | 23.1x | 25.5x | +6.9% |
| Microsoft | MSFT | $3.20T | 12.5x | 24.0x | 32.0x | +13.5% |
| Alphabet | GOOGL | $2.10T | 6.8x | 18.5x | 22.5x | +11.0% |
| Amazon | AMZN | $2.05T | 3.2x | 16.0x | 28.0x | +10.5% |
| Samsung | 005930.KS | $380B | 1.8x | 10.5x | 15.0x | +5.0% |
| **Peer Median** | | | **5.0x** | **17.3x** | **22.5x** | **+10.8%** |

---

*This strip profile is prepared for informational purposes in connection with a potential M&A advisory engagement. All financial data sourced from public filings and Bloomberg as of the date indicated. This is not a recommendation to buy, sell, or hold any security.*

**Prepared by:** Investment Banking Division | Technology Coverage Group
