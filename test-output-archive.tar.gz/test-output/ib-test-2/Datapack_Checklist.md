# M&A Data Pack — Build Checklist & Structure

**Project:** [Deal Code Name]
**Prepared By:** Investment Banking Analyst Team
**Date:** May 2026
**Version:** 1.0

---

## 1. Purpose & Overview

This checklist provides a comprehensive framework for assembling an M&A data pack used by buy-side or sell-side advisory teams. The data pack consolidates information from multiple sources into a structured, analysis-ready format that supports valuation, due diligence, and transaction decision-making.

### Primary Data Sources

| Source | Description | Typical Format | Timing |
|--------|-------------|----------------|--------|
| **CIM** | Confidential Information Memorandum prepared by sell-side advisor | PDF / Printed | Phase I |
| **Public Filings** | 10-K, 10-Q, 8-K, proxy statements, annual reports | SEC EDGAR | Continuous |
| **Management Projections** | Forward-looking financials provided by target management | Excel / PDF | Phase II |
| **Data Room** | Virtual data room (VDR) containing detailed operational, financial, and legal documents | Secure Platform | Phase II |
| **Industry Reports** | Third-party market research, analyst reports, trade publications | PDF / Database | Phase I–II |
| **Management Presentations** | Slide decks and transcripts from management meetings | PPT / PDF | Phase II |
| **Expert Network Calls** | Summaries from industry expert consultations | Notes / Memos | Phase II |

---

## 2. Data Pack Structure

### 2.1 Financial Data Module

#### 2.1.1 Historical Financials

- [ ] **Income Statement** — 3–5 year historical income statement (annual and quarterly)
  - [ ] Revenue by segment / product line / geography
  - [ ] Cost of goods sold and gross profit bridge
  - [ ] Operating expense detail (S&M, G&A, R&D)
  - [ ] EBITDA and EBIT (reported and adjusted)
  - [ ] Non-recurring items identified and categorized
  - [ ] Net income and EPS
- [ ] **Balance Sheet** — 3–5 year historical balance sheets (quarterly)
  - [ ] Assets: current and non-current breakdown
  - [ ] Liabilities: current and non-current breakdown
  - [ ] Debt schedule (all facilities, maturity, interest rates, covenants)
  - [ ] Working capital detail (accounts receivable, inventory, accounts payable, accrued liabilities)
  - [ ] Goodwill and intangible assets
- [ ] **Cash Flow Statement** — 3–5 year historical cash flow statements
  - [ ] Operating cash flow and reconciliation to net income
  - [ ] Capital expenditure (maintenance vs. growth split where available)
  - [ ] Free cash flow calculation
  - [ ] Financing cash flows (debt issuance/repayment, dividends, buybacks)
- [ ] **Management Adjustments** — Bridge from reported to adjusted financials
  - [ ] Add-backs: one-time charges, restructuring, transaction costs, stock-based compensation
  - [ ] Pro-forma adjustments: acquisitions, divestitures, accounting changes
  - [ ] Normalization of non-recurring revenue and expenses

#### 2.1.2 Forward-Looking Financials

- [ ] **Management Base Case Projections** — 3–5 year forward projections
  - [ ] Revenue build: by segment, product, customer, geography
  - [ ] Gross margin assumptions and bridge
  - [ ] Operating expense growth assumptions
  - [ ] EBITDA and net income projections
  - [ ] Capital expenditure plan
  - [ ] Working capital assumptions
  - [ ] Tax rate assumptions and NOL utilization
- [ ] **Management Upside Case** — Bull case with supporting assumptions
- [ ] **Management Downside Case** — Bear case with risk scenarios
- [ ] **Analyst Consensus Estimates** — Sell-side consensus for comparison
- [ ] **Variance Analysis** — Historical projection vs. actual performance (management credibility assessment)

#### 2.1.3 Quality of Earnings (QoE) Analysis

- [ ] Revenue quality assessment
  - [ ] Recurring vs. non-recurring revenue split
  - [ ] Customer concentration analysis
  - [ ] Backlog and pipeline visibility
  - [ ] Pricing trends and contract escalators
- [ ] EBITDA quality assessment
  - [ ] Adjusted EBITDA bridge with detailed add-backs
  - [ ] Run-rate vs. reported EBITDA
  - [ ] Maintenance vs. growth CapEx analysis
  - [ ] Working capital seasonality and cyclicality
- [ ] Cash flow quality
  - [ ] Cash conversion ratio (FCF / EBITDA)
  - [ ] Working capital trends and sustainability
  - [ ] Capital expenditure intensity

### 2.2 Operational Data Module

- [ ] **Customer Analysis**
  - [ ] Top 20 customers by revenue (5-year history)
  - [ ] Customer concentration metrics (top 5, 10, 20 as % of revenue)
  - [ ] Customer retention / churn rates
  - [ ] Customer lifetime value analysis
  - [ ] Contract terms and renewal rates
  - [ ] New customer acquisition trends
  - [ ] Customer profitability by segment
- [ ] **Product / Service Analysis**
  - [ ] Revenue by product line (historical and projected)
  - [ ] Product mix trends and cross-sell rates
  - [ ] Pricing architecture and historical price changes
  - [ ] Product lifecycle analysis
  - [ ] R&D pipeline and upcoming launches
- [ ] **Geographic Analysis**
  - [ ] Revenue by geography (country / region)
  - [ ] Geographic growth rates and market penetration
  - [ ] Currency exposure and hedging strategy
  - [ ] International regulatory considerations
- [ ] **Employee & Organization**
  - [ ] Headcount by department and function
  - [ ] Compensation benchmarks and benefits analysis
  - [ ] Key employee contracts and retention risk
  - [ ] Organizational chart (top 50 positions)
  - [ ] Employee turnover and satisfaction metrics
- [ ] **Facilities & Assets**
  - [ ] Facility list: location, size, ownership vs. lease, capacity utilization
  - [ ] Capital asset register
  - [ ] Maintenance CapEx history and requirements
  - [ ] Environmental compliance status

### 2.3 Market & Competitive Data Module

- [ ] **Total Addressable Market (TAM)**
  - [ ] Market sizing by segment and geography
  - [ ] Market growth projections (3rd party sources)
  - [ ] Market share analysis for target and key competitors
- [ ] **Competitive Landscape**
  - [ ] Competitor profiles (top 5–10)
  - [ ] Competitive positioning matrix (price, quality, service, innovation)
  - [ ] Competitive advantages and barriers to entry
  - [ ] Win/loss analysis vs. competitors
- [ ] **Industry Dynamics**
  - [ ] Regulatory environment and pending changes
  - [ ] Technology disruption risks
  - [ ] Supply chain structure and key supplier relationships
  - [ ] Customer buying behavior and decision criteria
- [ ] **Comparable Transaction Analysis**
  - [ ] Relevant M&A precedents (last 5 years)
  - [ ] Implied multiples and transaction premiums
  - [ ] Strategic rationale for each precedent
  - [ ] Post-acquisition performance where available

### 2.4 Legal & Regulatory Module

- [ ] **Corporate Structure**
  - [ ] Organizational chart (legal entities)
  - [ ] Articles of incorporation, bylaws, operating agreements
  - [ ] Cap table and equity structure
- [ ] **Material Contracts**
  - [ ] Top 10 customer contracts (summary of terms)
  - [ ] Top 10 supplier contracts
  - [ ] Partnership and joint venture agreements
  - [ ] Licensing agreements (in-bound and out-bound)
  - [ ] Change-of-control provisions in key contracts
- [ ] **Litigation & Claims**
  - [ ] Pending litigation summary
  - [ ] Settled matters (last 5 years)
  - [ ] Government investigations or regulatory actions
  - [ ] Product liability claims history
- [ ] **Intellectual Property**
  - [ ] Patent portfolio summary
  - [ ] Trademark registrations
  - [ ] Trade secrets and proprietary processes
  - [ ] IP litigation history
  - [ ] Open source software usage and compliance
- [ ] **Regulatory Compliance**
  - [ ] Required licenses and permits
  - [ ] Environmental compliance status
  - [ ] Data privacy compliance (GDPR, CCPA, etc.)
  - [ ] Industry-specific regulatory requirements
  - [ ] Antitrust / HSR considerations for transaction

### 2.5 Tax & Accounting Module

- [ ] **Tax Structure**
  - [ ] Federal, state, and international tax rate analysis
  - [ ] Net operating losses (NOLs) and tax credit carryforwards
  - [ ] Transfer pricing documentation
  - [ ] Tax attribute utilization schedule
  - [ ] Section 382 limitation analysis (if applicable)
- [ ] **Accounting Policies**
  - [ ] Revenue recognition methodology (ASC 606 compliance)
  - [ ] Significant accounting policies and estimates
  - [ ] Recent accounting changes and impact
  - [ ] Audit history and any restatements
  - [ ] Internal controls assessment (SOX compliance if applicable)

### 2.6 Valuation & Deal Structure Module

- [ ] **Valuation Analyses**
  - [ ] DCF analysis (WACC build-up, terminal value assumptions)
  - [ ] Comparable company analysis (trading multiples)
  - [ ] Precedent transaction analysis
  - [ ] LBO analysis (for financial sponsor buyers)
  - [ ] Sum-of-the-parts analysis (if multi-business)
  - [ ] Football field / valuation summary chart
- [ ] **Deal Structure Considerations**
  - [ ] Enterprise value to equity value bridge
  - [ ] Working capital target and adjustment mechanism
  - [ ] Cash-free, debt-free assumptions
  - [ ] Transaction cost estimates
  - [ ] Earnout or contingent consideration structure
  - [ ] Management rollover / retention equity structure
- [ ] **Synergy Analysis**
  - [ ] Revenue synergy identification and quantification
  - [ ] Cost synergy identification and quantification
  - [ ] Synergy realization timeline and confidence levels
  - [ ] Integration cost estimates

---

## 3. Data Pack Assembly Process

### Phase I: Initial Collection (Weeks 1–2)

| Step | Task | Owner | Source | Deliverable |
|------|------|-------|--------|-------------|
| 1.1 | Obtain and index CIM | Analyst | CIM (sell-side advisor) | Annotated CIM with key data points highlighted |
| 1.2 | Pull public filings (3–5 years) | Analyst | SEC EDGAR | Organized filing repository (10-K, 10-Q, 8-K, proxy) |
| 1.3 | Extract historical financials | Analyst | Public filings, CIM | Standardized historical financial model (Excel) |
| 1.4 | Compile comparable companies | Associate | Bloomberg, Capital IQ | Trading comps table |
| 1.5 | Compile precedent transactions | Associate | Capital IQ, Mergermarket | Precedent transactions table |
| 1.6 | Gather industry research | Analyst | Third-party reports | Industry overview memo |

### Phase II: Deep Dive (Weeks 3–5)

| Step | Task | Owner | Source | Deliverable |
|------|------|-------|--------|-------------|
| 2.1 | Access virtual data room | VP / Associate | VDR platform | VDR index and prioritized review list |
| 2.2 | Extract management projections | Analyst | Management materials, data room | Projection model with variance analysis |
| 2.3 | Build QoE analysis | Associate | CIM, filings, data room | QoE report with adjusted EBITDA bridge |
| 2.4 | Analyze customer and revenue data | Analyst | Data room, CIM | Customer concentration and revenue quality report |
| 2.5 | Review legal and regulatory items | VP + Legal | Data room, legal counsel | Legal risk summary memo |
| 2.6 | Tax structure review | VP + Tax | Data room, tax counsel | Tax attribute summary |

### Phase III: Analysis & Packaging (Weeks 5–7)

| Step | Task | Owner | Source | Deliverable |
|------|------|-------|--------|-------------|
| 3.1 | Build valuation model | Associate / Analyst | All modules | Integrated valuation model (DCF, comps, precedents, LBO) |
| 3.2 | Develop synergy estimates | VP / Associate | Management input, analysis | Synergy quantification model |
| 3.3 | Prepare deal structure analysis | VP | Valuation model, legal review | Deal structure memo with EV-to-equity bridge |
| 3.4 | Create management presentation | VP / Associate | All analyses | Investment committee presentation (PPT) |
| 3.5 | Compile final data pack | Analyst | All deliverables | Organized data pack folder with index |
| 3.6 | Quality control review | MD / VP | Final data pack | QC sign-off checklist |

---

## 4. Quality Control Checklist

### Before Finalizing Data Pack

- [ ] All financial figures cross-referenced to source documents (CIM page #, filing reference, data room document ID)
- [ ] Adjusted EBITDA reconciles to reported EBITDA with clear documentation of each add-back
- [ ] Working capital analysis uses consistent methodology (current vs. non-current classification)
- [ ] Management projections compared to historical accuracy (management credibility score)
- [ ] All multiples calculated using consistent time periods (LTM vs. NTM clearly labeled)
- [ ] Comparable companies screened for relevance (sector, size, growth, margin profile)
- [ ] Precedent transactions include transaction premiums and strategic context
- [ ] Legal and regulatory items reviewed by qualified counsel
- [ ] Tax assumptions reviewed by tax advisor
- [ ] Version control: all files named with date stamps and version numbers
- [ ] Sensitivity analysis included for key assumptions (growth rate, margin, discount rate, multiple)

### Data Room Document Tracking

| Document Category | Total Expected | Received | Reviewed | Gap / Pending |
|-------------------|---------------|----------|----------|---------------|
| Historical Financials | 20 | — | — | — |
| Projections & Budgets | 8 | — | — | — |
| Customer Contracts | 25 | — | — | — |
| Supplier Contracts | 15 | — | — | — |
| Legal / Litigation | 12 | — | — | — |
| IP / Patents | 6 | — | — | — |
| Tax Returns | 10 | — | — | — |
| Employee / HR | 8 | — | — | — |
| Environmental | 5 | — | — | — |
| Insurance | 4 | — | — | — |
| **Total** | **113** | **—** | **—** | **—** |

---

## 5. Output Deliverables

| # | Deliverable | Format | Audience | Typical Length |
|---|-------------|--------|----------|----------------|
| 1 | Historical Financial Model | Excel | Deal team | 15–20 tabs |
| 2 | Projection & Valuation Model | Excel | Deal team, IC | 10–15 tabs |
| 3 | QoE Analysis | Excel + Memo | Deal team, DD advisors | 5–10 pages |
| 4 | Comparable Company Analysis | Excel | Deal team | 1–2 tabs |
| 5 | Precedent Transaction Analysis | Excel | Deal team | 1–2 tabs |
| 6 | Customer & Revenue Analysis | Excel + Memo | Deal team | 5–8 pages |
| 7 | Market & Competitive Overview | PPT or Memo | Deal team, IC | 10–15 slides |
| 8 | Legal & Regulatory Summary | Memo | Deal team, legal | 3–5 pages |
| 9 | Tax Summary | Memo | Deal team, tax | 2–4 pages |
| 10 | Investment Committee Memo | PPT or DOCX | IC / Senior leadership | 25–40 pages |
| 11 | Synergy Analysis | Excel | Deal team | 3–5 tabs |
| 12 | Data Pack Index & Tracker | Excel | Deal team | 1 tab |

---

*This checklist is a template and should be customized based on the specific transaction, industry, and deal team requirements. All items should be reviewed and updated throughout the transaction process as new information becomes available.*

**Investment Banking Division | M&A Advisory Group**
