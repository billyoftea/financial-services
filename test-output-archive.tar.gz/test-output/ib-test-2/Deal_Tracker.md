# M&A Deal Tracker — Active Pipeline

**Last Updated:** May 8, 2026
**Prepared By:** Investment Banking Coverage Team
**Confidentiality:** Internal Use Only

---

## Portfolio Summary

| Deal | Sector | Stage | Enterprise Value | Target Close | Status |
|------|--------|-------|-----------------|--------------|--------|
| **Deal A — Project Atlas** | Healthcare | LOI Signed | $850M | Q3 2026 | On Track |
| **Deal B — Project Beacon** | Technology | Due Diligence | $420M | Q3 2026 | At Risk |
| **Deal C — Project Crest** | Consumer | Closing | $310M | Q2 2026 | Delayed |

---

## Deal A — Project Atlas (Healthcare)

### Overview

| Field | Detail |
|-------|--------|
| **Target** | Regional healthcare services platform (confidential) |
| **Sector** | Healthcare — Provider Services |
| **Sub-Sector** | Ambulatory Care & Specialty Clinics |
| **Buyer** | Strategic acquirer — publicly traded healthcare company |
| **Seller** | PE-backed portfolio company (Fund III vintage 2018) |
| **Enterprise Value** | $850M (12.1x LTM EBITDA) |
| **EBITDA (LTM)** | $70M |
| **Revenue (LTM)** | $380M |
| **Revenue Growth** | 8% CAGR (3-year) |
| **Current Stage** | LOI Signed — Transitioning to Definitive Documentation |
| **Target Signing** | July 2026 |
| **Target Close** | September 2026 |
| **Deal Lead** | Sarah Chen, Managing Director |
| **Associate** | Michael Park, VP |
| **Analyst** | Emily Rodriguez |

### Key Milestones

| # | Milestone | Deadline | Owner | Status | Notes |
|---|-----------|----------|-------|--------|-------|
| 1 | Teaser & Buyer Outreach | Jan 15, 2026 | S. Chen | Complete | 45 buyers contacted |
| 2 | IOI Receipt & Evaluation | Feb 28, 2026 | M. Park | Complete | 8 IOIs received; top 3 shortlisted |
| 3 | Management Presentations | Mar 15, 2026 | S. Chen | Complete | All 3 finalists presented |
| 4 | Final Bids Received | Apr 1, 2026 | M. Park | Complete | Selected bidder at $850M |
| 5 | LOI Execution | Apr 15, 2026 | S. Chen | **Complete** | 45-day exclusivity granted |
| 6 | Confirmatory DD Kickoff | Apr 22, 2026 | M. Park | **In Progress** | Financial, legal, regulatory tracks |
| 7 | Regulatory Filing (HSR) | May 15, 2026 | Legal Counsel | Upcoming | Anticipated 30-day review |
| 8 | Definitive Agreement Execution | Jun 30, 2026 | S. Chen | Upcoming | Mark-up in progress |
| 9 | Regulatory Clearance | Jul 31, 2026 | Legal Counsel | Upcoming | — |
| 10 | Closing & Funding | Sep 1, 2026 | S. Chen | Upcoming | Financing committed |

### Open Items & Risks

- **Regulatory:** Potential HSR second request risk due to buyer's existing market share in overlapping geographies (Southeast U.S.). Mitigation: proactive engagement with FTC counsel; prepared divestiture package if required.
- **Key Person:** Target CEO has 18-month non-compete; retention agreement under negotiation.
- **Working Capital:** Dispute on seasonal working capital adjustment mechanism; $5M gap remaining. Target meeting scheduled May 12.

---

## Deal B — Project Beacon (Technology)

### Overview

| Field | Detail |
|-------|--------|
| **Target** | Enterprise SaaS analytics platform (confidential) |
| **Sector** | Technology — Enterprise Software |
| **Sub-Sector** | Data Analytics & Business Intelligence |
| **Buyer** | Financial sponsor — mega-cap PE fund |
| **Seller** | Founder-owned (majority) + minority institutional investors |
| **Enterprise Value** | $420M (10.5x NTM ARR) |
| **ARR** | $40M (NTM) |
| **Revenue (LTM)** | $35M |
| **Revenue Growth** | 45% YoY |
| **Current Stage** | Due Diligence — Confirmatory Phase |
| **Target Signing** | July 2026 |
| **Target Close** | August 2026 |
| **Deal Lead** | James Whitfield, Managing Director |
| **Associate** | Anika Patel, VP |
| **Analyst** | David Kim |

### Key Milestones

| # | Milestone | Deadline | Owner | Status | Notes |
|---|-----------|----------|-------|--------|-------|
| 1 | Teaser Distribution | Feb 1, 2026 | J. Whitfield | Complete | 30 financial sponsors contacted |
| 2 | IOI Deadline | Mar 1, 2026 | A. Patel | Complete | 6 IOIs; 4 above $350M |
| 3 | Management Presentations | Mar 20, 2026 | J. Whitfield | Complete | Top 4 sponsors presented |
| 4 | Final Bids | Apr 10, 2026 | A. Patel | Complete | Winning bid at $420M |
| 5 | Exclusivity & LOI | Apr 20, 2026 | J. Whitfield | **Complete** | 60-day exclusivity |
| 6 | Financial DD (QoE) | May 15, 2026 | D. Kim | **In Progress** | 70% complete; revenue cohort analysis flagged |
| 7 | Technology / IP DD | May 20, 2026 | A. Patel | **In Progress** | Third-party code audit underway |
| 8 | Commercial DD | May 10, 2026 | J. Whitfield | **In Progress** | Customer calls 60% complete |
| 9 | Legal DD | May 25, 2026 | Legal Counsel | **In Progress** | IP assignment chain under review |
| 10 | Definitive Agreement Draft | Jun 1, 2026 | J. Whitfield | Upcoming | — |
| 11 | Financing Commitment | Jun 15, 2026 | A. Patel | Upcoming | 3 banks in syndicate |
| 12 | Signing & Announcement | Jul 10, 2026 | J. Whitfield | Upcoming | — |
| 13 | Closing | Aug 15, 2026 | J. Whitfield | Upcoming | — |

### Open Items & Risks

- **Revenue Quality (HIGH):** QoE analysis revealed $3.2M in non-recurring consulting revenue included in LTM. Adjusted EBITDA impact: -$1.8M. Buyer seeking purchase price reduction of $10–15M. **Status: Under negotiation.**
- **Customer Concentration (MEDIUM):** Top 3 customers represent 28% of ARR. Two are on month-to-month contracts post-initial term. Buyer requesting pro-rata escrow of $8M. **Status: Seller countering with 12-month auto-renewal amendment.**
- **IP Assignment (MEDIUM):** Key algorithm developed by contractor without executed IP assignment. Legal counsel drafting retroactive assignment agreement. **Status: Contractor located; negotiation in progress.**
- **Key Employee Retention:** CTO has received competing offer. Buyer requesting 3-year retention package with $2M equity grant. **Status: Seller agrees in principle; structuring deferred comp.**

### Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Price renegotiation (QoE) | High | Moderate | Prepare seller with adjusted EBITDA bridge; highlight SaaS KPIs |
| IP assignment failure | Low | High | Backup plan: re-engineer algorithm over 6 months |
| CTO departure | Medium | High | Retention package + non-compete; identify backup technical lead |
| Financing syndicate pullback | Low | Medium | Backup lender identified; strong credit metrics |

---

## Deal C — Project Crest (Consumer)

### Overview

| Field | Detail |
|-------|--------|
| **Target** | Premium consumer brands portfolio (confidential) |
| **Sector** | Consumer — Branded Products |
| **Sub-Sector** | Premium Home & Lifestyle |
| **Buyer** | Strategic acquirer — global consumer goods company |
| **Seller** | Family-owned (3rd generation) |
| **Enterprise Value** | $310M (8.6x LTM EBITDA) |
| **EBITDA (LTM)** | $36M |
| **Revenue (LTM)** | $185M |
| **Revenue Growth** | 5% CAGR (3-year) |
| **Current Stage** | Closing — Pre-Close Integration |
| **Target Signing** | April 2026 (Signed) |
| **Target Close** | June 2026 (Delayed from May) |
| **Deal Lead** | Robert Vasquez, Managing Director |
| **Associate** | Lisa Chen, VP |
| **Analyst** | Thomas Baker |

### Key Milestones

| # | Milestone | Deadline | Owner | Status | Notes |
|---|-----------|----------|-------|--------|-------|
| 1 | Buyer Identification & Outreach | Sep 1, 2025 | R. Vasquez | Complete | Strategic + sponsor approach |
| 2 | IOI Deadline | Oct 15, 2025 | L. Chen | Complete | 5 IOIs received |
| 3 | Management Presentations | Nov 10, 2025 | R. Vasquez | Complete | 3 finalists |
| 4 | Final Bids | Dec 1, 2025 | L. Chen | Complete | Winning bid at $310M |
| 5 | LOI & Exclusivity | Dec 15, 2025 | R. Vasquez | **Complete** | 90-day exclusivity |
| 6 | Confirmatory DD Complete | Feb 28, 2026 | T. Baker | **Complete** | All workstreams cleared |
| 7 | Definitive Agreement Signed | Apr 1, 2026 | R. Vasquez | **Complete** | Signed April 1 |
| 8 | Regulatory Filing | Apr 5, 2026 | Legal Counsel | **Complete** | Filed; no HSR issues |
| 9 | Regulatory Clearance | May 5, 2026 | Legal Counsel | **Complete** | Cleared May 2 |
| 10 | Pre-Close Integration Planning | May 15, 2026 | L. Chen | **In Progress** | Day 1 readiness checklist 80% complete |
| 11 | Closing Conditions Satisfaction | Jun 1, 2026 | R. Vasquez | **In Progress** | 2 items remaining (see below) |
| 12 | Closing & Funds Flow | Jun 15, 2026 | R. Vasquez | **Upcoming** | Rescheduled from May 30 |
| 13 | Announcement & Integration Day 1 | Jun 16, 2026 | All | Upcoming | Press release and internal comms ready |

### Open Items & Risks

- **Closing Delay (ACTIVE):** Original close date of May 30 delayed to June 15 due to two unresolved closing conditions:
  1. **Landlord Consent:** Assignment of lease for flagship manufacturing facility requires landlord consent. Landlord requested environmental assessment. Assessment complete and clean; consent letter expected by June 1.
  2. **Key Customer Novation:** One customer contract ($12M annual, 6.5% of revenue) requires buyer assumption consent. Customer requested modified payment terms. Negotiation ongoing; expected resolution by June 5.
- **Day 1 Readiness:** Integration planning on track. ERP migration timeline agreed. Key employee retention offers drafted for top 25 employees. Buyer integration team on-site at target HQ starting June 2.
- **Working Capital True-Up:** Preliminary estimate shows $4.2M above target working capital. Seller entitled to excess; final calculation due at closing.

---

## Pipeline Summary Dashboard

### Stage Distribution

```
Closing ████████░░░░░░░░░░░░  1 deal (Deal C)
DD      ██████████████░░░░░░  1 deal (Deal B)
LOI     ██████████████████░░  1 deal (Deal A)
─────────────────────────────────
        0        1        2        3
```

### Deal Value by Stage

| Stage | # Deals | Total EV | Avg. EV |
|-------|---------|----------|---------|
| LOI | 1 | $850M | $850M |
| Due Diligence | 1 | $420M | $420M |
| Closing | 1 | $310M | $310M |
| **Total Pipeline** | **3** | **$1,580M** | **$527M** |

### Upcoming Critical Dates (Next 30 Days)

| Date | Deal | Event | Priority |
|------|------|-------|----------|
| May 10 | Beacon | Commercial DD customer calls complete | High |
| May 12 | Atlas | Working capital negotiation meeting | High |
| May 15 | Atlas | HSR regulatory filing | High |
| May 15 | Beacon | QoE financial DD complete | High |
| May 15 | Crest | Pre-close integration planning deadline | Medium |
| May 20 | Beacon | Technology / IP DD complete | High |
| May 25 | Beacon | Legal DD complete | High |
| Jun 1 | Crest | Closing conditions satisfaction | High |
| Jun 1 | Beacon | Definitive agreement first draft | Medium |
| Jun 5 | Crest | Customer novation resolution deadline | High |
| Jun 15 | Crest | **Closing & Funds Flow** | Critical |

---

*This deal tracker is confidential and intended for internal team use only. Do not distribute outside the deal team without approval from the relevant Managing Director.*

**Investment Banking Division | M&A Coverage Group**
