# Dispatch Todos Test

> Requires ccpanes MCP server

## Overview

The `dispatch-todos` skill automates the conversion of project TODO items into executable task prompts, enabling batch launching of Claude Code instances to address open work items.

## Workflow

### Step 1: Query Todos

```
query_todos(
  projectPath="/projects/api-service",
  status="open",
  priority="high"
)
```

Returns a list of TODO items found in the project (from code comments, issue trackers, or explicitly created todos).

**Expected output:**
```json
[
  { "id": "todo-1", "title": "Add input validation to /users POST", "file": "src/routes/users.ts", "line": 45 },
  { "id": "todo-2", "title": "Implement rate limiting middleware", "file": "src/middleware/rateLimit.ts", "line": 12 },
  { "id": "todo-3", "title": "Add error handling for payment flow", "file": "src/services/payments.ts", "line": 88 }
]
```

### Step 2: Generate Prompts

For each TODO, the skill generates a structured prompt:

```
"Fix the TODO at src/routes/users.ts:45 - Add input validation to the POST /users endpoint. Ensure email format validation, required field checks, and appropriate error responses."
```

### Step 3: Batch Launch

```
dispatch_todos(
  projectPath="/projects/api-service",
  todoIds=["todo-1", "todo-2", "todo-3"],
  strategy="sequential"  // or "parallel"
)
```

## Configuration Options

| Option | Values | Description |
|--------|--------|-------------|
| `strategy` | `sequential`, `parallel` | Execute todos one at a time or simultaneously |
| `maxParallel` | Number | Limit concurrent tasks when using parallel strategy |
| `promptTemplate` | String | Custom template for generating prompts from TODOs |
| `filter` | Object | Filter by status, priority, file pattern, or tag |

## Creating Todos

```
create_todo(
  projectPath="/projects/api-service",
  title="Refactor database connection pooling",
  priority="medium",
  file="src/db/connection.ts",
  tags=["performance", "backend"]
)
```

## Updating Todos

```
update_todo(
  todoId="todo-1",
  status="in_progress"  // or "completed", "cancelled"
)
```

## Best Practices

1. **Batch related TODOs** by file or module to minimize context switching
2. **Use sequential strategy** when TODOs may affect the same files
3. **Review generated prompts** before launching to ensure accuracy
4. **Update todo status** after task completion for tracking

---
*Requires ccpanes MCP server*
