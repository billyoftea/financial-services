# Parallel Run Test

> Requires ccpanes MCP server

## Overview

The `parallel-run` skill executes multiple independent tasks simultaneously across available panes, maximizing throughput by distributing work across Claude Code instances.

## Task Decomposition

Effective parallel execution requires breaking work into independent units:

1. **Identify the goal**: Define the overall objective
2. **Decompose into tasks**: Split into independent, non-conflicting subtasks
3. **Assign panes**: Map each task to an available pane
4. **Launch all tasks**: Execute simultaneously
5. **Monitor progress**: Track each task independently
6. **Aggregate results**: Combine outputs into a final deliverable

## Sample Workflow

```
// Step 1: Define parallel tasks
tasks = [
  {
    paneId: "pane-1",
    projectPath: "/projects/api-gateway",
    prompt: "Write integration tests for the /users endpoint"
  },
  {
    paneId: "pane-2",
    projectPath: "/projects/api-gateway",
    prompt: "Write integration tests for the /orders endpoint"
  },
  {
    paneId: "pane-3",
    projectPath: "/projects/api-gateway",
    prompt: "Write integration tests for the /payments endpoint"
  }
]

// Step 2: Launch all tasks via launch_task for each
// Step 3: Monitor with get_session_status for each sessionId
// Step 4: Collect results with get_session_output for each
```

## Monitoring

Use `get_session_status` to track each task:

| Status | Meaning |
|--------|---------|
| `launched` | Task accepted, Claude instance starting |
| `running` | Claude is actively processing |
| `completed` | Task finished successfully |
| `error` | Task encountered an error |

## Result Aggregation

After all tasks complete:

1. Collect each task's output via `get_session_output`
2. Review outputs for consistency and completeness
3. Merge results (e.g., combine test files, consolidate reports)
4. Run validation to ensure no conflicts between parallel outputs

## Best Practices

- Keep tasks truly independent to avoid file conflicts
- Limit parallelism to available pane count
- Use separate directories or file paths for each task's output
- Set clear completion criteria for each subtask
- Handle partial failures gracefully (some tasks may succeed while others fail)

---
*Requires ccpanes MCP server*
