# Spec Workflow Test

> Requires ccpanes MCP server

## Overview

The `spec` skill drives a structured workflow from requirements through design, task breakdown, and implementation, producing actionable specifications that can be handed off to Claude Code instances.

## Workflow Stages

```
Requirements -> Design -> Tasks -> Implementation
```

### Stage 1: Requirements

Capture what needs to be built. Input can be a user description, PRD, or feature request.

```
spec(
  projectPath="/projects/api-service",
  stage="requirements",
  input="Add user authentication with OAuth2 support, including Google and GitHub providers"
)
```

**Output**: Structured requirements document with functional requirements, constraints, and acceptance criteria.

### Stage 2: Design

Transform requirements into a technical design.

```
spec(
  projectPath="/projects/api-service",
  stage="design",
  requirementsId="spec-req-001"
)
```

**Output**: Technical design including architecture decisions, data models, API contracts, and component boundaries.

### Stage 3: Task Breakdown

Decompose the design into implementable tasks.

```
spec(
  projectPath="/projects/api-service",
  stage="tasks",
  designId="spec-design-001"
)
```

**Output**: Ordered task list with dependencies, estimated complexity, and file-level scope.

### Stage 4: Implementation

Execute tasks via launched Claude Code instances.

```
spec(
  projectPath="/projects/api-service",
  stage="implementation",
  taskIds=["spec-task-001", "spec-task-002"],
  strategy="sequential"
)
```

**Output**: Implementation results with change summaries and verification status.

## Deliverables by Stage

| Stage | Deliverable | Format |
|-------|------------|--------|
| Requirements | Requirements spec | Markdown |
| Design | Technical design doc | Markdown + diagrams |
| Tasks | Task list with dependencies | JSON |
| Implementation | Code changes + summary | Code + Markdown |

## Integration with Other Skills

- **launch_task**: Each implementation task can be launched as a separate Claude instance
- **dispatch_todos**: Generated tasks integrate with the TODO system
- **parallel_run**: Independent tasks can be executed in parallel

---
*Requires ccpanes MCP server*
