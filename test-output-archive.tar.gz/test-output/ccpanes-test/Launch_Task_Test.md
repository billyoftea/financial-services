# Launch Task Test

> Requires ccpanes MCP server

## Overview

The `launch-task` skill starts a new Claude Code instance in a specified pane, enabling parallel execution of tasks across multiple projects.

## Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `projectPath` | Yes | Absolute path to the project directory |
| `paneId` | No | Target pane ID (auto-selected if omitted) |
| `prompt` | Yes | The task prompt to execute |
| `resumeId` | No | Session ID to resume an existing conversation |
| `cliTool` | No | CLI tool to use (default: `claude`) |

## Sample Command

```
launch_task(
  projectPath="/home/user/projects/api-service",
  paneId="pane-3",
  prompt="Refactor the authentication middleware to use JWT rotation"
)
```

## Expected Output

On success, the skill returns:

```json
{
  "taskId": "task-abc123",
  "paneId": "pane-3",
  "sessionId": "sess-def456",
  "status": "launched"
}
```

## Monitoring Workflow

1. Launch the task with `launch_task`
2. Poll `get_session_status(sessionId)` until status is `completed`
3. Retrieve results with `get_session_output(sessionId)`

## Error Cases

- **Invalid projectPath**: Returns error with "Project not found" message
- **Pane busy**: Returns error if target pane already has an active session
- **Resume ID not found**: Returns error if `resumeId` does not match an existing session

## Use Cases

- Running code reviews across multiple repositories simultaneously
- Executing test suites in parallel for different services
- Generating documentation for multiple projects concurrently

---
*Requires ccpanes MCP server*
