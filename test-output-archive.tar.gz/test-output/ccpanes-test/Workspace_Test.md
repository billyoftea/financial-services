# Workspace Management Test

> Requires ccpanes MCP server

## Overview

Workspace management skills provide project organization, enabling grouping of related projects, tracking their status, and orchestrating work across them.

## Available Operations

| Command | Description |
|---------|-------------|
| `list_workspaces` | List all registered workspaces |
| `get_workspace` | Get details of a specific workspace |
| `create_workspace` | Create a new workspace |
| `add_project_to_workspace` | Register a project under a workspace |
| `scan_directory` | Discover projects in a directory |

## Workflow: List Projects

```
list_projects()
// Returns all registered projects with paths and metadata
```

**Expected output:**
```json
[
  { "name": "api-service", "path": "/projects/api-service", "language": "TypeScript" },
  { "name": "web-frontend", "path": "/projects/web-frontend", "language": "React" }
]
```

## Workflow: Create Workspace and Add Projects

```
// Step 1: Create workspace
create_workspace(
  name="Financial Services Platform",
  description="Core platform microservices"
)

// Step 2: Add projects
add_project_to_workspace(
  workspaceId="ws-abc123",
  projectPath="/projects/api-service"
)
add_project_to_workspace(
  workspaceId="ws-abc123",
  projectPath="/projects/web-frontend"
)
```

## Workflow: Scan Directory for Projects

```
scan_directory(
  path="/home/user/projects",
  depth=2
)
```

This discovers projects by looking for common project markers (package.json, pyproject.toml, Cargo.toml, go.mod, etc.) and returns a list of detected projects available for registration.

## Typical Project Onboarding Flow

1. `scan_directory` to discover projects in a codebase
2. `create_workspace` to group related projects
3. `add_project_to_workspace` for each relevant project
4. `launch_task` to begin working on projects within the workspace

## Workspace Metadata

Each workspace tracks:
- **Name and description**
- **Project list** with paths and detected languages
- **Creation date** and last modified timestamp
- **Task history** for all operations within the workspace

---
*Requires ccpanes MCP server*
