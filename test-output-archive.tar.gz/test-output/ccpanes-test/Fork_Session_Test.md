# Fork Session Test

> Requires ccpanes MCP server

## Overview

The `fork-session` skill creates a divergent copy of an existing Claude Code session, allowing users to explore alternative approaches from a shared conversation history without affecting the original session.

## When to Use

- **Exploring alternatives**: Test different solutions to the same problem from a common starting point
- **Risk-free experimentation**: Try a refactor approach while preserving the original session's state
- **Parallel debugging**: Fork a session to investigate a bug from multiple angles simultaneously
- **Context sharing**: Share conversation context across team members working on related tasks

## Sample Workflow

### Step 1: Identify the session to fork

```
list_sessions()
// Returns active sessions with sessionId values
```

### Step 2: Fork the session

```
fork_session(
  sessionId="sess-original-abc",
  paneId="pane-4",
  prompt="Now try solving this using a functional approach instead of OOP"
)
```

### Step 3: Work both sessions independently

- Original session continues from its last state
- Forked session has full history but diverges from this point forward

## Expected Behavior

| Aspect | Behavior |
|--------|----------|
| **History** | Full conversation history is copied to the new session |
| **Divergence** | New session and original evolve independently after fork |
| **File State** | Both sessions share the same filesystem; coordinate file writes carefully |
| **Session ID** | New session receives a unique ID |
| **Original** | Unaffected by the fork operation |

## Important Considerations

1. **File conflicts**: Since both sessions operate on the same filesystem, avoid concurrent edits to the same files
2. **Resource usage**: Each forked session consumes a Claude Code instance
3. **Context window**: The forked session starts with the same context, consuming tokens from the new session's budget

## Sample Use Case

A developer has a session that built a REST API. They fork the session to try converting it to GraphQL while the original session continues with REST refinements. Both approaches can be compared later.

---
*Requires ccpanes MCP server*
