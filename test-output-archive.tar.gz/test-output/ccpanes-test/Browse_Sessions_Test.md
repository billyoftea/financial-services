# Browse Sessions Test

> Requires ccpanes MCP server

## Overview

The `browse-sessions` skill provides visibility into all active and recent Claude Code sessions, enabling users to inspect outputs, review history, and manage session lifecycle.

## Core Operations

| Command | Description |
|---------|-------------|
| `list_sessions` | List all active sessions across panes |
| `get_session_status` | Check the current status of a session |
| `get_session_output` | Read the output of a completed session |
| `kill_session` | Terminate an active session |
| `list_resume_sessions` | List sessions available for resumption |
| `list_launch_history` | View historical task launches with metadata |

## Workflow: List Active Tabs

```
list_sessions()
```

**Expected output:**
```json
[
  {
    "sessionId": "sess-001",
    "paneId": "pane-1",
    "projectPath": "/projects/api-service",
    "status": "running",
    "startedAt": "2026-05-08T10:00:00Z"
  },
  {
    "sessionId": "sess-002",
    "paneId": "pane-2",
    "projectPath": "/projects/web-frontend",
    "status": "completed",
    "startedAt": "2026-05-08T09:30:00Z",
    "completedAt": "2026-05-08T09:55:00Z"
  }
]
```

## Workflow: Read Session Output

```
get_session_output(
  sessionId="sess-002",
  lines=50
)
```

Returns the last N lines of output from the session, including Claude's responses, tool calls, and any errors.

## Workflow: View History

```
list_launch_history(
  projectPath="/projects/api-service"
)
```

Returns historical launches for the project, including `resumeSessionId` and `cliTool` fields needed to resume a prior session.

## Session States

| State | Description | Action Available |
|-------|-------------|-----------------|
| `launched` | Session starting up | Wait |
| `running` | Actively processing | Monitor, kill |
| `completed` | Finished successfully | Read output |
| `error` | Terminated with error | Read output, retry |
| `idle` | Session alive but no active task | Resume, kill |

## Use Cases

- **Progress check**: Monitor long-running tasks without interrupting them
- **Output review**: Read completed task results for aggregation
- **Cleanup**: Identify and kill stale sessions to free panes
- **Resume**: Find a previous session's ID to continue work

---
*Requires ccpanes MCP server*
