# PlanToCodex Test

> Requires ccpanes MCP server

## Overview

The `plan-to-codex` (plantocodex) skill bridges Claude Code planning with Codex execution, enabling users to design solutions in Claude and delegate implementation to OpenAI's Codex CLI tool.

## Concept

Claude excels at understanding requirements, designing architecture, and breaking down tasks. Codex excels at rapid code generation. This skill combines both strengths:

```
[Claude: Plan/Design] --> [Codex: Implement] --> [Claude: Review/Refine]
```

## Workflow

### Step 1: Plan in Claude

Use Claude to analyze requirements and create an implementation plan:

```
// In a Claude session:
"Design a caching layer for the API gateway. Consider Redis vs in-memory, TTL policies, and cache invalidation strategies."
```

### Step 2: Generate Codex Prompt

The skill converts the plan into a Codex-compatible prompt:

```
plantocodex(
  projectPath="/projects/api-gateway",
  plan="Implement Redis-based caching middleware with configurable TTL,
        cache key generation from request path and query params,
        and automatic cache invalidation on POST/PUT/DELETE requests",
  files=["src/middleware/cache.ts", "src/config/cache.config.ts"]
)
```

### Step 3: Execute in Codex

The skill launches Codex with the generated prompt:

```
launch_task(
  projectPath="/projects/api-gateway",
  cliTool="codex",
  prompt="[Generated codex prompt from step 2]"
)
```

### Step 4: Review in Claude

After Codex completes, review the output back in Claude:

```
get_session_output(sessionId="sess-codex-001")
// Claude reviews the generated code for quality and correctness
```

## Key Parameters

| Parameter | Description |
|-----------|-------------|
| `projectPath` | Target project directory |
| `plan` | The plan or design to implement |
| `files` | Optional list of target files for context |
| `model` | Codex model to use (default: latest) |
| `reviewPrompt` | Optional prompt for post-implementation review |

## Benefits

1. **Best of both worlds**: Claude's reasoning + Codex's speed
2. **Iterative refinement**: Plan, implement, review loop
3. **Context preservation**: Plan context carries through to implementation
4. **Quality gate**: Claude reviews Codex output before finalizing

## Limitations

- Requires Codex CLI installed and configured
- Codex sessions have separate context windows from Claude
- File-level conflicts possible if both tools modify files concurrently

---
*Requires ccpanes MCP server*
