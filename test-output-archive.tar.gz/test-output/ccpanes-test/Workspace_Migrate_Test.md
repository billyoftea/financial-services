# Workspace Migration Test

> Requires ccpanes MCP server

## Overview

The `workspace-migrate` skill handles migrating project configurations, settings, and session data between workspace environments, enabling smooth transitions when restructuring or relocating projects.

## Prerequisites

Before running a migration:

1. **Source workspace** must exist and be accessible
2. **Target workspace** must be created (or existing target identified)
3. **All active tasks** in the source workspace should be completed or paused
4. **File system** paths must be valid at the target location
5. **CC-Panes MCP server** must be connected and operational

## Migration Steps

### Step 1: Verify source workspace

```
get_workspace(workspaceId="ws-source-123")
// Confirm all projects and their paths
```

### Step 2: Create or identify target workspace

```
create_workspace(
  name="Migrated Platform",
  description="Post-migration workspace"
)
// Note the target workspaceId
```

### Step 3: Execute migration

```
workspace_migrate(
  sourceWorkspaceId="ws-source-123",
  targetWorkspaceId="ws-target-456",
  options={
    migrateSettings: true,
    migrateHistory: true,
    updatePaths: true
  }
)
```

### Step 4: Validate migration

```
get_workspace(workspaceId="ws-target-456")
// Verify all projects, settings, and history transferred correctly
```

## What Gets Migrated

| Component | Migrated | Notes |
|-----------|----------|-------|
| Project registry | Yes | All project paths updated |
| Workspace settings | Yes | Includes description and metadata |
| Task history | Optional | Controlled by `migrateHistory` flag |
| Session data | No | Sessions are runtime-only |
| CLAUDE.md files | No | These live in the project directories |

## Post-Migration Validation

1. Confirm all projects appear in the target workspace
2. Verify project paths resolve correctly
3. Test a `launch_task` on a migrated project
4. Archive or delete the source workspace if no longer needed

## Error Handling

- **Path not found**: Migration reports which project paths are invalid at the target
- **Name conflicts**: Option to skip or overwrite existing projects in the target
- **Partial failure**: Migration completes what it can and reports failures for manual resolution

---
*Requires ccpanes MCP server*
