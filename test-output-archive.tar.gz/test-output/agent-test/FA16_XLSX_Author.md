[DATA SOURCE: WebSearch — CFI (Corporate Finance Institute) DCF modeling standards from corporatefinanceinstitute.com; Wall Street Prep DCF and financial modeling best practices from wallstreetprep.com; FRED DGS10 10Y UST yield (4.39%) from fred.stlouisfed.org; Damodaran NYU Stern US Software Beta (1.14), Implied ERP (4.23%) from pages.stern.nyu.edu; FRED ICE BofA BBB Index yield (5.36%) from fred.stlouisfed.org; openpyxl documentation from openpyxl.readthedocs.io; CloudPeak Technologies historical/projected financials from FA05_DCF_Model.md; Macabacus formatting conventions from macabacus.com; Mergers & Inquisitions model structure from mergersandinquisitions.com]

---

# xlsx-author 技能执行报告
## CloudPeak Technologies DCF 估值模型 — Excel 工作簿规范

**编制日期：** 2026年5月10日
**技能名称：** xlsx-author（headless模式Excel文件生成）
**目标公司：** CloudPeak Technologies（B2B SaaS 云管理）
**估值货币：** USD | **单位：** 百万美元（除每股数据外）

---

## 1. 技能概述与执行环境

### 1.1 技能定位

`xlsx-author` 技能适用于**无界面（headless）运行环境**，即在托管代理（Managed Agent / CMA）模式下需要交付 Excel 工作簿文件产物，而非通过 `mcp__office__excel_*` 实时编辑用户打开的工作簿。

### 1.2 产出物约定

| 项目 | 规范 |
|------|------|
| **输出路径** | `./out/CloudPeak_DCF_Model_2026-05-10.xlsx` |
| **路径创建** | 若 `./out/` 不存在则自动创建 |
| **工具库** | Python 3.x + openpyxl |
| **公式重算** | 交付前执行 `python recalc.py <file> 30`，确保零公式错误 |
| **外部传输** | 禁止 — 本技能仅写本地文件 |

### 1.3 CFI / Wall Street Prep 标准遵循

本模型严格遵循以下行业标准的 DCF 建模规范：

| 标准体系 | 核心要求 | 本模型落实 |
|----------|----------|-----------|
| **CFI - FMVA** | 蓝色=输入，黑色=公式，绿色=跨表引用 | 三色字体严格执行 |
| **Wall Street Prep** | 情景切换（Bear/Base/Bull）+ 合并列（Consolidation Column） | INDEX公式合并列 + 情景选择器 |
| **Macabacus** | 单元格注释标注数据来源，专业边框 | 全部硬编码值附带来源注释 |
| **M&I** | 年中折现惯例（Mid-Year Convention），永续增长法 + 退出倍数法交叉验证 | 双方法终端价值计算 |

---

## 2. 工作簿结构概览

### 2.1 工作表架构

| 工作表名称 | 功能 | 行数估计 | 列范围 |
|-----------|------|---------|--------|
| **DCF** | 主估值模型 + 三情景假设 + 敏感性分析 | ~140 行 | A - L |
| **WACC** | 加权平均资本成本计算 | ~55 行 | A - D |
| **Checks** | 平衡校验（资产负债表平衡、现金流勾稽） | ~30 行 | A - H |

**总计：** 3 个工作表

### 2.2 命名范围（Named Ranges）

以下命名范围用于模型核心参数的跨表引用和敏感性分析公式构建：

| 命名范围名称 | 引用位置 | 用途 |
|-------------|---------|------|
| `Case_Selector` | DCF!B6 | 情景选择器（1=悲观, 2=基准, 3=乐观） |
| `WACC_Rate` | WACC!C27 | 加权平均资本成本 |
| `Terminal_Growth` | DCF!E25 | 终端增长率（合并列当前值） |
| `Tax_Rate` | DCF!E24 | 税率（合并列当前值） |
| `Net_Debt` | DCF!C13 | 净债务 |
| `Shares_Outstanding` | DCF!C11 | 稀释后流通股数 |
| `Stock_Price` | DCF!C10 | 当前股价（如适用） |
| `Risk_Free_Rate` | WACC!C5 | 无风险利率 |
| `Equity_Risk_Premium` | WACC!C7 | 股权风险溢价 |
| `Beta` | WACC!C6 | Levered Beta |
| `Cost_of_Equity` | WACC!C8 | 股权成本 |
| `Pre_Tax_Cost_of_Debt` | WACC!C12 | 税前债务成本 |
| `After_Tax_Cost_of_Debt` | WACC!C14 | 税后债务成本 |
| `Market_Cap` | WACC!C19 | 市值 |
| `Enterprise_Value_WACC` | WACC!C23 | 企业价值（WACC表计算） |
| `Equity_Weight` | WACC!C25 | 股权权重 |
| `Debt_Weight` | WACC!C26 | 债务权重 |
| `Base_Revenue_LTM` | DCF!E29 | LTM/最近年度收入（预测起始） |
| `Sum_PV_FCF` | DCF!C98 | 预测期FCF现值总和 |
| `PV_Terminal_Value` | DCF!C104 | 终端价值现值 |

---

## 3. DCF 工作表详细规范

### 3.1 行布局规划（Row Layout Plan）

以下为 DCF 工作表的完整行布局，所有行号在编写公式前锁定：

```
行号    内容                                      类型
─────   ─────────────────────────────────────     ──────────
 1      CloudPeak Technologies DCF 估值模型       标题（合并A1:L1）
 2      Ticker: CPKT | 日期: 2026-05-10          副标题
 3      （空行）
 4      情景选择                                  标签
 5      当前情景:                                  公式 =IF(B6=1,"悲观",IF(B6=2,"基准","乐观"))
 6      [选择器值] 2                               蓝色输入（1/2/3）
 7      （空行）
 8-9     ══ SECTION: 市场数据 ══
 8      市场数据与关键输入                          标题（合并，深蓝底色）
 9      （列标题行）
10      当前股价（如适用）                          蓝色输入 / 不适用标注
11      稀释后流通股数 (M)                          蓝色输入: 42.5
12      市值 ($M)                                  公式: =C10*C11
13      净债务 ($M)                                蓝色输入: 35.0
14      非营业资产 ($M)                            蓝色输入: 5.0
15      （空行）
16-25    ══ SECTION: 情景假设 ══
16      情景假设                                   标题（合并，深蓝底色）
17      （空行）
18      ── 悲观情景假设 ──                         子标题（合并）
19      假设 / FY2025E / FY2026E / ... / FY2029E  列标题（浅蓝底色）
20      收入增长率                                 18.0% / 15.0% / 12.0% / 10.0% / 8.0%
21      毛利率                                     77.0% / 76.5% / 76.0% / 75.5% / 75.0%
22      EBIT利润率                                  24.0% / 23.0% / 22.0% / 21.0% / 20.0%
23      D&A占收入比                                 4.0% / 4.0% / 4.0% / 4.0% / 4.0%
24      CapEx占收入比                               7.5% / 7.5% / 7.5% / 7.5% / 7.5%
25      NWC变动(占收入增量比)                       -5.0% / -5.0% / -5.0% / -5.0% / -5.0%
26      税率                                       21.0%
27      终端增长率                                  2.0%
28      WACC                                       10.0%
29      （空行）
30      ── 基准情景假设 ──                         子标题（合并）
31      假设 / FY2025E / FY2026E / ... / FY2029E  列标题（浅蓝底色）
32      收入增长率                                 22.0% / 19.0% / 16.0% / 13.0% / 10.0%
33      毛利率                                     78.0% / 79.0% / 79.5% / 80.0% / 80.0%
34      EBIT利润率                                  27.0% / 28.5% / 29.5% / 30.0% / 30.5%
35      D&A占收入比                                 3.8% / 3.5% / 3.5% / 3.5% / 3.5%
36      CapEx占收入比                               6.5% / 6.0% / 5.5% / 5.5% / 5.0%
37      NWC变动(占收入增量比)                       -5.0% / -5.0% / -5.0% / -5.0% / -5.0%
38      税率                                       21.0%
39      终端增长率                                  2.75%
40      WACC                                       9.1%
41      （空行）
42      ── 乐观情景假设 ──                         子标题（合并）
43      假设 / FY2025E / FY2026E / ... / FY2029E  列标题（浅蓝底色）
44      收入增长率                                 26.0% / 23.0% / 20.0% / 17.0% / 14.0%
45      毛利率                                     79.0% / 80.0% / 81.0% / 82.0% / 82.0%
46      EBIT利润率                                  29.0% / 31.0% / 33.0% / 34.0% / 35.0%
47      D&A占收入比                                 3.5% / 3.5% / 3.0% / 3.0% / 3.0%
48      CapEx占收入比                               6.0% / 5.5% / 5.0% / 5.0% / 4.5%
49      NWC变动(占收入增量比)                       -5.0% / -5.0% / -5.0% / -5.0% / -5.0%
50      税率                                       21.0%
51      终端增长率                                  3.5%
52      WACC                                       8.5%
53      （空行）
54-62    ══ SECTION: 合并列（Consolidation Column）══
54      选定情景假设（合并列）                      标题（合并）
55      假设 / FY2025E / FY2026E / ... / FY2029E  列标题
56      收入增长率                                 INDEX公式引用对应情景块
57      毛利率                                     INDEX公式引用对应情景块
58      EBIT利润率                                  INDEX公式引用对应情景块
59      D&A占收入比                                 INDEX公式引用对应情景块
60      CapEx占收入比                               INDEX公式引用对应情景块
61      NWC变动(占收入增量比)                       INDEX公式引用对应情景块
62      税率                                       INDEX公式引用对应情景块
63      终端增长率                                  INDEX公式引用对应情景块
64      WACC                                       INDEX公式引用对应情景块
65      （空行）
66-93    ══ SECTION: 历史与预测利润表 + FCF ══
66      历史与预测财务数据                          标题（合并，深蓝底色）
67      利润表 ($M) / FY2021A / ... / FY2029E      列标题（浅蓝底色）
68      收入                                       历史: 78.0/95.2/116.4/143.0，预测: 公式
69        收入增长率                               公式: =D68/C68-1 等
70      （空行）
71      毛利润                                     历史: 公式，预测: =E68*E57 等
72        毛利率                                   公式: =E71/E68
73      （空行）
74      营业费用                                    子标签
75        销售与营销 (S&M)                          历史蓝色，预测: =E68*相关S&M%
76        研发 (R&D)                               历史蓝色，预测: 基于收入公式
77        一般及行政 (G&A)                          历史蓝色，预测: 基于收入公式
78      总营业费用                                  公式: =E75+E76+E77
79      （空行）
80      EBIT                                       公式: =E71-E78
81        EBIT利润率                               公式: =E80/E68
82      （空行）
83      税收                                       公式: =E80*$E$62（引用合并列税率）
84        有效税率                                 公式: =E83/E80
85      （空行）
86      NOPAT                                      公式: =E80-E83
87      （空行）
88      自由现金流构建                              子标题
89      (+) 折旧与摊销 (D&A)                       公式: =E68*$E$59
90        D&A占收入比                              公式: =E89/E68
91      (-) 资本支出 (CapEx)                       公式: =E68*$E$60
92        CapEx占收入比                            公式: =E91/E68
93      (-) 营运资金变动 (NWC)                     公式: =(E68-D68)*$E$61
94        NWC占收入增量比                          公式: =E93/(E68-D68)
95      （空行）
96      无杠杆自由现金流 (UFCF)                     公式: =E86+E89-E91-E93
97        FCF利润率                                公式: =E96/E68
98      （空行）
99-118   ══ SECTION: 折现与估值 ══
99      折现与估值                                  标题（合并，深蓝底色）
100     DCF估值 / FY2025E / FY2026E / ... / FY2029E / 终端  列标题
101     无杠杆FCF ($M)                              链接: =E96 等
102     折现期间                                    0.5 / 1.5 / 2.5 / 3.5 / 4.5
103     折现因子                                    公式: =1/(1+$E$64)^F102 等
104     FCF现值 ($M)                                公式: =E101*E103
105     （空行）
106     终端价值计算                                子标题
107     终端FCF ($M)                                公式: =I101*(1+$E$63)
108     终端价值 ($M)                               公式: =G107/($E$64-$E$63)
109     终端价值现值 ($M)                           公式: =G108*I103
110     （空行）
111     ── 退出倍数法（交叉验证）──                子标题
112     FY2029E EBITDA                              公式: =I80+I89
113     退出EV/EBITDA倍数                           蓝色输入: 12.0x
114     终端价值-退出倍数法 ($M)                    公式: =G112*G113
115     终端价值现值-退出倍数法 ($M)                公式: =G114*I103
116     （空行）
117     估值汇总 ($M)                               标题（合并，深蓝底色）
118     预测期FCF现值总和                           公式: =SUM(E104:I104)
119     终端价值现值（永续增长法）                  公式: =G109
120     企业价值 (EV)                               公式: =C118+C119（中蓝底色+粗体）
121     (-) 净债务                                  链接: =C13
122     (+) 非营业资产                               链接: =C14
123     股权价值                                    公式: =C120-C121+C122（中蓝底色+粗体）
124     （空行）
125     稀释后流通股数 (M)                          链接: =C11
126     隐含每股价格                                公式: =C123/C125（中蓝底色+粗体，$#,##0.00格式）
127     （空行）
128     终端价值占EV比例                            公式: =C119/C120
129     质量检查：终端g < WACC                      公式: =IF(E63<E64,"通过","警告: g >= WACC")
130     （空行）
131-140  ══ SECTION: 敏感性分析表 ══
131     敏感性分析                                  标题（合并，深蓝底色）
132     （空行）
133     表1: WACC vs 终端增长率（隐含每股价格）     表标题
134     行列标题 + 5x5 公式网格                     见3.5节详细公式
135-140  （25个公式单元格）                          完整DCF重算公式
141     （空行）
142     表2: 收入增长率 vs EBIT利润率（隐含EV/ARR） 表标题
143-148  （25个公式单元格）                          完整DCF重算公式
149     （空行）
150     表3: Beta vs 无风险利率（隐含每股价格）     表标题
151-156  （25个公式单元格）                          完整DCF重算公式
```

### 3.2 情景假设块 — 行引用映射

以下映射确保公式引用正确的行号，编写公式前必须验证：

| 假设项目 | 悲观行 | 基准行 | 乐观行 | 合并列行 | INDEX公式示例 |
|----------|--------|--------|--------|---------|-------------|
| 收入增长率 | 20 | 32 | 44 | 56 | `=INDEX($C20:$C44,1,$B$6)` — 按情景块偏移 |
| 毛利率 | 21 | 33 | 45 | 57 | 同上模式 |
| EBIT利润率 | 22 | 34 | 46 | 58 | 同上模式 |
| D&A占收入比 | 23 | 35 | 47 | 59 | 同上模式 |
| CapEx占收入比 | 24 | 36 | 48 | 60 | 同上模式 |
| NWC变动 | 25 | 37 | 49 | 61 | 同上模式 |
| 税率 | 26 | 38 | 50 | 62 | 同上模式 |
| 终端增长率 | 27 | 39 | 51 | 63 | 同上模式 |
| WACC | 28 | 40 | 52 | 64 | 同上模式 |

**INDEX 公式实现模式（合并列）：**

每个合并列单元格使用以下结构从对应情景块提取值：

```excel
E56: =INDEX(INDEX(($C$20:$G$20,$C$32:$G$32,$C$44:$G$44),,,$B$6),1,COLUMN()-4)
```

其中：
- `$B$6` = Case_Selector（1=悲观, 2=基准, 3=乐观）
- `COLUMN()-4` = 年份偏移（FY2025E=1, FY2026E=2, ...）
- 三个数组分别对应悲观/基准/乐观情景的同一假设行

### 3.3 核心公式规范

#### 3.3.1 收入预测公式

```excel
E68: =D68*(1+$E$56)            — FY2025E 收入 = FY2024A收入 x (1 + 合并列增长率)
F68: =E68*(1+$F$56)            — FY2026E 收入
G68: =F68*(1+$G$56)            — FY2027E 收入
H68: =G68*(1+$H$56)            — FY2028E 收入
I68: =H68*(1+$I$56)            — FY2029E 收入
```

来源注释示例：
```
D68: "Source: FA05_DCF_Model.md, FY2024A 实际收入 $143.0M, 基于$143M ARR"
E56: "Source: INDEX公式引用情景块，由Case_Selector (B6) 控制"
```

#### 3.3.2 毛利润公式

```excel
E71: =E68*$E$57                — 毛利润 = 收入 x 合并列毛利率
```

#### 3.3.3 EBIT公式

```excel
E80: =E71-E78                  — EBIT = 毛利润 - 总营业费用
```

**关键约束：** 营业费用（S&M、R&D、G&A）必须基于**收入**计算，而非毛利润。

```excel
E75: =E68*S&M占收入比          — S&M = 收入 x S&M%
E76: =E68*R&D占收入比          — R&D = 收入 x R&D%
E77: =E68*G&A占收入比          — G&A = 收入 x G&A%
```

其中S&M%、R&D%、G&A%由以下差异推导：
```
S&M% = 毛利率 - EBIT利润率 - R&D% - G&A%（或直接基于历史S&M/Revenue计算）
```

为简化模型结构，营业费用各项通过以下模式计算：
```excel
E78: =E75+E76+E77              — 总营业费用 = S&M + R&D + G&A
```

#### 3.3.4 NOPAT公式

```excel
E83: =E80*$E$62                — 税收 = EBIT x 合并列税率
E86: =E80-E83                  — NOPAT = EBIT - 税收
```

#### 3.3.5 自由现金流公式

```excel
E89: =E68*$E$59                — D&A = 收入 x 合并列D&A%
E91: =-E68*$E$60               — CapEx = -(收入 x 合并列CapEx%)  [负数表示现金流出]
E93: =-(E68-D68)*$E$61         — NWC变动 = -(收入增量 x 合并列NWC%)  [负数表示现金使用]
E96: =E86+E89+E91+E93          — UFCF = NOPAT + D&A - CapEx - NWC变动
```

#### 3.3.6 折现因子公式（年中惯例）

```excel
E102: 0.5                      — FY2025E 折现期间（硬编码，年中惯例）
F102: 1.5                      — FY2026E
G102: 2.5                      — FY2027E
H102: 3.5                      — FY2028E
I102: 4.5                      — FY2029E

E103: =1/(1+$E$64)^E102        — 折现因子 = 1/(1+WACC)^期间
F103: =1/(1+$E$64)^F102
...

E104: =E101*E103               — FCF现值 = UFCF x 折现因子
```

#### 3.3.7 终端价值公式

**永续增长法：**
```excel
G107: =I101*(1+$E$63)                              — 终端FCF = FY2029E FCF x (1+终端增长率)
G108: =G107/($E$64-$E$63)                          — 终端价值 = 终端FCF / (WACC - g)
G109: =G108*I103                                   — 终端价值现值 = TV / (1+WACC)^4.5
```

**退出倍数法（交叉验证）：**
```excel
G112: =I80+I89                                     — FY2029E EBITDA = EBIT + D&A
G113: 12.0                                          — 退出EV/EBITDA倍数 [蓝色输入]
G114: =G112*G113                                    — 终端价值 = EBITDA x 倍数
G115: =G114*I103                                    — 终端价值现值
```

#### 3.3.8 估值汇总公式

```excel
C118: =SUM(E104:I104)                              — 预测期FCF现值总和
C119: =G109                                         — 终端价值现值（永续增长法）
C120: =C118+C119                                    — 企业价值 (EV)
C121: =C13                                          — 净债务（链接市场数据）
C122: =C14                                          — 非营业资产（链接市场数据）
C123: =C120-C121+C122                               — 股权价值 = EV - 净债务 + 非营业资产
C126: =C123/C125                                    — 隐含每股价格
C128: =C119/C120                                    — 终端价值占EV比例
C129: =IF(E63<E64,"通过","警告: g >= WACC")         — 质量检查
```

### 3.4 历史数据输入（蓝色字体 + 来源注释）

以下为硬编码历史数据，全部使用蓝色字体并附带单元格注释：

| 行 | 列 | 值 | 来源注释 |
|----|-----|-----|---------|
| 68 | C | 78.0 | "Source: FA05_DCF_Model.md, FY2021A 收入 $78.0M" |
| 68 | D | 95.2 | "Source: FA05_DCF_Model.md, FY2022A 收入 $95.2M" |
| 68 | E | 116.4 | "Source: FA05_DCF_Model.md, FY2023A 收入 $116.4M" |
| 68 | F | 143.0 | "Source: FA05_DCF_Model.md, FY2024A 收入 $143.0M" |
| 11 | C | 42.5 | "Source: FA05_DCF_Model.md, 稀释后流通股数 42.5M, 含期权池和RSU" |
| 13 | C | 35.0 | "Source: FA05_DCF_Model.md, 净债务 $35.0M (总债务$50M - 现金$15M)" |
| 14 | C | 5.0 | "Source: FA05_DCF_Model.md, 非营业资产 $5.0M (投资及其他)" |

### 3.5 敏感性分析表公式规范

#### 3.5.1 表1: WACC vs 终端增长率 — 隐含每股价格

**布局（5x5网格，基准居中）：**

```
                    2.00%    2.50%    2.75%    3.00%    3.50%
    8.10%          [F]      [F]      [F]      [F]      [F]
    8.60%          [F]      [F]      [F]      [F]      [F]
    9.10%          [F]      [F]      [★]      [F]      [F]    ← 基准WACC
    9.60%          [F]      [F]      [F]      [F]      [F]
   10.10%          [F]      [F]      [F]      [F]      [F]
                              ↑
                        基准终端增长率
```

**轴值计算：** `axis = [base - 2*step, base - step, base, base + step, base + 2*step]`
- WACC轴: 9.1% +/- 0.5% = {8.1%, 8.6%, 9.1%, 9.6%, 10.1%}
- 终端增长率轴: 2.75% +/- 0.25%/0.50% = {2.00%, 2.50%, 2.75%, 3.00%, 3.50%}

**单元格公式模式（每个[F]单元格）：**

```excel
=(((G107/(1+$A_row)^I102) + SUM(
   $E$96/(1+$A_row)^$E$102,
   $F$96/(1+$A_row)^$F$102,
   $G$96/(1+$A_row)^$G$102,
   $H$96/(1+$A_row)^$H$102,
   $I$96/(1+$A_row)^$I$102
)) - $C$13 + $C$14) / $C$11
```

其中：
- `$A_row` = 该行WACC值（行标题，绝对行引用，相对列引用）
- `$B_col` = 该列终端增长率值（列标题，相对行引用，绝对列引用）
- 公式内部替换终端增长率参数用于终端FCF计算

**Python openpyxl 实现伪代码：**

```python
wacc_values = [0.081, 0.086, 0.091, 0.096, 0.101]
tg_values = [0.020, 0.025, 0.0275, 0.030, 0.035]

for r, wacc in enumerate(wacc_values):
    ws.cell(row=134+r, column=1, value=wacc)  # 行标题
    for c, tg in enumerate(tg_values):
        ws.cell(row=133, column=2+c, value=tg)  # 列标题
        # 公式: 完整DCF重算
        fml = (
            f"=((($I$96*(1+{tg}))/({wacc}-{tg})"
            f"/(1+{wacc})^$I$102"
            f"+$E$96/(1+{wacc})^$E$102"
            f"+$F$96/(1+{wacc})^$F$102"
            f"+$G$96/(1+{wacc})^$G$102"
            f"+$H$96/(1+{wacc})^$H$102"
            f"+$I$96/(1+{wacc})^$I$102)"
            f"-$C$13+$C$14)/$C$11"
        )
        ws.cell(row=134+r, column=2+c, value=fml)

# 基准单元格高亮 (WACC=9.1%, g=2.75% 即 r=2, c=2)
ws.cell(row=136, column=4).font = Font(bold=True, color="000000")
ws.cell(row=136, column=4).fill = PatternFill("solid", fgColor="BDD7EE")
```

**中心单元格验证：** 基准情景单元格（WACC=9.1%, g=2.75%）的输出必须等于 C126（隐含每股价格），这是敏感性表构建正确性的验证点。

#### 3.5.2 表2: 收入增长率 vs EBIT利润率 — 隐含EV/ARR倍数

**轴值：**
- 收入增长率轴（年均复合增长率偏移）: {10.0%, 13.0%, 16.0%, 19.0%, 22.0%}
- EBIT利润率轴（终端年份利润率）: {25.0%, 27.5%, 30.0%, 32.5%, 35.0%}

**公式模式：**

每个单元格重新构建5年FCF预测（使用该行的增长率偏移和该列的EBIT利润率），折现求和，计算EV/ARR倍数：

```excel
=(((终端FCF基于新g和margin)/(1+WACC)^4.5 + SUM(PV FCFs基于新增长率和margin))
- 净债务 + 非营业资产) / ($I$68) / 1000
```

其中 `$I$68` = FY2029E ARR（收入）。

#### 3.5.3 表3: Beta vs 无风险利率 — 隐含每股价格

**轴值：**
- Beta轴: {0.94, 1.04, 1.14, 1.24, 1.34}
- 无风险利率轴: {3.89%, 4.14%, 4.39%, 4.64%, 4.89%}

**公式模式：**

每个单元格计算新的Ke = Rf + Beta x ERP，然后推导新WACC，用新WACC重新折现全部FCF和终端价值：

```excel
=((终端价值/(1+(新WACC))^4.5 + SUM(各年FCF/(1+新WACC)^期间))
- 净债务 + 非营业资产) / 流通股数
```

**新WACC计算：**
```
新Ke = $B_col + $A_row * ERP
新WACC = 新Ke * 股权权重 + Kd_税后 * 债务权重
```

---

## 4. WACC 工作表详细规范

### 4.1 行布局规划

```
行号    内容                                      类型
─────   ─────────────────────────────────────     ──────────
 1      CloudPeak Technologies — WACC 计算        标题
 2      （空行）
 3      股权成本计算 (CAPM)                        标题（合并，深蓝底色）
 4      （空行）
 5      无风险利率 (10Y UST)                       蓝色输入: 4.39%
 6      Beta (5Y Monthly, Levered)                 蓝色输入: 1.14
 7      股权风险溢价 (ERP)                         蓝色输入: 4.23%
 8      股权成本 (Ke)                              公式: =C5+C6*C7
 9      （空行）
10      债务成本计算                               标题（合并，深蓝底色）
11      （空行）
12      税前债务成本                               蓝色输入: 6.86%
13      税率                                       绿色链接: =DCF!E62
14      税后债务成本 (Kd)                          公式: =C12*(1-C13)
15      （空行）
16      资本结构                                   标题（合并，深蓝底色）
17      （空行）
18      当前股价                                   绿色链接: =DCF!C10
19      流通股数 (M)                               绿色链接: =DCF!C11
20      市值 ($M)                                  公式: =C18*C19
21      （空行）
22      总债务 ($M)                                蓝色输入: 50.0
23      现金及等价物 ($M)                          蓝色输入: 15.0
24      净债务 ($M)                                公式: =C22-C23
25      （空行）
26      企业价值 ($M)                              公式: =C20+C24
27      （空行）
28      WACC 计算                                  标题（合并，深蓝底色）
29      （空行）
30                 权重        成本        贡献     列标题
31      股权       公式:       公式:       公式:     公式行
                 =C20/C26   =C8        =B31*C31
32      债务       公式:       公式:       公式:
                 =C24/C26   =C14       =B32*C32
33      （空行）
34      加权平均资本成本 (WACC)                    公式: =D31+D32（中蓝底色+粗体，绿色字体）
```

### 4.2 WACC 核心公式

```excel
C8:  =C5+C6*C7                     — Ke = Rf + Beta x ERP
C14: =C12*(1-C13)                  — Kd_税后 = Kd_税前 x (1-税率)
C20: =C18*C19                      — 市值 = 股价 x 流通股数
C24: =C22-C23                      — 净债务 = 总债务 - 现金
C26: =C20+C24                      — EV = 市值 + 净债务
B31: =C20/C26                      — 股权权重 = 市值/EV
C31: =C8                           — 股权成本
D31: =B31*C31                      — 股权贡献 = 权重 x 成本
B32: =C24/C26                      — 债务权重 = 净债务/EV
C32: =C14                          — 债务成本（税后）
D32: =B32*C32                      — 债务贡献 = 权重 x 成本
C34: =D31+D32                      — WACC = 股权贡献 + 债务贡献
```

### 4.3 WACC 输入数据来源注释

| 单元格 | 值 | 来源注释 |
|--------|-----|---------|
| C5 | 4.39% | "Source: FRED DGS10, 10年期美国国债收益率, 2026-05-08, https://fred.stlouisfed.org/series/DGS10" |
| C6 | 1.14 | "Source: Damodaran NYU Stern, US Software (System & Application) Levered Beta, 2025-01更新, https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/Betas.html" |
| C7 | 4.23% | "Source: Damodaran NYU Stern, 隐含ERP, 2026年初, https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/histimpl.html" |
| C12 | 6.86% | "Source: FRED ICE BofA BBB Index (5.36%) + SaaS利差调整(1.50%), 2026-05, https://fred.stlouisfed.org/series/BAMLC0A4CBBBEY" |
| C22 | 50.0 | "Source: FA05_DCF_Model.md, 总债务$50M (定期贷款+循环信贷)" |
| C23 | 15.0 | "Source: FA05_DCF_Model.md, 现金及等价物$15M (营运现金)" |

---

## 5. Checks 工作表规范

### 5.1 校验项目

| 行 | 检查项 | 公式 | 期望值 |
|----|--------|------|--------|
| 2 | 终端增长率 < WACC | `=IF(DCF!E63<DCF!E64,TRUE,FALSE)` | TRUE |
| 3 | 终端价值占EV 50-80% | `=IF(AND(DCF!C128>=0.5,DCF!C128<=0.8),TRUE,FALSE)` | TRUE |
| 4 | 税率范围 21-28% | `=IF(AND(DCF!E62>=0.21,DCF!E62<=0.28),TRUE,FALSE)` | TRUE |
| 5 | 营业费用基于收入 | 手动确认标记 | TRUE |
| 6 | 收入增长率单调递减 | `=AND(F69<=E69,G69<=F69,H69<=G69,I69<=H68)` | TRUE |
| 7 | FCF利润率为正 | `=AND(E97>0,F97>0,G97>0,H97>0,I97>0)` | TRUE |
| 8 | WACC合理性 (7-15%) | `=IF(AND(WACC!C34>=0.07,WACC!C34<=0.15),TRUE,FALSE)` | TRUE |
| 9 | 折现因子单调递减 | `=AND(F103<E103,G103<F103,H103<G103,I103<H103)` | TRUE |
| 10 | 股权价值 > 0 | `=DCF!C123>0` | TRUE |
| 11 | 敏感性表基准值匹配 | `=ABS(DCF!C126-基准单元格)<0.01` | TRUE |
| 13 | **全部检查通过** | `=AND(B2:B11)` | TRUE |

---

## 6. 格式规范（CFI/Wall Street Prep 标准）

### 6.1 字体颜色规范

| 类型 | RGB值 | openpyxl实现 | 应用范围 |
|------|-------|-------------|---------|
| **蓝色（硬编码输入）** | (0, 0, 255) | `Font(color="0000FF")` | 所有手动输入值：历史数据、假设、股价、股数等 |
| **黑色（公式/计算）** | (0, 0, 0) | `Font(color="000000")` | 所有公式计算结果 |
| **绿色（跨表链接）** | (0, 128, 0) | `Font(color="008000")` | WACC表引用DCF表的单元格 |

### 6.2 填充色规范（最小化配色方案）

| 区域 | RGB值 | hex值 | 应用 |
|------|-------|-------|------|
| **区块标题** | (31, 78, 121) | `#1F4E79` | 深蓝底色 + 白色粗体字 |
| **列标题/子标题** | (217, 225, 242) | `#D9E1F2` | 浅蓝底色 + 黑色粗体字 |
| **输入单元格背景** | (242, 242, 242) | `#F2F2F2` | 浅灰底色 + 蓝色字 |
| **关键输出** | (189, 215, 238) | `#BDD7EE` | 中蓝底色 + 黑色粗体字 |
| **计算单元格** | (255, 255, 255) | `#FFFFFF` | 白色背景（默认） |
| **敏感性表基准格** | (189, 215, 238) | `#BDD7EE` | 中蓝底色 + 粗体字 |

### 6.3 边框规范

| 类型 | 粗细 | 应用位置 |
|------|------|---------|
| **粗边框 (1.5pt)** | `Side(style='medium')` | 各大区块外边框：市场数据、情景假设、预测财务、折现估值、估值汇总、各敏感性表 |
| **中边框 (1pt)** | `Side(style='thin')` | 子区块分隔：公司信息 vs 历史表现、各情景块之间 |
| **细边框 (0.5pt)** | `Side(style='hairline')` | 数据表格内边框 |

### 6.4 数字格式规范

| 数据类型 | Excel格式代码 | openpyxl格式 | 示例 |
|----------|-------------|-------------|------|
| 年份 | `@` | `'FY2025E'`（文本） | FY2025E |
| 百分比 | `0.0%` | `'0.0%'` | 22.0% |
| 百万金额 | `$#,##0` | `'$#,##0'` | $143.0 |
| 每股价格 | `$#,##0.00` | `'$#,##0.00'` | $20.47 |
| 倍数 | `0.0"x"` | `'0.0"x"'` | 12.0x |
| 大数字 | `#,##0` | `'#,##0'` | 1,071 |
| 负数 | `(#,##0)` | `'(#,##0)'` | (35.0) |
| 零值 | `$#,##0;($#,##0);-` | `'$#,##0;($#,##0);-'` | - |

### 6.5 字体与对齐

| 元素 | 字体 | 大小 | 对齐 |
|------|------|------|------|
| 工作表标题 | Calibri | 14pt | 左对齐, 粗体 |
| 区块标题 | Calibri | 11pt | 左对齐, 粗体, 白色 |
| 列标题 | Calibri | 10pt | 居中, 粗体 |
| 数据 | Calibri | 10pt | 默认 |
| 公式结果 | Calibri | 10pt | 右对齐（数字） |

---

## 7. Python/openpyxl 实现框架

### 7.1 核心依赖与初始化

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Border, Side, numbers, Alignment
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter

wb = Workbook()

# 颜色定义
BLUE_FONT = Font(color="0000FF")          # 硬编码输入
BLACK_FONT = Font(color="000000")         # 公式
BLACK_BOLD = Font(color="000000", bold=True)
GREEN_FONT = Font(color="008000")         # 跨表链接
WHITE_BOLD = Font(color="FFFFFF", bold=True)

# 填充定义
DARK_BLUE_FILL = PatternFill("solid", fgColor="1F4E79")
LIGHT_BLUE_FILL = PatternFill("solid", fgColor="D9E1F2")
MEDIUM_BLUE_FILL = PatternFill("solid", fgColor="BDD7EE")
LIGHT_GREY_FILL = PatternFill("solid", fgColor="F2F2F2")

# 边框定义
THICK_BORDER = Border(
    left=Side(style='medium'), right=Side(style='medium'),
    top=Side(style='medium'), bottom=Side(style='medium')
)
THIN_BORDER = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)
```

### 7.2 命名范围创建

```python
from openpyxl.workbook.defined_name import DefinedName

named_ranges = {
    "Case_Selector":      "DCF!$B$6",
    "WACC_Rate":          "WACC!$C$34",
    "Terminal_Growth":    "DCF!$E$63",
    "Tax_Rate":           "DCF!$E$62",
    "Net_Debt":           "DCF!$C$13",
    "Shares_Outstanding": "DCF!$C$11",
    "Stock_Price":        "DCF!$C$10",
    "Risk_Free_Rate":     "WACC!$C$5",
    "Equity_Risk_Premium":"WACC!$C$7",
    "Beta":               "WACC!$C$6",
    "Cost_of_Equity":     "WACC!$C$8",
    "Pre_Tax_Cost_of_Debt":"WACC!$C$12",
    "After_Tax_Cost_of_Debt":"WACC!$C$14",
    "Market_Cap":         "WACC!$C$20",
    "Enterprise_Value_WACC":"WACC!$C$26",
    "Equity_Weight":      "WACC!$B$31",
    "Debt_Weight":        "WACC!$B$32",
    "Sum_PV_FCF":         "DCF!$C$118",
    "PV_Terminal_Value":  "DCF!$C$119",
}

for name, ref in named_ranges.items():
    dn = DefinedName(name, attr_text=ref)
    wb.defined_names.add(dn)
```

### 7.3 敏感性表公式生成循环

```python
def write_sensitivity_table(ws, start_row, start_col,
                            row_values, col_values,
                            base_row_idx, base_col_idx,
                            formula_template):
    """通用敏感性表写入函数"""
    # 写列标题
    for c, val in enumerate(col_values):
        cell = ws.cell(row=start_row, column=start_col+1+c, value=val)
        cell.font = BLACK_BOLD
        cell.fill = LIGHT_BLUE_FILL
        cell.number_format = '0.00%'

    # 写行标题 + 公式
    for r, rval in enumerate(row_values):
        # 行标题
        cell = ws.cell(row=start_row+1+r, column=start_col, value=rval)
        cell.font = BLACK_BOLD
        cell.fill = LIGHT_BLUE_FILL
        cell.number_format = '0.00%'

        # 公式单元格
        for c, cval in enumerate(col_values):
            formula = formula_template(rval, cval)
            cell = ws.cell(row=start_row+1+r, column=start_col+1+c, value=formula)
            cell.number_format = '$#,##0.00'

            # 基准单元格高亮
            if r == base_row_idx and c == base_col_idx:
                cell.font = BLACK_BOLD
                cell.fill = MEDIUM_BLUE_FILL

# 表1: WACC vs 终端增长率
wacc_vals = [0.081, 0.086, 0.091, 0.096, 0.101]
tg_vals   = [0.020, 0.025, 0.0275, 0.030, 0.035]

def wacc_tg_formula(wacc, tg):
    return (
        f"=((($I$96*(1+{tg}))/({wacc}-{tg})"
        f"/(1+{wacc})^$I$102"
        f"+$E$96/(1+{wacc})^$E$102"
        f"+$F$96/(1+{wacc})^$F$102"
        f"+$G$96/(1+{wacc})^$G$102"
        f"+$H$96/(1+{wacc})^$H$102"
        f"+$I$96/(1+{wacc})^$I$102)"
        f"-$C$13+$C$14)/$C$11"
    )

write_sensitivity_table(dcf_ws, 133, 1,
    wacc_vals, tg_vals, 2, 2, wacc_tg_formula)
```

### 7.4 单元格注释添加模式

```python
def add_source_comment(cell, source_text):
    """为硬编码输入添加来源注释"""
    cell.comment = Comment(source_text, "xlsx-author", width=300, height=100)

# 示例：历史收入数据
dcf_ws["C68"] = 78.0
dcf_ws["C68"].font = BLUE_FONT
add_source_comment(dcf_ws["C68"],
    "Source: FA05_DCF_Model.md, FY2021A 收入 $78.0M, "
    "基于CloudPeak Technologies历史财务数据")

# 示例：无风险利率
wacc_ws["C5"] = 0.0439
wacc_ws["C5"].font = BLUE_FONT
wacc_ws["C5"].number_format = '0.00%'
add_source_comment(wacc_ws["C5"],
    "Source: FRED DGS10, 10年期美国国债收益率, 2026-05-08, "
    "https://fred.stlouisfed.org/series/DGS10")
```

### 7.5 保存与重算

```python
# 创建输出目录
import os
os.makedirs("./out", exist_ok=True)

# 保存工作簿
output_path = "./out/CloudPeak_DCF_Model_2026-05-10.xlsx"
wb.save(output_path)

# 公式重算（交付前必须执行）
# bash: python recalc.py ./out/CloudPeak_DCF_Model_2026-05-10.xlsx 30
# 期望输出: {"status": "success", "total_errors": 0}
```

---

## 8. 行布局一致性验证

以下为行号交叉引用检查，确保所有公式引用的行号与实际布局匹配：

| 公式引用 | 期望内容 | 验证行号 | 验证列 | 状态 |
|----------|---------|---------|--------|------|
| `$E$56` | 合并列-收入增长率FY2025E | 56 | E | 锁定 |
| `$E$57` | 合并列-毛利率FY2025E | 57 | E | 锁定 |
| `$E$58` | 合并列-EBIT利润率FY2025E | 58 | E | 锁定 |
| `$E$59` | 合并列-D&A%FY2025E | 59 | E | 锁定 |
| `$E$60` | 合并列-CapEx%FY2025E | 60 | E | 锁定 |
| `$E$61` | 合并列-NWC%FY2025E | 61 | E | 锁定 |
| `$E$62` | 合并列-税率 | 62 | E | 锁定 |
| `$E$63` | 合并列-终端增长率 | 63 | E | 锁定 |
| `$E$64` | 合并列-WACC | 64 | E | 锁定 |
| `$B$6` | Case_Selector | 6 | B | 锁定 |
| `D68` | FY2024A收入（预测起始） | 68 | D | 锁定 |
| `E68` | FY2025E收入 | 68 | E | 锁定 |
| `E80` | FY2025E EBIT | 80 | E | 锁定 |
| `E86` | FY2025E NOPAT | 86 | E | 锁定 |
| `E89` | FY2025E D&A | 89 | E | 锁定 |
| `E91` | FY2025E CapEx | 91 | E | 锁定 |
| `E93` | FY2025E NWC变动 | 93 | E | 锁定 |
| `E96` | FY2025E UFCF | 96 | E | 锁定 |
| `E101` | FY2025E UFCF（链接） | 101 | E | 锁定 |
| `E102` | FY2025E折现期间 (0.5) | 102 | E | 锁定 |
| `E103` | FY2025E折现因子 | 103 | E | 锁定 |
| `E104` | FY2025E FCF现值 | 104 | E | 锁定 |
| `I101` | FY2029E UFCF | 101 | I | 锁定 |
| `I102` | FY2029E折现期间 (4.5) | 102 | I | 锁定 |
| `I103` | FY2029E折现因子 | 103 | I | 锁定 |
| `I80` | FY2029E EBIT | 80 | I | 锁定 |
| `I89` | FY2029E D&A | 89 | I | 锁定 |
| `C13` | 净债务 | 13 | C | 锁定 |
| `C14` | 非营业资产 | 14 | C | 锁定 |
| `C11` | 稀释后流通股数 | 11 | C | 锁定 |
| `C118` | 预测期FCF现值总和 | 118 | C | 锁定 |
| `C119` | 终端价值现值 | 119 | C | 锁定 |
| `C120` | 企业价值 | 120 | C | 锁定 |
| `C123` | 股权价值 | 123 | C | 锁定 |
| `C125` | 流通股数（估值汇总） | 125 | C | 锁定 |
| `C126` | 隐含每股价格 | 126 | C | 锁定 |
| `C128` | 终端价值占EV比例 | 128 | C | 锁定 |
| `G107` | 终端FCF | 107 | G | 锁定 |
| `G108` | 终端价值（永续增长法） | 108 | G | 锁定 |
| `G109` | 终端价值现值 | 109 | G | 锁定 |
| `G112` | FY2029E EBITDA | 112 | G | 锁定 |
| `G113` | 退出EV/EBITDA倍数 | 113 | G | 锁定 |
| `G114` | 终端价值（退出倍数法） | 114 | G | 锁定 |
| `G115` | 终端价值现值（退出倍数法） | 115 | G | 锁定 |

---

## 9. 交付前检查清单

### 9.1 公式重算

```bash
python recalc.py ./out/CloudPeak_DCF_Model_2026-05-10.xlsx 30
```

期望结果：
```json
{"status": "success", "total_errors": 0, "total_formulas": "<count>"}
```

**零公式错误是硬性要求。** 如发现 `#REF!`、`#DIV/0!`、`#VALUE!`、`#NAME?` 等错误，必须修复后重新执行重算。

### 9.2 结构验证

| 检查项 | 期望 | 状态 |
|--------|------|------|
| 工作表数量 | 3（DCF, WACC, Checks） | 待验证 |
| DCF表敏感性表位置 | 表底部（非独立工作表） | 待验证 |
| 情景选择器 (B6) | 值为1/2/3，合并列正确响应 | 待验证 |
| 蓝色字体覆盖所有硬编码输入 | 100%覆盖 | 待验证 |
| 黑色字体覆盖所有公式 | 100%覆盖 | 待验证 |
| 绿色字体覆盖所有跨表链接 | 100%覆盖 | 待验证 |
| 单元格注释覆盖所有硬编码输入 | 100%覆盖 | 待验证 |
| 专业边框覆盖所有大区块 | 100%覆盖 | 待验证 |
| 敏感性表75个公式全部填写 | 3表 x 25格 = 75 | 待验证 |
| 基准单元格高亮（中蓝+粗体） | 3个表各1个 | 待验证 |
| Checks表全部TRUE | 10项校验 | 待验证 |

### 9.3 逻辑验证

| 验证项 | 方法 |
|--------|------|
| 情景切换 | 修改B6为1/3，验证合并列值变化、预测数据联动 |
| WACC联动 | 修改WACC表输入，验证DCF折现因子更新 |
| 终端价值合理性 | 确认TV/EV在50-80%范围 |
| 终端g < WACC | 确认Checks表该项为TRUE |
| 敏感性表基准值 | 确认中心格=估值汇总隐含价格 |
| 营业费用基于收入 | 确认公式引用行68（收入）而非行71（毛利润） |

---

## 10. 文件命名与路径

| 项目 | 值 |
|------|-----|
| 文件名 | `CloudPeak_DCF_Model_2026-05-10.xlsx` |
| 输出路径 | `./out/CloudPeak_DCF_Model_2026-05-10.xlsx` |
| Python脚本 | `./build_model.py`（生成工作簿的构建脚本） |
| 重算脚本 | `recalc.py`（xlsx-author技能提供） |

---

## 11. 技术实现要点总结

### 11.1 合并列（Consolidation Column）设计

合并列是本模型的核心架构决策，所有预测公式仅引用合并列（E56:E64），而非直接引用情景块。情景逻辑集中在INDEX公式中，便于：

1. **审计简洁性** — 修改情景切换逻辑只需检查INDEX公式
2. **公式可读性** — `=D68*(1+$E$56)` 比 `=D68*(1+IF($B$6=1,C20,IF($B$6=2,C32,C44)))` 更清晰
3. **扩展性** — 新增情景只需扩展INDEX数组范围

### 11.2 敏感性表公式架构

每个敏感性表单元格包含完整DCF重算逻辑：
- 重新计算5年FCF（使用新的假设参数）
- 重新折现（使用新的WACC/折现率）
- 重新计算终端价值
- 推导隐含每股价格

这确保敏感性表反映非线性关系，而非线性近似。

### 11.3 双终端价值方法

模型同时包含永续增长法和退出倍数法：
- 永续增长法作为主要估值方法
- 退出倍数法作为交叉验证
- 两种方法结果可在估值汇总区域对比

---

## Sources

- [CFI - DCF Model Training Guide](https://corporatefinanceinstitute.com/resources/valuation/dcf-model-training-guide/)
- [CFI - Financial Modeling Best Practices](https://corporatefinanceinstitute.com/resources/career-map/sell-side/corporate-finance/financial-modeling-best-practices/)
- [Wall Street Prep - DCF Model Guide](https://www.wallstreetprep.com/knowledge/dcf-model/)
- [Wall Street Prep - Financial Modeling Color Formatting](https://www.wallstreetprep.com/knowledge/financial-modeling-color-formatting/)
- [FRED - 10-Year Treasury Yield (DGS10)](https://fred.stlouisfed.org/series/DGS10)
- [FRED - ICE BofA BBB US Corporate Index Yield](https://fred.stlouisfed.org/series/BAMLC0A4CBBBEY)
- [Damodaran NYU Stern - Betas by Sector (US)](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/Betas.html)
- [Damodaran NYU Stern - Historical Implied ERP](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/histimpl.html)
- [Damodaran Substack - Data Update 2 for 2026](https://aswathdamodaran.substack.com/p/data-update-2-for-2026-a-testing)
- [Macabacus - Excel Formatting for Investment Banking](https://macabacus.com/)
- [Mergers & Inquisitions - DCF Model Tutorial](https://www.mergersandinquisitions.com/dcf-model/)
- [openpyxl Documentation](https://openpyxl.readthedocs.io/en/stable/)
- [Clearly Acquired - EBITDA Multiples for SaaS 2025-2026](https://www.clearlyacquired.com/blog/ebitda-multiples-for-saas-and-software-companies-2025-2026)
- [QuantPillar - 2025-2026 Private Market Valuation Multiples](https://quantpillar.com/resources/guides/valuation-multiples/)
- [G2 Squared CFO - SaaS Benchmarks 2026](https://www.gsquaredcfo.com/blog/saas-benchmarks-2026)
- [Aventis Advisors - SaaS Valuation Multiples 2015-2026](https://aventis-advisors.com/saas-valuation-multiples/)
- [FA05_DCF_Model.md — CloudPeak Technologies DCF 估值模型基础数据](file://./FA05_DCF_Model.md)
