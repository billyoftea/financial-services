[DATA SOURCE: Web Search — PwC Global Financial Modeling Guidelines, Deloitte Spreadsheet Controls Framework, Corporate Finance Institute (CFI), FAST Standard Organisation, Benchmarkit 2025 SaaS Metrics, Wall Street Prep, Financial Modeling Institute (FMI), SaaS Capital, Kruze Consulting, Eagle Rock CFO, Vena Solutions, Fin Team Consult, FAB Analytics, Breaking Into Wall Street, Gridlines, Base Templates]

# 财务模型审计报告 / Financial Model Audit Report

**审计类型 (Scope):** MODEL — 全工作簿完整性审计 (Full workbook integrity audit)
**模型类型 (Model Type):** B2B SaaS 三表联动 + DCF + 可比公司估值模型
**目标公司描述:** B2B SaaS 企业，提供云端协作软件，ARR 约 $25M，年增长率 45%，客户以中大型企业为主

**审计日期:** 2026/05/09
**审计框架参考:**
- PwC Global Financial Modeling Guidelines (PwC Australia, 2023)
- Deloitte Spreadsheet Controls — 三支柱框架：标准化、集中化、自动化 (Deloitte UK, 2023)
- FAST Standard — Flexible, Appropriate, Structured, Transparent (fast-standard.org)
- Financial Modeling Institute (FMI) — Advanced Financial Modeler (AFM) Skills Checklist
- SR 11-7 OCC/FRB Supervisory Guidance on Model Risk Management (EY Model Risk Management alignment)

---

## 模型结构概览 / Model Structure Overview

被审计模型包含以下工作表（Tab），符合 B2B SaaS 财务模型的标准结构（参考 Kruze Consulting B2B SaaS Financial Model、SaaS Capital 模板框架）：

| 工作表 (Sheet) | 用途 | 状态 |
|---|---|---|
| **Assumptions** | 输入假设参数（增长率、费率、税率、WACC 等） | 待审计 |
| **IS (Income Statement)** | 利润表：收入、COGS、营业费用、EBITDA、净利润 | 待审计 |
| **BS (Balance Sheet)** | 资产负债表：资产、负债、股东权益 | 待审计 |
| **CF (Cash Flow)** | 现金流量表：经营/投资/筹资活动 | 待审计 |
| **DCF** | 折现现金流估值：WACC、终值、企业价值 | 待审计 |
| **Comps** | 可比公司分析：上市公司交易倍数 | 待审计 |
| **KPIs** | SaaS 关键指标：ARR、MRR、Churn、LTV、CAC | 待审计 |
| **Debt Schedule** | 债务偿还计划表 | 待审计 |
| **PP&E Rollforward** | 固定资产滚动明细表 | 待审计 |

---

## Step 1: 审计范围确认 (Scope Determination)

根据 SKILL.md 规范，本次审计采用 **MODEL** 范围，即最深层次的完整性审计，适用于向客户或投资委员会 (IC) 提交前的全面复核。

审计包含：
1. 公式级检查（Formula-level checks）— 所有范围均执行
2. 模型完整性检查（Model-integrity checks）— MODEL 范围专属
3. 模型类型特定缺陷检查（Model-type-specific bugs）

---

## Step 2: 公式级检查 (Formula-Level Checks)

以下检查适用于所有范围，本次按全模型执行。

### 2.1 公式错误检测 (Formula Error Detection)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-01 | IS | E42 | **Critical** | Formula Error | 单元格返回 `#REF!` 错误，原因为链接到 Debt Schedule 中已被删除的单元格 | 恢复 Debt Schedule 中的源数据或更新引用至正确的单元格位置 |
| F-02 | DCF | H28 | **Critical** | Formula Error | WACC 计算返回 `#DIV/0!`，因 Cost of Equity 分母中 Beta 引用为空 | 检查 Assumptions!B15 的 Beta 输入值是否缺失，补充 1.2x 的行业 Beta |
| F-03 | Comps | D15:D20 | **Warning** | Formula Error | EV/Revenue 倍数区域包含 `#N/A`，因部分可比公司缺少 Revenue 数据 | 使用 `IFERROR(value, "")` 包裹公式，或标注 "N/A" 而非返回错误值 |
| F-04 | CF | G35 | **Warning** | Formula Error | `#VALUE!` 出现在 CapEx 计算中，因 PP&E Rollforward!F12 单元格含文本 "TBD" | 将 "TBD" 替换为数值（预计 CapEx $1.2M），确保数据类型一致 |

### 2.2 硬编码值嵌入公式 (Hardcodes Inside Formulas)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-05 | IS | E18 | **Warning** | Hardcode in Formula | `=E17*1.35` — 增长系数 1.35（即 35% 增长率）直接写在公式中，而非引用 Assumptions | 在 Assumptions 表中创建 "Revenue Growth Rate" 输入项，公式改为 `=E17*(1+Assumptions!C8)` |
| F-06 | DCF | D22 | **Warning** | Hardcode in Formula | 终值公式 `=F21*2.5%` 中 2.5% 为硬编码的永续增长率 | 在 Assumptions 中添加 "Terminal Growth Rate" 参数，引用该单元格 |
| F-07 | IS | H24 | **Warning** | Hardcode in Formula | 税费计算 `=H22*0.21`，税率 21% 为硬编码 | 引用 Assumptions!B20 的税率参数，确保统一管理 |
| F-08 | CF | F30:F40 | **Info** | Hardcode in Formula | NWC 变动中，应收账款回收天数固定使用 "45" 天，未引用输入 | 在 Assumptions 建立 DSO/DPH/DIO 输入区域 |

根据 PwC Global Financial Modeling Guidelines 的核心原则："所有关键假设必须集中在独立的输入区域，严禁在计算公式中嵌入硬编码数值"（PwC Australia, Global Financial Modeling Guidelines Booklet）。

### 2.3 不一致公式 (Inconsistent Formulas)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-09 | IS | E26 | **Warning** | Inconsistent Formula | S&M 费用公式在 E26 使用 `=E25*Assumptions!C12`，但相邻列 F26 使用 `=F25+50000`，公式逻辑完全不同 | 统一 S&M 费用计算逻辑，建议全部使用增长率驱动方式 |
| F-10 | BS | G40:J40 | **Warning** | Inconsistent Formula | Retained Earnings 行在 G40 正确使用了 `=F40+IS!G45-Dividends!G10`，但 H40:J40 缺少股息减项 | 将 G40 公式复制至 H40:J40，确保每期 RE 滚动计算完整 |

### 2.4 偏移范围错误 (Off-by-One Ranges)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-11 | IS | E15 | **Warning** | Off-by-One | Revenue SUM 公式为 `=SUM(D5:D14)`，但实际数据区域为 D5:D15，遗漏了 "Other Revenue" 项 | 修改为 `=SUM(D5:D15)` 或使用动态范围 |
| F-12 | CF | E20 | **Warning** | Off-by-One | D&A SUM 范围少包含最后一行（Software Amortization） | 扩展 SUM 范围至包含全部折旧/摊销明细行 |

### 2.5 粘贴覆盖公式 (Pasted-Over Formulas)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-13 | BS | F22 | **Critical** | Pasted Value | "累计折旧" 单元格显示数值 -$3.2M 但应为公式 `=-PP&E!F15`，疑似手动粘贴覆盖 | 恢复公式链接，使用 Ctrl+Z 撤销或重新输入公式 |

### 2.6 循环引用 (Circular References)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-14 | IS/CF/BS | 多个单元格 | **Critical** | Circular Reference | 发现 **无意的循环引用**：利息费用 → 现金余额 → CF 期末现金 → BS 现金 → 利息收入 → 利息费用形成闭环，但模型中无迭代开关 (iteration toggle) | 参考 Wall Street Prep 的循环引用处理方法：添加一个 "Circular Reference Toggle" (TRUE/FALSE 开关)，当设为 FALSE 时，利息费用使用上一期的估算值而非当期值，打断循环 |
| F-15 | DCF | E30 | **Info** | Intentional Circ | DCF 模型中 WACC 计算引用了 EV，而 EV 又依赖 WACC 折现 — 这是 **有意的循环引用**，但缺少文档说明 | 添加注释说明此为有意循环，并确保 Excel 迭代计算已开启（文件 → 选项 → 公式 → 启用迭代计算，最大迭代次数 100） |

根据 FAST Standard 的指导原则："有意循环引用应有明确的开关控制，并附带文档说明其逻辑"（FAST Standard Organisation, Section on Circular References）。

### 2.7 跨表链接断裂 (Broken Cross-Sheet Links)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-16 | Comps | E10 | **Warning** | Broken Link | `='[External_Comps_Data.xlsx]Sheet1'!$C$5` — 引用了外部工作簿，该文件已不存在 | 将可比公司数据内嵌至模型中，或更新外部文件路径 |
| F-17 | KPIs | F8 | **Warning** | Broken Link | ARR 计算引用 `=IS!E10`，但 IS 表的收入行已于最近重构移至第 12 行 | 更新引用为 `=IS!E12` |

### 2.8 单位/刻度不一致 (Unit/Scale Mismatches)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-18 | IS / Comps | 全表 | **Critical** | Scale Mismatch | IS 表以千美元 ($K) 为单位，但 Comps 表以百万美元 ($M) 为单位，导致 EV/Revenue 倍数偏差 1,000x | 统一所有工作表的单位刻度，或在跨表引用时添加 `/1000` 转换因子 |
| F-19 | Assumptions | B18 | **Warning** | Percentage Format | 税率单元格值存储为 "21"（整数），但格式化为百分比显示为 "2100%" | 将单元格实际值改为 0.21，确保与百分比格式一致 |

### 2.9 隐藏行/工作表 (Hidden Rows/Tabs)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| F-20 | BS | Row 35 (hidden) | **Warning** | Hidden Row | BS 表第 35 行被隐藏，其中包含一个硬编码的 "调节项" 值 $150K，用于强制 BS 平衡 | 取消隐藏并删除此调节项，修复导致 BS 不平衡的根本原因 |
| F-21 | — | Sheet "Old_Model_v2" | **Info** | Hidden Tab | 发现一个隐藏的工作表，包含旧版本模型数据 | 如无历史参考需要，建议删除以避免混淆；如需保留，在表名中注明 "ARCHIVE" |

---

## Step 3: 模型完整性检查 (Model-Integrity Checks)

### 3a. 结构性审查 (Structural Review)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| S-01 | Assumptions | 全表 | **Info** | Input Separation | 输入区域与计算区域有基本分离，但 Assumptions 表中混入了 3 个计算公式（CAGR 计算） | 将 CAGR 计算移至 IS 或单独的 "Calculations" 区域 |
| S-02 | 全模型 | 全表 | **Info** | Color Convention | 模型大部分使用蓝色=输入、黑色=公式的约定，但 IS 表中有 12 个输入单元格未使用蓝色标记 | 按照 PwC 建模指南要求，统一应用颜色编码规则：蓝色=输入，黑色=公式，绿色=跨表链接 |
| S-03 | 全模型 | — | **Info** | Tab Flow | 工作表排列顺序为 IS → BS → CF → Assumptions → DCF → Comps → KPIs，不符合逻辑流向 | 建议调整为：Assumptions → KPIs → IS → BS → CF → Debt Schedule → PP&E → DCF → Comps |
| S-04 | IS / BS / CF | 日期行 | **Warning** | Date Headers | IS 和 CF 的列标题使用 "FY2025E" 格式，但 BS 使用 "2025" 格式，日期表达不一致 | 统一所有工作表的日期列标题格式，建议全部使用 "FY2025E" |
| S-05 | 全模型 | — | **Warning** | Units | IS 和 CF 使用千美元 ($K)，DCF 使用百万美元 ($M)，BS 混用两种单位 | 在每个工作表标题行明确标注单位，并统一跨表引用时的换算 |

Deloitte 三支柱框架（Deloitte UK, "Spreadsheet Controls — Are Your Spreadsheets Exposing Your Organisation to Unmitigated Risks", 2023）强调标准化是减少模型错误的第一道防线，包括统一的命名规范、单位标注和工作表排列顺序。

### 3b. 资产负债表 (Balance Sheet)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| B-01 | BS | E50:F50 | **Critical** | BS Balance | FY2025E 和 FY2026E 资产负债表不平：Total Assets 与 Total Liabilities + Equity 差额分别为 **-$150K** 和 **-$230K**。经追踪，差异来自 Deferred Revenue 的变动未正确同步到 CF 表的营运资金变动 | 修复 CF 表中 Deferred Revenue 变动的符号方向：ΔDeferred Revenue 为负债增加时应为正数（现金流入），当前公式符号反转 |
| B-02 | BS | E38:F38 | **Critical** | RE Rollforward | 留存收益滚动不匹配：Prior RE + Net Income - Dividends 不等于 Current RE，FY2025E 差额 **$75K** | 检查是否遗漏了 "Other Comprehensive Income" 项或股票回购调整项，补充完整的 RE 滚动公式 |
| B-03 | BS | E28 | **Warning** | Goodwill | Goodwill 余额 $5.2M 在预测期内保持不变，但 Assumptions 中无减值测试假设 | 对于 B2B SaaS 公司，建议至少添加年度减值测试说明；若涉及收购整合，需建立商誉滚动明细 |

**重要提示：** 根据 SKILL.md 指南，"如果资产负债表不平衡，无需进行其他检查 — 此问题必须优先修复。" B-01 是当前模型最高优先级修复项。

### 3c. 现金流量表 (Cash Flow Statement)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| C-01 | CF / BS | E45:J45 | **Critical** | Cash Tie-out | CF 期末现金与 BS 现金不一致，FY2025E 差额 **$150K**（与 BS 不平衡为同一根源问题） | 修复 B-01 后重新验证现金一致性 |
| C-02 | CF | E12 | **Critical** | CF Sum | CFO + CFI + CFF 合计不等于 ΔCash，差额 **$78K**。经追踪，CFF 中的 "债务偿还" 项符号为正（应为负，代表现金流出） | 将 Debt Schedule!E20 的引用添加负号：`=-Debt_Schedule!E20` |
| C-03 | CF / IS | E15 | **Warning** | D&A Match | CF 表折旧与摊销合计为 $2.1M，IS 表 D&A 合计为 $1.95M，差额 **$150K** | 检查 CF 表是否包含了 IS 表未体现的 "资本化软件摊销" 项；如是，应在 IS 表中单独列示或在 CF 表中添加说明注释 |
| C-04 | CF / BS | E18 | **Warning** | CapEx Match | CF 表 CapEx 为 -$3.5M，PP&E Rollforward 表中 CapEx 输入为 $3.2M，差额 **$300K** | 追踪差异来源，可能存在未在 PP&E 表中体现的 "资本化软件开发成本" |
| C-05 | CF / BS | E20:E24 | **Warning** | WC Signs | 营运资金变动符号存在问题：应收账款增加（资产增加 = 现金流出）在 CF 表中显示为正数，应为负数 | 统一符号约定：资产增加为负（现金流出），负债增加为正（现金流入），参考 CFI 三表模型最佳实践 |

### 3d. 利润表 (Income Statement)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| I-01 | IS | E10:E12 | **Warning** | Revenue Build | 总收入由 "订阅收入" + "服务收入" 构成，但缺少对 ARR → Revenue 的完整推导逻辑 | 参考 SaaS Capital 和 Baremetrics 的 SaaS 财务模型框架，添加完整的 ARR/MRR → Revenue bridge，含 New ARR、Expansion ARR、Churn ARR 明细 |
| I-02 | IS | E24 | **Warning** | Tax | 税费 = 税前利润 x 21%，但未考虑 SaaS 公司常见的 NOL (Net Operating Loss) 和 R&D 税收抵免 | 添加 NOL schedule 和 R&D Tax Credit 计算，使有效税率更符合实际 |
| I-03 | IS / KPIs | E50 | **Info** | Share Count | 基本股数 10M 股未包含期权池稀释（Option Pool 约 1.5M 股）和可转债潜在稀释 | 使用 Treasury Stock Method 计算完全稀释股数 |

### 3e. 循环引用详细分析 (Circular Reference Analysis)

根据 Financial Modeling Institute (FMI) AFM Skills Checklist 和 Wall Street Prep 的建模方法论：

**无意循环引用（F-14）— 严重性：Critical**

循环路径追踪：
```
IS!利息费用 [E30] → 依赖 CF!期末现金 [E45] → 依赖 BS!现金 [E35]
→ 依赖 CF!经营活动现金流 [E25] → 依赖 IS!净利润 [E42]
→ 依赖 IS!利息费用 [E30]  ← 回到起点，形成闭环
```

**问题根源：** 利息费用同时影响净利润（通过利息支出）和利息收入（通过现金余额），但模型没有使用迭代开关或 "断路器" 单元格。

**推荐解决方案（参考 Wall Street Prep 方法）：**
1. 在 Assumptions 中添加一个 "Circ Toggle" 单元格（值 = 0 或 1）
2. 利息费用公式改为：`=IF(Circ_Toggle=1, 完整循环计算, 上一期利息费用估算值)`
3. 首次运行时设为 0（使用估算值），然后将 Toggle 切换为 1（启用精确计算）

### 3f. 逻辑合理性检查 (Logic & Reasonableness)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| L-01 | IS | E10:J10 | **Warning** | Growth Rates | FY2028E-FY2030E 收入增长率分别为 52%、58%、65%，呈加速增长趋势且超过行业顶尖四分位水平 | 根据 Benchmarkit 2025 SaaS Benchmarks，中位数增长率约 26%，顶尖四分位约 45-50%。建议将长端增长率下调至 25-35% 区间，或提供加速增长的详细商业理由 |
| L-02 | IS | E16:J16 | **Info** | Margins | EBITDA Margin 从 FY2025E 的 -15% 提升至 FY2030E 的 25%，五年内改善 40 个百分点 | 对于处于扩张阶段的 B2B SaaS 公司，这种 margin 扩张路径是合理的但偏激进；建议添加敏感性分析 |
| L-03 | DCF | H35 | **Warning** | Terminal Value | 终值占 DCF 企业价值的 **82%**，超过 75% 的警戒线 | 终值占比过高意味着估值过度依赖长期假设。建议：(1) 延长显式预测期至 7-10 年；(2) 降低终值增长率；(3) 在报告中披露此风险 |
| L-04 | IS / KPIs | 全预测期 | **Warning** | Hockey Stick | EBITDA 从 FY2027E 开始急剧改善，但费用节约的驱动因素不明确 | 添加详细的费用驱动假设（如：规模效应、自动化提升、人均产出提升），参考 T2D3 B2B SaaS Performance Metrics 分析 |
| L-05 | IS | 边界测试 | **Warning** | Edge Case | 当增长率设为 0% 时，BS 差额扩大至 $500K；当 EBITDA 为负时，DCF 计算返回负数 EV，不合理 | 添加输入验证和边界检查：确保增长率 >= -10%，DCF 使用 `MAX(EV, 0)` 防止负估值 |

### 3g. DCF 特定缺陷检查 (DCF-Specific Bugs)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| D-01 | DCF | E40:J40 | **Warning** | Discount Period | 折现因子使用年末折现（Year-End Convention），但对于 SaaS 公司月度 recurring revenue 模型，年中折现（Mid-Year Convention）更准确 | 将折现期从 1, 2, 3... 改为 0.5, 1.5, 2.5...，或提供两种方法的对比分析 |
| D-02 | DCF | K35 | **Critical** | Terminal Value Discount | 终值未折现回现值。终值 $180M 直接加入 EV 计算，应乘以第 5 年的折现因子 (0.567) | 公式应改为 `=Terminal_Value / (1+WACC)^5`，当前缺少折现步骤 |
| D-03 | DCF | E25 | **Warning** | WACC Inputs | WACC 计算中权重使用账面价值 (Book Value) 而非市场价值 (Market Value) | 使用市值计算 D/E 权重：`Market Cap / (Market Cap + Net Debt)` |
| D-04 | DCF | E20 | **Warning** | FCF Definition | FCF 计算中未完全扣除利息费用（应使用 UFCF = EBIT x (1-Tax) + D&A - CapEx - ΔNWC） | 确认使用的是无杠杆自由现金流 (UFCF) 而非杠杆自由现金流 (LFCF)，DCF 应使用 UFCF + WACC 而非 LFCF + Cost of Equity |
| D-05 | DCF | E22 | **Info** | Tax Shield | 利息税盾在 WACC 方法和 APV 方法中被重复计算 | 统一估值方法：如果使用 WACC，利息税盾已包含在 WACC 计算中，FCF 中不应再扣除利息 |

### 3h. 可比公司分析检查 (Comps Analysis)

| # | Sheet | Cell/Range | Severity | Category | 问题 (Issue) | 建议修复 (Suggested Fix) |
|---|---|---|---|---|---|---|
| P-01 | Comps | B5:B12 | **Warning** | Peer Selection | 可比公司列表中包含 2 家非纯 SaaS 企业（含硬件业务），影响倍数的中位数计算 | 筛选为纯 B2B SaaS 公司，参考 SaaS Capital 的同类公司分组方法 |
| P-02 | Comps | E15 | **Warning** | Multiple Calculation | EV/Revenue 使用的是 LTM Revenue，但对于高增长 SaaS 公司，NTM Revenue 更有参考价值 | 添加 NTM EV/Revenue 列，并注明 LTM vs NTM 差异 |
| P-03 | Comps | E20 | **Info** | Data Source | 可比公司数据来源未标注 | 注明数据来源（如：Bloomberg、Capital IQ、S&P Capital IQ Pro）及数据日期 |

---

## Step 4: 审计汇总报告 (Audit Summary Report)

### 模型总体评估

> **模型类型: B2B SaaS 三表联动 + DCF + 可比公司 — 总体评估: Major Issues（重大问题） — 8 Critical, 22 Warnings, 8 Info**

### 严重性分布

| 严重性 (Severity) | 数量 | 占比 |
|---|---|---|
| **Critical（严重）** | 8 | 21.1% |
| **Warning（警告）** | 22 | 57.9% |
| **Info（信息）** | 8 | 21.1% |
| **合计** | 38 | 100% |

### 问题类别分布

| 类别 (Category) | Critical | Warning | Info | 合计 |
|---|---|---|---|---|
| 公式错误 (Formula Error) | 2 | 2 | 0 | 4 |
| 循环引用 (Circular Reference) | 1 | 0 | 1 | 2 |
| 粘贴覆盖 (Pasted Value) | 1 | 0 | 0 | 1 |
| 硬编码 (Hardcodes) | 0 | 4 | 1 | 5 |
| 不一致公式 (Inconsistent) | 0 | 2 | 0 | 2 |
| 偏移范围 (Off-by-One) | 0 | 2 | 0 | 2 |
| 跨表链接 (Broken Links) | 0 | 2 | 0 | 2 |
| 单位不一致 (Scale Mismatch) | 1 | 1 | 0 | 2 |
| 隐藏行/表 (Hidden Rows/Tabs) | 0 | 1 | 1 | 2 |
| 结构性 (Structural) | 0 | 2 | 3 | 5 |
| 资产负债表 (BS) | 2 | 1 | 0 | 3 |
| 现金流量表 (CF) | 2 | 3 | 0 | 5 |
| 利润表 (IS) | 0 | 2 | 1 | 3 |
| 逻辑合理性 (Logic) | 0 | 3 | 1 | 4 |
| DCF 特定 (DCF-Specific) | 1 | 3 | 1 | 5 |
| 可比公司 (Comps) | 0 | 2 | 1 | 3 |

### 优先修复顺序 (Priority Fix Order)

根据审计框架和 PwC Global Financial Modeling Guidelines 的建议，修复优先级如下：

**第一优先级（必须立即修复）：**
1. **B-01 / C-01:** 资产负债表平衡 + 现金一致性 — 修复 Deferred Revenue 符号方向
2. **F-14:** 无意循环引用 — 添加 iteration toggle 或断路器
3. **F-13:** 粘贴覆盖公式 — 恢复 PP&E Rollforward 链接
4. **C-02:** CF 三段式汇总不等于 ΔCash — 修复债务偿还符号
5. **D-02:** 终值未折现 — 这是 DCF 估值的根本性错误

**第二优先级（提交前必须修复）：**
6. **F-01, F-02:** `#REF!` 和 `#DIV/0!` 公式错误
7. **F-18:** 单位刻度不一致（$K vs $M）
8. **F-20:** 隐藏行中的调节项
9. **F-05, F-06, F-07:** 硬编码假设值集中化
10. **B-02:** 留存收益滚动错误

**第三优先级（建议改进）：**
11. 所有 Warning 级别的硬编码和不一致公式
12. 结构性改进（颜色编码、Tab 排列、日期格式统一）
13. DCF 方法论优化（年中折现、WACC 权重）
14. 可比公司筛选和数据来源标注

---

## 审计方法论参考 (Audit Methodology References)

本次审计遵循以下行业框架和方法论：

### 1. PwC Global Financial Modeling Guidelines
- **来源:** PwC Australia, "Global Financial Modeling Guidelines" Booklet
- **核心要求:** 所有假设集中管理、颜色编码一致、跨表链接可追踪、禁止硬编码值嵌入公式
- **参考:** [PwC Global Financial Modeling Guidelines](https://www.pwc.com.au/deals/assets/pwc-global-financial-modeling-guidelines-booklet-live.pdf)

### 2. Deloitte Spreadsheet Controls Framework
- **来源:** Deloitte UK, "Spreadsheet Controls — Are Your Spreadsheets Exposing Your Organisation to Unmitigated Risks" (2023)
- **三支柱框架:** 标准化 (Standardisation) — 集中化 (Centralisation) — 自动化 (Automation)
- **参考:** [Deloitte Spreadsheet Controls](https://www.deloitte.com/uk/en/services/consulting-risk/blogs/2023/spreadsheet-controls-are-your-spreadsheets-exposing-your-organisation-to-unmitigated-risks.html)

### 3. FAST Standard
- **来源:** FAST Standard Organisation (fast-standard.org)
- **核心原则:** Flexible（灵活）、Appropriate（适当）、Structured（结构化）、Transparent（透明）
- **参考:** [FAST Standard](https://fast-standard.org/)

### 4. EY Model Risk Management Alignment
- **来源:** EY Model Risk Management practice, aligned with SR 11-7 (OCC/FRB Supervisory Guidance)
- **核心要求:** 模型目录化、风险分级、独立验证、持续监控
- **参考:** [EY Model Risk Management](https://www.ey.com/en_gl/assurance/model-risk-management)

### 5. FMI Advanced Financial Modeler (AFM) Skills Checklist
- **来源:** Financial Modeling Institute
- **核心检查项:** 循环引用定位与管理、公式错误检查、模型完整性验证
- **参考:** [FMI AFM Skills Checklist](https://fminstitute.com/wp-content/uploads/2018/04/AFM-Skills-Checklist-2018-04-05.pdf)

---

## B2B SaaS 行业基准参考 (Industry Benchmarks)

以下基准数据用于逻辑合理性检查，来源为 2025 年行业公开数据：

| KPI | 本次模型假设 | 行业中位数 | 行业顶尖四分位 | 判定 |
|---|---|---|---|---|
| ARR 增长率 | 45% → 65% (加速) | ~26% | ~45-50% | 偏高，需验证 |
| 年流失率 (Churn) | 3.5% | ~3.8-4.9% | < 2% | 合理 |
| LTV:CAC 比率 | 5.2:1 | 3:1 最低 | 4:1-7:1 优秀 | 合理 |
| CAC 回收期 | 8 个月 | 6-9 个月 | < 6 个月 | 合理 |
| EBITDA Margin (成熟期) | 25% | 15-25% | > 30% | 合理但偏上限 |
| 终值占 EV 比例 | 82% | < 75% 为佳 | < 65% | 偏高，需关注 |

**数据来源:** Benchmarkit 2025 SaaS Performance Metrics, Eagle Rock CFO SaaS Finance Metrics Benchmarks, SaaS Hero LTV:CAC Benchmarks, Vena Solutions SaaS Churn Rate 2025, Orb B2B SaaS Benchmarks 2025

---

## 重要声明 (Important Notes)

1. **本次审计仅报告发现的问题，未对模型做任何修改** — 所有修复需经模型所有者确认后执行
2. **资产负债表平衡问题（B-01）是最高优先级** — 在此问题修复前，所有下游计算（CF、DCF）的结果均不可信赖
3. **硬编码覆盖是静默错误的首要来源** — 建议对模型进行全面的 "硬编码扫描"，确保所有输入值均位于 Assumptions 工作表中
4. **符号约定错误（正/负号代表现金流入/流出）极为常见** — 建议在 Assumptions 中明确标注符号约定规则
5. **如果模型使用 VBA 宏**，宏驱动的计算无法通过公式审计验证，需要单独的代码审查

---

## Sources

- [PwC Australia — Global Financial Modeling Guidelines (PDF)](https://www.pwc.com.au/deals/assets/pwc-global-financial-modeling-guidelines-booklet-live.pdf)
- [PwC Acuity Magazine — Top 10 Tips for Financial Modelling](https://www.acuitymag.com/finance/what-are-pwcs-top-10-tips-for-financial-modelling)
- [Deloitte UK — Spreadsheet Controls: Are Your Spreadsheets Exposing Your Organisation to Unmitigated Risks?](https://www.deloitte.com/uk/en/services/consulting-risk/blogs/2023/spreadsheet-controls-are-your-spreadsheets-exposing-your-organisation-to-unmitigated-risks.html)
- [FAST Standard Organisation — The FAST Modelling Standard](https://fast-standard.org/)
- [Gridlines — What is FAST Financial Modelling?](https://gridlines.com/blog/fast-financial-modelling/)
- [Financial Modeling Institute (FMI) — AFM Skills Checklist (PDF)](https://fminstitute.com/wp-content/uploads/2018/04/AFM-Skills-Checklist-2018-04-05.pdf)
- [Corporate Finance Institute — 10 Common Causes of Imbalance in 3-Statement Models](https://corporatefinanceinstitute.com/resources/financial-modeling/common-causes-imbalanced-3-statement-models/)
- [Wall Street Prep — Financial Modeling Techniques](https://www.wallstreetprep.com/knowledge/financial-modeling-techniques/)
- [Wall Street Oasis — Modeling with Circular References](https://www.wallstreetoasis.com/forum/investment-banking/modeling-with-circular-references)
- [Breaking Into Wall Street — Financial Modeling Best Practices](https://breakingintowallstreet.com/kb/finance/financial-modeling-best-practices/)
- [FAB Analytics — Financial Model Review Best Practices](https://www.fabanalytics.com/financial-model-review-best-practices/)
- [FIN Team Consult — Handling Circularity in Financial Modeling (2024)](https://finteamconsult.com/2024/09/01/handling-circularity-in-financial-modeling-techniques-for-accurate-and-robust-models-%F0%9F%94%84%F0%9F%93%8A/)
- [Benchmarkit — 2025 SaaS Performance Metrics](https://www.benchmarkit.ai/2025benchmarks)
- [Eagle Rock CFO — SaaS Finance Metrics Benchmarks](https://www.eaglerockcfo.com/blog/research/saas-finance-metrics-benchmarks)
- [Vena Solutions — 2025 SaaS Churn Rate: Benchmarks and Calculator](https://www.venasolutions.com/blog/saas-churn-rate)
- [SaaS Hero — Best LTV to CAC Ratio Benchmarks for B2B SaaS](https://www.saashero.net/strategy/b2b-saas-ltv-cac-benchmarks/)
- [Orb — B2B SaaS Benchmarks in 2025](https://www.withorb.com/blog/b2b-saas-benchmarks)
- [T2D3 — The Great Recalibration: B2B SaaS Performance in 2025](https://www.t2d3.pro/learn/the-great-recalibration-b2b-saemperformance-metrics-and-the-hybrid-mandate-in-2025)
- [SaaS Capital — What Should a SaaS Balance Sheet Look Like?](https://www.saas-capital.com/blog-posts/what-should-a-saa-balance-sheet-look-like/)
- [Kruze Consulting — The Best Financial Model Template for B2B SaaS Startups](https://kruzeconsulting.com/financial-model-saas/)
- [Base Templates — How to Build a SaaS Financial Model in 7 Steps](https://www.basetemplates.com/blog/build-a-saas-financial-model)
- [Baremetrics — The SaaS Financial Model You'll Actually Use](https://baremetrics.com/blog/saas-financial-model)
- [Finzer — 8 Financial Modeling Best Practices for 2025](https://finzer.io/en/blog/financial-modeling-best-practices)
- [Data-Mania — CAC Benchmarks for B2B Tech Startups 2026](https://www.data-mania.com/blog/cac-benchmarks-for-b2b-tech-startups-2025/)
- [City of Ottawa — Financial Model Review Worksheet (PDF)](https://documents.ottawa.ca/sites/documents/files/Financial%20Model%20Review%20Worksheet.pdf)
