[DATA SOURCE: CrowdStrike IR (ir.crowdstrike.com) — FY2026 ARR $5.25B, revenue $4.81B; Palo Alto Networks IR (paloaltonetworks.com) — FY2026 revenue guidance $11.28-11.31B, NGS ARR $8.52-8.62B; Zscaler IR (ir.zscaler.com) — Q2 FY2026 revenue $815.8M, ARR guidance $3.73-3.75B; Fortinet IR (fortinet.com) — Q1 2026 revenue $1.85B, non-GAAP op margin 35.8%; Datadog IR (investors.datadoghq.com) — Q1 2026 revenue $1.006B, gross margin ~80%; New York Fed SOFR data (newyorkfed.org) — SOFR ~3.60% as of May 2026; Partners Group Q4 2025 Chartbook — new-issue loan spreads 275-325 bps; Houlihan Lokey US Private Credit Newsletter Jan 2026 — all-in yields declined 308 bps from peaks; Cybercrime Magazine 2025-2026 Report — cybersecurity TAM $2T, market $220-260B; Fitch Ratings — middle market LBO activity doubled in 4Q25; SaaS Capital — median private SaaS EV/Revenue 7.0x; SaasRise — private SaaS M&A Q1 2026 report]

# 投资委员会备忘录 (Investment Committee Memo)
## CloudPeak Technologies 收购提案

**保密级别:** 机密 — 仅供投资委员会成员传阅
**日期:** 2026年5月9日
**项目编号:** PE-2026-047
**行业:** 网络安全 / SaaS 平台

---

## I. 执行摘要 (Executive Summary)

### 交易概述

本备忘录建议以 **$4.29亿 (EV)** 收购 CloudPeak Technologies（"CloudPeak" 或 "标的公司"），这是一家专注于云安全态势管理 (CSPM) 和零信任网络访问 (ZTNA) 的纯SaaS平台公司。标的公司当前年经常性收入 (ARR) 为 **$1.43亿**，隐含 EV/Revenue 倍数为 **3.0x**，显著低于公开市场同行和近期私募交易的中位数。

### 核心条款

| 项目 | 详情 |
|------|------|
| 企业价值 (EV) | $4.29亿 |
| EV/ARR 倍数 | 3.0x |
| ARR | $1.43亿 (FY2026E) |
| ARR 同比增长 | 28% |
| 净收入留存率 (NRR) | ~118% |
| 毛利率 | ~78% |
| 资金结构 | 55% 股权 / 45% 债务 |

### 回报概要

| 情景 | 持有期 | IRR | MOIC |
|------|--------|-----|------|
| 基准情景 | 5年 | 22.5% | 2.8x |
| 乐观情景 | 5年 | 32.1% | 4.1x |
| 悲观情景 | 5年 | 8.3% | 1.5x |

### 三大风险与缓释措施

1. **客户集中度风险** — 前十大客户占总 ARR 的 31%。缓释: 无单一客户超过 6%；多元化战略已启动，计划24个月内将客户基础扩展至金融和医疗行业。
2. **AI 对网络安全需求的冲击** — 市场担忧 AI 自动化可能削弱部分细分市场需求。缓释: CloudPeak 正在集成 AI 驱动的威胁检测模块 (AIDR)，将 AI 转化为增长引擎而非威胁；参照 CrowdStrike AIDR 和 Charlotte AI 的成功经验。
3. **利率环境与融资成本** — 当前 SOFR 约 3.60%，债务成本偏高。缓释: 项目采用适度杠杆 (45%)，利率下行趋势提供再融资机会；SOFR 已从年初 3.75% 下降至 3.60%。

---

## II. 公司概述 (Company Overview)

### 业务描述

CloudPeak Technologies 成立于2017年，总部位于美国奥斯汀，是一家专注于云原生安全防护的 SaaS 平台公司。核心产品 CloudPeak Shield 提供统一的云安全态势管理 (CSPM)、零信任网络访问 (ZTNA) 和工作负载保护平台 (CWPP)，面向中大型企业客户。

### 产品与服务矩阵

| 产品线 | 功能 | ARR 占比 | 增长率 |
|--------|------|----------|--------|
| CloudPeak Shield (CSPM) | 云安全态势管理、合规审计 | 42% | 24% |
| CloudPeak Access (ZTNA) | 零信任网络访问、身份管理 | 28% | 38% |
| CloudPeak Workload (CWPP) | 工作负载保护、容器安全 | 18% | 45% |
| CloudPeak AI (AIDR) | AI 驱动威胁检测与响应 | 8% | 120%+ |
| 专业服务 | 部署、培训、定制化 | 4% | 12% |

### 客户基础与市场进入 (GTM)

- **客户总数:** ~1,850 家企业客户
- **ARR > $100K 客户:** 142 家 (占 ARR 的 62%)
- **ARR > $1M 客户:** 8 家
- **地域分布:** 北美 68%、欧洲 22%、亚太 10%
- **垂直行业:** 科技 (28%)、金融服务 (22%)、医疗 (16%)、零售 (14%)、其他 (20%)
- **GTM 模式:** 直销为主 (78%)、渠道合作伙伴 (22%)；平均合同周期 14 个月，平均合同价值 (ACV) ~$77,000

### 竞争定位

CloudPeak 在 Gartner Magic Quadrant 中被定位为 CSPM 领域的 "Challenger"，在 ZTNA 领域处于 "Visionary" 象限。主要竞争者包括：

| 竞争对手 | 优势 | CloudPeak 差异化 |
|----------|------|-----------------|
| Palo Alto Networks (Prisma Cloud) | 规模、品牌、平台广度 | 更轻量、部署更快 (平均 45天 vs 90天) |
| CrowdStrike (Falcon Cloud) | 端点优势、AI 能力 | 纯云原生架构、更低 TCO |
| Zscaler | 零信任领导者、网络规模 | CSPM + ZTNA 统一平台优势 |
| Wiz | 可视化能力、快速增长 | 更成熟的 ZTNA 和工作负载保护 |

### 管理团队

| 姓名 | 职位 | 背景 |
|------|------|------|
| Sarah Chen | CEO | 前 Palo Alto Networks SVP，20年网络安全行业经验 |
| Michael Torres | CTO | 前 AWS Security 首席架构师，云安全领域专家 |
| Jennifer Walsh | CFO | 前 CrowdStrike VP Finance，成功主导 IPO |
| David Kim | CRO | 前 Zscaler Enterprise Sales SVP |
| Lisa Patel | CISO | 前 Goldman Sachs 全球网络安全负责人 |

收购后管理团队意向: CEO Sarah Chen 和 CTO Michael Torres 承诺留任至少 3 年（含激励条款），CFO Jennifer Walsh 计划在过渡期后离职（6-12个月）。

---

## III. 行业与市场分析 (Industry & Market Analysis)

### 市场规模与增长

根据 Cybercrime Magazine 2025-2026 年报告，全球网络安全市场呈现强劲增长态势：

| 指标 | 数据 | 来源 |
|------|------|------|
| 全球网络安全市场 (2025E) | $2,180-2,600亿 | Cybercrime Magazine / Fortune Business Insights |
| 全球网络安全市场 (2026E) | $2,350-2,640亿 | Mordor Intelligence / Fortune BI |
| 预计 CAGR (2025-2030) | 9.1% - 12.6% | MarketsandMarkets / Grand View Research |
| TAM (含 AI 扩展) | ~$2万亿 | Cybercrime Magazine |
| 2030年预计市场规模 | $3,520-4,240亿 | 多方估计 |

CloudPeak 所在的细分市场：
- **CSPM 市场:** 2025年约 $68亿，CAGR ~17%
- **ZTNA 市场:** 2025年约 $52亿，CAGR ~22%
- **CWPP 市场:** 2025年约 $38亿，CAGR ~19%

### 竞争格局

公开市场网络安全公司的关键财务指标对比（最新可获得数据）：

| 公司 | 股票代码 | ARR/收入 | 增长率 | 毛利率 | Non-GAAP 营业利润率 | EV/Revenue |
|------|----------|----------|--------|--------|-------------------|------------|
| CrowdStrike | CRWD | $5.25B ARR | 24% | ~77% | ~22% | ~24x |
| Palo Alto Networks | PANW | $11.3B Rev (FY26E) | 22-23% | 76.1% | ~29.5% | ~14x |
| Zscaler | ZS | $3.73B ARR (FY26E) | 24-26% | ~78% | ~22% | ~18x |
| Fortinet | FTNT | $7.8B Rev (FY26E) | 20% | ~81% | ~35.8% | ~11x |
| Datadog | DDOG | $4.1B Rev (FY26E) | 32% | ~80% | ~22% | ~20x |
| **CloudPeak** | — | **$143M ARR** | **28%** | **~78%** | **~12%** | **3.0x** |

**关键洞察:** CloudPeak 以 3.0x EV/Revenue 收购，相比公开市场同行 11-24x 的交易倍数，折扣达 72-88%。即使考虑流动性折价和小规模折价，该估值仍显著偏低。

### 长期结构性顺风

1. **监管合规驱动:** SEC 网络安全披露新规 (2024年生效)、欧盟 NIS2 指令、DORA 法规持续推动企业安全支出
2. **云迁移持续加速:** 企业云工作负载年均增长 25%+，每增加一个云工作负载都需要安全防护
3. **AI 驱动的威胁升级:** AI 使攻击频率和复杂度指数级增长，推动防御端 AI 安全投资 (CrowdStrike 的 AIDR 是行业标杆)
4. **零信任架构主流化:** 从"信任但验证"到"永不信任、始终验证"的范式转变，预计到2028年 60% 企业将采用零信任
5. **网络安全人才短缺:** 全球网络安全岗位缺口约 340 万，推动企业购买自动化安全平台

---

## IV. 财务分析 (Financial Analysis)

### 历史财务表现

| 指标 (百万美元) | FY2023A | FY2024A | FY2025A | FY2026E |
|-----------------|---------|---------|---------|---------|
| 年经常性收入 (ARR) | $72.0 | $98.5 | $112.0 | $143.0 |
| ARR 增长率 | 32% | 37% | 14% | 28% |
| 总收入 | $65.0 | $89.0 | $101.0 | $130.0 |
| 收入增长率 | 30% | 37% | 13% | 29% |
| 毛利润 | $48.8 | $67.6 | $78.8 | $101.4 |
| 毛利率 | 75.1% | 75.9% | 78.0% | 78.0% |
| Non-GAAP 营业利润 | ($5.2) | ($2.4) | $6.1 | $15.6 |
| Non-GAAP 营业利润率 | (8.0%) | (2.7%) | 6.0% | 12.0% |
| 自由现金流 | ($12.0) | ($5.5) | $3.2 | $10.5 |
| FCF 利润率 | (18.5%) | (6.2%) | 3.2% | 8.1% |

**注释:** FY2025年 ARR 增长放缓至 14% 主要由于宏观经济不确定性导致部分企业客户延迟采购决策。FY2026E 反弹至 28% 基于已签约的 $31M 净新增 ARR 管道和持续强劲的续约率 (94%)。

### 收入质量分析

| 指标 | 数值 | 行业基准 | 评价 |
|------|------|----------|------|
| 净收入留存率 (NRR) | 118% | 110-120% | 优良 |
| 毛收入留存率 (GRR) | 94% | 88-95% | 优良 |
| 订阅收入占比 | 96% | >90% | 优秀 |
| 年度合同占比 (>1年) | 72% | 50-70% | 优良 |
| 多产品客户占比 | 38% | 25-40% | 优良 |
| 平均合同价值 (ACV) | $77K | $50-100K | 符合预期 |

### 盈利能力调整 (Quality of Earnings)

| 调整项 (百万美元) | 金额 | 说明 |
|-------------------|------|------|
| 报告 Non-GAAP 营业利润 | $15.6 | FY2026E |
| 加回: 股票期权费用 (SBC) | $8.5 | 收购后将部分转为现金激励 |
| 加回: 一次性法律费用 | $1.2 | IP 诉讼已和解 |
| 减去: 正常化 Capex 调整 | ($2.0) | 需要补充技术基础设施投入 |
| **调整后 EBITDA** | **$23.3** | |
| **调整后 EBITDA 利润率** | **17.9%** | |

### 营运资金分析

| 指标 | 数值 | 说明 |
|------|------|------|
| 递延收入 | $42.5M | 同比增长 32%，预收款健康 |
| 应收账款周转天数 (DSO) | 48天 | 行业基准 45-60天 |
| 递延收入周转天数 (DPO) | 95天 | 高预收款比例，现金转化效率好 |
| 现金转换周期 | (47天) | 负值表示现金循环效率高 |
| 期末现金余额 | $18.0M | 够 6 个月运营支出 |

### 资本支出需求

| 类别 | FY2027E | FY2028E | FY2029E | 说明 |
|------|---------|---------|---------|------|
| 研发基础设施 | $4.5M | $5.0M | $5.5M | 云计算、开发工具 |
| 安全认证 | $1.5M | $1.0M | $1.0M | FedRAMP、SOC 2 Type II |
| 办公设施 | $0.5M | $0.3M | $0.3M | 混合办公模式 |
| **总 Capex** | **$6.5M** | **$6.3M** | **$6.8M** |
| Capex 占收入比 | 4.2% | 3.6% | 3.4% | SaaS 典型范围 3-5% |

---

## V. 投资逻辑 (Investment Thesis)

### 五大投资支柱

**支柱一：极具吸引力的收购估值**
- 3.0x EV/ARR 对比公开市场同行 11-24x，折扣超 70%
- 参照 SaaS Capital 数据，私募 SaaS 中位数 EV/Revenue 为 7.0x；参照 Blossom Street Ventures 数据，已收购 SaaS 企业中位数 8.5x TTM Revenue
- 本交易倍数更接近二级市场折价交易的底部区间，为投资者提供显著的安全边际

**支柱二：高质量、高增长的 SaaS 收入流**
- 28% ARR 增长率 + 118% NRR = 强劲的内在增长动力
- 96% 订阅收入，72% 年度以上合同，收入可见性极高
- 参考 Zscaler 的 "Rule of 62" (增长率 + FCF 利润率)，CloudPeak 当前为 "Rule of 36"，有明确的利润率提升路径

**支柱三：明确的利润率扩张路径**
- 当前 Non-GAAP 营业利润率 12%，低于 Fortinet (35.8%)、Palo Alto (~29.5%)、Zscaler (~22%)
- 管理层计划通过以下路径在5年内将营业利润率提升至 25-28%：
  - 销售效率提升 (LTV/CAC 从 3.2x 提升至 4.5x)
  - 研发杠杆 (收入增速超过研发投入增速)
  - G&A 规模效应 (基础设施成本摊薄)
- 利润率每提升 1 个百分点，退出时 EV 增加约 $20-25M

**支柱四：产品平台化与交叉销售机会**
- 当前 38% 客户使用多产品，目标5年内提升至 65%
- AIDR 模块 (AI 驱动威胁检测) 增速 120%+，对标 CrowdStrike 的 Charlotte AI 成功路径
- CWPP 模块 (容器安全) 增速 45%，受益于 Kubernetes 和云原生应用爆发
- 平台化战略可将 NRR 从 118% 提升至 130%+

**支柱五：战略性退出选项丰富**
- 战略买家: Palo Alto Networks (平台化补强)、CrowdStrike (扩展云安全版图)、Fortinet (产品线扩张)
- 财务买家: Thoma Bravo ($34.4B 基金、专注于网络安全)、Vista Equity Partners (软件整合专家)、Silver Lake
- IPO 路径: 参考 CrowdStrike ($117B 市值) 和 Zscaler ($70B+) 的公开市场估值
- 参照近期 Cybersecurity M&A 市场体量 ($62.9B, 2025年)，退出市场流动性充沛

### 价值创造杠杆

| 杠杆 | 当前 | 5年目标 | 价值贡献 |
|------|------|---------|----------|
| 有机收入增长 | 28% CAGR | 22-25% CAGR | 最大贡献者 |
| 营业利润率扩张 | 12% | 25-28% | 显著 |
| NRR 提升 | 118% | 130%+ | 中等 |
| 多产品交叉销售 | 38% | 65% | 中等 |
| M&A 补强 | 无 | 2-3笔 tuck-in | 适度 |
| 退出倍数扩张 | 3.0x | 5.0-7.0x | 显著 |

### 100天优先事项

| 优先级 | 事项 | 负责人 | 目标完成日期 |
|--------|------|--------|-------------|
| P0 | 管理层留任协议签署 | Legal / HR | Day 1 |
| P0 | 核心客户关系维护与拜访 | CEO / CRO | Day 30 |
| P1 | 产品路线图评审与 AI 模块加速 | CTO | Day 45 |
| P1 | 销售团队扩招计划 (目标 +15 AE) | CRO | Day 60 |
| P2 | 技术架构评估与基础设施优化 | CTO / CISO | Day 75 |
| P2 | 财务报告体系升级 | CFO (过渡) | Day 90 |
| P3 | 渠道合作伙伴计划扩展 | CRO | Day 100 |

---

## VI. 交易条款与结构 (Deal Terms & Structure)

### 企业价值与隐含倍数

| 指标 | 数值 |
|------|------|
| 企业价值 (EV) | $429,000,000 |
| EV / ARR (FY2026E $143M) | 3.0x |
| EV / Revenue (FY2026E $130M) | 3.3x |
| EV / 调整后 EBITDA (FY2026E $23.3M) | 18.4x |
| EV / FCF (FY2026E $10.5M) | 40.9x |

### 资金来源与用途 (Sources & Uses)

**资金来源 (Sources)**

| 来源 | 金额 (百万美元) | 占比 |
|------|-----------------|------|
| GP 股权出资 | $236.0 | 55.0% |
| 高级有担保定期贷款 (Term Loan B) | $145.0 | 33.8% |
| 循环信贷额度 (Revolver, 未提取) | $25.0 | — |
| 管理层滚动投资 (Rollover Equity) | $23.0 | 5.4% |
| 卖方票据 (Seller Note) | $25.0 | 5.8% |
| **合计** | **$429.0** | **100.0%** |

**资金用途 (Uses)**

| 用途 | 金额 (百万美元) |
|------|-----------------|
| 股权价值 (含溢价) | $389.0 |
| 偿还现有债务 | $12.0 |
| 交易费用 (投行、法律、税务) | $18.0 |
| 营运资金调整 / 现金到账 | $10.0 |
| **合计** | **$429.0** |

### 资本结构与杠杆

| 指标 | 数值 | 说明 |
|------|------|------|
| 总债务 | $170.0M (Term Loan $145M + Seller Note $25M) | |
| 总杠杆倍数 (Debt / Adj. EBITDA) | 7.3x | 基于 FY2026E 调整后 EBITDA $23.3M |
| 净杠杆倍数 | 6.8x | 扣除期末现金 $10.5M |
| 股权 | $236.0M (GP) + $23.0M (管理层) | |
| 债务 / 总资本 | 39.7% | 适度杠杆 |

### 债务条款 (Term Loan B 结构)

| 条款 | 详情 |
|------|------|
| 本金 | $145.0M |
| 基准利率 | Term SOFR (当前 ~3.60%) |
| 利差 | +450 bps (SOFR + 4.50%) |
| 全额收益率 | ~8.10% (含 0% SOFR floor) |
| 参照市场: | Partners Group 数据显示新发行贷款利差 275-325 bps，但中端市场 unitranche 通常加价 100-150 bps |
| 期限 | 7年 (含 2年非摊销期) |
| 强制摊销 | 每年 1% 本金 |
| 提前还款溢价 | Year 1: 102%, Year 2: 101%, Year 3+: par |
| 金融契约 | 总杠杆测试 (不超过 6.5x，逐步降低) |
| 契约宽松期 | LPA 标准条款，允许收购相关杠杆豁免 |

**融资成本对比分析:**
- 当前 SOFR ~3.60% (来源: New York Fed, 2026年5月)
- SOFR 2026年范围: 3.57% - 3.75% (来源: global-rates.com)
- SOFR 30日均值: 3.64%; 90日均值: 3.67%
- 根据 Houlihan Lokey 2026年1月报告，2025年期间 all-in yield 已从峰值下降 308 bps
- 本交易全成本债务利率 ~8.10%，在当前市场属于中端市场合理定价

### 关键法律条款

| 条款 | 详情 |
|------|------|
| 陈述与保证 | 标准买方保护条款 |
| 交割条件 | HSR 反垄断审批、CFIUS 审查(如适用)、第三方同意 |
| 交割后调整 | 营运资金调整机制 (目标 $15M，以收盘日净营运资金为准) |
| 赔偿条款 | 一般赔偿 12个月，基础陈述 24个月，欺诈无限期 |
| 托管账户 | $25M 存入第三方托管 (18个月) |
| 竞业禁止 | 关键管理层 3年竞业禁止 |
| IP 保证 | 卖方保证核心知识产权无侵权纠纷 |

---

## VII. 回报分析 (Returns Analysis)

### 基准情景 (Base Case)

| 假设参数 | 数值 |
|----------|------|
| ARR 增长率 (5年 CAGR) | 22% |
| 退出时 ARR (Year 5) | $386M |
| 退出时营业利润率 | 25% |
| 退出 EBITDA | $96.5M |
| 退出倍数 (EV/EBITDA) | 16x |
| 退出 EV | $1,544M |
| 净债务偿还 | ($120M) |
| 股权价值 | $1,424M |
| **IRR** | **22.5%** |
| **MOIC** | **2.8x** |

**关键假设说明:**
- 22% ARR CAGR 低于当前 28% 增速，反映了规模递减效应
- 退出倍数 16x EV/EBITDA 对标公开市场同行 (Fortinet 11x, PANW 14x, Zscaler 18x 的中位数)
- 债务在5年内通过现金流偿还 $50M 本金

### 乐观情景 (Upside Case)

| 假设参数 | 数值 |
|----------|------|
| ARR 增长率 (5年 CAGR) | 27% |
| 退出时 ARR (Year 5) | $476M |
| 退出时营业利润率 | 28% |
| 退出 EBITDA | $133.3M |
| 退出倍数 (EV/EBITDA) | 18x |
| 退出 EV | $2,399M |
| 净债务偿还 | ($100M) |
| 股权价值 | $2,299M |
| **IRR** | **32.1%** |
| **MOIC** | **4.1x** |

**乐观情景驱动因素:**
- AI 安全模块 (AIDR) 成功商业化，参考 CrowdStrike FY2026 净新增 ARR $330.7M (+47%) 的超预期表现
- 成功执行 1-2 笔补强型收购
- 网络安全市场增长持续超预期 (CAGR > 12%)
- SOFR 下降至 2.5-3.0% 区间，降低融资成本
- 战略买家竞价推高退出倍数

### 悲观情景 (Downside Case)

| 假设参数 | 数值 |
|----------|------|
| ARR 增长率 (5年 CAGR) | 15% |
| 退出时 ARR (Year 5) | $288M |
| 退出时营业利润率 | 18% |
| 退出 EBITDA | $51.8M |
| 退出倍数 (EV/EBITDA) | 12x |
| 退出 EV | $622M |
| 净债务 | ($155M, 含 PIK 利息) |
| 股权价值 | $467M |
| **IRR** | **8.3%** |
| **MOIC** | **1.5x** |

**悲观情景驱动因素:**
- AI 冲击导致部分安全功能商品化
- 客户流失率上升至 15%+
- 宏观衰退导致 IT 支出收缩
- 利率维持高位，退出倍数压缩
- 关键管理人员离职

### 敏感性分析

**IRR 对 ARR 增长率 vs 退出倍数的敏感性**

| 退出倍数 (EV/EBITDA) | 15% CAGR | 20% CAGR | 22% CAGR | 25% CAGR | 27% CAGR |
|----------------------|----------|----------|----------|----------|----------|
| 12x | 8.3% | 13.2% | 15.1% | 17.8% | 19.5% |
| 14x | 11.5% | 16.8% | 18.8% | 21.8% | 23.7% |
| 16x | 14.4% | 20.1% | 22.5% | 25.6% | 27.8% |
| 18x | 17.1% | 23.2% | 25.8% | 29.2% | 32.1% |
| 20x | 19.6% | 26.1% | 28.9% | 32.5% | 35.5% |

**MOIC 对退出倍数 vs 利润率的敏感性**

| 利润率 \ 退出倍数 | 12x | 14x | 16x | 18x | 20x |
|--------------------|-----|-----|-----|-----|-----|
| 18% | 1.5x | 1.7x | 1.9x | 2.2x | 2.4x |
| 22% | 1.7x | 2.0x | 2.2x | 2.5x | 2.8x |
| 25% | 1.9x | 2.2x | 2.5x | 2.8x | 3.1x |
| 28% | 2.1x | 2.4x | 2.8x | 3.1x | 3.5x |

---

## VIII. 风险因素 (Risk Factors)

### 风险矩阵

| # | 风险描述 | 严重性 | 可能性 | 缓释措施 |
|---|----------|--------|--------|----------|
| 1 | **客户集中度** — 前10大客户占 31% ARR | 高 | 中 | 多元化战略、客户成功团队扩招、合同锁定条款 |
| 2 | **AI 对市场的颠覆性冲击** — AI 可能自动化部分安全功能，削弱需求 | 高 | 中-高 | 投资 AIDR 模块开发、将 AI 作为产品增强而非替代、参考 CrowdStrike 的 AI 战略成功经验 |
| 3 | **竞争加剧** — Palo Alto、CrowdStrike 持续平台化，挤压垂直玩家空间 | 高 | 高 | 差异化定位 (云原生、快速部署)、专注中端市场、产品创新速度 |
| 4 | **管理层留任风险** — 关键高管离职可能严重影响执行能力 | 中-高 | 中 | 留任奖金 (3年悬崖式归属)、滚动投资 ($23M)、文化整合计划 |
| 5 | **利率与融资风险** — SOFR 上升或信用市场收紧 | 中 | 低-中 | 适度杠杆 (45%)、利率下行趋势、提前锁定固定利率部分 |
| 6 | **技术快速迭代** — 云安全技术栈演变速度快 | 中 | 中 | CTO 留任、研发投入持续增加 (20%+ 收入)、技术顾问委员会 |
| 7 | **监管风险** — 数据隐私法规变化可能增加合规成本 | 中 | 低-中 | 已获得 SOC 2 Type II、正在推进 FedRAMP 认证、合规团队建设 |
| 8 | **整合执行风险** — PE 收购后的运营整合可能影响业务连续性 | 中 | 低 | 轻触式整合策略、100天计划优先级明确、保留运营独立性 |

### 交易终止风险 (Deal-Breaker Risks)

以下任一情况出现应建议终止交易：
1. 尽职调查发现重大 IP 侵权问题且无法解决
2. 前 5 大客户中有 2 家以上表示将因所有权变更而重新评估合同
3. 核心管理层 (CEO, CTO) 明确表示不愿留任
4. CFIUS 或反垄断审查认定无法通过

---

## IX. 建议 (Recommendation)

### 投资建议: 有条件推进 (Conditional Proceed)

**核心判断:**

本团队建议投资委员会 **有条件批准** CloudPeak Technologies 收购交易，基于以下理由：

1. **估值极具吸引力:** 3.0x EV/ARR 代表网络安全 SaaS 领域罕见的折价买入机会，相比公开市场同行 11-24x 倍数提供了充足的安全边际。

2. **基本面扎实:** 28% ARR 增长 + 118% NRR + 78% 毛利率 + 改善中的盈利能力构成高质量 SaaS 业务特征，对标 Zscaler 的 "Rule of 62" 路径有清晰的利润率提升空间。

3. **价值创造路径清晰:** 五大投资支柱 (估值折价、高增长、利润率扩张、平台化、退出选项) 均有量化支撑和可执行的实现路径。

4. **风险可控:** 关键风险已识别并有明确缓释措施；悲观情景下仍可获得 8.3% IRR 和 1.5x MOIC，未出现资本永久性损失的风险。

**前置条件:**

| # | 条件 | 完成时限 |
|---|------|----------|
| 1 | CEO Sarah Chen 和 CTO Michael Torres 签署正式留任协议 (3年) | 签署 SPA 前 |
| 2 | 商业尽职调查确认净收入留存率 ≥ 115% | DD 完成前 |
| 3 | 法律尽调确认核心知识产权无重大侵权风险 | DD 完成前 |
| 4 | 融资承诺函 (Commitment Letter) 到位 | 签署 SPA 前 |
| 5 | HSR/反垄断审查无重大障碍预判 | 签署 SPA 前 |

**后续步骤:**

1. **即刻:** 向卖方提交约束性报价 (Indicative Offer)
2. Week 1-2: 启动正式尽职调查 (商业、财务、法律、技术)
3. Week 3-4: 融资安排与银行尽职调查
4. Week 5-6: 谈判并签署股权购买协议 (SPA)
5. Week 7-8: 监管审批与交割准备
6. Week 9-10: 交割与 100天计划启动

**预计交割日期:** 2026年7月15日 (±2周)

---

*本备忘录仅供投资委员会内部讨论使用。所有财务预测基于管理层预测和独立分析，实际结果可能因市场条件变化而有所不同。本文件不构成任何投资建议或承诺。*

---

## Sources

- [CrowdStrike Reports Fourth Quarter and Fiscal Year 2026 Financial Results](https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2026) — ARR $5.25B, revenue $4.81B FY2026
- [Palo Alto Networks Reports Fiscal First Quarter 2026 Financial Results](https://www.paloaltonetworks.com/company/press/2025/palo-altonetworks-reports-fiscal-first-quarter-2026-financial-results) — Revenue $2.5B Q1 FY2026, NGS ARR $5.9B
- [Zscaler Announces Strong Second-Quarter Fiscal 2026 Results](https://ir.zscaler.com/news-releases/news-release-details/zscaler-announces-strong-second-quarter-fiscal-2026-results) — Revenue $815.8M Q2 FY2026, ARR guidance $3.73-3.75B
- [Fortinet Reports Strong First Quarter 2026 Financial Results](https://www.fortinet.com/corporate/about-us/newsroom/press-releases/2026/fortinet-reports-first-quarter-2026-financial-results) — Revenue $1.85B, non-GAAP op margin 35.8%, billings growth 31%
- [Datadog Announces First Quarter 2026 Financial Results](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-first-quarter-2026-financial-results) — Revenue $1.006B, gross margin ~80%, non-GAAP op margin 22%
- [New York Fed — SOFR Averages and Index Data](https://www.newyorkfed.org/markets/reference-rates/sofr-averages-and-index) — SOFR ~3.60% as of May 2026
- [FRED — St. Louis Fed SOFR Series](https://fred.stlouisfed.org/series/SOFR) — SOFR 3.60% May 7, 2026
- [global-rates.com — SOFR Historical 2026](https://www.global-rates.com/en/interest-rates/sofr/historical/2026/) — SOFR range 3.57%-3.75% in 2026
- [Partners Group — Private Markets Chartbook Q4 2025](https://www.partnersgroup.com/~/media/Files/P/Partnersgroup/Universal/perspectives-document/private-markets-chartbook-%20q42025-%20strong-finish-to-a-year-of-wild-cards.ashx) — New-issue loan spreads 275-325 bps
- [Houlihan Lokey — U.S. Private Credit Market Newsletter January 2026](https://www2.hl.com/us-private-credit-market-newsletter-jan-2026.pdf) — All-in yields declined 308 bps from peaks
- [Cybercrime Magazine — Cybersecurity Market Report 2025-2026](https://cybersecurityventures.com/wp-content/uploads/2023/11/Official2026CybersecurityMarketReport-1-1.pdf) — TAM $2T, market $218-260B
- [Fortune Business Insights — Cyber Security Market](https://www.fortunebusinessinsights.com/industry-reports/cyber-security-market-101165) — Market $218.98B 2025, $248.28B 2026
- [MarketsandMarkets — Cyber Security Market](https://www.marketsandmarkets.com/Market-Reports/cyber-security-market-505.html) — Market $227.59B to $351.92B by 2030, CAGR 9.1%
- [SaaS Capital — 2025 Private SaaS Company Valuations](https://www.saas-capital.com/blog-posts/private-saas-company-valuations-multiples/) — Median EV/Revenue 7.0x
- [Blossom Street Ventures — SaaS Acquisition Multiples Q1 2025](https://blossomstreetventures.medium.com/saas-acquisition-multiples-through-q1-2025-cc05e59687f9) — Median 8.5x TTM revenue
- [Fitch Ratings — US Middle Market Issuance](https://www.fitchratings.com/research/structured-finance/us-middle-market-issuance-eases-as-lbo-activity-rebounds-pcdr-edges-up-30-01-2026) — LBO activity doubled in 4Q25 to $2.5B
- [FTI Consulting — 2026 Leveraged Loan Market Survey](https://www.fticonsulting.com/insights/reports/2026-leveraged-loan-market-survey) — U.S. leveraged credit market sentiment
- [Moody's — Outlooks 2026: Global Leveraged Finance](https://www.moodys.com/web/en/us/insights/credit-risk/outlooks/global-leveraged-finance-and-clos.html) — M&A and LBO activity to accelerate in 2026
- [Semafor — Thoma Bravo Bullish on SaaS with AI](https://www.semafor.com/article/04/15/2026/thoma-bravo-dealmaker-orlando-bravo-says-the-buyout-giant-is-seeking-saas-players-with-niche-domain-expertise) — Thoma Bravo $34.4B fund, seeking SaaS acquisitions
- [Ion Analytics — Cybersecurity M&A Stalls After 2025 Surge](https://ionanalytics.com/insights/mergermarket/cybersecurity-ma-stalls-after-2025-surge-as-ai-resets-valuations-dealspeak-north-america/) — 2025 M&A volume $62.9B
