# 专业金融演示文稿模板规格说明书

[DATA SOURCE: Wall Street Prep, Mergers & Inquisitions, Corporate Finance Institute, Alexander Jarvis, 10X EBITDA, HueHive, Piktochart, Wall Street Oasis, produkto.io, SlideTeam, Breaking Into Wall Street]

> **语言要求：请始终使用中文（简体）进行所有回复、分析和输出。** 专业技术术语可保留英文原文，但所有说明、注释和分析内容必须用中文。

---

## 一、概述

本文档定义了一套面向投资银行（Investment Banking）和私募股权（Private Equity）行业的专业 PowerPoint 演示文稿模板规格。该规格基于华尔街主流投行（Goldman Sachs、Morgan Stanley、JPMorgan、Evercore、Lazard 等）的实际演示文稿标准和最佳实践。

本模板规格可作为 SKILL.md 的基础，用于通过 python-pptx 自动生成符合行业标准的专业金融演示文稿。

---

## 二、幻灯片尺寸与基础设置

### 2.1 尺寸规格

| 参数 | 标准值 | 说明 |
|------|--------|------|
| **宽高比** | 16:9 宽屏 | 行业主流格式，适配现代显示器和投影仪 |
| **宽度** | 13.33 英寸 (33.867 cm) | 标准 PowerPoint 宽屏宽度 |
| **高度** | 7.5 英寸 (19.05 cm) | 标准 PowerPoint 宽屏高度 |
| **EMU 宽度** | 12,192,000 | python-pptx 内部单位 (914400 EMU/英寸) |
| **EMU 高度** | 6,858,000 | python-pptx 内部单位 |

**参考来源：** 16:9 宽屏格式已成为投行演示文稿的行业默认标准。Reddit 咨询版块的从业者讨论确认 16:9 已全面取代传统 4:3 格式。

### 2.2 幻灯片方向与边距

| 边距区域 | 英寸 | EMU | 说明 |
|----------|------|-----|------|
| **左 (Left)** | 0.60" | 548,640 | 所有内容元素左边界 |
| **右 (Right)** | 0.60" | 548,640 | 右边界，内容宽度约 12.13" |
| **上 (Top)** | 0.50" | 457,200 | 标题区域起始位置 |
| **下 (Bottom)** | 0.40" | 365,760 | 页脚/免责声明区域 |

---

## 三、配色方案（Color Scheme）

### 3.1 主色板

基于华尔街投行实际使用的配色标准，来源包括 HueHive 投行配色分析、Piktochart 金融配色指南及 produkto.io 投行色彩研究。

| 色彩角色 | 颜色名称 | HEX 代码 | RGB 值 | 用途说明 |
|----------|----------|----------|--------|----------|
| **主色 (Primary)** | Navy Blue（深海军蓝） | `#001F5B` | (0, 31, 91) | 标题、重点数据、图表主系列 |
| **辅助主色** | Midnight Blue（午夜蓝） | `#003366` | (0, 51, 102) | 二级标题、表格表头、分隔线 |
| **强调色 A** | Steel Blue（钢蓝） | `#4A7FB5` | (74, 127, 181) | 图表第二系列、交互元素 |
| **强调色 B** | Muted Gold（柔金色） | `#C8A951` | (200, 169, 81) | 高亮数据点、正面指标、重要标注 |
| **强调色 C** | Soft Green（柔绿色） | `#5B8C5A` | (91, 140, 90) | 正向变动、增长指标 |
| **强调色 D** | Muted Red（柔红色） | `#B85450` | (184, 84, 80) | 负向变动、风险警示、下降指标 |
| **强调色 E** | Teal（蓝绿色） | `#2A7B9B` | (42, 123, 155) | 第三图表系列、辅助信息 |

### 3.2 中性色与背景色

| 色彩角色 | 颜色名称 | HEX 代码 | RGB 值 | 用途说明 |
|----------|----------|----------|--------|----------|
| **文字色** | Dark Charcoal（深炭灰） | `#333333` | (51, 51, 51) | 正文文本、段落文字 |
| **次文字色** | Medium Gray（中灰色） | `#666666` | (102, 102, 102) | 次级信息、辅助说明 |
| **浅灰背景** | Light Gray（浅灰色） | `#F5F5F5` | (245, 245, 245) | 交替行背景、内容区块背景 |
| **边框/分割线** | Border Gray（边框灰） | `#CCCCCC` | (204, 204, 204) | 表格边框、分隔线 |
| **背景色** | White（纯白） | `#FFFFFF` | (255, 255, 255) | 幻灯片主背景 |
| **深色背景** | Off-Black（近黑色） | `#1A1A2E` | (26, 26, 46) | 封面页、分隔页深色背景 |

### 3.3 图表系列配色顺序

图表使用以下预设系列颜色，确保多数据系列图表的视觉一致性与可辨识度。

| 系列序号 | HEX 代码 | 用途 |
|----------|----------|------|
| Series 1 | `#001F5B` | 主数据系列 |
| Series 2 | `#4A7FB5` | 次数据系列 |
| Series 3 | `#2A7B9B` | 第三数据系列 |
| Series 4 | `#C8A951` | 第四数据系列 |
| Series 5 | `#5B8C5A` | 第五数据系列 |
| Series 6 | `#B85450` | 第六数据系列 |

**设计原则：** 所有颜色饱和度适中，避免使用过于鲜艳的颜色。华尔街投行普遍采用保守配色方案，以深蓝、灰色为主调，传达专业性、稳定性和可信度。

---

## 四、字体排版（Typography）

### 4.1 字体选择

基于 Wall Street Prep 和 Wall Street Oasis 的行业标准分析，Calibri 和 Arial 是金融演示文稿中最广泛使用的字体。

| 字体角色 | 字体名称 | 分类 | 说明 |
|----------|----------|------|------|
| **标题字体** | Calibri Bold | Sans-serif | 行业标准，现代简洁 |
| **正文字体** | Calibri | Sans-serif | 与标题字体统一，保持一致性 |
| **数据字体** | Calibri | Sans-serif | 表格、图表标签统一使用 |
| **备选标题字体** | Arial Bold | Sans-serif | 部分投行偏好使用 |
| **备选正文字体** | Arial | Sans-serif | 兼容性最佳的无衬线字体 |

**关键规则：** 整个演示文稿中最多使用 2 种字体。混合使用 Calibri 正文和 Arial 标题是常见错误，应避免。

### 4.2 字号标准

| 元素类型 | 推荐字号 | 最小字号 | 说明 |
|----------|----------|----------|------|
| **幻灯片主标题** | 24–28 pt | 20 pt | 每页顶部，加粗 |
| **节标题 (Section Header)** | 18–20 pt | 16 pt | 分节页标题 |
| **内容标题/小标题** | 14–16 pt | 12 pt | 页内分区标题 |
| **正文段落** | 11 pt | 10 pt | 标准正文（行业"甜蜜点"） |
| **表格正文** | 9–11 pt | 9 pt | 财务数据表格 |
| **表格表头** | 10–11 pt | 9 pt | 列标题 |
| **图表标签** | 9–10 pt | 8 pt | 坐标轴标签、图例 |
| **脚注/来源** | 8 pt | 7 pt | 页面底部数据来源 |
| **免责声明** | 7 pt | 6 pt | 机密性声明等 |

### 4.3 行距与段落

| 设置项 | 标准值 | 说明 |
|--------|--------|------|
| **正文行距** | 1.15 倍 | 可读性最佳 |
| **段落间距（段前）** | 4 pt | 区分段落 |
| **段落间距（段后）** | 4 pt | 区分段落 |
| **项目符号缩进** | 0.25 英寸 | 标准缩进 |
| **二级项目符号缩进** | 0.50 英寸 | 嵌套层级 |

---

## 五、版式布局（Slide Layouts）

本模板定义 8 种标准版式布局，覆盖投行和 PE 演示文稿的所有常见场景。

### 5.1 Layout [0]: 封面页 (Cover Slide)

**用途：** 演示文稿首页，展示公司名称、项目标题、日期及保密声明。

```
+--------------------------------------------------+
|                                                    |
|           [公司 LOGO]                              |
|                                                    |
|     ═══════════════════════════════════            |
|                                                    |
|           项目名称 / 交易标题                       |
|           副标题 / 交易类型                         |
|                                                    |
|           日期 | 部门名称                           |
|                                                    |
|     ─────────────────────────────────              |
|     严格保密 - 仅供授权人员阅览                      |
+--------------------------------------------------+
```

**占位符映射：**

| idx | 类型 | 位置 (x, y, w, h) | 用途 |
|-----|------|-------------------|------|
| 1 | TITLE (1) | x=1.50", y=2.20", w=10.33", h=1.00" | 项目/交易标题 |
| 2 | BODY (2) | x=1.50", y=3.20", w=10.33", h=0.50" | 副标题/交易类型 |
| 3 | BODY (2) | x=1.50", y=5.80", w=10.33", h=0.40" | 日期与部门 |
| 4 | BODY (2) | x=0.60", y=6.80", w=12.13", h=0.30" | 保密声明 |

### 5.2 Layout [1]: 标题与正文 (Title & Content)

**用途：** 最常用的内容页布局，适用于文字要点、分析说明、执行摘要等。

```
+--------------------------------------------------+
| [页面标题]                              [LOGO]     |
| ──────────────────────────────────────            |
|                                                    |
|   ● Section Header                                 |
|     • First bullet point                           |
|     • Second bullet point                          |
|     • Third bullet point                           |
|                                                    |
|   ● Section Header 2                               |
|     • Key finding                                  |
|     • Supporting detail                            |
|                                                    |
| ──────────────────────────────────────            |
| 来源: [数据来源]                      第 X 页      |
+--------------------------------------------------+
```

**占位符映射：**

| idx | 类型 | 位置 (x, y, w, h) | 用途 |
|-----|------|-------------------|------|
| 1 | TITLE (1) | x=0.60", y=0.30", w=10.50", h=0.60" | 页面标题 |
| 2 | BODY (2) | x=0.60", y=0.95", w=12.13", h=0.03" | 蓝色分割线（装饰元素） |
| 3 | BODY (2) | x=0.60", y=1.10", w=12.13", h=5.30" | 正文内容区域 |
| 4 | BODY (2) | x=0.60", y=6.60", w=8.00", h=0.30" | 数据来源/脚注 |
| 5 | BODY (2) | x=10.73", y=6.60", w=2.00", h=0.30" | 页码 |

**内容区域边界：**
- 左边界: 0.60"
- 上边界: 1.10"（标题分割线下方）
- 宽度: 12.13"
- 高度: 5.30"（从内容顶部到页脚区域）
- 右边界: 12.73"

### 5.3 Layout [2]: 双栏布局 (Two-Column)

**用途：** 对比分析、左右对照、并列展示。

```
+--------------------------------------------------+
| [页面标题]                              [LOGO]     |
| ──────────────────────────────────────            |
|                                                    |
|   ┌─────────────────┐  ┌─────────────────┐        |
|   │  左栏标题         │  │  右栏标题         │      |
|   │                   │  │                   │      |
|   │  ● 内容要点       │  │  ● 内容要点       │      |
|   │  ● 数据展示       │  │  ● 分析结论       │      |
|   │                   │  │                   │      |
|   └─────────────────┘  └─────────────────┘        |
|                                                    |
| ──────────────────────────────────────            |
| 来源: [数据来源]                      第 X 页      |
+--------------------------------------------------+
```

**内容区域边界（双栏）：**
- 左栏: x=0.60", y=1.10", w=5.80", h=5.30"
- 右栏: x=6.93", y=1.10", w=5.80", h=5.30"
- 栏间距: 0.53"

### 5.4 Layout [3]: 四象限布局 (Four-Quadrant)

**用途：** 多维度分析、多图表并排展示、关键指标汇总。

```
+--------------------------------------------------+
| [页面标题]                              [LOGO]     |
| ──────────────────────────────────────            |
|                                                    |
|   ┌─────────────────┐  ┌─────────────────┐        |
|   │  象限 1           │  │  象限 2           │      |
|   │  (左上)           │  │  (右上)           │      |
|   └─────────────────┘  └─────────────────┘        |
|   ┌─────────────────┐  ┌─────────────────┐        |
|   │  象限 3           │  │  象限 4           │      |
|   │  (左下)           │  │  (右下)           │      |
|   └─────────────────┘  └─────────────────┘        |
|                                                    |
| 来源: [数据来源]                      第 X 页      |
+--------------------------------------------------+
```

**内容区域边界（四象限）：**
- 左列: x=0.60", w=5.80"
- 右列: x=6.93", w=5.80"
- 上行: y=1.10", h=2.55"
- 下行: y=3.85", h=2.55"
- 象限间距（水平）: 0.53"
- 象限间距（垂直）: 0.20"

### 5.5 Layout [4]: 图表页 (Chart Slide)

**用途：** 单个大型图表展示，如收入趋势、估值分析等。

```
+--------------------------------------------------+
| [页面标题]                              [LOGO]     |
| ──────────────────────────────────────            |
|                                                    |
|   ┌──────────────────────────────────┐             |
|   │                                   │             |
|   │         [主图表区域]               │             |
|   │                                   │             |
|   │                                   │             |
|   └──────────────────────────────────┘             |
|                                                    |
|   [图表说明/关键要点]                               |
|                                                    |
| 来源: [数据来源]                      第 X 页      |
+--------------------------------------------------+
```

**图表区域边界：**
- x=0.60", y=1.10", w=12.13", h=4.50"
- 图表说明区域: y=5.70", h=0.60"

### 5.6 Layout [5]: 表格页 (Table Slide)

**用途：** 财务数据表格展示，如财务摘要、可比公司分析等。

```
+--------------------------------------------------+
| [页面标题]                              [LOGO]     |
| ──────────────────────────────────────            |
|                                                    |
|   ┌──────────────────────────────────┐             |
|   │ 表头 │ Col1 │ Col2 │ Col3 │ Col4 │            |
|   │──────┼──────┼──────┼──────┼──────│             |
|   │ Row1 │      │      │      │      │             |
|   │ Row2 │      │      │      │      │             |
|   │ Row3 │      │      │      │      │             |
|   │ Row4 │      │      │      │      │             |
|   └──────────────────────────────────┘             |
|                                                    |
|   [表格说明/单位标注]                               |
|                                                    |
| 来源: [数据来源]                      第 X 页      |
+--------------------------------------------------+
```

**表格区域边界：**
- x=0.60", y=1.10", w=12.13", h=5.00"
- 表格说明区域: y=6.20", h=0.30"

### 5.7 Layout [6]: 分节页 (Section Divider)

**用途：** 大型演示文稿中的分节标识页。

```
+--------------------------------------------------+
|                                                    |
|                                                    |
|           ═══════════════════════════               |
|                                                    |
|              [节标题]                               |
|                                                    |
|           ═══════════════════════════               |
|                                                    |
|                                                    |
+--------------------------------------------------+
```

**占位符映射：**

| idx | 类型 | 位置 (x, y, w, h) | 用途 |
|-----|------|-------------------|------|
| 1 | TITLE (1) | x=2.00", y=2.80", w=9.33", h=1.50" | 节标题 |

### 5.8 Layout [7]: 附录页 (Appendix)

**用途：** 附录材料页，支持密集数据表格和补充图表。

与 Layout [1] 相同结构，但页眉添加"附录 (Appendix)"标识。

---

## 六、版式总览表

| Index | 名称 | 用途 | 适用场景 |
|-------|------|------|----------|
| 0 | Cover Slide（封面页） | 封面/标题页 | 演示文稿首页 |
| 1 | Title & Content（标题与正文） | 标准内容页 | 执行摘要、分析说明、要点列表 |
| 2 | Two-Column（双栏布局） | 左右对照 | 对比分析、优劣势分析 |
| 3 | Four-Quadrant（四象限布局） | 多维度展示 | KPI 汇总、多图表并排 |
| 4 | Chart Slide（图表页） | 大型图表 | 趋势图、估值分析 |
| 5 | Table Slide（表格页） | 数据表格 | 财务摘要、可比公司 |
| 6 | Section Divider（分节页） | 分节标识 | 大型文档章节分隔 |
| 7 | Appendix（附录页） | 附录材料 | 补充数据、详细表格 |

---

## 七、图表格式标准（Chart Formats）

### 7.1 柱状图/条形图 (Bar/Column Chart)

| 设置项 | 标准值 | 说明 |
|--------|--------|------|
| **系列间距** | 100% | 标准间距 |
| **类别间距** | 80% | 类别间留白 |
| **数据标签** | 显示 | 位于柱顶部，9pt Calibri |
| **坐标轴** | 左Y轴 + 底X轴 | 深灰色 (#666666) |
| **网格线** | 仅水平网格线 | 浅灰色 (#E0E0E0)，虚线样式 |
| **图例** | 底部居中 | 9pt Calibri |
| **边框** | 无 | 清除图表外边框 |

### 7.2 折线图 (Line Chart)

| 设置项 | 标准值 | 说明 |
|--------|--------|------|
| **线宽** | 2.25 pt | 主系列线宽 |
| **数据点标记** | 圆形，5pt | 仅在关键数据点标记 |
| **面积填充** | 无或半透明 | 主系列可使用 15% 透明度填充 |
| **坐标轴** | 左Y轴 + 底X轴 | 年份标注使用 YYYY 格式 |
| **趋势线** | 可选 | 虚线，灰色 |

### 7.3 饼图/环形图 (Pie/Donut Chart)

| 设置项 | 标准值 | 说明 |
|--------|--------|------|
| **类型** | 环形图（Donut）优先 | 更现代、专业的视觉风格 |
| **内径比例** | 50% | 环形宽度适中 |
| **数据标签** | 外部标签 + 百分比 | 显示类别名称和占比 |
| **颜色** | 使用系列配色顺序 | 不超过 6 个扇区 |

### 7.4 组合图 (Combination Chart)

| 设置项 | 标准值 | 说明 |
|--------|--------|------|
| **主轴** | 柱状图 | 金额类数据（收入、利润） |
| **次轴** | 折线图 | 比率类数据（利润率、增长率） |
| **次轴位置** | 右侧 | 次Y轴标签靠右对齐 |
| **图例** | 底部 | 区分柱状和折线系列 |

### 7.5 "Football Field" 估值区间图

投资银行估值分析中的标志性图表，展示不同估值方法下的价值区间。

| 设置项 | 标准值 | 说明 |
|--------|--------|------|
| **图表类型** | 水平浮动条形图 | 每行展示一个估值方法的区间 |
| **估值方法** | 4–6 行 | Comparable Companies, Precedent Transactions, DCF, LBO 等 |
| **颜色** | 按系列配色 | 每个方法使用不同颜色 |
| **参考线** | 当前股价/出价 | 垂直虚线标注 |

---

## 八、表格样式标准（Table Styles）

### 8.1 表格通用样式

| 设置项 | 标准值 | 说明 |
|--------|--------|------|
| **表头背景色** | `#001F5B` (Navy Blue) | 深海军蓝背景 |
| **表头文字色** | `#FFFFFF` (White) | 白色文字 |
| **表头字号** | 10 pt Calibri Bold | 统一加粗 |
| **表头对齐** | 居中 | 数值列右对齐除外 |
| **正文行背景色（奇数行）** | `#FFFFFF` (White) | 白色 |
| **正文行背景色（偶数行）** | `#F5F5F5` (Light Gray) | 浅灰交替行 |
| **正文文字色** | `#333333` (Dark Charcoal) | 深炭灰 |
| **正文字号** | 9–10 pt Calibri | 标准字号 |
| **边框样式** | 细边框 | `#CCCCCC` 浅灰色 |
| **边框宽度** | 0.5 pt | 极细线条 |

### 8.2 数值格式

| 数据类型 | 格式示例 | 说明 |
|----------|----------|------|
| **大额金额** | $1,234M 或 ¥12.3 亿 | 统一使用百万/亿单位 |
| **百分比（1 位小数）** | 12.3% | 增长率、利润率 |
| **百分比（2 位小数）** | 1.25% | 利率、汇率变动 |
| **乘数** | 8.5x | P/E、EV/EBITDA 等估值倍数 |
| **年份** | FY2024A / FY2025E | A=实际, E=预估, P=预测 |
| **日期** | 2024年12月31日 | 中文格式或 Dec 31, 2024 |

### 8.3 财务摘要表格样例

```
┌──────────────────┬─────────┬─────────┬─────────┬─────────┬─────────┐
│                  │ FY2021A │ FY2022A │ FY2023A │ FY2024E │ FY2025E │
├──────────────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
│ 营业收入 (百万元) │  10,234 │  11,567 │  12,890 │  14,200 │  15,800 │
│   同比增长率 (%)  │   15.2% │   13.0% │   11.4% │   10.2% │   11.3% │
├──────────────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
│ EBITDA (百万元)  │   2,865 │   3,238 │   3,612 │   4,047 │   4,581 │
│   EBITDA 率 (%)  │   28.0% │   28.0% │   28.0% │   28.5% │   29.0% │
├──────────────────┼─────────┼─────────┼─────────┼─────────┼─────────┤
│ 净利润 (百万元)  │   1,535 │   1,742 │   1,934 │   2,170 │   2,460 │
│   净利润率 (%)   │   15.0% │   15.1% │   15.0% │   15.3% │   15.6% │
└──────────────────┴─────────┴─────────┴─────────┴─────────┴─────────┘
```

---

## 九、投行演示文稿标准结构

基于 Mergers & Inquisitions、Wall Street Prep、Corporate Finance Institute 及 Financial Edge Training 的行业最佳实践整理。

### 9.1 典型 Pitchbook 章节结构

| 章节编号 | 章节名称 | 建议页数 | 建议版式 | 内容说明 |
|----------|----------|----------|----------|----------|
| — | 封面页 (Cover) | 1 | Layout [0] | 公司名、项目名、日期、保密声明 |
| — | 目录页 (Contents) | 1 | Layout [1] | 各章节标题及页码 |
| 1 | 执行摘要 (Executive Summary) | 1–2 | Layout [1] | 交易概述、核心投资亮点、推荐意见 |
| 2 | 公司概况 (Company Overview) | 2–3 | Layout [1], [3] | 业务模式、产品/服务、地理布局 |
| 3 | 行业分析 (Industry Analysis) | 2–3 | Layout [4], [5] | 市场规模、增长趋势、竞争格局 |
| 4 | 历史财务分析 (Historical Financials) | 2–3 | Layout [5] | 3–5 年历史财务数据 |
| 5 | 财务预测 (Financial Projections) | 2–3 | Layout [4], [5] | 收入增长、利润率预测 |
| 6 | 估值分析 (Valuation Analysis) | 3–5 | Layout [4], [5] | 可比公司、先例交易、DCF、LBO |
| 7 | 交易结构 (Transaction Structure) | 1–2 | Layout [1], [2] | 交易条款、协同效应 |
| 8 | 推荐意见 (Recommendation) | 1 | Layout [1] | 核心发现、建议行动 |
| — | 附录 (Appendix) | 5–10 | Layout [7] | 详细数据表、补充图表、假设说明 |
| — | 免责声明 (Disclaimer) | 1 | Layout [1] | 法律声明 |

**建议总页数：** 20–35 页（不含附录）

### 9.2 PE 投资备忘录 (IC Memo) 标准结构

| 章节编号 | 章节名称 | 建议页数 | 内容说明 |
|----------|----------|----------|----------|
| 1 | 投资主题 (Investment Thesis) | 1–2 | 核心投资逻辑与机会 |
| 2 | 公司概况 (Company Overview) | 2–3 | 业务、管理团队、历史表现 |
| 3 | 市场与竞争 (Market & Competition) | 2–3 | TAM、市场份额、进入壁垒 |
| 4 | 财务分析 (Financial Analysis) | 3–4 | 历史及预测财务数据 |
| 5 | 估值分析 (Valuation) | 2–3 | 估值方法及结论 |
| 6 | 交易结构 (Deal Structure) | 1–2 | 资本结构、融资方案 |
| 7 | 风险分析 (Risk Analysis) | 1–2 | 主要风险因素及缓释措施 |
| 8 | 退出策略 (Exit Strategy) | 1 | 预计退出时间及方式 |
| 9 | 回报分析 (Returns Analysis) | 1–2 | IRR、MOIC 敏感性分析 |

---

## 十、Python-pptx 实现指南

### 10.1 模板初始化

```python
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

# 颜色常量定义
NAVY_BLUE = RGBColor(0x00, 0x1F, 0x5B)
MIDNIGHT_BLUE = RGBColor(0x00, 0x33, 0x66)
STEEL_BLUE = RGBColor(0x4A, 0x7F, 0xB5)
MUTED_GOLD = RGBColor(0xC8, 0xA9, 0x51)
DARK_CHARCOAL = RGBColor(0x33, 0x33, 0x33)
MEDIUM_GRAY = RGBColor(0x66, 0x66, 0x66)
LIGHT_GRAY = RGBColor(0xF5, 0xF5, 0xF5)
BORDER_GRAY = RGBColor(0xCC, 0xCC, 0xCC)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

# 加载模板
prs = Presentation("assets/template.pptx")

# 删除所有现有幻灯片
while len(prs.slides) > 0:
    rId = prs.slides._sldIdLst[0].rId
    prs.part.drop_rel(rId)
    del prs.slides._sldIdLst[0]
```

### 10.2 创建封面页

```python
slide = prs.slides.add_slide(prs.slide_layouts[0])

for shape in slide.shapes:
    if hasattr(shape, 'placeholder_format'):
        idx = shape.placeholder_format.idx
        if idx == 1:  # TITLE
            shape.text = "机密项目名称"
        elif idx == 2:  # SUBTITLE
            shape.text = "战略选择评估 | 项目建议书"
        elif idx == 3:  # DATE/DEPT
            shape.text = "2026年5月 | 投资银行部"
        elif idx == 4:  # DISCLAIMER
            shape.text = "严格保密 — 仅供授权人员阅览"
```

### 10.3 创建内容页

```python
slide = prs.slides.add_slide(prs.slide_layouts[1])

for shape in slide.shapes:
    if hasattr(shape, 'placeholder_format'):
        ph_type = shape.placeholder_format.type
        idx = shape.placeholder_format.idx
        if ph_type == 1:  # TITLE
            shape.text = "执行摘要"
        elif idx == 3:  # BODY CONTENT
            tf = shape.text_frame
            for para in tf.paragraphs:
                para.clear()
            content = [
                ("核心投资亮点", 0),
                ("目标公司年收入增长 40% YoY 至 50 亿元", 1),
                ("已扩展至 3 个新市场，市占率持续提升", 1),
                ("EBITDA 利润率稳定在 28% 以上", 1),
                ("推荐意见", 0),
                ("建议推进战略收购交易", 1),
                ("预计交易完成后可实现显著协同效应", 1),
            ]
            tf.paragraphs[0].text = content[0][0]
            tf.paragraphs[0].level = content[0][1]
            for text, level in content[1:]:
                p = tf.add_paragraph()
                p.text = text
                p.level = level
        elif idx == 4:  # SOURCE
            shape.text = "来源：公司年报、管理层访谈、分析师估计"
```

### 10.4 添加自定义表格

```python
from pptx.util import Inches, Pt

# 在 Layout [5] 表格页中添加财务摘要表格
slide = prs.slides.add_slide(prs.slide_layouts[5])

# 设置标题
for shape in slide.shapes:
    if hasattr(shape, 'placeholder_format'):
        if shape.placeholder_format.type == 1:
            shape.text = "历史财务摘要"

# 添加表格
rows, cols = 6, 6
table_shape = slide.shapes.add_table(
    rows, cols,
    Inches(0.60), Inches(1.10),
    Inches(12.13), Inches(4.50)
)
table = table_shape.table

# 设置列宽
col_widths = [Inches(2.50), Inches(1.93), Inches(1.93),
              Inches(1.93), Inches(1.93), Inches(1.93)]
for i, width in enumerate(col_widths):
    table.columns[i].width = width

# 填充表头
headers = ["（百万元）", "FY2021A", "FY2022A", "FY2023A", "FY2024E", "FY2025E"]
for i, header in enumerate(headers):
    cell = table.cell(0, i)
    cell.text = header
    for para in cell.text_frame.paragraphs:
        para.font.size = Pt(10)
        para.font.bold = True
        para.font.color.rgb = WHITE
        para.alignment = PP_ALIGN.CENTER
    cell.fill.solid()
    cell.fill.fore_color.rgb = NAVY_BLUE

# 填充数据行
data = [
    ["营业收入",       "10,234", "11,567", "12,890", "14,200", "15,800"],
    ["  同比增长率",    "15.2%",  "13.0%",  "11.4%",  "10.2%",  "11.3%"],
    ["EBITDA",         "2,865",  "3,238",  "3,612",  "4,047",  "4,581"],
    ["  EBITDA 率",    "28.0%",  "28.0%",  "28.0%",  "28.5%",  "29.0%"],
    ["净利润",         "1,535",  "1,742",  "1,934",  "2,170",  "2,460"],
]
for row_idx, row_data in enumerate(data, 1):
    for col_idx, value in enumerate(row_data):
        cell = table.cell(row_idx, col_idx)
        cell.text = value
        for para in cell.text_frame.paragraphs:
            para.font.size = Pt(9)
            para.font.color.rgb = DARK_CHARCOAL
            if col_idx > 0:
                para.alignment = PP_ALIGN.RIGHT
        # 交替行颜色
        if row_idx % 2 == 0:
            cell.fill.solid()
            cell.fill.fore_color.rgb = LIGHT_GRAY
        else:
            cell.fill.solid()
            cell.fill.fore_color.rgb = WHITE
```

### 10.5 添加图表

```python
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE

# 在 Layout [4] 图表页中添加收入趋势图
slide = prs.slides.add_slide(prs.slide_layouts[4])

for shape in slide.shapes:
    if hasattr(shape, 'placeholder_format'):
        if shape.placeholder_format.type == 1:
            shape.text = "收入与 EBITDA 趋势分析"

# 准备图表数据
chart_data = CategoryChartData()
chart_data.categories = ['FY2021A', 'FY2022A', 'FY2023A', 'FY2024E', 'FY2025E']
chart_data.add_series('营业收入', (10.234, 11.567, 12.890, 14.200, 15.800))
chart_data.add_series('EBITDA',    (2.865,  3.238,  3.612,  4.047,  4.581))

# 添加柱状图
chart_frame = slide.shapes.add_chart(
    XL_CHART_TYPE.COLUMN_CLUSTERED,
    Inches(0.60), Inches(1.10),
    Inches(12.13), Inches(4.50),
    chart_data
)
chart = chart_frame.chart

# 设置系列颜色
series_0 = chart.series[0]
series_0.format.fill.solid()
series_0.format.fill.fore_color.rgb = NAVY_BLUE

series_1 = chart.series[1]
series_1.format.fill.solid()
series_1.format.fill.fore_color.rgb = STEEL_BLUE

# 设置坐标轴样式
value_axis = chart.value_axis
value_axis.has_title = False
value_axis.major_gridlines.format.line.color.rgb = RGBColor(0xE0, 0xE0, 0xE0)

chart.has_legend = True
chart.legend.include_in_layout = False
chart.legend.font.size = Pt(9)
```

---

## 十一、内容区域边界汇总

以下为所有版式的安全内容区域边界定义，用于放置自定义元素（文本框、表格、图表）。

### Layout [1]: Title & Content
```
内容区域:
- 左边界: 0.60"
- 上边界: 1.10"（标题分割线下方）
- 宽度: 12.13"
- 高度: 5.30"
- 右边界: 12.73"
- 下边界: 6.40"（页脚区域上方）
```

### Layout [2]: Two-Column
```
左栏: x=0.60", y=1.10", w=5.80", h=5.30"
右栏: x=6.93", y=1.10", w=5.80", h=5.30"
栏间距: 0.53"
```

### Layout [3]: Four-Quadrant
```
左列: x=0.60", w=5.80"
右列: x=6.93", w=5.80"
上行: y=1.10", h=2.55"
下行: y=3.85", h=2.55"
象限间距（水平）: 0.53"
象限间距（垂直）: 0.20"
```

### Layout [4]: Chart Slide
```
图表区域: x=0.60", y=1.10", w=12.13", h=4.50"
说明区域: y=5.70", h=0.60"
```

### Layout [5]: Table Slide
```
表格区域: x=0.60", y=1.10", w=12.13", h=5.00"
说明区域: y=6.20", h=0.30"
```

---

## 十二、关键设计规则

### 12.1 必须遵守的规则

1. **不要手动添加项目符号字符** — 使用 `paragraph.level` 控制层级，幻灯片母版处理格式化。
2. **始终先删除现有幻灯片** — 在添加新幻灯片之前，清除模板中所有现有幻灯片。
3. **每个数据点标注来源** — 所有数据、图表、表格必须在页面底部标注数据来源（8pt 字号）。
4. **保持字体一致性** — 全文使用 Calibri，最多不超过 2 种字体。
5. **遵守配色方案** — 不使用模板规格之外的颜色。
6. **财务数据右对齐** — 表格中所有数值列右对齐，文字列左对齐。
7. **图表必须有标题和图例** — 每个图表须包含清晰标题和图例说明。

### 12.2 常见错误避免

| 错误 | 正确做法 |
|------|----------|
| 混合使用 Calibri 和 Arial | 全文统一使用 Calibri |
| 使用 5 种以上字号 | 限制在 4 种字号以内 |
| 超出内容区域边界 | 严格使用定义的边界尺寸 |
| 使用鲜艳颜色 | 使用本规格定义的柔和中性色 |
| 缺少数据来源脚注 | 每页必须包含来源说明 |
| 表格缺少交替行颜色 | 使用白色/浅灰交替行 |
| 图表边框过粗 | 使用无图表外边框或极细边框 |

### 12.3 文件保存与导出

```python
# 保存演示文稿
prs.save("output_filename.pptx")

# 同时导出 PDF 版本（建议使用 LibreOffice 或 comtypes）
#投行标准：同时提供 PPTX 和 PDF 两个版本
```

---

## 十三、行业参考标准来源

本模板规格参考了以下行业权威来源的实际标准和最佳实践：

| 来源 | 参考内容 | URL |
|------|----------|-----|
| Wall Street Prep | PowerPoint 格式标准、投行快捷键、图表/表格格式 | https://www.wallstreetprep.com/knowledge/powerpoint-hacks-for-investment-banking-and-consulting/ |
| Mergers & Inquisitions | Pitchbook 结构、买卖方演示文稿格式 | https://mergersandinquisitions.com/investment-banking-pitch-books/ |
| Corporate Finance Institute | Pitchbook 模板、估值分析结构 | https://corporatefinanceinstitute.com/resources/valuation/investment-banking-pitchbook-template/ |
| Alexander Jarvis | Goldman Sachs、Morgan Stanley 真实交易演示文稿 | https://www.alexanderjarvis.com/goldman-sachs-investment-banking-presentation-examples/ |
| 10X EBITDA | 真实 M&A 分析和投行演示文稿集 | https://www.10xebitda.com/investment-banking-presentations/ |
| Breaking Into Wall Street | 推荐意见页制作、表格结构 | https://breakingintowallstreet.com/kb/powerpoint/powerpoint-recommendations-slide/ |
| Wall Street Oasis | PPT 配色方案、财务模型格式指南 | https://www.wallstreetoasis.com/forum/investment-banking/ppt-color-schemes |
| HueHive | 投行专业配色方案（Navy Blue #001F5B, Midnight Blue #003366） | https://huehive.co/ai_generated_palettes/11443 |
| Piktochart | 金融行业 15 种配色组合 | https://piktochart.com/blog/finance-color-palette/ |
| produkto.io | 投行配色研究（蓝灰色保守方案） | https://produkto.io/color-palettes/investment-banking |
| Financial Edge Training | Pitchbook 三大分类：银行介绍、交易推介、管理层演示 | https://fe.training/free-resources/investment-banking/investment-banking-pitch-book/ |
| Deckary | Pitchbook 最佳实践（15-20 页初始推介） | https://deckary.com/blog/investment-banking-pitch-book |
| Slidebook.io | Goldman Sachs / Morgan Stanley 真实投资者演示文稿 | https://www.slidebook.io/company/goldman-sachs/ |
| python-pptx 官方文档 | 图表创建 API、表格操作、占位符格式 | https://python-pptx.readthedocs.io/en/stable/user/charts.html |

---

## Sources

- [Wall Street Prep - PowerPoint Hacks for IB and Consulting](https://www.wallstreetprep.com/knowledge/powerpoint-hacks-for-investment-banking-and-consulting/)
- [Wall Street Prep - Investment Banking Pitchbook Format](https://www.wallstreetprep.com/knowledge/investment-banking-pitchbook/)
- [Mergers & Inquisitions - Investment Banking Pitch Books](https://mergersandinquisitions.com/investment-banking-pitch-books/)
- [Corporate Finance Institute - IB Pitchbook Template](https://corporatefinanceinstitute.com/resources/valuation/investment-banking-pitchbook-template/)
- [Alexander Jarvis - Goldman Sachs IB Presentation Examples](https://www.alexanderjarvis.com/goldman-sachs-investment-banking-presentation-examples/)
- [Alexander Jarvis - Morgan Stanley IB Presentation Examples](https://www.alexanderjarvis.com/morgan-stanley-investment-banking-presentation-examples/)
- [10X EBITDA - Investment Banking Presentations](https://www.10xebitda.com/investment-banking-presentations/)
- [Breaking Into Wall Street - Recommendations Slide](https://breakingintowallstreet.com/kb/powerpoint/powerpoint-recommendations-slide/)
- [Wall Street Oasis - PPT Color Schemes](https://www.wallstreetoasis.com/forum/investment-banking/ppt-color-schemes)
- [Wall Street Oasis - Financial Model Formatting](https://www.wallstreetoasis.com/resources/financial-modeling/financial-model-formatting)
- [HueHive - IB Presentation Color Palette](https://huehive.co/ai_generated_palettes/11443)
- [HueHive - Professional IB Firm Color Palette](https://huehive.co/ai_generated_palettes/7030)
- [Piktochart - Finance Color Palette Combinations](https://piktochart.com/blog/finance-color-palette/)
- [produkto.io - Investment Banking Color Palettes](https://produkto.io/color-palettes/investment-banking)
- [Financial Edge Training - IB Pitch Book Guide](https://fe.training/free-resources/investment-banking/investment-banking-pitch-book/)
- [Deckary - IB Pitch Book Structure](https://deckary.com/blog/investment-banking-pitch-book)
- [Morgan Stanley - Official Presentations](https://www.morganstanley.com/about-us-ir/presentations)
- [Goldman Sachs - Investor Relations Presentations](https://www.goldmansachs.com/investor-relations/presentations)
- [Slidebook.io - Goldman Sachs Presentations](https://www.slidebook.io/company/goldman-sachs/)
- [Superside - Best IB PowerPoint Templates](https://www.superside.com/blog/banking-finance-powerpoint)
- [python-pptx Documentation - Working with Charts](https://python-pptx.readthedocs.io/en/stable/user/charts.html)
- [python-pptx Bar Chart Analysis](https://python-pptx.readthedocs.io/en/latest/dev/analysis/cht-bar-chart.html)
- [SlideTeam - IB Color Theme Templates](https://www.slideteam.net/top-10-investment-banking-color-theme-powerpoint-presentation-templates)
