# Global Equity Data Report

**[DATA SOURCE: Yahoo Finance, Macrotrends, FinanceCharts, CompaniesMarketCap, GuruFocus, Trading Economics, Investing.com, MarketBeat, StockAnalysis, London Stock Exchange, WSJ]**

**Report Date:** 2026-05-09
**Data As Of:** 2026-05-08 (market close)

---

## 一、美股龙头个股行情 (US Mega-Cap Equities)

### 1. Apple Inc. (AAPL)

| 指标 | 数值 |
|---|---|
| **最新收盘价** | $293.32 (2026-05-08) |
| **日内区间** | $289.10 - $294.76 |
| **盘后价格** | ~$293.86 (+$0.54) |
| **市值** | ~$4.3 万亿 (Trillion) |
| **市盈率 (P/E TTM)** | 32.93 - 34.14 |
| **远期市盈率 (Forward P/E)** | ~30x |
| **股息率 (Dividend Yield)** | 0.37% (前瞻) |
| **季度股息** | $0.27/股 (近期从 $0.26 上调) |
| **年化股息** | ~$1.04 - $1.08/股 |
| **52周区间** | ~$195 - $295 |
| **分析师目标价** | $306.96 (共识) |

**要点:** Apple 市值约 $4.3万亿，P/E约33-34x，高于10年中位数26.29x约30%。股息率偏低(0.37%)，但通过大规模回购回报股东（FY2025回购+股息合计超$1060亿）。

---

### 2. Microsoft Corp. (MSFT)

| 指标 | 数值 |
|---|---|
| **最新收盘价** | $415.12 (2026-05-08) |
| **市值** | ~$3.08 万亿 (CNBC) / ~$2.75 万亿 (Macrotrends) |
| **市盈率 (P/E TTM)** | 24.11 - 25.36 |
| **远期市盈率** | ~24x |
| **股息率 (Dividend Yield)** | 0.83% - 0.88% |
| **季度股息** | $0.91/股 (除息日: 2026-05-21) |
| **年化股息** | $3.64/股 |
| **派息率 (Payout Ratio)** | ~20.6% |
| **52周高点** | ~$455.00 |
| **10日平均成交量** | ~34.83M |

**要点:** Microsoft 当前P/E约24-25x，较其12个月均值31.74低约22%，较10年中位数32.85低约23%，处于相对低估区间。股息率约0.85%，派息率仅21%，安全边际充足。

---

### 3. NVIDIA Corp. (NVDA)

| 指标 | 数值 |
|---|---|
| **最新收盘价** | ~$215.20 (2026-05-08, MacroTrends) |
| **市值** | ~$4.77 万亿 |
| **市盈率 (P/E TTM)** | 40.10 - 43.92 |
| **远期市盈率 (Forward P/E)** | ~24.21 - 26.00 |
| **PEG 比率 (5年预期)** | 0.62 |
| **EPS (TTM)** | ~$4.90 - $4.93 |
| **价格/销售比 (P/S TTM)** | 22.31 |
| **企业价值 (EV)** | ~$4.72 万亿 |
| **股息率** | ~0.02% - 0.03% (极低) |

**要点:** NVIDIA P/E 从2024年的~80.5x下降至2026年的~40x，反映盈利增速超过股价涨幅。远期P/E约24x，PEG仅0.62（<1.0），表明相对增长预期估值合理。AI驱动的数据中心需求持续强劲。

---

### 4. Alphabet Inc. (GOOGL)

| 指标 | 数值 |
|---|---|
| **最新价格** | ~$396.36 (Robinhood) |
| **市值** | ~$4.86 万亿 (StockAnalysis) |
| **市盈率 (P/E TTM)** | 29.35 - 30.36 |
| **远期市盈率** | ~27 - 29x |
| **2026 EPS 预期** | $11.47 - $11.50 |
| **分析师共识目标价** | $388.59 - $407.86 |
| **全球市值排名** | #2 |
| **股息率** | 有 (近期开始派息) |

**要点:** Alphabet 在2026年受AI（Gemini）和云计算增长驱动，市值飙升至约$4.8-4.9万亿，一年内增长约150%。P/E约29-30x，对于AI超级大盘股而言估值合理。分析师共识评级为"买入"。

---

### 5. Amazon.com Inc. (AMZN)

| 指标 | 数值 |
|---|---|
| **最新收盘价** | $272.68 (2026-05-08, Investing.com) |
| **市值** | ~$2.56 万亿 (Macrotrends) |
| **市盈率 (P/E TTM)** | 32.12 - 33.25 |
| **远期市盈率** | ~30.6x |
| **股息率** | 0.00% (不派息) |
| **历史最高** | $273.88 (2026-04-29) |
| **52周区间** | $196.00 - $278.56 |
| **2026 AI投资** | ~$2000亿 |

**要点:** Amazon 股价从2月底的~$210飙升至5月初的~$273，数月内涨幅约30%。P/E约32-33x，市场仍赋予较高增长溢价。Amazon 不派发股息，持续将利润再投资于AWS和AI基础设施。

---

### 6. Tesla Inc. (TSLA)

| 指标 | 数值 |
|---|---|
| **最新收盘价** | ~$428.35 (CNN Markets) |
| **市值** | ~$1.23 - $1.61 万亿 |
| **市盈率 (P/E TTM)** | 362.92 - 392.98 |
| **远期市盈率** | ~188.68 - 208.33 |
| **PEG 比率** | 5.90 |
| **价格/销售比 (P/S)** | ~15.46 |
| **股息率** | 0.00% (不派息) |
| **分析师目标区间** | $25 - $600 |

**要点:** Tesla 估值极高，P/E TTM约370-393x，市场定价反映对其自动驾驶、能源和AI业务的巨大预期。分析师观点极度分化（目标价从$25到$600）。Tesla 不派息。

---

## 二、全球半导体龙头 (Global Semiconductor Leaders)

### 7. Taiwan Semiconductor (TSM)

| 指标 | 数值 |
|---|---|
| **最新收盘价** | ~$411.68 |
| **市值** | ~$2.05 - $2.13 万亿 (全球第6) |
| **市盈率 (P/E TTM)** | 28.7 - 34.80 |
| **远期市盈率** | ~24x |
| **股息率** | 0.63% - 0.96% |
| **年化股息** | ~$2.97 - $3.51/股 |
| **5年股息增长率** | +10.65% |
| **全球晶圆代工市场份额** | ~70% |

**要点:** TSMC作为全球最大晶圆代工企业，AI需求持续驱动增长。P/E约29-35x，远期P/E约24x被认为相对合理。股息率约0.8%，且以约10.65%的年化速度增长。

---

### 8. ASML Holding NV (ASML)

| 指标 | 数值 |
|---|---|
| **最新价格** | ~EUR 1,187 - 1,300 |
| **市值** | ~$587.4 亿 (Billion) |
| **市盈率 (P/E TTM)** | 45.29 - 53.09 |
| **远期市盈率** | ~38.41 |
| **PEG 比率** | 1.65 |
| **股息率** | 0.50% - 0.67% |
| **年化股息** | EUR 8.00/股 (FY2024) |
| **GF Score** | 97/100 |

**要点:** ASML作为EUV光刻设备垄断供应商，P/E约45-53x，高于10年中位数36x约27%。2026年以来涨幅约16%。远期P/E约38x，表明市场预期盈利增长。分析师共识评级为"买入"，12个月目标价约$1,500-1,625。

---

## 三、欧洲/中国企业 (European & Chinese Equities)

### 9. SAP SE (SAP)

| 指标 | 数值 |
|---|---|
| **最新收盘价 (NYSE ADR)** | ~$173.70 (2026-05-08) |
| **最新价格 (XETRA EUR)** | EUR 146.20 - 149.74 |
| **市值** | ~$169 - $236 亿 (Billion) |
| **市盈率 (P/E TTM)** | 23.25 - 24.20 |
| **12个月均值P/E** | 38.61 |
| **10年中位数P/E** | 30.65 |
| **分析师目标价** | ~$301 (47%上行空间) |

**要点:** SAP P/E从12个月均值38.6下降至约23-24，较10年中位数低约24%，处于相对折价区间。云业务增长低于市场预期导致股价承压，但分析师仍看好长期前景。

---

### 10. CATL 当代安普瑞科技 (300750.SZ)

| 指标 | 数值 |
|---|---|
| **最新价格** | CNY 437.00 - 451.64 |
| **前日收盘** | CNY 451.64 |
| **日内区间** | CNY 436.20 - 455.50 |
| **52周区间** | CNY 238.03 - 468.75 |
| **Q1 2026 营收** | CNY 1291.31 亿 (+52.45% YoY) |
| **Q1 2026 净利润** | CNY 207.38 亿 (+48.52% YoY) |
| **分析师目标价** | CNY 450 - 640 |

**要点:** CATL是全球最大动力电池制造商（市场份额超35%），Q1 2026营收和净利润均大幅增长近50%。股价从52周低点CNY 238反弹至当前约CNY 437-452，接近历史高位。公司正在推进港股二次上市以融资国际扩张。

---

## 四、全球主要指数 (Global Major Indices)

### 美国指数 (US Indices)

| 指数 | 代码 | 最新水平 | 变动 | YTD |
|---|---|---|---|---|
| **S&P 500** | ^GSPC | 7,401.50 (2026-05-08) | +0.84% | +7.18% |
| **NASDAQ Composite** | ^IXIC | ~18,500 - 19,200 (estimated) | -- | -- |
| **Dow Jones Industrial Avg** | ^DJI | 49,596.97 (2026-05-07) | -- | ~-1.07% |

**S&P 500 详细数据 (2026年5月):**

| 日期 | 收盘 |
|---|---|
| 2026-05-08 | 7,401.50 |
| 2026-05-07 | 7,385.02 |
| 2026-05-06 | 7,369.22 |
| 2026-05-05 | 7,273.26 |

**Dow Jones 详细数据 (2026年5月):**

| 日期 | 收盘 |
|---|---|
| 2026-05-07 | 49,596.97 |
| 2026-05-06 | 49,910.59 |
| 2026-05-05 | 49,298.25 |
| 2026-05-04 | 48,941.90 |

---

### 欧洲指数 (European Indices)

| 指数 | 代码 | 最新水平 | 变动 |
|---|---|---|---|
| **FTSE 100** | ^FTSE | 10,233.07 (2026-05-08) | -0.43% |
| **DAX 40** | ^GDAXI | 24,339 (2026-05-08) | -1.32% |

**FTSE 100 详细数据 (2026年5月):**

| 日期 | 收盘 |
|---|---|
| 2026-05-08 | 10,233.07 |
| 2026-05-07 | 10,276.95 |
| 2026-05-06 | 10,438.66 |
| 2026-05-05 | 10,219.11 |

- FTSE 100 净市值: GBP 2,435,557 million
- FTSE 100 整体股息率: 3.12%

**DAX 40 要点:**
- 52周区间: 22,057 - 25,816
- 分析师年末目标: ~27,000
- 德国财政刺激和利率下行支撑指数

---

### 亚太指数 (Asia-Pacific Index)

| 指数 | 代码 | 最新水平 | 变动 |
|---|---|---|---|
| **Nikkei 225** | ^N225 | 62,713.65 (2026-05-08) | -- |

**Nikkei 225 详细数据 (2026年5月):**

| 日期 | 开盘 | 最高 | 最低 | 收盘 |
|---|---|---|---|---|
| 2026-05-01 | 59,379.12 | 59,706.70 | 59,263.50 | 59,513.12 |
| 2026-05-07 | 60,241.31 | 63,091.14 | 60,213.02 | 62,833.84 |
| 2026-05-08 | 62,654.01 | 62,724.36 | 62,137.95 | 62,713.65 |

**要点:** 日经225指数从5月初的59,513飙升至62,714，一周内涨幅超5%，大幅超出分析师在2025年底预测的年末目标54,000。

---

## 五、个股估值对比汇总 (Valuation Comparison Matrix)

| 股票 | 代码 | 收盘价 (USD) | 市值 (万亿USD) | P/E (TTM) | 远期P/E | 股息率 | 行业 |
|---|---|---|---|---|---|---|---|
| Apple | AAPL | $293.32 | ~4.30 | 33.0 | ~30x | 0.37% | 科技/消费电子 |
| Microsoft | MSFT | $415.12 | ~3.08 | 24.7 | ~24x | 0.85% | 科技/软件 |
| NVIDIA | NVDA | $215.20 | ~4.77 | 43.9 | ~24x | ~0.03% | 科技/半导体 |
| Alphabet | GOOGL | $396.36 | ~4.86 | 30.4 | ~28x | 有 | 科技/互联网 |
| Amazon | AMZN | $272.68 | ~2.56 | 33.3 | ~31x | 0.00% | 科技/电商/云 |
| Tesla | TSLA | $428.35 | ~1.61 | 393.0 | ~208x | 0.00% | 汽车/新能源 |
| TSMC | TSM | $411.68 | ~2.10 | 34.8 | ~24x | 0.80% | 半导体代工 |
| ASML | ASML | ~$1,187* | ~0.59 | 51.0 | ~38x | 0.60% | 半导体设备 |
| SAP | SAP | $173.70 | ~0.17 | 23.4 | ~22x | ~1.0% | 企业软件 |
| CATL | 300750.SZ | ~$60** | -- | -- | -- | -- | 动力电池 |

*ASML 价格为 EUR 换算; **CATL 为 CNY 换算约值

---

## 六、全球指数表现对比 (Global Index Performance)

| 指数 | 最新水平 | 月涨跌 | YTD | 52周高点 |
|---|---|---|---|---|
| **S&P 500** | 7,401.50 | +1.78% (MTD) | +7.18% | -- |
| **Dow Jones** | 49,596.97 | ~-0.6% | ~-1.07% | 50,011.53 |
| **NASDAQ** | -- | -- | -- | -- |
| **FTSE 100** | 10,233.07 | ~-1.4% (5日) | -- | 10,488.20 |
| **Nikkei 225** | 62,713.65 | +5.4% (MTD) | -- | 63,091.14 |
| **DAX 40** | 24,339 | -1.32% (当日) | -- | 25,816 |

---

## 七、市场观察与要点 (Market Observations)

### 美股市场
- **AI主题持续主导**: NVIDIA、Alphabet 受AI需求推动，市值分别为$4.77万亿和$4.86万亿，分列全球第1-2位
- **估值分化明显**: Tesla P/E超390x vs. SAP P/E仅23x，市场对不同成长预期定价差异巨大
- **大盘稳健上行**: S&P 500 站上7,400，YTD涨幅7.18%
- **道指波动**: DJIA 在49,000-50,000区间震荡，曾突破50,000心理关口

### 欧洲市场
- **FTSE 100 表现稳健**: 在10,200-10,500区间运行，整体股息率3.12%具吸引力
- **DAX受政策刺激**: 德国财政扩张和ECB降息预期支撑DAX涨至24,000+

### 亚太市场
- **日经225强势突破**: 从5月初59,513升至62,714，远超分析师预期
- **CATL业绩亮眼**: Q1营收和净利润均增长约50%，动力电池全球龙头地位稳固

### 关键风险因素
- 中东地缘政治紧张升级
- 全球关税政策不确定性
- AI资本支出可持续性（Big Four预计2026年CAPEX合计超$7000亿）
- 估值压缩风险（S&P 500 P/E约31.4x，处于历史高位）

---

## 数据来源 (Sources)

### 个股数据
- [Yahoo Finance - AAPL](https://finance.yahoo.com/quote/AAPL/)
- [Yahoo Finance - MSFT](https://finance.yahoo.com/quote/MSFT/)
- [Yahoo Finance - NVDA](https://finance.yahoo.com/quote/NVDA/)
- [Yahoo Finance - GOOGL](https://finance.yahoo.com/quote/GOOGL/)
- [Yahoo Finance - AMZN](https://finance.yahoo.com/quote/AMZN/)
- [Yahoo Finance - TSLA](https://finance.yahoo.com/quote/TSLA/)
- [Yahoo Finance - TSM](https://finance.yahoo.com/quote/TSM/)
- [Yahoo Finance - ASML](https://finance.yahoo.com/quote/ASML/)
- [Yahoo Finance - SAP](https://finance.yahoo.com/quote/SAP/)

### 估值与财务数据
- [Macrotrends - AAPL PE](https://www.macrotrends.net/stocks/charts/AAPL/apple/pe-ratio)
- [Macrotrends - MSFT Market Cap](https://www.macrotrends.net/stocks/charts/MSFT/microsoft/market-cap)
- [Macrotrends - AMZN Market Cap](https://www.macrotrends.net/stocks/charts/AMZN/amazon/market-cap)
- [Macrotrends - GOOGL Market Cap](https://www.macrotrends.net/stocks/charts/GOOGL/alphabet/market-cap)
- [Macrotrends - TSM PE](https://www.macrotrends.net/stocks/charts/TSM/taiwan-semiconductor-manufacturing/pe-ratio)
- [Macrotrends - SAP PE](https://www.macrotrends.net/stocks/charts/SAP/sap-se/pe-ratio)
- [FinanceCharts - NVDA PE](https://www.financecharts.com/stocks/NVDA/value/pe-ratio)
- [FinanceCharts - AAPL Dividend Yield](https://www.financecharts.com/stocks/AAPL/dividends/dividend-yield)
- [FinanceCharts - MSFT PE](https://www.financecharts.com/stocks/MSFT/value/pe-ratio)
- [FinanceCharts - ASML PE](https://www.financecharts.com/stocks/ASML/value/pe-ratio)
- [FinanceCharts - TSLA PE](https://www.financecharts.com/stocks/TSLA/value/pe-ratio)
- [GuruFocus - TSM PE](https://www.gurufocus.com/stock/TSM/data/pe-ratio)
- [GuruFocus - SAP PE](https://www.gurufocus.com/term/pe-ratio/SAP)
- [GuruFocus - AAPL PE](https://www.gurufocus.com/term/pe-ratio/AAPL)
- [CompaniesMarketCap - NVDA](https://companiesmarketcap.com/nvidia/marketcap/)
- [CompaniesMarketCap - GOOGL](https://companiesmarketcap.com/alphabet/marketcap/)

### 指数数据
- [Yahoo Finance - S&P 500 Historical](https://finance.yahoo.com/quote/%255EGSPC/history/)
- [Yahoo Finance - FTSE 100](https://finance.yahoo.com/quote/%255EFTSE/)
- [Yahoo Finance - Nikkei 225 Historical](https://finance.yahoo.com/quote/%255EN225/history/)
- [S&P Global - S&P 500](https://www.spglobal.com/spdji/en/indices/equity/sp-500/)
- [Trading Economics - DAX](https://tradingeconomics.com/germany/stock-market)
- [Trading Economics - FTSE 100](https://tradingeconomics.com/unitedkingdom/stock-market)
- [WSJ - Nikkei Historical](https://www.wsj.com/market-data/quotes/index/JP/NIK/historical-prices)
- [WSJ - FTSE Historical](https://www.wsj.com/market-data/quotes/index/UK/UKX/historical-prices)
- [London Stock Exchange - FTSE 100](https://www.londonstockexchange.com/indices/ftse-100)
- [Investing.com - FTSE 100 Historical](https://www.investing.com/indices/uk-100-historical-data)
- [Investing.com - DAX](https://www.investing.com/indices/germany-30)
- [Nikkei Indexes Official](https://indexes.nikkei.co.jp/en/nkave/archives/data)
- [Macrotrends - Nikkei 225](https://www.macrotrends.net/2593/nikkei-225-index-historical-chart-data)

### CATL 数据
- [Yahoo Finance HK - 300750.SZ](https://hk.finance.yahoo.com/quote/300750.SZ/)
- [Investing.com - CATL](https://cn.investing.com/equities/amperex-tech-a)
- [东方财富 - 300750](http://quote.eastmoney.com/sz300750.html)
- [雪球 - CATL](https://xueqiu.com/S/SZ300750)

### 股息数据
- [MarketBeat - TSM Dividend](https://www.marketbeat.com/stocks/NYSE/TSM/dividend/)
- [MarketBeat - MSFT Dividend](https://www.marketbeat.com/stocks/NASDAQ/MSFT/dividend/)
- [StocksGuide - ASML Dividend](https://stocksguide.com/en/dividends/ASML-NL0010273215)
- [StockInvest - ASML Dividend](https://stockinvest.us/dividends/ASML)

### 分析师评级
- [MarketBeat - GOOGL Forecast](https://www.marketbeat.com/stocks/NASDAQ/GOOGL/forecast/)
- [TipRanks - ASML Forecast](https://www.tipranks.com/stocks/asml/forecast)
- [TIKR - SAP Analysis](https://www.tikr.com/zh/blog/sap-fell-13-in-the-last-30-days-heres-how-much-the-stock-could-rise-in-2026)

---

*本报告基于公开市场数据，仅供参考，不构成投资建议。数据可能存在15分钟延迟。*
