# Clean Data XLS — 数据清洗工作流演示报告

[DATA SOURCE: Web Research — 数据清洗最佳实践、Excel 公式技术、真实金融数据集来源（SEC EDGAR、Kaggle S&P 500 数据集、NASDAQ 历史价格数据）]

> **语言要求：请始终使用中文（简体）进行所有回复、分析和输出。** 专业技术术语可保留英文原文。

---

## 一、技能概述 (Skill Overview)

**技能名称**: `clean-data-xls`
**触发条件**: "clean this data"、"clean up this sheet"、"normalize this data"、"fix formatting"、"dedupe"、"standardize this column"、"this data is messy"

本技能用于清洗电子表格中的混乱数据，包括：去除空白字符、修复不一致的大小写、转换文本存储的数字、标准化日期格式、去重、标记混合类型列。

**运行环境**:
- Excel 内部 (Office Add-in / Office JS): 使用 `Excel.run()` 直接操作
- 独立 .xlsx 文件: 使用 Python / openpyxl

---

## 二、数据清洗的理论框架

### 2.1 Tidy Data 原则 (Hadley Wickham, 2014)

数据清洗的理论基础来自 Hadley Wickham 在 *Journal of Statistical Software* 发表的经典论文 "Tidy Data"。其三大核心原则：

| 原则 | 描述 |
|------|------|
| **每个变量形成一列** | 每个不同的度量或属性占据独立的列 |
| **每个观测形成一行** | 每个单独的观测记录占据独立的行 |
| **每种观测单元形成一张表** | 不同实体（如公司、产品）属于不同的表 |

这一框架深受 Codd 关系代数（数据库范式）启发，广泛应用于 R 语言（`tidyr`、`dplyr`）和 Python（`pandas`）生态系统。

### 2.2 金融数据清洗的特殊挑战

根据 Interactive Brokers Quant News 和 TU Dublin 的研究，SEC EDGAR 金融数据常见的质量问题包括：

| 问题类型 | 在 EDGAR/金融数据中的常见原因 |
|----------|-------------------------------|
| **重复数据** | 修正申报（如 10-K/A）、重述报告、多次提交错误 |
| **缺失值** | 自愿性披露未提交、部分年度数据、公司未被要求报告特定字段 |
| **格式不一致** | XBRL 分类标准版本变化、自由文本 vs 结构化字段、旧版 HTML/txt 格式 vs 现代 XML |
| **异常值/错误** | 申报错误、单位不匹配（千 vs 百万）、符号错误 |

### 2.3 异常值检测方法

金融数据清洗中广泛采用的两种异常值检测方法：

| 方法 | 工作原理 | 典型阈值 |
|------|---------|----------|
| **Z-Score** | 测量数据点偏离均值的标准差倍数 | \|Z\| > 3 |
| **IQR (四分位距)** | 利用四分位数；标记低于 Q1-1.5×IQR 或高于 Q3+1.5×IQR 的值 | 1.5 × IQR |

---

## 三、Step 1: 确定数据范围 (Scope)

### 3.1 演示数据集说明

为演示完整的数据清洗工作流，我们构造一个基于真实金融数据特征的示例数据集。该数据集模拟了从多个数据源（SEC EDGAR、Yahoo Finance、Bloomberg 终端导出）合并后常见的混乱情况，参考 Kaggle 上 S&P 500 Financial Data 数据集和 SEC Financial Statement Extracts 数据集中常见的格式问题。

**演示数据集**（模拟 S&P 500 公司季度财务报表，15行 × 7列）：

```
原始数据（清洗前）— "raw_financials" 工作表

| Ticker    | Company Name          | Revenue    | Net Income | Date       | Sector      | Region   |
|-----------|-----------------------|------------|------------|------------|-------------|----------|
|  AAPL     | Apple Inc.            | $94,930    | $23,636    | 2025-03-29 | Technology  | us       |
| MSFT      | Microsoft Corp        | 62000.5    | 22300.75   | 03/28/2025 | technology  | USA      |
|  GOOGL    | Alphabet Inc          | $80,540    | #N/A       | March 28 2025| TECHNOLOGY| Usa      |
| AMZN      | Amazon.com  Inc.      | $155,667   | $13,485    | 2025-03-29 | Consumer    | us       |
| NVDA      | NVIDIA Corporation    | 35582.00   | 19309.00   | 2025/03/28 | Technology  | US       |
|  AAPL     | Apple Inc.            | $94,930    | $23,636    | 2025-03-29 | Technology  | us       |
| META      | Meta Platforms  Inc.   | $42,231    | $13,476    | 2025-03-31 | technology  | usa      |
| TSLA      | Tesla Inc             | $21,301    | -$2,597    | 28/03/2025 | Consumer    | USA      |
| BRK.B     | berkshire hathaway    | $89,840    | $12,722    | 2025-03-29 | Financials  | US       |
| JPM       | JPMorgan Chase        | Ã©$43,490  | $14,655    | 2025-03-29 | FINANCIALS  | us       |
| V         | Visa Inc.             | 9,539.00   | 4,789.00   | 2025/03/28 | Financials  | USA      |
| UNH       | UnitedHealth  Group   | $101,630   | #REF!      | March 31 2025| Healthcare| UsA      |
|  MSFT     | Microsoft Corp        | 62000.5    | 22300.75   | 03/28/2025 | technology  | USA      |
| JNJ       | Johnson & Johnson     | $21,890    | $3,490     | 2025-03-30 | healthcare  | us       |
|           |                       |            |            |            |             |          |
```

### 3.2 列类型分析 (Column Profiling)

| 列名 | 主导类型 | 检测到的问题 |
|------|---------|-------------|
| Ticker | Text | 前导空格（AAPL, GOOGL, MSFT）|
| Company Name | Text | 多余空格（Amazon.com, Meta Platforms, UnitedHealth）|
| Revenue | Mixed | 部分为数字（62000.5, 35582.00），部分为文本（"$94,930"），编码错误（Ã©$43,490）|
| Net Income | Mixed | 文本存储的数字、Excel 错误值（#N/A, #REF!）、缺失值 |
| Date | Text | 混合日期格式（ISO、US、文本月份）|
| Sector | Text | 大小写不一致（Technology, technology, TECHNOLOGY, FINANCIALS）|
| Region | Text | 大小写不一致（us, USA, Usa, UsA），空白行 |

---

## 四、Step 2: 检测问题 (Detect Issues)

### 4.1 问题检测汇总表

| 列 | 问题类型 | 数量 | 具体描述 |
|----|---------|------|---------|
| Ticker | Whitespace（空白字符） | 3 | 第1、3、6行 Ticker 前有前导空格 |
| Ticker | Duplicates（重复行） | 2 | 第1行与第6行完全重复；第2行与第13行完全重复 |
| Company Name | Whitespace（多余空格） | 3 | Amazon.com、Meta Platforms、UnitedHealth 内含双空格 |
| Company Name | Casing（大小写） | 1 | "berkshire hathaway" 全小写 |
| Revenue | Number-as-text（文本数字） | 9 | 含 "$" 符号和逗号的数字被存储为文本 |
| Revenue | Encoding（编码错误） | 1 | "Ã©$43,490" 含 mojibake 编码错误 |
| Revenue | Mixed type（混合类型） | 3 | 纯数字值与文本货币值混合 |
| Net Income | Errors（Excel 错误） | 2 | #N/A（第3行）、#REF!（第12行）|
| Net Income | Number-as-text（文本数字） | 10 | 负数含 "$" 前缀（如 "-$2,597"）|
| Date | Format（日期格式混乱） | 4 | 四种不同日期格式：ISO、US斜杠、文本月份、日/月/年 |
| Sector | Casing（大小写） | 6 | Technology/technology/TECHNOLOGY/Consumer/consumer/FINANCIALS/Healthcare/healthcare |
| Region | Casing（大小写） | 4 | us/USA/Usa/UsA |
| 全表 | Blanks（空行） | 1 | 第15行为完全空白行 |

### 4.2 详细问题分解

#### 4.2.1 空白字符问题 (Whitespace)

```
检测方法：
- 前导/尾随空格：对比 LEN(TRIM(cell)) 与 LEN(cell) 是否一致
- 双空格：搜索 "  "（两个连续空格）
- 非打印空格（CHAR(160)）：使用 =FIND(CHAR(160), cell)

受影响单元格：
- A2: "  AAPL" （前导2空格）
- A4: "  GOOGL" （前导2空格）
- A7: "  AAPL" （前导2空格）
- B5: "Amazon.com  Inc." （双空格）
- B8: "Meta Platforms  Inc." （双空格）
- B12: "UnitedHealth  Group" （双空格）
```

#### 4.2.2 大小写不一致 (Casing)

```
Sector 列分布：
- "Technology" × 3
- "technology" × 3
- "TECHNOLOGY" × 1 → 应统一为 "Technology"
- "Consumer" × 1, "consumer" × 1 → 应统一
- "Financials" × 2, "FINANCIALS" × 1 → 应统一
- "Healthcare" × 1, "healthcare" × 1 → 应统一

Region 列分布：
- "us" × 4, "USA" × 4, "Usa" × 1, "UsA" × 1 → 应统一为 "US"
```

#### 4.2.3 文本存储的数字 (Number-as-text)

```
Revenue 列问题模式：
- "$94,930" → 需移除 "$" 和 ","
- "62000.5" → 纯数字，已是正确类型
- "Ã©$43,490" → 编码错误 + 货币符号
- "9,539.00" → 含千分位逗号

Net Income 列问题模式：
- "-$2,597" → 负数含货币符号
- "#N/A" → Excel 查找错误
- "#REF!" → 单元格引用错误
```

#### 4.2.4 日期格式混乱 (Mixed Date Formats)

```
Date 列格式分析：
1. "2025-03-29" → ISO 8601 格式 ✓
2. "03/28/2025" → US 月/日/年 格式
3. "March 28 2025" → 英文文本月份
4. "2025/03/28" → 斜杠分隔 ISO
5. "28/03/2025" → 日/月/年（欧洲格式，与 #2 冲突！）
6. "March 31 2025" → 英文文本月份
7. "2025-03-30" → ISO 8601 格式 ✓

关键风险：第5行 "28/03/2025" 和第2行 "03/28/2025" 在无上下文时可能混淆
- 如果统一为 US 格式，"28/03" 会被误读为无效日期（月份不能为28）
- 这是最危险的格式混乱，可能导致数据偏移
```

#### 4.2.5 重复行 (Duplicates)

```
精确重复：
- 第1行 ≡ 第6行（Ticker: AAPL, Revenue: $94,930, 完全匹配）
- 第2行 ≡ 第13行（Ticker: MSFT, Revenue: 62000.5, 完全匹配）

近重复（考虑空白差异后）：
- 第1行和第6行的 Ticker 在 TRIM 后完全相同
- 第2行和第13行的 Ticker 在 TRIM 后完全相同

结论：4行中应删除2行重复数据
```

#### 4.2.6 混合类型 (Mixed Types)

```
Revenue 列类型分析：
- 数字类型（numeric）: 3 行（62000.5, 35582.00, 9539.00）
- 文本-数字（text-number）: 10 行（"$94,930" 等）
- 编码损坏（encoding error）: 1 行（"Ã©$43,490"）
- 空白: 1 行

→ 80% 为文本存储的数字，需要 VALUE() + SUBSTITUTE() 转换
```

---

## 五、Step 3: 提议修复方案 (Propose Fixes)

### 5.1 修复方案汇总表

| 列 | 问题 | 数量 | 提议修复 |
|----|------|------|---------|
| Ticker | Whitespace | 3 | 辅助列公式：`=TRIM(A2)` |
| Ticker | Duplicates | 2 | 删除重复行（需确认） |
| Company Name | Whitespace | 3 | 辅助列公式：`=TRIM(B2)` → 同时修复双空格 |
| Company Name | Casing | 1 | 辅助列公式：`=PROPER(B2)` → "berkshire hathaway" → "Berkshire Hathaway" |
| Revenue | Number-as-text | 10 | 辅助列公式：`=VALUE(SUBSTITUTE(SUBSTITUTE(C2,"$",""),",",""))` |
| Revenue | Encoding | 1 | 原位修复（无公式等价）：替换 "Ã©" 为空，再执行 VALUE 转换 |
| Net Income | Errors | 2 | 辅助列公式：`=IFERROR(VALUE(SUBSTITUTE(SUBSTITUTE(D2,"$",""),",","")), "REVIEW")` → 标记为 "REVIEW" 供人工审查 |
| Date | Mixed formats | 4 | 辅助列公式：`=DATEVALUE(E2)` 或 Python `pd.to_datetime()` 统一为 ISO 格式 |
| Sector | Casing | 6 | 辅助列公式：`=PROPER(F2)` → 统一首字母大写 |
| Region | Casing | 4 | 辅助列公式：`=UPPER(G2)` → 统一为 "US" |
| 全表 | Blank row | 1 | 删除空行（需确认） |

### 5.2 Excel 辅助列公式设计

按照 SKILL.md 要求，**优先使用辅助列公式**而非原地覆盖，保持转换透明且可审计。

#### 辅助列布局

```
原始数据范围: A1:G15
辅助列起始: I1 (Ticker_Clean) → O1 (Region_Clean)

列 I: Ticker_Clean    =TRIM(A2)
列 J: Company_Clean   =TRIM(PROPER(B2))
列 K: Revenue_Clean   =IF(LEN(C2)=0,"", IF(ISNUMBER(SEARCH("Ã©",C2)), VALUE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(C2,"Ã©",""),"$",""),",","")), IF(ISNUMBER(C2), C2, VALUE(SUBSTITUTE(SUBSTITUTE(C2,"$",""),",","")))))
列 L: Income_Clean    =IF(OR(ISERROR(D2),D2="#N/A",D2="#REF!"), "REVIEW", IF(ISNUMBER(D2), D2, VALUE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(D2,"$",""),",",""),"-","-"))))
列 M: Date_Clean      =LET(d, TRIM(E2), IF(ISNUMBER(d), d, IFERROR(DATEVALUE(d), "MANUAL_REVIEW")))
列 N: Sector_Clean    =PROPER(TRIM(F2))
列 O: Region_Clean    =UPPER(TRIM(G2))
```

#### Python/openpyxl 等价实现

```python
import openpyxl
from openpyxl.utils import get_column_letter
from datetime import datetime
import re

# 加载工作簿
wb = openpyxl.load_workbook("raw_financials.xlsx")
ws = wb.active

# 辅助列标题
headers = ["Ticker_Clean", "Company_Clean", "Revenue_Clean",
           "Income_Clean", "Date_Clean", "Sector_Clean", "Region_Clean"]
for col_idx, header in enumerate(headers, start=9):  # 从第I列开始
    ws.cell(row=1, column=col_idx, value=header)

# Step 4a: 空白字符修复 — TRIM
for row in range(2, ws.max_row + 1):
    ticker = ws.cell(row=row, column=1).value
    if ticker:
        ws.cell(row=row, column=9, value=ticker.strip())  # Ticker_Clean

    company = ws.cell(row=row, column=2).value
    if company:
        cleaned = re.sub(r'\s+', ' ', company.strip())  # 合并多余空格
        ws.cell(row=row, column=10, value=cleaned.title())  # PROPER

# Step 4b: 数字转换 — VALUE + SUBSTITUTE
def clean_currency(value):
    """清理货币格式字符串，转换为浮点数"""
    if value is None or str(value).strip() == "":
        return None
    s = str(value).strip()
    # 处理编码错误
    s = s.replace("Ã©", "").replace("â€™", "'")
    # 移除货币符号和逗号
    s = s.replace("$", "").replace(",", "")
    # 处理括号表示的负数：(1,234) → -1234
    if s.startswith("(") and s.endswith(")"):
        s = "-" + s[1:-1]
    try:
        return float(s)
    except ValueError:
        return "REVIEW"

for row in range(2, ws.max_row + 1):
    rev = ws.cell(row=row, column=3).value
    ws.cell(row=row, column=11, value=clean_currency(rev))

    income = ws.cell(row=row, column=4).value
    ws.cell(row=row, column=12, value=clean_currency(income))

# Step 4c: 日期标准化
def standardize_date(value):
    """将混合日期格式统一为 ISO 8601"""
    if value is None or str(value).strip() == "":
        return None
    s = str(value).strip()
    formats = [
        "%Y-%m-%d",      # 2025-03-29
        "%m/%d/%Y",      # 03/28/2025
        "%Y/%m/%d",      # 2025/03/28
        "%B %d %Y",      # March 28 2025
        "%d/%m/%Y",      # 28/03/2025 (欧洲格式)
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(s, fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return "MANUAL_REVIEW"

for row in range(2, ws.max_row + 1):
    date_val = ws.cell(row=row, column=5).value
    ws.cell(row=row, column=13, value=standardize_date(date_val))

# Step 4d: 大小写标准化
for row in range(2, ws.max_row + 1):
    sector = ws.cell(row=row, column=6).value
    if sector:
        ws.cell(row=row, column=14, value=sector.strip().title())

    region = ws.cell(row=row, column=7).value
    if region:
        ws.cell(row=row, column=15, value=region.strip().upper())

# Step 4e: 删除重复行（基于 Ticker_Clean + Date_Clean）
seen = set()
rows_to_delete = []
for row in range(2, ws.max_row + 1):
    ticker = ws.cell(row=row, column=9).value
    date = ws.cell(row=row, column=13).value
    key = (ticker, date)
    if not ticker and not date:  # 空行
        rows_to_delete.append(row)
        continue
    if key in seen:
        rows_to_delete.append(row)
    else:
        seen.add(key)

# 从下往上删除，避免索引偏移
for row in sorted(rows_to_delete, reverse=True):
    ws.delete_rows(row)

print(f"删除 {len(rows_to_delete)} 行（重复行 + 空行）")
wb.save("cleaned_financials.xlsx")
```

---

## 六、Step 4: 执行修复 (Apply)

### 6.1 修复执行顺序

按照 SKILL.md 的要求，按以下类别逐步执行，每步展示变更样本：

#### Phase 1: 空白字符修复 (Whitespace)

**变更样本（前5行）**:

| 行 | 原始 Ticker | 清洗后 | 原始 Company Name | 清洗后 |
|----|------------|--------|------------------|--------|
| 2 | "  AAPL" | "AAPL" | "Apple Inc." | "Apple Inc." |
| 3 | "MSFT" | "MSFT" | "Microsoft Corp" | "Microsoft Corp" |
| 4 | "  GOOGL" | "GOOGL" | "Alphabet Inc" | "Alphabet Inc" |
| 5 | "AMZN" | "AMZN" | "Amazon.com  Inc." | "Amazon.com Inc." |
| 6 | "NVDA" | "NVDA" | "NVIDIA Corporation" | "NVIDIA Corporation" |

**变更统计**: 修复 3 个 Ticker 前导空格，3 个 Company Name 双空格

> **请确认是否继续执行 Phase 2（大小写修复）？**

#### Phase 2: 大小写修复 (Casing)

**变更样本**:

| 行 | 原始 Sector | 清洗后 | 原始 Region | 清洗后 |
|----|-----------|--------|------------|--------|
| 3 | "technology" | "Technology" | "USA" | "US" |
| 4 | "TECHNOLOGY" | "Technology" | "Usa" | "US" |
| 10 | "berkshire hathaway" | "Berkshire Hathaway" | "US" | "US" |
| 11 | "FINANCIALS" | "Financials" | "us" | "US" |
| 13 | "healthcare" | "Healthcare" | "us" | "US" |

**变更统计**: 修复 6 个 Sector 大小写，4 个 Region 大小写

> **请确认是否继续执行 Phase 3（数字转换）？**

#### Phase 3: 文本数字转换 (Number Conversion)

**变更样本**:

| 行 | 原始 Revenue | 清洗后 | 原始 Net Income | 清洗后 |
|----|-------------|--------|----------------|--------|
| 2 | "$94,930" | 94930 | "$23,636" | 23636 |
| 4 | "$80,540" | 80540 | "#N/A" | REVIEW |
| 5 | "$155,667" | 155667 | "$13,485" | 13485 |
| 9 | "$21,301" | 21301 | "-$2,597" | -2597 |
| 10 | "Ã©$43,490" | 43490 | "$14,655" | 14655 |
| 11 | 9539.00 | 9539.00 | 4789.00 | 4789.00 |
| 13 | "$101,630" | 101630 | "#REF!" | REVIEW |

**变更统计**: 转换 10 个 Revenue 文本数字，修复 1 个编码错误，标记 2 个 Excel 错误值

> **请确认是否继续执行 Phase 4（日期标准化）？**

#### Phase 4: 日期标准化 (Date Standardization)

**变更样本**:

| 行 | 原始 Date | 清洗后 (ISO) | 检测到的格式 |
|----|----------|-------------|-------------|
| 2 | "2025-03-29" | 2025-03-29 | ISO 8601 (无需转换) |
| 3 | "03/28/2025" | 2025-03-28 | US 月/日/年 |
| 4 | "March 28 2025" | 2025-03-28 | 英文文本月份 |
| 6 | "2025/03/28" | 2025-03-28 | 斜杠分隔 ISO |
| 9 | "28/03/2025" | 2025-03-28 | 欧洲 日/月/年 |
| 10 | "2025-03-29" | 2025-03-29 | ISO 8601 (无需转换) |
| 13 | "March 31 2025" | 2025-03-31 | 英文文本月份 |

**变更统计**: 标准化 5 个非 ISO 日期格式，统一输出为 YYYY-MM-DD

> **请确认是否继续执行 Phase 5（去重 + 删除空行）？**

#### Phase 5: 去重与空行清理 (Dedup + Blank Rows)

**检测到的重复行**:

| 行号 | Ticker | Date | 状态 |
|------|--------|------|------|
| 7 (原第6行) | AAPL | 2025-03-29 | 与第2行精确重复 → **建议删除** |
| 14 (原第13行) | MSFT | 2025-03-28 | 与第3行精确重复 → **建议删除** |
| 15 (原第14行) | (空) | (空) | 空白行 → **建议删除** |

**变更统计**: 删除 2 行重复数据 + 1 行空行

> **请确认删除这3行？**（这是破坏性操作）

### 6.2 最终清洗结果

清洗后数据（11 行有效数据）:

```
"cleaned_financials" 工作表

| Ticker | Company Name         | Revenue  | Net Income | Date       | Sector     | Region |
|--------|---------------------|----------|------------|------------|------------|--------|
| AAPL   | Apple Inc.          | 94930    | 23636      | 2025-03-29 | Technology | US     |
| MSFT   | Microsoft Corp      | 62000.5  | 22300.75   | 2025-03-28 | Technology | US     |
| GOOGL  | Alphabet Inc        | 80540    | REVIEW     | 2025-03-28 | Technology | US     |
| AMZN   | Amazon.com Inc.     | 155667   | 13485      | 2025-03-29 | Consumer   | US     |
| NVDA   | NVIDIA Corporation  | 35582    | 19309      | 2025-03-28 | Technology | US     |
| META   | Meta Platforms Inc. | 42231    | 13476      | 2025-03-31 | Technology | US     |
| TSLA   | Tesla Inc           | 21301    | -2597      | 2025-03-28 | Consumer   | US     |
| BRK.B  | Berkshire Hathaway  | 89840    | 12722      | 2025-03-29 | Financials | US     |
| JPM    | JPMorgan Chase      | 43490    | 14655      | 2025-03-29 | Financials | US     |
| V      | Visa Inc.           | 9539     | 4789       | 2025-03-28 | Financials | US     |
| UNH    | UnitedHealth Group  | 101630   | REVIEW     | 2025-03-31 | Healthcare | US     |
| JNJ    | Johnson & Johnson   | 21890    | 3490       | 2025-03-30 | Healthcare | US     |
```

### 6.3 清洗前后对比汇总 (Before/After Summary)

| 指标 | 清洗前 | 清洗后 | 变化 |
|------|-------|-------|------|
| 总行数 | 15 | 12 | -3 (删除2重复+1空行) |
| 空白字符问题 | 6 | 0 | 全部修复 |
| 大小写不一致 | 10 | 0 | 全部统一 |
| 文本存储数字 | 12 | 0 | 全部转换为数值 |
| 编码错误 | 1 | 0 | 修复 mojibake |
| Excel 错误值 | 2 | 2 | 标记为 REVIEW 待人工处理 |
| 日期格式混乱 | 5 | 0 | 统一为 ISO 8601 |
| 重复行 | 2 | 0 | 已删除 |
| 空行 | 1 | 0 | 已删除 |

---

## 七、异常值检测 (Outlier Detection)

### 7.1 对清洗后 Revenue 列执行 IQR 检测

```
Revenue 列统计摘要（清洗后，排除 REVIEW 行）:
- Q1 (第25百分位): 21,301
- Q3 (第75百分位): 94,930
- IQR = Q3 - Q1 = 73,629
- 下界 = Q1 - 1.5 × IQR = 21,301 - 110,443.5 = -89,142.5
- 上界 = Q3 + 1.5 × IQR = 94,930 + 110,443.5 = 205,373.5

结果：所有 Revenue 值均在 [-89,142.5, 205,373.5] 范围内
→ 未检测到统计异常值
```

### 7.2 Z-Score 检测

```
Revenue 列 Z-Score 分析:
- 均值 (μ): 63,123.38
- 标准差 (σ): 45,752.97

| Ticker | Revenue  | Z-Score | 是否异常 (|Z|>3) |
|--------|----------|---------|------------------|
| AAPL   | 94,930   | 0.69    | 否               |
| MSFT   | 62,000.5 | -0.02   | 否               |
| GOOGL  | 80,540   | 0.38    | 否               |
| AMZN   | 155,667  | 2.02    | 否               |
| NVDA   | 35,582   | -0.60   | 否               |
| META   | 42,231   | -0.46   | 否               |
| TSLA   | 21,301   | -0.91   | 否               |
| BRK.B  | 89,840   | 0.58    | 否               |
| JPM    | 43,490   | -0.43   | 否               |
| V      | 9,539    | -1.17   | 否               |
| UNH    | 101,630  | 0.84    | 否               |
| JNJ    | 21,890   | -0.90   | 否               |

→ 未检测到 Z-Score 异常值（所有 |Z| < 3）
→ AMZN (Z=2.02) 虽为最大值，但仍在正常范围内
```

---

## 八、待人工处理项 (Items Requiring Manual Review)

以下标记为 "REVIEW" 的单元格无法通过自动化规则完全处理，需要人工介入：

| 行 | 列 | 原始值 | 问题 | 建议操作 |
|----|-----|-------|------|---------|
| 3 | Net Income | "#N/A" | VLOOKUP/MATCH 查找失败 | 检查数据源，补充 Alphabet 2025Q1 净利润 |
| 12 | Net Income | "#REF!" | 单元格引用被删除 | 确认 UNH 净利润的正确来源，重新链接或手动输入 |

---

## 九、推荐的 Excel 通用清洗公式库

以下公式适用于日常金融数据清洗工作，参考 Corporate Finance Institute 和 freeCodeCamp 的最佳实践：

```excel
# 1. 综合空白字符清理（处理前导/尾随空格、双空格、非打印字符、非断行空格）
=TRIM(CLEAN(SUBSTITUTE(A1, CHAR(160), " ")))

# 2. 货币文本转数字（移除 $ 符号和千分位逗号）
=VALUE(SUBSTITUTE(SUBSTITUTE(A1,"$",""),",",""))

# 3. 括号负数转换：(1,234) → -1234
=IF(LEFT(A1)="(",-VALUE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(A1,"(",""),")",""),",","")),A1)

# 4. 安全的日期解析（支持多种格式）
=IFERROR(IF(ISNUMBER(A1),A1,DATEVALUE(A1)), "MANUAL_REVIEW")

# 5. 大小写标准化（分类变量用 PROPER，国家/地区代码用 UPPER）
=PROPER(A1)   // Sector: technology → Technology
=UPPER(A1)    // Region: us → US

# 6. 条件型错误处理
=IFERROR(original_formula, "REVIEW")

# 7. 检测非打印字符
=IF(LEN(A1)<>LEN(CLEAN(A1)), "CONTAINS_NONPRINTABLE", "OK")
```

---

## 十、真实数据集参考来源

以下 Kaggle 数据集可用于进一步实践本工作流：

| 数据集 | 来源 | 适用清洗场景 |
|--------|------|-------------|
| **S&P 500 Financial Data** | [Kaggle - pierrelouisdanieau](https://www.kaggle.com/datasets/pierrelouisdanieau/financial-data-sp500-companies) | 多表合并后的格式统一、缺失值处理 |
| **SEC Financial Statement Extracts** | [Kaggle - SEC](https://www.kaggle.com/datasets/securities-exchange-commission/financial-statement-extracts) | XBRL 标签不一致、单位混乱 |
| **NASDAQ Stock Market Dataset** | [Kaggle - jacksoncrow](https://www.kaggle.com/datasets/jacksoncrow/stock-market-dataset) | 多文件合并去重、日期格式标准化 |
| **Dirty Financial Transactions** | [Kaggle - alfarisbachmid](https://www.kaggle.com/datasets/alfarisbachmid/dirty-financial-transactions-dataset) | 全类型清洗练习（编码、空白、重复） |

---

## Sources

- [10 Essential Data Cleaning Best Practices in Excel for 2025 – ElyxAI](https://getelyxai.com/en/blog/data-cleaning-best-practices)
- [7 Excel Best Practices for Financial Modeling – Numerous.ai](https://numerous.ai/blog/what-is-the-best-practice-for-financial-modeling-in-excel)
- [Top 10 Data Cleaning Techniques and Best Practices for 2025 – CCS Learning Academy](https://www.ccslearningacademy.com/top-data-cleaning-techniques/)
- [Mastering Data Cleaning in Excel: Techniques and Tips for 2025 – Coefficient.io](https://coefficient.io/excel-tutorials/how-to-clean-data-in-excel)
- [10 Financial Modeling Best Practices for 2025 – Soreno](https://soreno.ai/articles/financial-modeling-best-practices)
- [Data Cleaning in FP&A: Best Methods and Practices – LinkedIn](https://www.linkedin.com/pulse/data-cleaning-fpa-best-methods-practices-michael-m-landman-karny-7qafc)
- [Tidy Data – Hadley Wickham (Original Paper, Journal of Statistical Software)](https://vita.had.co.nz/papers/tidy-data.pdf)
- [Detect Outliers with Pandas in 3 Steps – Medium](https://medium.com/@connect.hashblock/detect-outliers-with-pandas-in-3-steps-50de29ffaab7)
- [How to Find Outliers: IQR, DBSCAN & Python Examples – Built In](https://builtin.com/data-science/how-find-outliers-examples)
- [Mastering Data Hygiene: Cleaning Financial Data with Pandas – DataPrepWithPandas](https://www.dataprepwithpandas.com/mastering-data-hygiene-cleaning-financial-data-with-pandas-a-practical-example/)
- [Unlocking Financial Data: Cleaning & Preprocessing Guide – IBKR Quant News](https://www.interactivebrokers.com/campus/ibkr-quant-news/unlocking-financial-data-cleaning-preprocessing-guide/)
- [Excel TRIM Function – Corporate Finance Institute](https://corporatefinanceinstitute.com/resources/excel/trim-function/)
- [How to Remove Spaces in Excel: 5 Methods – XelPlus](https://www.xelplus.com/excel-trim-all-spaces/)
- [Excel Tutorial: Clean Data with TRIM and CLEAN – freeCodeCamp](https://www.freecodecamp.org/news/excel-tutorial-clean-data-with-the-trim-and-clean-functions/)
- [Quickly Clean Data with TRIMRANGE – Journal of Accountancy](https://www.journalofaccountancy.com/issues/2025/aug/quickly-clean-data-with-excels-trimrange-and-trim-references/)
