[DATA SOURCE: WebSearch — CrowdStrike IR (ir.crowdstrike.com), Palo Alto Networks IR (investors.paloaltonetworks.com), Zscaler IR (ir.zscaler.com), Fortinet IR (fortinet.com), Datadog IR (investors.datadoghq.com), Cloudflare IR (cloudflare.net), monday.com IR (ir.monday.com), HubSpot IR (ir.hubspot.com), CyberArk IR (cyberark.com), Rapid7 IR (investors.rapid7.com), Tenable IR (tenable.com), Qualys IR (qualys.com), Software Equity Group, BCG, McKinsey, S&P Global, Momentum Cyber, SaasRise, Finro, Windsor Drake, Multiples.vc, QuantPillar]

---

# 私募股权交易筛选备忘录
## PE Deal Screening Memo — B2B SaaS: 网络安全 / 云管理 / 数据基础设施

**筛选日期**: 2026年5月9日
**筛选分析师**: PE Investment Team
**基金策略**: 中大型市场私募股权（Min $50M ARR, 20%+ 增长, 70%+ 毛利率）
**目标板块**: B2B SaaS — 网络安全、云管理、数据基础设施

---

## 第一部分：投资筛选标准 (Step 2 — Screen Against Criteria)

本筛选应用以下基金投资标准，对公开市场可比公司及潜在私有标的进行评估：

| 筛选指标 | 基金目标 | 说明 |
|----------|----------|------|
| ARR 范围 | >= $50M | 中大型市场标的 |
| EBITDA 利润率 | >= 15%（Non-GAAP） | 可持续盈利能力 |
| 毛利率 | >= 70% | SaaS 模式健康度 |
| ARR 增长率 | >= 20% YoY | 高质量增长 |
| 板块契合度 | 网络安全 / 云管理 / 数据基础设施 | 核心能力圈 |
| 地理范围 | 全球（优先北美/欧洲） | 成熟市场 |
| 交易规模 | $200M–$5B EV | 基金规模匹配 |
| 估值倍数 | <= 10x ARR（私有标的） | 估值纪律 |
| 客户集中度 | 无单一客户 >10% | 收入分散性 |
| 管理层连续性 | 关键管理层愿意留任 | 执行力保障 |
| Rule of 40 | >= 40% | 增长+利润率综合评估 |
| NRR（净收入留存率） | >= 110% | 客户粘性指标 |
| LTV/CAC | >= 3:1 | 单位经济模型健康 |

---

## 第二部分：公开市场可比基准 (Comparable Benchmarks)

以下为公开市场可比公司的最新财务数据（来源：公司IR公告、SEC文件），用于建立估值基准和筛选参考。

### 2.1 网络安全板块 (Cybersecurity)

| 公司 | 代码 | ARR / 年收入 | ARR增长率 | 毛利率 | Non-GAAP营业利润率 | Rule of 40 | NRR |
|------|------|-------------|-----------|--------|-------------------|-----------|-----|
| CrowdStrike | CRWD | $5.25B (ARR) | 24% | ~81% | 22% | 46% | ~120%+ |
| Palo Alto Networks | PANW | $6.3B (NGS ARR) | 33% | ~75% | 30.3% | 63% | ~115%+ |
| Zscaler | ZS | $3.4B (ARR) | 25% | ~78% | 22% | 47% | ~118% |
| Fortinet | FTNT | ~$7.4B (年收入指引) | 20% | ~80% | 35.8% | 56% | ~110% |
| CyberArk | CYBR | $1.44B (ARR) | 23% | ~78% | ~18% | 41% | ~115% |
| Rapid7 | RPD | $832M (ARR) | ~0% | 72% | 15.8% | 16% | ~105% |
| Tenable | TENB | ~$1.05B (年收入) | 11% | ~76% | ~14% | 25% | ~110% |
| Qualys | QLYS | ~$600M (年收入) | ~7% | ~82% | ~28% | 35% | ~108% |

### 2.2 云管理与数据基础设施板块 (Cloud Management & Data Infra)

| 公司 | 代码 | ARR / 年收入 | ARR增长率 | 毛利率 | Non-GAAP营业利润率 | Rule of 40 | NRR |
|------|------|-------------|-----------|--------|-------------------|-----------|-----|
| Datadog | DDOG | ~$4.32B (FY26指引) | 25-27% | ~80% | 22% | 47-49% | ~120%+ |
| Cloudflare | NET | ~$2.8B (FY26指引) | 28-30% | ~71% | ~15% | 43-45% | ~115% |
| monday.com | MNDY | $1.34B (ARR) | 19-20% | ~89-90% | ~14% | 33-34% | 111% |
| HubSpot | HUBS | ~$3.7B (FY26指引) | 18-20% | ~83% | ~20% | 38-40% | ~110% |

---

## 第三部分：筛选结果与评估 (Step 1 & 2 — Extract & Screen)

### 3.1 一级通过 (Tier 1 — Strong Pass)

**通过所有核心筛选标准，为高优先级跟踪标的**

#### (A) CrowdStrike Holdings (CRWD) — 参考基准

- **公司**: CrowdStrike Holdings, Inc. | 总部: Austin, TX | 板块: 端点安全 / XDR / 云安全
- **描述**: 全球领先的云原生端点安全平台，提供Falcon平台覆盖端点、云工作负载、身份和数据的全方位威胁检测与响应。
- **财务数据**:
  - ARR: $5.25B (+24% YoY)
  - FY2026收入: $4.812B (+21.7% YoY)
  - 订阅毛利率: ~81%
  - Non-GAAP营业利润率: 22%
  - Rule of 40: 46%（24%增长 + 22%利润率）
  - 净新ARR: Q4 FY2026新增$330.7M
- **评估**: **PASS** — 超出所有筛选标准。作为基准公司，其估值倍数（预计15x+ ARR）对私募市场标的具有参考意义。但公开市场估值较高，更适合作为战略买家而非PE直接收购目标。
- **关键风险**: 估值极高（EV/Revenue >15x）；2024年全球IT中断事件对品牌的长期影响尚待观察。

#### (B) Palo Alto Networks (PANW) — 参考基准

- **公司**: Palo Alto Networks, Inc. | 总部: Santa Clara, CA | 板块: 网络安全 / SASE / 云安全
- **描述**: 全球最大的纯网络安全公司，通过平台化战略提供下一代防火墙、Prisma Cloud、Cortex XSIAM等全线产品。
- **财务数据**:
  - NGS ARR: $6.3B (+33% YoY)
  - FY2026 Q2收入: $2.6B (+15% YoY)
  - Non-GAAP营业利润率: 30.3%
  - 全年指引: 总收入$11.28-11.31B
  - Rule of 40: 63%（33% ARR增长 + 30%利润率）
- **评估**: **PASS** — 行业标杆。极强盈利能力和加速增长的ARR。但市值超过$1,200亿，超出PE收购范围。作为平台收购方参考。
- **关键风险**: 平台化策略执行风险；活跃的收购策略（收购Chronosphere $3.35B）增加整合复杂度。

#### (C) Zscaler (ZS) — 参考基准

- **公司**: Zscaler, Inc. | 总部: San Jose, CA | 板块: 云安全 / SASE / Zero Trust
- **描述**: 云原生安全服务边缘（SSE）领导者，提供Zero Trust架构下的安全Web网关、云访问安全代理和数据保护。
- **财务数据**:
  - ARR: $3.4B (+25% YoY，含Red Canary收购)
  - 有机ARR增长: ~21%
  - Q2 FY2026收入: $816M (+26% YoY)
  - Non-GAAP营业利润率: 22%+
  - Rule of 40: 47%
- **评估**: **PASS** — 各项指标健康。但2026年股价下跌约33%，可能反映估值压力。作为可比公司估值参考。
- **关键风险**: Red Canary收购整合风险（$114M ARR贡献）；GAAP净利润仍为负。

#### (D) Datadog (DDOG) — 参考基准

- **公司**: Datadog, Inc. | 总部: New York, NY | 板块: 可观测性 / 数据基础设施 / 云管理
- **描述**: 统一可观测性和安全平台，提供基础设施监控、APM、日志管理、安全监控和云成本管理。
- **财务数据**:
  - Q1 FY2026收入: $1.006B (+32% YoY)
  - FY2026收入指引: $4.30-4.34B（上调，+25-27% YoY）
  - Non-GAAP营业利润率: 22%
  - GAAP营业利润率: 1%（首次转正）
  - 自由现金流: $289M（Q1）
  - $100K+ ARR客户: ~4,550
- **评估**: **PASS** — 增长加速，利润率扩张，AI驱动增长强劲。作为数据基础设施板块核心可比公司。
- **关键风险**: GAAP利润率极低；产品线扩张带来的执行风险；估值倍数仍高。

---

### 3.2 二级通过 (Tier 2 — Conditional Pass)

**通过大部分筛选标准，但存在1-2个需要深入尽调的关注点**

#### (E) CyberArk Software (CYBR)

- **公司**: CyberArk Software Ltd. | 总部: Petah Tikva, Israel / Newton, MA | 板块: 身份安全 / PAM / IGA
- **描述**: 特权访问管理（PAM）和身份安全领域的全球领导者，通过SaaS转型高速增长，服务企业级客户。
- **财务数据**:
  - ARR: $1.44B (+23% YoY)
  - FY2025收入: $1.361B (+36% YoY)
  - 订阅收入: $1.105B (+51% YoY)
  - Rule of 40: 41%
- **评估**: **CONDITIONAL PASS** — 增长强劲，SaaS转型进展出色。但作为以色列公司地缘政治风险需评估。从PE角度看，$1.44B ARR规模适合大型PE交易。
- **关注点**: SaaS转型完成度（仍有部分本地部署收入）；以色列总部带来的地缘风险。
- **关键问题**: (1) SaaS转型后NRR趋势如何？(2) 有机增长vs.收购贡献占比？(3) 中东地缘风险溢价如何定价？

#### (F) Cloudflare (NET)

- **公司**: Cloudflare, Inc. | 总部: San Francisco, CA | 板块: 云基础设施 / CDN / 网络安全 / 边缘计算
- **描述**: 全球边缘云平台，提供CDN、DDoS防护、WAF、Workers无服务器计算和Zero Trust安全服务。
- **财务数据**:
  - FY2025收入: ~$2.14B
  - Q4 FY2025收入: $614.5M (+33.6% YoY)
  - FY2026收入指引: $2.79-2.80B
  - 毛利率: ~71%（Q1 FY2026）
  - 10年收入CAGR: 44.1%
- **评估**: **CONDITIONAL PASS** — 增长极佳，但毛利率71%低于筛选阈值（70%+勉强通过）。GAAP净亏损虽已大幅收窄，但仍未实现稳定盈利。
- **关注点**: 毛利率低于可比公司（71% vs. 行业80%+）；GAAP盈利能力尚未完全验证。
- **关键问题**: (1) 毛利率何时能提升至75%+？(2) Workers/AI推理等新产品线利润率如何？(3) 企业级客户渗透率和NRR？

#### (G) HubSpot (HUBS)

- **公司**: HubSpot, Inc. | 总部: Cambridge, MA | 板块: CRM / 营销自动化 / 客户平台
- **描述**: SMB和中型市场CRM和营销自动化领导者，提供AI驱动的全栈客户平台（营销、销售、服务、运营、内容管理）。
- **财务数据**:
  - FY2026收入指引: $3.69-3.708B
  - 收入增长: 18-20% YoY（恒定汇率）
  - 毛利率: ~83%
  - Non-GAAP营业利润率: ~20%
  - Rule of 40: 38-40%
- **评估**: **CONDITIONAL PASS** — 利润率优秀，但增长率接近筛选阈值下限（18-20% vs. 20%最低要求）。Rule of 40在38-40%边缘。
- **关注点**: 增长减速风险（从20%+降至18%区间）；AI驱动的"agent pricing"新模式不确定性。
- **关键问题**: (1) AI agent定价模式对ARR增长的影响？(2) SMB客户在经济衰退中的韧性？(3) 企业市场渗透策略？

---

### 3.3 未通过 (Tier 3 — Hard Pass / Monitor)

**未通过核心筛选标准，但可作为监测标的**

#### (H) monday.com (MNDY)

- **财务概要**: ARR $1.34B, 增长19-20%, 毛利率89-90%, 营业利润率14%
- **评估**: **MONITOR** — 毛利率为板块最高（90%），但增长率降至20%以下（FY2026指引18-19%）。NRR 111%低于顶级SaaS标准。作为"盈利转型"标的可跟踪。
- **未通过原因**: Rule of 40为33-34%，低于40%阈值。

#### (I) Fortinet (FTNT)

- **财务概要**: 收入$7.4B+（指引）, 增长20%, 毛利率~80%, 营业利润率35.8%
- **评估**: **MONITOR** — 盈利能力极强（行业最高营业利润率），但增长依赖硬件产品周期。Q1 FY2026产品收入增长41%反映补库存需求。
- **未通过原因**: 混合商业模式（硬件+软件）不符合纯SaaS筛选标准；增长波动性较大。

#### (J) Rapid7 (RPD)

- **财务概要**: ARR $832M, 增长~0%, 毛利率72%, 营业利润率15.8%
- **评估**: **HARD PASS** — 增长完全停滞，ARR和收入同比持平甚至下降。股价YTD下跌55.5%。
- **未通过原因**: 0%增长率远低于20%最低要求；Rule of 40仅16%。

#### (K) Tenable (TENB)

- **财务概要**: 收入~$1.05B, 增长11%, 毛利率~76%
- **评估**: **MONITOR** — 漏洞管理领域龙头，但增长仅11%低于筛选要求。
- **未通过原因**: 11%增长率低于20%阈值。

#### (L) Qualys (QLYS)

- **财务概要**: 收入~$600M, 增长~7%, 毛利率~82%, 营业利润率~28%
- **评估**: **MONITOR** — 高利润率"现金牛"模式，但增长仅7%远低于要求。$200M回购计划反映增长乏力。
- **未通过原因**: 7%增长率；Rule of 40约35%低于阈值。

---

## 第四部分：快速评估 (Step 3 — Quick Assessment)

### 4.1 综合判定

| 判定 | 结果 |
|------|------|
| **总体结论** | **进一步尽调 (Further Diligence)** |
| **优先级** | Tier 1可比基准建立完毕；需聚焦私有市场标的发掘 |
| **建议下一步** | 基于公开基准，筛选$50M-$500M ARR的私有标的 |

### 4.2 利好因素 (Bull Case)

- **行业顺风强劲**: 全球网络安全市场2026年预计达$311B（+12.1% YoY），2025年M&A总额达$76B，为历史最高水平
- **PE交易活跃**: Thoma Bravo已完成8笔take-private交易，占总量70%。2025年PE融资轮次734轮/$18B（+37% YoY）
- **估值窗口开启**: 公开SaaS EV/Revenue中位数从2024年6.2x降至2026年3.3x，私有市场估值更趋合理（3-7x ARR）
- **网络安全溢价持续**: 网络安全中位数EV/NTM收入9.1x vs. 一般SaaS 6.0-6.5x，溢价约40-50%
- **AI驱动新增长**: AI安全需求成为新增长引擎（Datadog Q1增长32%，Cloudflare边缘AI推理，Fortinet AI安全需求推动增长）

### 4.3 利空因素 (Bear Case)

- **估值仍偏高**: 尽管倍数压缩，顶级网络安全公司仍以10-15x+ ARR交易，私有标的预期倍数也可能偏高
- **AI颠覆风险**: Q1 2026 M&A明显放缓，买家重新评估AI对传统安全产品的替代风险
- **利率环境不确定**: 高利率环境对LBO杠杆成本有直接影响，影响交易可行性
- **增长减速趋势**: 多家可比公司增长减速（CrowdStrike从29%→22%，monday.com从27%→19%），行业整体增长中枢下移
- **私有市场信息不对称**: 私有标的财务透明度低，尽调成本高，NRR/LTV:CAC等关键指标难以获取

### 4.4 首次电话会议关键问题 (Key Questions for First Call)

1. **增长质量**: 有机增长率vs.收购贡献率分别是多少？净新ARR趋势如何？
2. **单位经济**: LTV/CAC比率是否达到3:1？客户获取成本趋势？毛利率扩张路径？
3. **客户基础**: Top 10客户收入集中度？客户规模分布（$100K+ ARR客户数量和占比）？企业级vs. SMB占比？
4. **竞争定位**: 与CrowdStrike/Palo Alto/Zscaler的差异化？技术壁垒和护城河？
5. **NRR趋势**: 净收入留存率历史趋势？扩张收入vs.流失率分解？
6. **退出路线图**: 管理层对退出时间线和方式的预期？是否愿意接受多数股权交易？
7. **AI影响**: AI对产品和竞争格局的影响？已有AI功能的产品化进展？
8. **团队稳定性**: 核心技术团队和销售领导的留任意愿？是否有竞业限制？

---

## 第五部分：估值参考框架 (Valuation Context)

### 5.1 当前市场估值倍数

| 板块 | EV/Revenue中位数 | EV/NTM Revenue均值 | EV/EBITDA |
|------|-----------------|-------------------|-----------|
| 网络安全（公开） | 3.3x | 9.1x | 25-30x |
| 云基础设施（公开） | 2.3x | 8-12x | 20-25x |
| 数据管理（公开） | 2.5x | 8-10x | 18-22x |
| 私有SaaS（通用） | 3-7x ARR | N/A | 12-18x |
| 私有SaaS（顶级退出） | 12x+ ARR | N/A | 20x+ |
| 云安全（M&A） | 21.7x | 35.5x | N/A |

### 5.2 PE收购参考估值区间

基于当前公开市场倍数和PE交易惯例，对$50M-$500M ARR私有标的的收购估值参考：

| ARR规模 | 目标EV/ARR | EV范围 | 典型杠杆率 |
|---------|-----------|--------|-----------|
| $50-100M | 4-8x | $200M-$800M | 3-4x EBITDA |
| $100-250M | 5-10x | $500M-$2.5B | 3.5-4.5x EBITDA |
| $250-500M | 6-12x | $1.5B-$6B | 4-5x EBITDA |

---

## 第六部分：市场动态与交易机会 (Market Dynamics)

### 6.1 网络安全M&A市场概况（2025-2026）

- **2025年M&A总额**: $76B（历史最高）
- **2025年融资总额**: $25B
- **2025年活跃轮次**: 734轮，$18B（+37% YoY）
- **Q1 2026趋势**: M&A交易量放缓（38笔/3月），买家重新评估AI对估值的影响
- **活跃买家**: Thoma Bravo（8笔take-private）、Palo Alto（Chronosphere $3.35B）、CrowdStrike（Pangea、Onum）、Fortinet

### 6.2 PE投资主题

1. **SaaS转型套利**: 收购混合模式公司，通过加速SaaS转型提升估值倍数（参考CyberArk模式）
2. **平台整合 (Platform + Bolt-on)**: 在网络安全/云管理领域建立平台，通过bolt-on收购实现交叉销售和成本协同
3. **AI赋能增值**: 投资具备AI能力的标的，通过AI功能提升NRR和毛利率
4. **估值套利窗口**: 公开市场倍数压缩带来私有市场收购机会，特别是增长减速但盈利能力改善的标的

---

## 附录：数据来源

### 公司IR公告
- [CrowdStrike FY2026 Results](https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2026)
- [Palo Alto Networks FY Q2 2026 Results](https://investors.paloaltonetworks.com/news-releases/news-release-details/palo-alto-networks-reports-fiscal-second-quarter-2026-financial/)
- [Zscaler Q2 FY2026 Results](https://ir.zscaler.com/news-releases/news-release-details/zscaler-announces-strong-second-quarter-fiscal-2026-results)
- [Fortinet Q1 2026 Results](https://www.fortinet.com/corporate/about-us/newsroom/press-releases/2026/fortinet-reports-first-quarter-2026-financial-results)
- [Datadog Q1 FY2026 Results](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-first-quarter-2026-financial-results)
- [Cloudflare FY2025 / Q1 2026 Results](https://cloudflare.net/news/news-details/2026/Cloudflare-Announces-Fourth-Quarter-and-Fiscal-Year-2025-Financial-Results/default.aspx)
- [monday.com FY2025 Results](https://ir.monday.com/news-and-events/news-releases/news-details/2026/monday-com-Announces-Fourth-Quarter-and-Fiscal-Year-2025-Results/default.aspx)
- [HubSpot Q1 2026 Results](https://ir.hubspot.com/news-releases/news-release-details/hubspot-reports-strong-q1-2026-results)
- [CyberArk FY2025 Results](https://www.cyberark.com/press/cyberark-announces-record-fourth-quarter-and-full-year-2025-results/)
- [Rapid7 Q1 FY2026 Results](https://investors.rapid7.com/news/news-details/2026/Rapid7-Announces-First-Quarter-2026-Financial-Results/default.aspx)

### 行业研究报告
- [Public Software Valuation Multiples — April 2026 (Multiples.vc)](https://multiples.vc/insights/software-saas-valuation-multiples)
- [Cybersecurity Valuation Mid-2025 (Finro)](https://www.finrofca.com/news/cybersecurity-valuation-mid-2025)
- [Cybersecurity Valuation Q1 2026 Outlook (Windsor Drake)](https://windsordrake.com/wp-content/uploads/2026/01/cyberValuationQ12026Outlook.pdf)
- [BCG Rule of 40 Analysis](https://www.bcg.com/publications/2025/rule-of-40-lessons-from-top-performers-software)
- [McKinsey SaaS Rule of 40](https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/saas-and-the-rule-of-40-keys-to-the-critical-value-creation-metric)
- [Private SaaS M&A Q1 2026 Report (SaasRise)](https://www.saasrise.com/blog/private-saas-m-a-deals-q1-2026-report)
- [S&P Global: PE Inflows to Cybersecurity](https://www.spglobal.com/market-intelligence/en/news-insights/articles/2025/3/private-equity-inflows-to-cybersecurity-soar-as-googles-32b-deal-adds-tailwind-88055244)
- [Record Cybersecurity Deal Activity 2025 (SiliconAngle)](https://siliconangle.com/2026/01/07/record-cybersecurity-deal-activity-2025-sets-aggressive-tone-2026-says-momentum-cyber/)
- [2025 State of Cybersecurity Market (Return on Security)](https://www.returnonsecurity.com/p/2025-state-of-the-cybersecurity-market)
- [QuantPillar Valuation Multiples 2025-2026](https://quantpillar.com/resources/guides/valuation-multiples/)
- [SEG 2026 Annual SaaS Report](https://softwareequity.com/research/annual-saas-report)
- [Cybersecurity Going Private (Strategy of Security)](https://strategyofsecurity.com/cybersecurity-is-going-private)
- [SaaS Valuation Multiples 2026 (Livmo)](https://livmo.com/blog/saas-valuation-multiples-2026/)

---

**免责声明**: 本筛选备忘录仅供内部投资决策参考使用。所有财务数据来自公开信息源（公司IR公告、SEC文件、行业研究报告），截至2026年5月9日。不构成投资建议。实际投资决策需基于完整尽调和独立估值分析。
