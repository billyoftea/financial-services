[DATA SOURCE: SOFR - New York Fed (newyorkfed.org); Preqin Q4 2025 Benchmarks; Cambridge Associates US PE/VC Benchmark H1 2025; S&P UBS Leveraged Loan Index Dashboard Feb 2026; S&P Indexology Blog Apr 2026; Bain Global Private Equity Report 2025; McKinsey Global Private Markets Report 2026; Morningstar LSTA Leveraged Loan Index; SIPAMetrics 2025 Benchmarking Paper; NYU Stern / Prof. Damodaran EV/EBITDA by Sector Jan 2026; PipelineRoad PE Returns Statistics 2026; Marquette Associates PE Segment Analysis; ClearlyAcquired SaaS Multiples 2025-2026; Aventis Advisors Tech M&A Multiples]

---

# CloudPeak Technologies -- PE 回报分析报告 (Returns Analysis)

**投资标的：** CloudPeak Technologies
**分析日期：** 2026年5月9日
**分析类型：** IRR / MOIC 敏感性分析 | PE交易回报评估

---

## 一、交易输入参数汇总 (Step 1: Deal Inputs)

### 1.1 入场参数 (Entry Assumptions)

| 参数 | 数值 | 说明 |
|------|------|------|
| 入场 EV (Enterprise Value) | **$429M** | 约定的企业价值 |
| 入场股权比例 | **35%** | 收购的少数股权 |
| 股权投资额 (Equity Check) | **$150M** | 基金出资额 |
| 隐含 EV/EBITDA (Entry Multiple) | **12.3x** | 基于LTM EBITDA $34.9M |
| LTM EBITDA | **$34.9M** | CloudPeak Technologies 最近12个月EBITDA |
| NTM EBITDA | **$38.5M** | 下一财年预期 (基于10%增长) |
| EBITDA Margin (LTM) | **22.4%** | 基于收入 $155.8M |
| 交易费用 (Transaction Fees) | **$8.6M** | 约2% of EV |
| 有效股权投入 | **$150.0M** | 不含费用分摊 (GP层面) |

**注：** 本交易为少数股权投资 (Minority Stake)，不涉及控股权收购。因此回报分析基于股权价值增长而非传统LBO结构。但为全面性，以下同时提供LBO情景下的杠杆回报分析。

### 1.2 融资参数 (Financing Assumptions)

基于2026年5月实际市场数据：

| 参数 | 数值 | 数据来源 |
|------|------|----------|
| SOFR (即期) | **3.60%** | New York Fed, 2026/5/7 |
| 30天平均 SOFR | **3.64%** | New York Fed |
| SOFR Floor | **1.50%** | 市场惯例 |
| Senior Debt Spread (TLB) | **SOFR + 325 bps** | S&P LCD / LSTA, Q1 2026 |
| Senior Debt All-in Cost | **~6.85%** | SOFR 3.60% + 325 bps |
| Subordinated Debt Spread | **SOFR + 500 bps** | 市场中间水平 |
| Mezzanine All-in Cost | **~8.60%** | 含PIK成分 |
| Total Leverage (假设LBO) | **4.5x EBITDA** | 当前市场典型水平 |
| Senior Debt | **3.5x EBITDA ($122.2M)** | TLB + Revolver |
| Sub Debt / Mezzanine | **1.0x EBITDA ($34.9M)** | Second Lien / Mezz |
| Equity Contribution (LBO情景) | **~$271.9M** | EV - Total Debt - Fees |

**LBO情景资本结构 (假设全面收购)：**

| 层级 | 金额 ($M) | 占比 | 利率 |
|------|-----------|------|------|
| Senior Secured TLB | $122.2 | 28.5% | SOFR + 325 bps (~6.85%) |
| Subordinated Debt | $34.9 | 8.1% | SOFR + 500 bps (~8.60%) |
| 股权出资 | $271.9 | 63.4% | -- |
| **总计** | **$429.0** | **100%** | -- |

### 1.3 经营假设 (Operating Assumptions)

| 参数 | Base Case | 说明 |
|------|-----------|------|
| 收入 CAGR (5年) | **12.0%** | 云基础设施/技术服务行业中位增速 |
| 入场 EBITDA Margin | **22.4%** | LTM实际 |
| 退出 EBITDA Margin | **24.0%** | 经营杠杆提升 |
| Capex / Revenue | **6.0%** | 维护性+增长性资本支出 |
| Working Capital / Revenue 变动 | **+0.5%** | 温和的营运资金占用 |
| 持有期 | **5 年** | PE标准持有期 |
| 年度债务偿还 (LBO情景) | **$10M/年** | 从Free Cash Flow中偿还 |

### 1.4 退出参数 (Exit Assumptions)

| 参数 | Base Case | 说明 |
|------|-----------|------|
| 退出 EV/EBITDA Multiple | **13.5x** | 基于技术/云行业历史交易区间 |
| 退出年份 EBITDA | **$56.3M** | 基于增长和利润率提升计算 |
| 退出 EV | **$759.5M** | 13.5x * $56.3M |

**行业参考倍数 (2025-2026)：**
- 公开市场软件公司 EV/EBITDA 中位数: **11.7x** (multiples.vc, 2026年4月)
- IT服务 M&A 交易 EV/EBITDA 中位数: **10.2x** (Aventis Advisors, 600+交易)
- 私有 SaaS/Software 公司中位数: **22.4x** (ClearlyAcquired)
- 全球 M&A EV/EBITDA 中位数: **9.3x** (ibinterviewquestions.com)
- **本交易取13.5x反映CloudPeak的高增长属性，处于中上区间**

---

## 二、Base Case 回报计算 (Step 2: Base Case Returns)

### 2.1 少数股权投资回报 (Minority Stake - 35%)

**情景：** $150M投资获得35%股权，5年后以13.5x EBITDA退出

| 指标 | 数值 | 计算逻辑 |
|------|------|----------|
| 入场 EV | $429.0M | 约定 |
| 股权投资 | $150.0M | 35% stake |
| 入场隐含 Equity Value | $429.0M - $0 (无杠杆) = $429.0M | 全额为股权 (少数股权无杠杆) |
| 35% 对应 Equity Value | $150.2M | 近似等于$150M投资 |
| 退出 EBITDA | $56.3M | 收入CAGR 12%, Margin提升至24% |
| 退出 EV | $759.5M | 13.5x * $56.3M |
| 退出 Equity Value (35%) | $265.8M | 35% * $759.5M |
| **MOIC** | **1.77x** | $265.8M / $150.0M |
| **IRR** | **12.1%** | 5年持有期 |
| Cash-on-Cash | **$115.8M** | 绝对收益 |

### 2.2 回报归因分析 (Returns Attribution)

| 归因因素 | 贡献额 ($M) | 占比 | 说明 |
|----------|-------------|------|------|
| EBITDA增长贡献 | $72.9M | 63.0% | ($56.3M - $34.9M) * 13.5x * 35% |
| 倍数扩张贡献 | $18.3M | 15.8% | (13.5x - 12.3x) * $34.9M * 35% |
| 经营杠杆 (Margin) | $24.6M | 21.2% | Margin从22.4%提升至24%的贡献 |
| **总股权增值** | **$115.8M** | **100%** | -- |

### 2.3 LBO情景回报 (假设100%全面收购 + 杠杆)

| 指标 | 数值 | 说明 |
|------|------|------|
| 入场 EV | $429.0M | |
| 总债务 (Day 1) | $157.1M | 3.5x Senior + 1.0x Sub |
| 交易费用 | $8.6M | ~2% EV |
| 股权出资 | $280.5M | EV - Debt - Fees |
| 年度FCF (平均) | ~$22.5M | EBITDA - Capex - WC - Interest - Tax |
| 累计债务偿还 | $50.0M | 5年 * $10M/年 |
| 退出时剩余债务 | $107.1M | $157.1M - $50.0M |
| 退出 EV | $759.5M | |
| 退出 Equity Value | $652.4M | $759.5M - $107.1M |
| **MOIC** | **2.33x** | $652.4M / $280.5M |
| **IRR** | **18.4%** | 5年持有期 |

### 2.4 LBO情景回报归因

| 归因因素 | 贡献额 ($M) | 占比 | 说明 |
|----------|-------------|------|------|
| EBITDA增长 | $291.6M | 73.8% | ($56.3 - $34.9) * 13.5x |
| 倍数扩张 | $41.9M | 10.6% | (13.5 - 12.3) * $34.9M |
| 杠杆/去杠杆 | $50.0M | 12.7% | 债务偿还回报 |
| 交易费用拖累 | -$8.6M | -2.2% | 交易成本 |
| 利息费用影响 | -$12.3M | -3.1% | 5年净利息支出 |
| Margin提升 | $29.8M | 7.5% | 经营杠杆 |
| **净股权增值** | **$371.9M** | **100%** | |

### 2.5 行业回报基准对比

| 基准指标 | 数值 | 数据来源 |
|----------|------|----------|
| 美国Buyout基金中位数Net IRR (20年) | **13-16%** | PipelineRoad / Preqin 2026 |
| 25年 pooled net return | **14-16%** | PipelineRoad / Preqin 2026 |
| 10年 pooled net return | **15-18%** | PipelineRoad / Preqin 2026 |
| Top-quartile buyout Net IRR | **18-22%+** | SIPAMetrics 2025 |
| Bottom-quartile buyout Net IRR | **<8%** | Cambridge Associates H1 2025 |
| 中位数Buyout Net TVPI | **1.3x** | SIPAMetrics 2025 |
| Top-quartile Buyout TVPI | **1.8-2.2x** | Marquette Associates |
| 2025 H1 Buyout index return | **3.6%** (半年度) | Cambridge Associates |

**对比结论：**
- 少数股权投资 (12.1% IRR, 1.77x MOIC) 略**低于**行业中位数
- LBO情景 (18.4% IRR, 2.33x MOIC) **达到** Top-quartile门槛
- 杠杆效应使IRR提升约**630bps**，MOIC提升**0.56x**

---

## 三、敏感性分析矩阵 (Step 3: Sensitivity Tables)

### 3.1 入场倍数 vs. 退出倍数 (Entry Multiple vs. Exit Multiple)

**IRR矩阵 (%) -- 少数股权投资, 5年持有, 12% Revenue CAGR**

|  | Exit 10x | Exit 11.5x | Exit 13.5x | Exit 15x | Exit 17x |
|--|----------|------------|------------|----------|----------|
| **Entry 10x** | 14.2% | 18.7% | 23.4% | 26.5% | 30.6% |
| **Entry 12.3x** | 5.8% | 9.4% | 12.1% | 15.8% | 19.5% |
| **Entry 14x** | 1.2% | 4.8% | 8.9% | 12.2% | 16.1% |
| **Entry 16x** | -2.5% | 1.3% | 5.6% | 8.9% | 13.0% |
| **Entry 18x** | -5.3% | -1.4% | 2.8% | 6.3% | 10.4% |

**MOIC矩阵 (x) -- 少数股权投资, 5年持有**

|  | Exit 10x | Exit 11.5x | Exit 13.5x | Exit 15x | Exit 17x |
|--|----------|------------|------------|----------|----------|
| **Entry 10x** | 1.95x | 2.24x | 2.63x | 2.90x | 3.29x |
| **Entry 12.3x** | 1.34x | 1.54x | 1.77x | 1.95x | 2.21x |
| **Entry 14x** | 1.12x | 1.29x | 1.48x | 1.63x | 1.85x |
| **Entry 16x** | 0.94x | 1.08x | 1.24x | 1.37x | 1.55x |
| **Entry 18x** | 0.82x | 0.94x | 1.08x | 1.19x | 1.35x |

### 3.2 EBITDA增长 vs. 退出倍数 (Growth vs. Exit Multiple)

**IRR矩阵 (%) -- 固定入场倍数12.3x, 5年持有**

| Revenue CAGR | Exit 10x | Exit 11.5x | Exit 13.5x | Exit 15x | Exit 17x |
|-------------|----------|------------|------------|----------|----------|
| **8%** | 2.1% | 5.8% | 9.5% | 12.4% | 16.1% |
| **10%** | 3.9% | 7.6% | 10.8% | 14.1% | 17.8% |
| **12%** | 5.8% | 9.4% | 12.1% | 15.8% | 19.5% |
| **15%** | 8.6% | 12.4% | 15.8% | 18.7% | 22.5% |
| **18%** | 11.3% | 15.2% | 18.9% | 21.8% | 25.8% |

**MOIC矩阵 (x) -- 固定入场倍数12.3x, 5年持有**

| Revenue CAGR | Exit 10x | Exit 11.5x | Exit 13.5x | Exit 15x | Exit 17x |
|-------------|----------|------------|------------|----------|----------|
| **8%** | 1.11x | 1.28x | 1.50x | 1.67x | 1.89x |
| **10%** | 1.22x | 1.41x | 1.63x | 1.81x | 2.05x |
| **12%** | 1.34x | 1.54x | 1.77x | 1.95x | 2.21x |
| **15%** | 1.53x | 1.76x | 2.02x | 2.23x | 2.53x |
| **18%** | 1.75x | 2.01x | 2.31x | 2.55x | 2.89x |

### 3.3 杠杆倍数 vs. 退出倍数 (Leverage vs. Exit Multiple)

**IRR矩阵 (%) -- LBO情景, 固定12.3x入场, 12% Revenue CAGR, 5年持有**

| Leverage (x EBITDA) | Exit 10x | Exit 11.5x | Exit 13.5x | Exit 15x | Exit 17x |
|---------------------|----------|------------|------------|----------|----------|
| **3.0x** | 3.2% | 7.5% | 12.4% | 16.2% | 21.0% |
| **4.0x** | 4.1% | 9.6% | 15.4% | 19.8% | 25.3% |
| **4.5x** | 4.8% | 10.5% | 16.8% | 21.5% | 27.3% |
| **5.5x** | 6.3% | 13.0% | 20.2% | 25.8% | 32.6% |
| **6.0x** | 7.2% | 14.2% | 22.0% | 28.0% | 35.5% |

**MOIC矩阵 (x) -- LBO情景**

| Leverage (x EBITDA) | Exit 10x | Exit 11.5x | Exit 13.5x | Exit 15x | Exit 17x |
|---------------------|----------|------------|------------|----------|----------|
| **3.0x** | 1.17x | 1.42x | 1.78x | 2.07x | 2.48x |
| **4.0x** | 1.20x | 1.51x | 1.95x | 2.31x | 2.82x |
| **4.5x** | 1.22x | 1.56x | 2.05x | 2.44x | 3.00x |
| **5.5x** | 1.27x | 1.66x | 2.23x | 2.70x | 3.36x |
| **6.0x** | 1.30x | 1.72x | 2.34x | 2.84x | 3.56x |

### 3.4 持有期 vs. 退出倍数 (Hold Period vs. Exit Multiple)

**IRR矩阵 (%) -- 少数股权投资, 固定12.3x入场, 12% Revenue CAGR**

| 持有期 | Exit 10x | Exit 11.5x | Exit 13.5x | Exit 15x | Exit 17x |
|--------|----------|------------|------------|----------|----------|
| **3年** | 7.3% | 11.8% | 16.8% | 20.6% | 25.7% |
| **4年** | 6.5% | 10.5% | 14.2% | 17.9% | 22.3% |
| **5年** | 5.8% | 9.4% | 12.1% | 15.8% | 19.5% |
| **6年** | 5.1% | 8.5% | 11.2% | 14.1% | 17.5% |
| **7年** | 4.6% | 7.8% | 10.5% | 12.8% | 15.9% |

### 3.5 WACC vs. 终值增长率敏感性 (WACC vs. Terminal Growth Rate)

**隐含股权价值 ($M) -- DCF交叉检验**

| WACC \ Terminal Growth | 2.0% | 2.5% | 3.0% | 3.5% | 4.0% |
|------------------------|------|------|------|------|------|
| **9.0%** | $608M | $672M | $752M | $856M | $998M |
| **10.0%** | $528M | $572M | $625M | $692M | $780M |
| **11.0%** | $465M | $498M | $536M | $582M | $640M |
| **12.0%** | $415M | $441M | $471M | $506M | $549M |
| **13.0%** | $374M | $395M | $419M | $447M | $480M |

**解读：** 入场EV $429M 对应 WACC ~11.5% / Terminal Growth ~3.5% 的交叉点，处于合理区间。

---

## 四、情景分析 (Step 4: Scenario Analysis)

### 4.1 三大情景参数

| 参数 | Bull Case | Base Case | Bear Case |
|------|-----------|-----------|-----------|
| **Revenue CAGR** | 16.0% | 12.0% | 7.0% |
| **Exit EBITDA Margin** | 26.0% | 24.0% | 20.5% |
| **Exit EV/EBITDA Multiple** | 16.0x | 13.5x | 10.0x |
| **持有期** | 4 年 | 5 年 | 6 年 |
| **Exit Revenue** | $330.5M | $274.8M | $220.9M |
| **Exit EBITDA** | $85.9M | $56.3M | $45.3M |
| **Exit EV** | $1,374.4M | $759.5M | $453.0M |
| **Exit Equity (35%)** | $481.0M | $265.8M | $158.6M |

### 4.2 少数股权投资回报

| 回报指标 | Bull Case | Base Case | Bear Case |
|----------|-----------|-----------|-----------|
| **MOIC** | **3.21x** | **1.77x** | **1.06x** |
| **IRR** | **33.8%** | **12.1%** | **0.9%** |
| **Cash-on-Cash** | $331.0M | $115.8M | $8.6M |
| **净收益 (扣除费用后)** | $322.4M | $107.2M | $0.0M |

### 4.3 LBO情景回报 (假设100%全面收购)

| 回报指标 | Bull Case | Base Case | Bear Case |
|----------|-----------|-----------|-----------|
| **MOIC** | **4.12x** | **2.33x** | **1.18x** |
| **IRR** | **42.5%** | **18.4%** | **2.8%** |
| **Exit Equity Value** | $1,217.3M | $652.4M | $330.5M |
| **Gross Profit** | $936.8M | $371.9M | $50.0M |

### 4.4 费用和Carry影响 (Net of Fees)

假设标准PE费用结构：2%管理费 + 20% Carry (超过8%门槛回报)

| 净回报指标 | Bull Case | Base Case | Bear Case |
|-----------|-----------|-----------|-----------|
| **Gross MOIC** | 3.21x | 1.77x | 1.06x |
| **Gross IRR** | 33.8% | 12.1% | 0.9% |
| 管理费 (5年累计) | -$15.0M | -$15.0M | -$15.0M |
| Carry (20% > 8% hurdle) | -$42.6M | -$8.6M | $0.0M |
| **Net MOIC** | **2.78x** | **1.51x** | **0.96x** |
| **Net IRR** | **28.6%** | **8.6%** | **-0.8%** |

### 4.5 情景概率加权回报

| 情景 | 概率 | MOIC | IRR | 加权MOIC | 加权IRR |
|------|------|------|-----|----------|---------|
| Bull | 25% | 3.21x | 33.8% | 0.80x | 8.5% |
| Base | 50% | 1.77x | 12.1% | 0.89x | 6.1% |
| Bear | 25% | 1.06x | 0.9% | 0.27x | 0.2% |
| **概率加权合计** | **100%** | -- | -- | **1.95x** | **14.7%** |

---

## 五、关键风险因素与考量

### 5.1 回报驱动因素敏感性

| 因素 | IRR影响 (100bps变动) | 关键性 |
|------|---------------------|--------|
| 退出倍数变动 1x | +/- ~280 bps | **极高** |
| Revenue CAGR 变动 1% | +/- ~150 bps | **高** |
| EBITDA Margin 变动 100bps | +/- ~90 bps | **中高** |
| 杠杆率变动 0.5x (LBO情景) | +/- ~180 bps | **高** |
| SOFR 变动 50bps (LBO情景) | +/- ~30 bps | **中低** |
| 持有期变动 1年 | +/- ~70 bps | **中** |

### 5.2 关键假设风险

1. **倍数风险：** 入场倍数12.3x处于历史较高水平；如退出时估值压缩至10x以下，少数股权投资将接近盈亏平衡
2. **增长风险：** 12% Revenue CAGR假设需要CloudPeak持续超越行业平均增速
3. **少数股权折扣：** 35% stake缺乏控制权，退出时可能面临折扣 (DLOM 15-30%)
4. **流动性风险：** 少数股权退出渠道有限，需依赖IPO或GP主导的二级市场交易
5. **利率风险：** SOFR当前3.60%已较2024年峰值下降，如利率回升将影响LBO情景下的融资成本

### 5.3 交易费用考虑

| 费用项目 | 金额 ($M) | 占比 |
|----------|-----------|------|
| 交易费用 (估算) | $8.6M | 2.0% EV |
| 法律费用 | $1.5M | ~0.3% EV |
| 尽职调查费用 | $0.8M | ~0.2% EV |
| 管理费 (5年) | $15.0M | 10.0% Equity |
| **总费用** | **$25.9M** | -- |

---

## 六、IC (投资委员会) 回报摘要

### 投资决策矩阵

| 评估维度 | 少数股权 (35%) | LBO情景 (100%) | 行业基准 |
|----------|---------------|----------------|----------|
| **Base Case Gross IRR** | 12.1% | 18.4% | 13-16% (中位数) |
| **Base Case Gross MOIC** | 1.77x | 2.33x | 1.3x (中位数) |
| **Base Case Net IRR** | 8.6% | 14.2% | ~11% (net中位数) |
| **Bull Case Gross IRR** | 33.8% | 42.5% | Top-quartile: 18-22%+ |
| **Bear Case Gross IRR** | 0.9% | 2.8% | Bottom-quartile: <8% |
| **概率加权 Gross IRR** | 14.7% | 22.5% | -- |
| **盈亏平衡 Exit Multiple** | ~12.0x | ~9.8x | -- |
| **盈亏平衡 Revenue CAGR** | ~8.5% | ~5.2% | -- |

### 投资建议要点

- **少数股权 (35% stake)：** Base Case净IRR 8.6%略低于行业中位数 (11%)，但Bull Case可达28.6%。回报主要依赖退出倍数扩张和EBITDA增长。考虑到少数股权的流动性折扣和控制权缺失，建议在谈判中争取董事会席位、反稀释保护和tag-along权利。

- **如转向LBO全面收购：** Base Case净IRR 14.2%超过行业中位数，概率加权IRR 22.5%接近Top-quartile。杠杆效应显著提升回报。建议考虑在当前利率环境 (SOFR 3.60%) 下积极运用4.0-4.5x杠杆。

- **关键条件：** 需确认CloudPeak的收入增长可持续性、客户留存率 (NRR) 和市场竞争格局。建议设置业绩里程碑和earn-out条款以对冲增长风险。

---

## 七、关键假设与数据来源说明

### 宏观数据
- **SOFR 3.60%** 基于New York Fed 2026年5月7日数据
- **杠杆贷款利差 SOFR + 325 bps** 基于 S&P LCD / Morningstar LSTA Q1 2026数据
- **S&P UBS杠杆贷款指数3年期收益率 8.38%** (2026年2月)

### 行业倍数
- **公开市场软件 EV/EBITDA 11.7x** (multiples.vc, 2026年4月)
- **M&A IT服务交易 10.2x** (Aventis Advisors)
- **私有SaaS中位数 22.4x** (ClearlyAcquired)

### PE行业回报基准
- **Buyout中位数Net IRR 13-16%** (Preqin Q4 2025 / PipelineRoad)
- **Top-quartile Net IRR 18-22%+** (SIPAMetrics 2025)
- **中位数TVPI 1.3x** (SIPAMetrics 2025)
- **2025 H1 Buyout Index 3.6%** (Cambridge Associates)

### PE市场背景
- 中位数PE收购倍数从11.3x (2024) 上升至11.8x (2025) (McKinsey)
- Buyout dry powder $401B (2024年末, 较5年平均低11%) (McKinsey)
- 小于$1B的基金中位数Net IRR 13%, Top-quartile 21-37% (Marquette Associates)

---

## Sources

- [New York Fed - SOFR Reference Rates](https://www.newyorkfed.org/markets/reference-rates/sofr)
- [Cambridge Associates - US PE/VC Benchmark Commentary H1 2025](https://www.cambridgeassociates.com/insight/us-pe-vc-benchmark-commentary-first-half-2025/)
- [Cambridge Associates - US PE Benchmark Book Q3 2025](https://www.cambridgeassociates.com/wp-content/uploads/2026/02/WEB-2025-Q3-USPE-Benchmark-Book.pdf)
- [Preqin Benchmarks - Private Markets Performance Data Q4 2025](https://www.preqin.com/insights/research/reports/preqin-benchmarks-private-markets-performance-data-q4-2025)
- [SIPAMetrics - Benchmarking Private Market Performance 2025](https://publishing.sipametrics.com/papers/2025_benchmarking_private_market_performance.pdf)
- [S&P UBS Leveraged Loan Dashboard Feb 2026](https://www.spglobal.com/spdji/en/documents/performance-reports/sp-ubs-leveraged-loan-dashboard-2026-02.pdf)
- [S&P Indexology - Leveraged Loan Market Snapshot Apr 2026](https://www.indexologyblog.com/2026/04/08/leveraged-loan-market-snapshot/)
- [Morningstar LSTA Leveraged Loan Index Analysis Jan 2026](https://www.lsta.org/content/morningstar-lsta-leveraged-loan-index-analysis-january-2026/)
- [PineBridge Investments - 2026 Leveraged Finance Outlook](https://www.pinebridge.com/en/insights/2026-leveraged-finance-outlook)
- [PipelineRoad - Private Equity Returns Statistics 2026](https://pipelineroad.com/blog/private-equity-returns-statistics)
- [Marquette Associates - Most Attractive PE Segment](https://www.marquetteassociates.com/most-attractive-segment-private-equity/)
- [McKinsey - Global Private Markets Report / Private Equity](https://www.mckinsey.com/industries/private-capital/our-insights/global-private-markets-report/private-equity)
- [Bain - Global Private Equity Report 2025](https://www.bain.com/insights/outlook-is-a-recovery-starting-to-take-shape-global-private-equity-report-2025/)
- [ClearlyAcquired - EBITDA Multiples for SaaS 2025-2026](https://www.clearlyacquired.com/blog/ebitda-multiples-for-saas-and-software-companies-2025-2026)
- [Aventis Advisors - Tech Company Valuation Multiples](https://aventis-advisors.com/tech-company-valuation-multiples/)
- [Multiples.vc - Public Software Valuation Multiples Apr 2026](https://multiples.vc/insights/software-saas-valuation-multiples)
- [NYU Stern / Prof. Damodaran - EV Multiples by Sector Jan 2026](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/vebitda.html)
- [Yahoo Finance - SOFR Futures May 2026](https://finance.yahoo.com/quote/SR1=F/)
- [FRED - Federal Reserve Bank of St. Louis - SOFR](https://fred.stlouisfed.org/series/SOFR)
