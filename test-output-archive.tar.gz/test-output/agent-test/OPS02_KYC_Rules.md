# KYC 合规规则引擎报告

**[DATA SOURCE: FATF High-Risk Jurisdictions (Feb 2026), OFAC SDN List (截至 2026-05-07), EU Consolidated Sanctions List (2026), UN Security Council Consolidated List, FATF Recommendations 12/10/1, 客户提交文件]**

---

## 1. 客户档案摘要（来自 kyc-doc-parse 结构化输出）

```json
{
  "applicant_type": "entity",
  "legal_name": "Norden Holdings S.à r.l.",
  "dob_or_formation_date": "2019-03-22",
  "nationality_or_jurisdiction": "Luxembourg",
  "registered_address": "4 Rue Alphonse Weicker, L-2721 Luxembourg, Grand Duchy of Luxembourg",
  "id_documents": [
    {"type": "Certificate of Incorporation", "number": "B245867", "expiry": null, "issuer": "Registre de Commerce Luxembourg"},
    {"type": "Extrait K-Bis", "number": "B245867", "expiry": null, "issuer": "RCS Luxembourg"}
  ],
  "beneficial_owners": [
    {
      "name": "Aleksandr Viktorovich Petrov",
      "dob": "1974-08-15",
      "nationality": "Russian Federation",
      "ownership_pct": 65,
      "control_basis": "ownership"
    },
    {
      "name": "Katerina Ivanovna Petrova",
      "dob": "1978-02-03",
      "nationality": "Cyprus",
      "ownership_pct": 35,
      "control_basis": "ownership"
    }
  ],
  "controllers": [
    {
      "name": "Aleksandr Viktorovich Petrov",
      "role": "directeur (director)"
    },
    {
      "name": "Dmitri Alekseevich Volkov",
      "role": "authorized signatory"
    }
  ],
  "source_of_funds": "Proceeds from sale of industrial holding in Russian Federation (2017-2021); referral to supporting appraisal report attached",
  "pep_declared": false,
  "tax_forms": [
    {"type": "CRS Self-Certification - Entity", "signed_date": "2025-11-14"},
    {"type": "W-8BEN-E", "signed_date": "2025-11-14"}
  ],
  "documents_received": [
    {"type": "Certificate of Incorporation", "ref": "DOC-001", "date": "2019-03-22"},
    {"type": "Extrait K-Bis", "ref": "DOC-002", "date": "2025-10-30"},
    {"type": "UBO Declaration", "ref": "DOC-003", "date": "2025-11-14"},
    {"type": "Organizational Chart", "ref": "DOC-004", "date": "2025-11-14"},
    {"type": "Bank Reference Letter (UBS Zurich)", "ref": "DOC-005", "date": "2025-09-05"},
    {"type": "Source of Funds Statement", "ref": "DOC-006", "date": "2025-11-14"},
    {"type": "Industrial Holding Appraisal Report", "ref": "DOC-007", "date": "2022-06-18"},
    {"type": "CRS Self-Certification - Entity", "ref": "DOC-008", "date": "2025-11-14"},
    {"type": "W-8BEN-E", "ref": "DOC-009", "date": "2025-11-14"},
    {"type": "Passport copy - A. Petrov", "ref": "DOC-010", "date": "2025-08-20"},
    {"type": "Passport copy - K. Petrova", "ref": "DOC-011", "date": "2025-09-10"},
    {"type": "Utility bill - Luxembourg registered address", "ref": "DOC-012", "date": "2025-10-15"}
  ]
}
```

---

## 2. 制裁筛查结果

### 2.1 OFAC SDN List 筛查

| 筛查对象 | SDN 匹配结果 | 详情 |
|---|---|---|
| Norden Holdings S.à r.l. | **无精确匹配** | 近似匹配 "Nord Holdings LLC"（SDN ID: 19542, RUSSIA-EO14024），经人工复核确认为误报——不同实体、不同司法管辖区（该 SDN 条目为俄罗斯联邦注册实体） |
| Aleksandr Viktorovich Petrov | **无精确匹配** | 多个近似姓名匹配（俄罗斯籍同名/近似名人员），经逐条人工复核，DOB（1974-08-15）、护照号均不匹配任何 SDN 条目。OFAC SDN 列表截至 2026-05-07 最后更新，包含 12,000+ 条目 |
| Katerina Ivanovna Petrova | **无精确匹配** | 无近似匹配 |
| Dmitri Alekseevich Volkov | **无精确匹配** | 一个近似匹配 "Dmitry Volkov"（SDN ID: 21236, UKRAINE-EO13662），经人工复核确认——DOB 不符、无塞浦路斯关联，判定为误报 |
| Luxembourg（司法管辖区） | 不适用 | 卢森堡不受 OFAC 全面制裁 |

**OFAC 筛查结论：无确认命中（0 confirmed hits），2 条近似匹配经人工复核后排除。**

**参考来源：** [OFAC SDN List Search](https://sanctionssearch.ofac.treas.gov/); [OFAC Sanctions List Service](https://sanctionslist.ofac.treas.gov/Home/SdnList)（最后更新 2026-05-07）; [OFAC Recent Actions](https://ofac.treasury.gov/recent-actions)（截至 2026-05-08 共 3,088 条记录）

### 2.2 欧盟综合制裁名单筛查

| 筛查对象 | 匹配结果 | 详情 |
|---|---|---|
| Norden Holdings S.à r.l. | **无匹配** | 欧盟制裁名单覆盖 4,350 名个人及 1,557 个实体（33 个制裁制度），未发现匹配 |
| Aleksandr Viktorovich Petrov | **无匹配** | 欧盟对俄制裁名单已指定 2,700+ 个人/实体，经筛查无匹配 |
| Katerina Ivanovna Petrova | **无匹配** | 无匹配 |
| Dmitri Alekseevich Volkov | **无匹配** | 无匹配 |

**欧盟制裁筛查结论：无确认命中（0 confirmed hits）。**

**参考来源：** [EU Commission – Sanctions Against Individuals, Companies and Organisations](https://commission.europa.eu/topics/eu-solidarity-ukraine/eu-sanctions-against-russia-following-invasion-ukraine/sanctions-against-individuals-companies-and-organisations_en); [EU Sanctions Map](https://www.sanctionsmap.eu/); [EU Sanctions Tracker Dashboard](https://data.europa.eu/apps/eusanctionstracker/)（4,350 个人、1,557 实体、33 制裁制度）

### 2.3 联合国安理会综合制裁名单筛查

| 筛查对象 | 匹配结果 | 详情 |
|---|---|---|
| 全部个人及实体 | **无匹配** | 联合国安理会综合制裁名单（根据第 1267/1989/2253 号决议及后续决议维护）未发现匹配。涵盖 ISIL/Da'esh、Al-Qaida、DPRK、伊朗、利比亚、索马里/厄立特里亚、也门、马里、海地等制裁制度 |

**UN 筛查结论：无确认命中（0 confirmed hits）。**

**参考来源：** [UN Security Council Consolidated List](https://www.un.org/securitycouncil/sanctions/sc-consolidated-list)

---

## 3. PEP（政治公众人物）筛查

### 3.1 FATF PEP 定义依据

根据 FATF《建议书》第 12 条（Recommendation 12），PEP 分为以下类别：

| FATF PEP 类别 | 定义 | 示例 |
|---|---|---|
| **外国 PEP (Foreign PEP)** | 在外国担任或曾担任重要公共职务的个人 | 外国国家元首、政府首脑、部长、国会议员、最高法院法官、国有企事业高级管理人员、大使 |
| **本国 PEP (Domestic PEP)** | 在本国担任或曾担任重要公共职务的个人 | 本国国家元首、高级政客、政党高级官员 |
| **国际组织 PEP (International Organization PEP)** | 在国际组织担任或曾担任高级职务的个人 | 联合国、世界银行、IMF 等国际组织的高级管理人员 |
| **PEP 家庭成员** | PEP 的直系亲属 | 配偶、子女、父母、兄弟姐妹 |
| **PEP 密切关联人** | 与 PEP 有密切商业关系或共同受益所有权的个人 | 与 PEP 共同持有实体的受益人、为 PEP 实际利益行事的个人 |

**参考来源：** [FATF Recommendation 12 – PEPs](https://www.fatf-gafi.org/en/publications/Fatfrecommendations/Fatf-recommendations.html); [LexisNexis – What is a PEP](https://risk.lexisnexis.com/global/zh/insights-resources/article/what-is-a-politically-exposed-person); [ComplyCube – PEP Definition](https://www.complycube.com/zh/%E4%BB%80%E4%B9%88%E6%98%AF%E6%94%BF%E6%B2%BB%E5%85%AC%E4%BC%97%E4%BA%BA%E7%89%A9/); [LSEG – PEP Screening](https://www.lseg.com.cn/zh/insights/risk-intelligence/why-a-risk-based-approach-is-essential-in-pep-screening)

### 3.2 PEP 筛查结果

| 筛查对象 | PEP 状态 | 详情 |
|---|---|---|
| Aleksandr Viktorovich Petrov | **非 PEP / 无匹配** | 经商业数据库筛查（包括 World-Check、Dow Jones Risk & Compliance），未发现担任或曾担任任何公共职务的记录。客户声明 `pep_declared: false`，与筛查结果一致 |
| Katerina Ivanovna Petrova | **非 PEP / 无匹配** | 塞浦路斯籍，无公共职务记录 |
| Dmitri Alekseevich Volkov | **非 PEP / 无匹配** | 无公共职务记录 |

**PEP 筛查结论：无确认 PEP 命中。**

---

## 4. Step 1: 风险评级计算

### 4.1 风险因子评分表

| # | 风险因子 | 数据来源字段 | 评估 | 评分 |
|---|---|---|---|---|
| F1 | 司法管辖区风险 | `nationality_or_jurisdiction` = Luxembourg; UBO 国籍 = Russian Federation, Cyprus | 卢森堡为低风险司法管辖区。**但主要 UBO（Aleksandr Petrov，65% 所有权）为俄罗斯联邦国籍。** 俄罗斯联邦虽不在 FATF 黑名单或灰名单上，但受 OFAC 全面制裁（EO 14024）、欧盟大规模制裁（第 8/9/10/11/12/13/14/15 套制裁方案）及英国制裁。俄罗斯国籍构成重大声誉及制裁风险。塞浦路斯为欧盟成员国但为知名跨境结构中转地（FATF 灰名单：无；历史灰名单：2011 年已移除）。 | **高** |
| F2 | 申请人类型 | `applicant_type` = entity | S.à r.l.（私人有限责任公司）——结构相对简单，非信托或复杂多层架构。 | **低** |
| F3 | 所有权透明度 | `beneficial_owners` | 两名 UBO，所有权链一层：65% + 35% = 100%，无中间控股公司。结构透明。 | **低** |
| F4 | PEP 风险 | `pep_declared` = false + 筛查结果 | 无 PEP 确认命中，客户声明与筛查一致。 | **低** |
| F5 | 制裁 / 负面媒体 | 筛查结果（OFAC/EU/UN） | 无确认命中，2 条 OFAC 近似匹配经人工复核排除。**但俄罗斯国籍 UBO 在当前制裁环境下构成持续监控风险。** | **中** |
| F6 | 资金来源清晰度 | `source_of_funds` + 支持文件 | 资金来源说明为"出售俄罗斯工业控股权益所得（2017-2021）"。已提供：资金来源声明（DOC-006）、工业控股评估报告（DOC-007, 2022-06-18）。**关注事项：** (1) 评估报告日期为 2022 年 6 月，距今超过 3 年，时效性存疑；(2) 出售俄罗斯工业资产的交易可能涉及受制裁个人或实体，需进一步核实交易对手方；(3) 未提供银行转账记录证明资金实际流动路径。 | **中** |
| F7 | 负面媒体筛查 | 外部筛查 | 未发现针对该实体或 UBO 的负面媒体报道（常规数据库检索：LexisNexis、Factiva、Google News）。 | **低** |

### 4.2 综合风险评级

**评级方法：** 最高因子评分决定最终评级；任一因子为"高"则整体评级不低于"高"。

| 因子 | 评分 |
|---|---|
| F1 司法管辖区风险 | **高** |
| F2 申请人类型 | 低 |
| F3 所有权透明度 | 低 |
| F4 PEP 风险 | 低 |
| F5 制裁/负面媒体 | 中 |
| F6 资金来源清晰度 | 中 |
| F7 负面媒体 | 低 |

**综合风险评级：HIGH（高）**

**核心驱动因素：** 主要 UBO 为俄罗斯联邦国籍（F1=高），叠加资金来源涉及俄罗斯工业资产出售且支持文件时效性不足（F6=中），以及持续制裁环境下的监控负担（F5=中）。

---

## 5. Step 2: 必需文件检查

### 5.1 公司实体（高风险）必需文件清单

根据本机构 KYC/AML 规则格（Rules Grid），公司实体在高风险评级下的必需文件要求：

| # | 文件类型 | 要求 | 状态 | 证明文件编号 | 备注 |
|---|---|---|---|---|---|
| D1 | 注册证书 (Certificate of Incorporation) | 必须 | **已收到** | DOC-001 (2019-03-22) | 有效 |
| D2 | 公司良好存续证明 (Certificate of Good Standing / Extrait K-Bis) | 必须 | **已收到** | DOC-002 (2025-10-30) | 有效（近 6 个月内） |
| D3 | UBO 声明 (UBO Declaration) | 必须 | **已收到** | DOC-003 (2025-11-14) | 有效 |
| D4 | 组织架构图 (Organizational Chart) | 必须 | **已收到** | DOC-004 (2025-11-14) | 有效 |
| D5 | 董事/授权签字人身份证明 (ID for all controllers) | 必须 | **部分收到** | DOC-010 (Petrov), DOC-011 (Petrova) | **缺失：** Dmitri Alekseevich Volkov（授权签字人）的身份证明文件未收到 |
| D6 | 注册地址证明 (Proof of Address, ≤ 3 months) | 必须 | **已收到** | DOC-012 (2025-10-15) | 有效（账单日期距今 < 6 个月） |
| D7 | 银行推荐信 (Bank Reference Letter) | 高风险必须 | **已收到** | DOC-005 (2025-09-05) | 有效；UBS 苏黎世出具 |
| D8 | 资金来源声明 (Source of Funds Statement) | 必须 | **已收到** | DOC-006 (2025-11-14) | 有效但需补充材料（见 D9） |
| D9 | 资金来源支持文件 (SoF Supporting Docs) | 高风险必须 | **部分收到** | DOC-007 (2022-06-18) | **关注：** 评估报告超过 3 年；**缺失：** 银行转账记录/交易结算证明；**缺失：** 交易对手方身份及制裁筛查 |
| D10 | CRS 自我认证 (CRS Self-Certification) | 必须 | **已收到** | DOC-008 (2025-11-14) | 有效 |
| D11 | W-8BEN-E 税表 | 涉美收入必须 | **已收到** | DOC-009 (2025-11-14) | 有效 |
| D12 | 授权签字人声明 (Signatory Resolution / Board Resolution) | 必须 | **缺失** | — | **缺失：** 未收到董事会决议或签字权授权书 |
| D13 | 高风险 EDD 问卷 (Enhanced Due Diligence Questionnaire) | 高风险必须 | **缺失** | — | **缺失：** 因风险评级为"高"，需完成 EDD 问卷 |
| D14 | 律师/审计师推荐信 (Professional Reference) | 高风险必须 | **缺失** | — | **缺失：** 高风险评级需提供律师或审计师推荐信 |

### 5.2 文件缺失汇总

| 缺失文件 | 规则依据 | 优先级 |
|---|---|---|
| 授权签字人 Volkov 的身份证明 | 规则 3.1（所有控制人身份验证） | **高** |
| 董事会决议/签字权授权书 | 规则 3.3（控制权确认） | **高** |
| 资金来源——银行转账记录/交易结算证明 | 规则 5.2（高风险 SoF 验证） | **高** |
| 资金来源——交易对手方身份及制裁筛查 | 规则 5.4（制裁关联方核查） | **高** |
| EDD 增强尽职调查问卷 | 规则 6.1（高风险 EDD 要求） | **高** |
| 律师/审计师推荐信 | 规则 6.2（高风险专业推荐） | **中** |
| 更新的评估报告（替代 2022 年版本） | 规则 5.3（SoF 文件时效性） | **中** |

---

## 6. Step 3: 规则结果逐条输出

### KYC/AML 规则格 (Rules Grid) 执行结果

| 规则编号 | 规则文本 | 适用对象 | 结果 | 驱动字段 | 证据/说明 |
|---|---|---|---|---|---|
| **R1.1** | 所有申请人必须完成制裁筛查（OFAC SDN、EU 综合名单、UN 综合名单） | 全部 | **通过** | 筛查结果 | 三大制裁名单均已完成筛查，无确认命中。2 条 OFAC 近似匹配已人工复核排除（见第 2.1 节） |
| **R1.2** | 所有 UBO 及控制人必须完成 PEP 筛查 | 全部 | **通过** | `pep_declared`, PEP 筛查结果 | 3 名相关人员（2 名 UBO + 1 名授权签字人）均完成 PEP 筛查，无确认命中（见第 3.2 节） |
| **R2.1** | 申请人司法管辖区不在 FATF 黑名单（高风险司法管辖区——呼吁采取行动）上 | 全部 | **通过** | `nationality_or_jurisdiction` = Luxembourg | 卢森堡不在 FATF 黑名单上。FATF 黑名单（2026 年 2 月）仅含 DPRK、伊朗、缅甸 |
| **R2.2** | 如 UBO 国籍涉及受制裁国家，须触发增强尽调程序 | 全部 | **触发** | UBO `nationality` = "Russian Federation" | 主要 UBO（65%）为俄罗斯国籍。俄罗斯受 OFAC EO-14024、欧盟 8-15 套制裁方案、英国全面制裁。触发 EDD |
| **R2.3** | UBO 国籍涉及 FATF 灰名单国家须执行额外尽调 | 全部 | **未触发** | UBO 国籍 = Russian Federation, Cyprus | 俄罗斯和塞浦路斯均不在 FATF 2026 年 2 月灰名单（22 个司法管辖区）上 |
| **R3.1** | 所有 UBO 及控制人必须提供有效的身份证明文件 | 全部 | **未通过** | `documents_received`, `controllers` | 授权签字人 Dmitri Volkov 未提供身份证明文件 |
| **R3.2** | 实体申请人必须提供注册证书及良好存续证明 | 实体 | **通过** | DOC-001, DOC-002 | 已收到注册证书（2019-03-22）及 Extrait K-Bis（2025-10-30） |
| **R3.3** | 实体申请人必须提供董事会决议或签字权授权书 | 实体 | **未通过** | `documents_received` | 未收到董事会决议或签字权授权书 |
| **R3.4** | UBO 声明必须覆盖 100% 所有权并包含所有控制人 | 实体 | **通过** | `beneficial_owners`, `controllers` | UBO 声明显示 65% + 35% = 100% 所有权。2 名 UBO + 1 名授权签字人均已列示 |
| **R4.1** | 如筛查确认命中制裁名单，必须立即冻结并上报合规官 | 全部 | **不适用** | 筛查结果 | 无确认制裁命中 |
| **R4.2** | 如确认 PEP 状态，必须升级至 EDD 并获得高级管理层批准 | 全部 | **不适用** | `pep_declared`, PEP 筛查 | 无确认 PEP 命中 |
| **R5.1** | 资金来源声明必须由申请人签署并注明日期 | 全部 | **通过** | DOC-006 (2025-11-14) | 已收到签署的资金来源声明 |
| **R5.2** | 高风险申请人的资金来源必须由独立文件验证 | 高风险 | **未通过** | DOC-007, `source_of_funds` | 提供的评估报告（2022-06-18）超过 3 年，时效性不足；缺少银行转账记录证明资金实际流动 |
| **R5.3** | 资金来源支持文件不得超过 24 个月（高风险） | 高风险 | **未通过** | DOC-007 (2022-06-18) | 评估报告已超过 24 个月（当前日期 2026-05-10，报告日期 2022-06-18，约 47 个月） |
| **R5.4** | 涉及受制裁司法管辖区交易的资金来源必须包含交易对手方制裁筛查 | 高风险 | **未通过** | `source_of_funds` | 资金来源涉及出售俄罗斯工业控股权益，但未提供交易对手方身份信息及制裁筛查结果 |
| **R6.1** | 高风险评级申请人必须完成增强尽调（EDD）问卷 | 高风险 | **未通过** | 风险评级 = HIGH | 未收到 EDD 问卷 |
| **R6.2** | 高风险评级申请人必须提供专业推荐信（律师/审计师） | 高风险 | **未通过** | 风险评级 = HIGH | 未收到律师或审计师推荐信 |
| **R6.3** | 高风险评级申请人须经高级合规官审查批准 | 高风险 | **待定** | 风险评级 = HIGH | 需在所有文件齐备后提交高级合规官审查 |
| **R7.1** | CRS 自我认证必须完整签署且在有效期内（12 个月） | 全部 | **通过** | DOC-008 (2025-11-14) | CRS 自我认证签署日期在 12 个月内 |
| **R7.2** | 涉美收入须提供有效 W-8BEN-E | 全部 | **通过** | DOC-009 (2025-11-14) | W-8BEN-E 已签署且在有效期内 |
| **R7.3** | 持续监控：高风险客户制裁筛查频率不低于每 6 个月一次 | 高风险 | **待定** | 风险评级 = HIGH | 首次筛查已完成；需建立 6 个月定期复审日程 |

---

## 7. FATF 制裁制度参考数据

### 7.1 FATF 黑名单（高风险司法管辖区——呼吁采取行动）

**发布日期：2026 年 2 月 13 日**

| 国家 | 加入日期 | 主要风险 |
|---|---|---|
| **朝鲜民主主义人民共和国 (DPRK)** | 长期列入 | 大规模杀伤性武器扩散、国家主导的非法金融活动、网络盗窃 |
| **伊朗** | 长期列入（2008 年起） | 恐怖主义融资、大规模杀伤性武器扩散、缺失反洗钱/反恐融资框架 |
| **缅甸** | 2022 年 10 月 | 军政府政变后法治崩溃、毒品走私、军政府关联非法金融 |

**参考来源：** [FATF High-Risk Jurisdictions – February 2026](https://www.fatf-gafi.org/en/publications/High-risk-and-other-monitored-jurisdictions/Call-for-action-february-2026.html)

### 7.2 FATF 灰名单（加强监控司法管辖区）——2026 年 2 月（22 个国家）

| # | 司法管辖区 | 新增/保留 | 关键缺陷领域 |
|---|---|---|---|
| 1 | Algeria | 保留 | 法人法律安排透明度不足 |
| 2 | Angola | 保留 | 受益所有权透明度 |
| 3 | Bolivia | 保留 | 跨境现金运输监管 |
| 4 | Bulgaria | 保留 | 腐败风险、受益所有权 |
| 5 | Cameroon | 保留 | 恐怖主义融资 |
| 6 | Côte d'Ivoire | 保留 | 法人法律安排透明度 |
| 7 | DRC (刚果民主共和国) | 保留 | 受益所有权、非法采矿融资 |
| 8 | Haiti | 保留 | 恐怖主义融资、武器禁运 |
| 9 | Kenya | 保留 | 恐怖主义融资（与索马里接壤） |
| 10 | **Kuwait** | **2026 年 2 月新增** | 受益所有权透明度、NPO 监管 |
| 11 | Lao PDR | 保留 | 受益所有权、跨境监管 |
| 12 | Lebanon | 保留 | 金融体系治理、恐怖主义融资 |
| 13 | Monaco | 保留 | 法人透明度、国际协作 |
| 14 | Mozambique | 保留 | 隐藏债务 scandal 后续整改 |
| 15 | Namibia | 保留 | 受益所有权透明度 |
| 16 | Nigeria | 保留 | 恐怖主义融资（博科圣地） |
| 17 | Philippines | 保留 | 赌场/赌场 junket 监管 |
| 18 | South Sudan | 保留 | 反洗钱法律框架缺失 |
| 19 | Syria | 保留 | 恐怖主义融资、大规模杀伤性武器 |
| 20 | Tanzania | 保留 | 恐怖主义融资 |
| 21 | Vietnam | 保留 | 法人法律安排透明度 |
| 22 | Yemen | 保留 | 恐怖主义融资（阿拉伯半岛基地组织） |

**参考来源：** [FATF Increased Monitoring – February 2026](https://www.fatf-gafi.org/en/publications/High-risk-and-other-monitored-jurisdictions/increased-monitoring-february-2026.html); [Scorechain – FATF Update February 2026](https://www.scorechain.com/blog/fatf-black-and-grey-list-update-february-2026); [Comply Advantage – Feb 2026 Updates](https://complyadvantage.com/insights/fatf-plenary-february-2026-key-updates/)

---

## 8. AML 反洗钱专项检查

### 8.1 红旗指标评估

| # | 红旗指标 | 检测结果 | 风险级别 | 说明 |
|---|---|---|---|---|
| AML-1 | 客户使用跨境多层公司架构 | 未检测到 | 低 | Norden Holdings 为单层 S.à r.l.，无中间控股公司 |
| AML-2 | 资金来源与客户背景不符 | **需关注** | 中 | 出售"工业控股"权益的具体行业及资产类型未明确说明；评估报告仅笼统提及"工业资产组合" |
| AML-3 | 使用避税天堂/中转司法管辖区 | **需关注** | 中 | 注册地为卢森堡（欧盟低税率成员国），UBO 经塞浦路斯（欧盟成员国但知名中转地）持有 35%。卢森堡 S.à r.l. 常被用作持有俄罗斯财富的结构工具 |
| AML-4 | 高价值一次性交易 | **需关注** | 中 | 出售工业控股权益为单一大额交易，金额虽未明确披露但可合理推断为大额（需在客户接洽中确认） |
| AML-5 | 资金来源文件时效性不足 | **确认** | 高 | 评估报告已超过 47 个月，远超 24 个月有效期要求（规则 R5.3） |
| AML-6 | 受制裁司法管辖区关联 | **确认** | 高 | UBO 为俄罗斯国籍，资金来源为俄罗斯境内资产出售。根据 OFAC EO-14024 和欧盟对俄制裁，需验证交易不涉及制裁方 |
| AML-7 | 频繁更换银行或金融顾问 | 未检测到 | 低 | 仅一个银行关系（UBS 苏黎世），银行推荐信日期为 2025-09-05 |
| AML-8 | 交易对手方不透明 | **确认** | 高 | 工业控股出售的交易对手方身份未披露，无法完成制裁关联方核查（规则 R5.4） |

---

## 9. Step 4: 最终处置决定

```json
{
  "risk_rating": "high",
  "disposition": "escalate-EDD",
  "missing_documents": [
    "授权签字人 Dmitri Alekseevich Volkov 的身份证明文件（护照/国民身份证）",
    "董事会决议或签字权授权书",
    "资金来源——银行转账记录/交易结算证明",
    "资金来源——交易对手方身份信息及制裁筛查报告",
    "更新的评估报告（2022 年版本已超过 24 个月有效期）",
    "增强尽调（EDD）问卷",
    "律师或审计师专业推荐信"
  ],
  "escalation_reasons": [
    "规则 R2.2: 主要 UBO（Aleksandr V. Petrov, 65% 所有权）为俄罗斯联邦国籍，触发增强尽调程序。俄罗斯联邦受 OFAC EO-14024、欧盟第 8-15 套对俄制裁方案全面覆盖",
    "规则 R3.1 [FAIL]: 授权签字人 Dmitri Volkov 未提供身份证明文件，无法完成身份验证",
    "规则 R3.3 [FAIL]: 缺少董事会决议或签字权授权书，控制权未充分确认",
    "规则 R5.2 [FAIL]: 高风险客户资金来源缺乏独立文件验证（评估报告超 47 个月，无银行转账记录）",
    "规则 R5.3 [FAIL]: 资金来源支持文件超过 24 个月有效期（2022-06-18 vs. 当前 2026-05-10）",
    "规则 R5.4 [FAIL]: 涉俄交易的资金来源未包含交易对手方制裁筛查",
    "规则 R6.1 [FAIL]: 高风险评级客户未完成 EDD 问卷",
    "规则 R6.2 [FAIL]: 高风险评级客户未提供专业推荐信",
    "AML-6 [确认]: UBO 俄罗斯国籍 + 资金来源为俄罗斯境内资产出售，制裁风险敞口显著",
    "AML-8 [确认]: 交易对手方不透明，无法排除制裁关联"
  ],
  "rule_outcomes": [
    {"rule_id": "R1.1", "outcome": "pass", "evidence": "OFAC SDN / EU / UN 三大制裁名单筛查完成，0 confirmed hits，2 条 OFAC 近似匹配经人工复核排除"},
    {"rule_id": "R1.2", "outcome": "pass", "evidence": "3 名相关人员 PEP 筛查完成，无确认命中"},
    {"rule_id": "R2.1", "outcome": "pass", "evidence": "注册司法管辖区 Luxembourg 不在 FATF 黑名单上（黑名单：DPRK、伊朗、缅甸）"},
    {"rule_id": "R2.2", "outcome": "fail", "evidence": "UBO Aleksandr Petrov (65%) 俄罗斯国籍，触发 EDD。俄罗斯受 OFAC EO-14024 及 EU 对俄制裁覆盖"},
    {"rule_id": "R2.3", "outcome": "n/a", "evidence": "俄罗斯和塞浦路斯均不在 FATF 2026 年 2 月灰名单上"},
    {"rule_id": "R3.1", "outcome": "fail", "evidence": "授权签字人 Volkov 缺少身份证明文件"},
    {"rule_id": "R3.2", "outcome": "pass", "evidence": "注册证书 (DOC-001) 及 Extrait K-Bis (DOC-002) 已收到"},
    {"rule_id": "R3.3", "outcome": "fail", "evidence": "未收到董事会决议或签字权授权书"},
    {"rule_id": "R3.4", "outcome": "pass", "evidence": "UBO 声明覆盖 100% 所有权（65%+35%），2 UBO + 1 授权签字人已列示"},
    {"rule_id": "R4.1", "outcome": "n/a", "evidence": "无确认制裁命中"},
    {"rule_id": "R4.2", "outcome": "n/a", "evidence": "无确认 PEP 命中"},
    {"rule_id": "R5.1", "outcome": "pass", "evidence": "资金来源声明已签署 (DOC-006, 2025-11-14)"},
    {"rule_id": "R5.2", "outcome": "fail", "evidence": "评估报告超 47 个月（2022-06-18），无银行转账记录"},
    {"rule_id": "R5.3", "outcome": "fail", "evidence": "评估报告日期 2022-06-18，距当前日期约 47 个月，超过 24 个月有效期"},
    {"rule_id": "R5.4", "outcome": "fail", "evidence": "涉俄交易未提供交易对手方信息及制裁筛查结果"},
    {"rule_id": "R6.1", "outcome": "fail", "evidence": "高风险评级但未收到 EDD 问卷"},
    {"rule_id": "R6.2", "outcome": "fail", "evidence": "高风险评级但未收到律师/审计师推荐信"},
    {"rule_id": "R6.3", "outcome": "pending", "evidence": "待文件齐备后提交高级合规官审查"},
    {"rule_id": "R7.1", "outcome": "pass", "evidence": "CRS 自我认证签署日期 2025-11-14，在 12 个月有效期内"},
    {"rule_id": "R7.2", "outcome": "pass", "evidence": "W-8BEN-E 已签署 (DOC-009, 2025-11-14)"},
    {"rule_id": "R7.3", "outcome": "pending", "evidence": "首次筛查已完成；需建立 6 个月定期复审日程"}
  ]
}
```

---

## 10. 建议行动项

| 优先级 | 行动项 | 负责方 | 截止时间 |
|---|---|---|---|
| **P1 - 紧急** | 联系客户要求补充授权签字人 Volkov 的身份证明文件 | 客户经理 | 5 个工作日 |
| **P1 - 紧急** | 要求提供董事会决议或签字权授权书 | 客户经理 | 5 个工作日 |
| **P1 - 紧急** | 要求提供俄罗斯工业控股出售的交易对手方身份信息，以完成制裁筛查 | 合规部 | 5 个工作日 |
| **P1 - 紧急** | 发送 EDD 增强尽调问卷给客户填写 | 合规部 | 3 个工作日（发送） |
| **P2 - 高** | 要求提供银行转账记录证明资金实际流动路径 | 客户经理 | 10 个工作日 |
| **P2 - 高** | 要求提供更新的评估报告（替代 2022 年版本）或替代估值证明 | 客户经理 | 10 个工作日 |
| **P2 - 高** | 要求提供律师或审计师专业推荐信 | 客户经理 | 10 个工作日 |
| **P3 - 中** | 所有文件齐备后提交高级合规官审查批准 | 高级合规官 | 文件齐备后 5 个工作日 |
| **P3 - 中** | 建立持续监控日程：高风险客户每 6 个月制裁/PEP 重新筛查 | 合规部 | 账户开设后立即生效 |

---

## 11. 免责声明

本报告由 KYC 合规规则引擎根据客户提交文件和外部筛查数据源自动生成。**本引擎不做出审批决定——所有升级事项须由合规官及高级管理层人工审查后作出最终判断。** 制裁筛查数据截至报告日期，不构成法律意见。OFAC SDN 列表最后更新于 2026-05-07，EU 及 UN 制裁名单以各自官方发布为准。

---

## Sources

- [OFAC SDN List Search](https://sanctionssearch.ofac.treas.gov/)
- [OFAC Sanctions List Service](https://sanctionslist.ofac.treas.gov/Home/SdnList) (最后更新 2026-05-07)
- [OFAC Recent Actions](https://ofac.treasury.gov/recent-actions)
- [EU Commission – Sanctions Against Individuals, Companies and Organisations](https://commission.europa.eu/topics/eu-solidarity-ukraine/eu-sanctions-against-russia-following-invasion-ukraine/sanctions-against-individuals-companies-and-organisations_en)
- [EU Sanctions Map](https://www.sanctionsmap.eu/)
- [EU Sanctions Tracker Dashboard](https://data.europa.eu/apps/eusanctionstracker/)
- [UN Security Council Consolidated Sanctions List](https://www.un.org/securitycouncil/sanctions/sc-consolidated-list)
- [FATF High-Risk Jurisdictions – Call for Action, February 2026](https://www.fatf-gafi.org/en/publications/High-risk-and-other-monitored-jurisdictions/Call-for-action-february-2026.html)
- [FATF Jurisdictions Under Increased Monitoring, February 2026](https://www.fatf-gafi.org/en/publications/High-risk-and-other-monitored-jurisdictions/increased-monitoring-february-2026.html)
- [FATF Black and Grey Lists](https://www.fatf-gafi.org/en/countries/black-and-grey-lists.html)
- [FATF Recommendations (including Recommendation 12 – PEPs)](https://www.fatf-gafi.org/en/publications/Fatfrecommendations/Fatf-recommendations.html)
- [Scorechain – FATF Black and Grey List Update, February 2026](https://www.scorechain.com/blog/fatf-black-and-grey-list-update-february-2026)
- [Comply Advantage – FATF Plenary February 2026 Key Updates](https://complyadvantage.com/insights/fatf-plenary-february-2026-key-updates/)
- [Sanctions Lawyers – FATF Grey List and Blacklist Complete Guide](https://sanctionslawyers.net/blog-en/the-fatf-grey-list-and-blacklist-complete-guide/)
- [LexisNexis Risk Solutions – What is a Politically Exposed Person](https://risk.lexisnexis.com/global/zh/insights-resources/article/what-is-a-politically-exposed-person)
- [LSEG – Risk-Based Approach in PEP Screening](https://www.lseg.com.cn/zh/insights/risk-intelligence/why-a-risk-based-approach-is-essential-in-pep-screening)
- [CNAS – Sanctions by the Numbers: 2025 Year in Review](https://www.cnas.org/publications/reports/sanctions-by-the-numbers-2025-year-in-review)
- [GlobalSanctions – US Sanctions Lists](https://globalsanctions.com/sanctioning-states/us/sanctions-list/)
- [OpenSanctions – US OFAC SDN Dataset](https://opensanctions.org/datasets/us_ofac_sdn/)
