[DATA SOURCE: Web Search — Callan 2024 Private Equity Fees and Terms Study, Duane Morris Private Equity Fund Fees Guide, Hamilton Lane Evaluating Private Equity Fees, StepStone Group Uncovering the Costs and Benefits of PE, Carta Carried Interest Guide, EQT How Private Capital Firms Make Money, Linnovate Partners Management Fees & Distribution Waterfalls, PwC Asset Management Audit Guide (2024), EY Alternative Investments Accounting & Valuation Guide, KPMG Guide to Fund Accounting (2024), AICPA Audit & Accounting Guide — Investment Companies (ASC 946), ILPA Quarterly Reporting Standards (Version 3.0), Invest Europe Investor Reporting Guidelines (2024), CITCO Fund Services Fee Benchmarking Survey, Preqin Global Private Capital Fee Data, PitchBook Fund Performance Benchmarks, CAIA Association Fund Operations Reference, Deloitte PE Fund Accounting Handbook, Troutman Pepper Locke Fees & Expenses Survey]

# 预提费用明细表 / Accrual Schedule

**科目类型:** 预提费用 (Accrued Liabilities, GL Account 2200-000)
**报告主体:** GreenLeaf Capital Partners Fund III, L.P.（以下简称 "基金"）
**基金类型:** 私募股权买断基金 (Private Equity Buyout Fund)
**基金规模:** $750,000,000 承诺资本 (Committed Capital)
**报告期间:** FY2026 Q1 — 2026年1月1日 至 2026年3月31日（共90天）
**报告币种:** USD（美元）
**编制日期:** 2026/05/10
**编制人:** Fund Accounting Team — GreenLeaf Capital Partners
**审核状态:** 待财务总监审批 (Pending Controller Approval — Draft Only, Not for Posting)

**编制框架参考:**
- AICPA Audit & Accounting Guide — Investment Companies (ASC 946)
- ASC 470 — Debt / 基金费用资本化指引
- PwC Asset Management Audit Guide (2024 Edition) — Chapter 5: Fund-Level Expense Accruals
- EY Alternative Investments Accounting & Valuation Guide — Fee Accrual Methodology
- KPMG Guide to Fund Accounting (2024) — Month-End Close Accrual Package
- Deloitte PE Fund Accounting Handbook — Accrual Best Practices
- ILPA Quarterly Reporting Standards (Version 3.0) — Fee Transparency Guidelines
- Callan 2024 Private Equity Fees and Terms Study — Industry Benchmarking
- Duane Morris LLP — Private Equity Fund Fees & Expenses Guidance

---

## 一、基金概况与费用政策 / Fund Overview and Expense Policy

### 1.1 基金基本信息

| 项目 | 详情 |
|---|---|
| **基金名称** | GreenLeaf Capital Partners Fund III, L.P. |
| **成立日期** | 2023年3月15日 |
| **基金期限** | 10年 + 2年展期 (Standard 10+2) |
| **承诺资本 (Committed Capital)** | $750,000,000 |
| **已缴资本 (Called Capital)** | $412,500,000（截至2026年3月31日，55.0%） |
| **投资期 (Investment Period)** | 第1-5年（2023年3月 — 2028年3月） |
| **当前所处阶段** | 投资期第3年 |
| **GP出资承诺** | 2.0%（$15,000,000） |
| **LP数量** | 28家机构投资者 |
| **审计师** | Deloitte & Touche LLP |
| **法律顾问** | Simpson Thacher & Bartlett LLP |
| **基金行政服务商** | CITCO Fund Services |
| **托管银行** | State Street Bank and Trust |

### 1.2 基金费用结构（LPA约定）

根据《有限合伙协议》(LPA) 第5条及附件A，基金费用结构如下：

| 费用类型 | 费率/金额 | 计算基础 | 备注 |
|---|---|---|---|
| **管理费 (Management Fee)** | 1.75% p.a. | 投资期：承诺资本；投资期后：投入资本成本 | 行业标准：1.5%-2.0%（来源：Callan 2024） |
| **Carried Interest** | 20% | 超过8%优先回报的利润 | 行业标准：20%（来源：EQT/Carta） |
| **优先回报 (Preferred Return)** | 8% p.a. | 按复利计算 | 行业标准：7%-10%（来源：PLI） |
| **审计费** | $285,000 p.a. | 固定费用协议 | 行业范围：$250K-$750K（来源：PwC） |
| **法律费** | $180,000 p.a. | 年度预算（不含交易费用） | 行业范围：$100K-$300K（来源：ILPA） |
| **基金行政费** | $225,000 p.a. | 固定 + NAV阶梯 | 行业范围：0.05%-0.15% NAV |
| **保险费** | $95,000 p.a. | D&O + 职业责任险 | 按年预缴，按月摊销 |
| **税务与合规费** | $65,000 p.a. | K-1编制 + FATCA/CRS | 季末集中确认 |
| **IT与数据服务费** | $48,000 p.a. | Bloomberg + PitchBook + Preqin | 按月计费 |
| **托管费** | $42,000 p.a. | 资产保管费 | 按季计费 |

### 1.3 预提政策 (Accrual Policy)

| 政策编号 | 政策描述 | 适用科目 |
|---|---|---|
| ACC-001 | 管理费按月直线法计提，基于承诺资本 | 管理费 |
| ACC-002 | Carried Interest 按季评估，基于整体基金法（Whole-Fund Method）| Carried Interest |
| ACC-003 | 审计费按月直线法计提，年度终了结算 | 审计费 |
| ACC-004 | 法律费按月直线法计提，实际发生时冲销预提 | 法律费 |
| ACC-005 | 行政费按月直线法计提 | 基金行政费 |
| ACC-006 | 保险费按月直线法摊销，年度保费已预缴 | 保险费 |
| ACC-007 | 税务合规费按季末集中确认 | 税务合规费 |
| ACC-008 | IT/数据服务费按月直线法计提 | IT与数据服务费 |
| ACC-009 | 托管费按季末确认 | 托管费 |
| ACC-010 | 所有预提均为自动冲回（Auto-Reversing）| 全部 |

---

## 二、预提费用计算明细 / Accrual Calculation Detail

### 2.1 管理费预提 (Management Fee Accrual)

**政策依据:** ACC-001 | LPA 第5.1(a)条
**计算公式:** 承诺资本 × 年费率 × (当期天数 ÷ 基础期天数)
**基础期:** 年度（365天） | **当期天数:** 90天（2026年1月1日 — 3月31日）

| 项目 | 计算 |
|---|---|
| 承诺资本 (Committed Capital) | $750,000,000 |
| 年费率 | 1.75% |
| 年度管理费基础金额 | $750,000,000 × 1.75% = $13,125,000 |
| 当期比例 | 90 / 365 = 24.6575% |
| **当期管理费预提** | **$13,125,000 × 24.6575% = $3,236,301** |

**已入账金额 (Already Booked):**

| 月份 | 已入账金额 | 凭证号 | 说明 |
|---|---|---|---|
| 2026年1月 | $1,093,750 | JE-2026-0045 | 1月管理费预提 |
| 2026年2月 | $1,093,750 | JE-2026-0078 | 2月管理费预提 |
| **已入账合计** | **$2,187,500** | | |

**本期间预提调整 (This-Period Accrual):**

| 项目 | 金额 |
|---|---|
| 当期应付总额 | $3,236,301 |
| 减：已入账金额 | ($2,187,500) |
| **本期应补提金额** | **$1,048,801** |

> 注：差异源于2月天数（28天）导致的直线法累计偏差，季末补提调整。

**支持文件:** LPA Amendment No. 1 (2023-08-15), Fee Computation Worksheet GL-Q1-2026-MF

---

### 2.2 Carried Interest 预提 (Carried Interest Accrual)

**政策依据:** ACC-002 | LPA 第5.2条及附件B（分配瀑布）
**计算方法:** 整体基金法 (Whole-Fund Method), 按季评估

**基金业绩概况 (截至2026年3月31日):**

| 项目 | 金额 |
|---|---|
| 已缴资本 (Paid-In Capital) | $412,500,000 |
| 投资成本 (Cost Basis) | $398,200,000 |
| 投资公允价值 (Fair Value) | $487,350,000 |
| 未实现增值 (Unrealized Appreciation) | $89,150,000 |
| 已实现收益 (Realized Gains) | $12,450,000 |
| 基金总价值 (Total Value) | $499,800,000 |
| TVPI (Total Value / Paid-In) | 1.21x |
| DPI (Distributions / Paid-In) | 0.03x |
| RVPI (Residual Value / Paid-In) | 1.18x |

**Carried Interest 计算步骤:**

| 步骤 | 计算 | 金额 |
|---|---|---|
| (1) 基金总价值 (TV) | 投资公允价值 + 现金 + 已分配 | $499,800,000 |
| (2) 归还资本 | 已缴资本 | ($412,500,000) |
| (3) 超额利润 | (1) - (2) | $87,300,000 |
| (4) 优先回报 (8% 复利, 3年) | $412,500,000 × [(1.08)^3 - 1] | $106,791,375 |
| (5) 优先回报缺额 | (4) - (3)（若为正） | $19,491,375 |
| **(6) 当期应计Carry** | max[0, (3) - (4)] × 20% | **$0** |

**Carried Interest 预提:**

| 项目 | 金额 |
|---|---|
| 当期应付Carry | $0 |
| 减：已入账金额 | $0 |
| **本期应补提金额** | **$0** |

> 注：截至报告期末，基金总价值尚未超过优先回报门槛（8%复利），因此Carried Interest无需预提。基金TVPI为1.21x，但考虑优先回报的复利效应（3年累计约25.9%），仍处于"追回期" (catch-up period)。应持续监控，预计在TVPI达到约1.26x时开始产生Carry。

**支持文件:** Waterfall Computation Worksheet GL-Q1-2026-CI, LP Capital Account Statement as of 2026-03-31

---

### 2.3 审计费预提 (Audit Fee Accrual)

**政策依据:** ACC-003 | 审计聘书 dated 2025-11-20 (Deloitte & Touche LLP)
**计算公式:** 年度审计费 × (当期天数 ÷ 365)

| 项目 | 计算 |
|---|---|
| 年度审计费（聘书约定） | $285,000 |
| 当期比例 (Q1: 90/365) | 24.6575% |
| **当期审计费预提** | **$285,000 × 24.6575% = $70,274** |

**已入账金额 (Already Booked):**

| 月份 | 已入账金额 | 凭证号 |
|---|---|---|
| 2026年1月 | $23,750 | JE-2026-0046 |
| 2026年2月 | $23,750 | JE-2026-0079 |
| **已入账合计** | **$47,500** | |

**本期间预提调整:**

| 项目 | 金额 |
|---|---|
| 当期应付总额 | $70,274 |
| 减：已入账金额 | ($47,500) |
| **本期应补提金额** | **$22,774** |

**支持文件:** Engagement Letter Deloitte-GLIII-2025, Invoice DEL-2026-INV-0001 ($47,500 YTD interim billing)

---

### 2.4 法律费预提 (Legal Fee Accrual)

**政策依据:** ACC-004 | 法律顾问预算协议 dated 2025-12-01 (Simpson Thacher & Bartlett LLP)
**计算公式:** 年度法律费预算 × (当期天数 ÷ 365)

| 项目 | 计算 |
|---|---|
| 年度法律费预算（不含交易费用） | $180,000 |
| 当期比例 (Q1: 90/365) | 24.6575% |
| **当期法律费预提** | **$180,000 × 24.6575% = $44,384** |

**已入账金额与实际发票:**

| 月份 | 已预提金额 | 实际发票 | 凭证号 | 说明 |
|---|---|---|---|---|
| 2026年1月 | $15,000 | $12,350 | JE-2026-0047 / AP-2026-0023 | 常规合规咨询 |
| 2026年2月 | $15,000 | $8,750 | JE-2026-0080 / AP-2026-0041 | LP沟通函件 |
| 2026年3月 | — | $18,200 | AP-2026-0058 | 季度报告 + 法规更新 |
| **已预提合计** | **$30,000** | | | |
| **实际发票合计** | | **$39,300** | | |

**本期间预提调整:**

| 项目 | 金额 |
|---|---|
| 当期应付总额 | $44,384 |
| 减：已预提金额 | ($30,000) |
| 减：实际发票已入账 | ($39,300) |
| **本期应补提（冲回）金额** | **($24,916)** |

> 注：本期法律实际支出超出预算预提，且3月尚未进行月度预提。净调整反映：冲回已过量的预提，补入实际发生的未入账发票。

**支持文件:** Simpson Thacher Monthly Invoices STB-2026-01/02/03, Legal Budget Tracker GL-Q1-2026-LAW

---

### 2.5 基金行政费预提 (Fund Administration Fee Accrual)

**政策依据:** ACC-005 | 基金行政服务协议 dated 2023-03-15 (CITCO Fund Services)
**计算公式:** 年度固定费 + NAV阶梯费 × (当期天数 ÷ 365)

| 项目 | 计算 |
|---|---|
| 年度固定费 | $175,000 |
| NAV阶梯费 ($487,350,000 × 0.01%) | $48,735 |
| 年度行政费总额 | $223,735 |
| 当期比例 (Q1: 90/365) | 24.6575% |
| **当期行政费预提** | **$223,735 × 24.6575% = $55,163** |

**已入账金额:**

| 月份 | 已入账金额 | 凭证号 |
|---|---|---|
| 2026年1月 | $18,333 | JE-2026-0048 |
| 2026年2月 | $18,333 | JE-2026-0081 |
| **已入账合计** | **$36,666** | |

**本期间预提调整:**

| 项目 | 金额 |
|---|---|
| 当期应付总额 | $55,163 |
| 减：已入账金额 | ($36,666) |
| **本期应补提金额** | **$18,497** |

> 注：NAV阶梯费部分基于季末公允价值重新计算，与月度直线预提存在差异。

**支持文件:** CITCO Service Agreement Amendment 2, CITCO Invoice CIT-2026-Q1-001

---

### 2.6 保险费摊销 (Insurance Expense Amortization)

**政策依据:** ACC-006 | 保险单 dated 2025-07-01 (年度保费已预缴)
**计算公式:** 年度保费 × (当期天数 ÷ 保单期天数)

| 项目 | 计算 |
|---|---|
| D&O保险年度保费 | $62,000 |
| 职业责任险年度保费 | $33,000 |
| 年度保费总额 | $95,000 |
| 保单期间 | 2025/07/01 — 2026/06/30（365天） |
| 当期比例 (Q1: 90/365) | 24.6575% |
| **当期保险费摊销** | **$95,000 × 24.6575% = $23,424** |

**已入账金额:**

| 月份 | 已入账金额 | 凭证号 |
|---|---|---|
| 2026年1月 | $7,917 | JE-2026-0049 |
| 2026年2月 | $7,917 | JE-2026-0082 |
| **已入账合计** | **$15,834** | |

**本期间预提调整:**

| 项目 | 金额 |
|---|---|
| 当期应付总额 | $23,424 |
| 减：已入账金额 | ($15,834) |
| **本期应补提金额** | **$7,590** |

**支持文件:** Insurance Policy GL-INS-2025-001 (AIG), Prepaid Amortization Schedule GL-Q1-2026-INS

---

### 2.7 税务与合规费预提 (Tax & Compliance Fee Accrual)

**政策依据:** ACC-007 | 税务服务协议 (PricewaterhouseCoopers LLP)
**计算方法:** 按季末集中确认（K-1编制周期 + FATCA/CRS合规）

| 项目 | 金额 |
|---|---|
| K-1编制费（年度预算） | $40,000 |
| FATCA/CRS合规费（年度预算） | $15,000 |
| 州税务申报费（年度预算） | $10,000 |
| 年度税务费总额 | $65,000 |
| Q1应确认比例 | 25%（季度均摊） |
| **当期税务费预提** | **$65,000 × 25% = $16,250** |

**已入账金额:**

| 凭证号 | 金额 | 说明 |
|---|---|---|
| — | $0 | 税务费按季末确认，Q1无前期入账 |

**本期间预提调整:**

| 项目 | 金额 |
|---|---|
| 当期应付总额 | $16,250 |
| 减：已入账金额 | $0 |
| **本期应补提金额** | **$16,250** |

> 注：K-1编制工作通常在Q2（4-5月）集中进行，但费用应按季预提以匹配期间。

**支持文件:** PwC Tax Engagement Letter PWC-GLIII-2025, Tax Compliance Calendar GL-2026-TAX

---

### 2.8 IT与数据服务费预提 (IT & Data Services Fee Accrual)

**政策依据:** ACC-008 | 数据订阅协议（Bloomberg, PitchBook, Preqin）
**计算公式:** 年度订阅费 × (当期天数 ÷ 365)

| 订阅服务 | 年度费用 | 当期预提 | 已入账 | 补提金额 |
|---|---|---|---|---|
| Bloomberg Terminal (2台) | $27,000 | $6,657 | $4,500 | $2,157 |
| PitchBook Enterprise | $12,000 | $2,959 | $1,000 | $1,959 |
| Preqin Data Feed | $9,000 | $2,219 | $750 | $1,469 |
| **合计** | **$48,000** | **$11,835** | **$6,250** | **$5,585** |

**支持文件:** Bloomberg Agreement BBT-2025-GL, PitchBook Subscription PK-2025-GL, Preqin License PRE-2025-GL

---

### 2.9 托管费预提 (Custody Fee Accrual)

**政策依据:** ACC-009 | 托管协议 dated 2023-03-15 (State Street Bank and Trust)
**计算方法:** 按季确认，基于平均托管资产

| 项目 | 计算 |
|---|---|
| Q1平均托管资产 | $489,600,000 |
| 年费率 | 0.0086% |
| 年度托管费基础 | $489,600,000 × 0.0086% = $42,106 |
| Q1应确认比例 | 25% |
| **当期托管费预提** | **$42,106 × 25% = $10,527** |

**已入账金额:** $0（托管费按季确认）

**本期应补提金额: $10,527**

**支持文件:** State Street Custody Agreement SSB-GLIII-2023, Q1 Average Balance Report SSB-2026-Q1

---

## 三、预提费用汇总表 / Accrual Summary Schedule

### 3.1 Q1 FY2026 预提费用汇总

| 序号 | 预提科目 | 年度基础金额 | 当期应付金额 | 已入账金额 | 本期补提金额 | 自动冲回 |
|---|---|---|---|---|---|---|
| 1 | 管理费 (Management Fee) | $13,125,000 | $3,236,301 | $2,187,500 | $1,048,801 | 是 |
| 2 | Carried Interest | N/A | $0 | $0 | $0 | 是 |
| 3 | 审计费 (Audit Fee) | $285,000 | $70,274 | $47,500 | $22,774 | 是 |
| 4 | 法律费 (Legal Fee) | $180,000 | $44,384 | $69,300 | ($24,916) | 是 |
| 5 | 基金行政费 (Admin Fee) | $223,735 | $55,163 | $36,666 | $18,497 | 是 |
| 6 | 保险费 (Insurance) | $95,000 | $23,424 | $15,834 | $7,590 | 否 |
| 7 | 税务合规费 (Tax & Compliance) | $65,000 | $16,250 | $0 | $16,250 | 是 |
| 8 | IT与数据服务 (IT & Data) | $48,000 | $11,835 | $6,250 | $5,585 | 是 |
| 9 | 托管费 (Custody Fee) | $42,106 | $10,527 | $0 | $10,527 | 是 |
| **合计** | | **$14,063,841** | **$3,468,158** | **$2,363,050** | **$1,105,108** | |

### 3.2 预提费用构成分析

| 费用类别 | 年度预算 | Q1实际 | 占年度预算% | 占承诺资本基点 |
|---|---|---|---|---|
| 管理费 | $13,125,000 | $3,236,301 | 24.7% | 43.2 bps |
| 审计费 | $285,000 | $70,274 | 24.7% | 0.9 bps |
| 法律费 | $180,000 | $44,384 | 24.7% | 0.6 bps |
| 基金行政费 | $223,735 | $55,163 | 24.7% | 0.7 bps |
| 保险费 | $95,000 | $23,424 | 24.7% | 0.3 bps |
| 税务合规费 | $65,000 | $16,250 | 25.0% | 0.2 bps |
| IT与数据服务 | $48,000 | $11,835 | 24.7% | 0.2 bps |
| 托管费 | $42,106 | $10,527 | 25.0% | 0.1 bps |
| **合计（不含管理费）** | **$938,841** | **$231,857** | **24.7%** | **3.1 bps** |
| **合计（含管理费）** | **$14,063,841** | **$3,468,158** | **24.7%** | **46.2 bps** |

> 行业基准：PE基金总费用（含管理费）通常占承诺资本的1.5%-2.0%（来源：StepStone Group, Callan 2024）。本基金年度费率约1.88%，处于行业中位水平。

---

## 四、草稿日记账 / Draft Journal Entries

> **重要提示：以下日记账为草稿，仅供财务总监审批参考。未经审批不得过账。**
> **IMPORTANT: These are draft JEs staged for controller sign-off. Do NOT post.**

### JE-2026-0145：Q1管理费预提调整

```
Dr  6100-000  管理费用 — 管理费 (Management Fee Expense)         $1,048,801
    Cr  2200-010  预提费用 — 管理费 (Accrued Management Fee)             $1,048,801
Memo: 管理费 — FY2026 Q1 季末补提调整，基准：承诺资本$750M × 1.75% × 90/365
      支持：LPA Amendment No. 1, Fee Computation Worksheet GL-Q1-2026-MF
      Reverses on day 1 of next period.
```

### JE-2026-0146：Q1 Carried Interest 预提

```
（无需预提 — 基金总价值未超过优先回报门槛）
Memo: Carried Interest — FY2026 Q1 评估结果：基金TVPI 1.21x，低于Carry触发点（约1.26x）
      支持：Waterfall Computation Worksheet GL-Q1-2026-CI
      下次评估日：2026年6月30日 (Q2)
```

### JE-2026-0147：Q1审计费预提调整

```
Dr  6200-000  管理费用 — 审计费 (Audit Fee Expense)                $22,774
    Cr  2200-020  预提费用 — 审计费 (Accrued Audit Fee)                   $22,774
Memo: 审计费 — FY2026 Q1 季末补提调整，基准：年度审计费$285,000 × 90/365
      支持：Deloitte Engagement Letter dated 2025-11-20
      Reverses on day 1 of next period.
```

### JE-2026-0148：Q1法律费预提冲回

```
Dr  2200-030  预提费用 — 法律费 (Accrued Legal Fee)                $24,916
    Cr  6200-010  管理费用 — 法律费 (Legal Fee Expense)                   $24,916
Memo: 法律费 — FY2026 Q1 冲回超额预提，实际发票$39,300 vs 已预提$30,000
      支持：Simpson Thacher Invoices STB-2026-01/02/03
      Reverses on day 1 of next period.
```

### JE-2026-0149：Q1基金行政费预提调整

```
Dr  6200-020  管理费用 — 基金行政费 (Admin Fee Expense)            $18,497
    Cr  2200-040  预提费用 — 行政费 (Accrued Admin Fee)                   $18,497
Memo: 基金行政费 — FY2026 Q1 季末补提，含NAV阶梯费调整
      基准：固定费$175,000 + NAV阶梯$48,735 = $223,735/年 × 90/365
      支持：CITCO Service Agreement Amendment 2, Q1 NAV Report
      Reverses on day 1 of next period.
```

### JE-2026-0150：Q1保险费摊销调整

```
Dr  6200-030  管理费用 — 保险费 (Insurance Expense)                 $7,590
    Cr  1300-000  预付费用 — 保险费 (Prepaid Insurance)                    $7,590
Memo: 保险费 — FY2026 Q1 季末摊销调整，D&O $62,000 + 职业责任 $33,000
      支持：Insurance Policy GL-INS-2025-001, Prepaid Amortization Schedule
      注：保险费为预付账款摊销，非预提费用，不自动冲回。
```

### JE-2026-0151：Q1税务合规费预提

```
Dr  6200-040  管理费用 — 税务合规费 (Tax & Compliance Expense)    $16,250
    Cr  2200-050  预提费用 — 税务费 (Accrued Tax & Compliance Fee)        $16,250
Memo: 税务合规费 — FY2026 Q1 季度确认，K-1编制$40K + FATCA/CRS $15K + 州税$10K = $65K × 25%
      支持：PwC Tax Engagement Letter PWC-GLIII-2025, Tax Calendar GL-2026-TAX
      Reverses on day 1 of next period.
```

### JE-2026-0152：Q1 IT与数据服务费预提调整

```
Dr  6200-050  管理费用 — IT与数据服务 (IT & Data Expense)          $5,585
    Cr  2200-060  预提费用 — IT与数据服务 (Accrued IT & Data Fee)          $5,585
Memo: IT与数据服务费 — FY2026 Q1 季末补提，Bloomberg + PitchBook + Preqin 订阅费
      支持：BBT-2025-GL, PK-2025-GL, PRE-2025-GL
      Reverses on day 1 of next period.
```

### JE-2026-0153：Q1托管费预提

```
Dr  6200-060  管理费用 — 托管费 (Custody Fee Expense)              $10,527
    Cr  2200-070  预提费用 — 托管费 (Accrued Custody Fee)                 $10,527
Memo: 托管费 — FY2026 Q1 季度确认，平均托管资产$489.6M × 0.0086% × 25%
      支持：State Street Custody Agreement SSB-GLIII-2023, Q1 Avg Balance Report
      Reverses on day 1 of next period.
```

---

## 五、日记账汇总 / JE Summary

| JE编号 | 借方科目 | 借方金额 | 贷方科目 | 贷方金额 |
|---|---|---|---|---|
| JE-2026-0145 | 6100-000 管理费 | $1,048,801 | 2200-010 预提管理费 | $1,048,801 |
| JE-2026-0146 | （无需分录） | $0 | — | $0 |
| JE-2026-0147 | 6200-000 审计费 | $22,774 | 2200-020 预提审计费 | $22,774 |
| JE-2026-0148 | 2200-030 预提法律费 | $24,916 | 6200-010 法律费 | $24,916 |
| JE-2026-0149 | 6200-020 行政费 | $18,497 | 2200-040 预提行政费 | $18,497 |
| JE-2026-0150 | 6200-030 保险费 | $7,590 | 1300-000 预付保险费 | $7,590 |
| JE-2026-0151 | 6200-040 税务合规费 | $16,250 | 2200-050 预提税务费 | $16,250 |
| JE-2026-0152 | 6200-050 IT与数据服务 | $5,585 | 2200-060 预提IT费 | $5,585 |
| JE-2026-0153 | 6200-060 托管费 | $10,527 | 2200-070 预提托管费 | $10,527 |
| **合计** | | **$1,154,940** | | **$1,154,940** |

> 借贷平衡校验：借方合计 $1,154,940 = 贷方合计 $1,154,940 ✓

---

## 六、行业基准比较 / Industry Benchmark Comparison

### 6.1 费用率基准对比

| 费用类别 | 本基金费率 | 行业中位数 | 行业范围 | 基准来源 |
|---|---|---|---|---|
| 管理费 (投资期) | 1.75% | 1.75% | 1.50% - 2.00% | Callan 2024, Duane Morris |
| 审计费 / AUM | 0.038% | 0.050% | 0.02% - 0.10% | PwC, KPMG Survey |
| 法律费 / AUM | 0.024% | 0.030% | 0.01% - 0.06% | ILPA, Troutman Pepper |
| 行政费 / AUM | 0.030% | 0.080% | 0.05% - 0.15% | CITCO Survey, Preqin |
| 总非管理费用 / AUM | 0.125% | 0.200% | 0.10% - 0.40% | StepStone, PitchBook |
| Carried Interest | 20% | 20% | 10% - 25% | Carta, EQT, Callan 2024 |
| 优先回报 (Hurdle) | 8% | 8% | 7% - 10% | PLI, Invest Europe |

### 6.2 与同类基金费用对比（$500M-$1B 规模区间）

| 指标 | 本基金 | 同类基金中位数 | 四分位范围 | 评级 |
|---|---|---|---|---|
| 管理费率 | 1.75% | 1.75% | 1.50% - 2.00% | 中位 |
| 非管理费用/AUM | 0.125% | 0.20% | 0.10% - 0.40% | 低于中位（有利） |
| 总费用/AUM | 1.875% | 1.95% | 1.50% - 2.40% | 低于中位（有利） |
| Carried Interest | 20% | 20% | 20% - 20% | 标准条款 |

---

## 七、风险提示与后续事项 / Risk Notes and Follow-Up Items

### 7.1 风险提示

| 编号 | 风险描述 | 影响 | 缓释措施 |
|---|---|---|---|
| R-001 | Carried Interest接近触发点，Q2可能需要开始预提 | 可能在Q2产生大额费用 | 每月监控TVPI，提前与审计师沟通 |
| R-002 | 法律费实际支出超出年度预算12.4% | 可能需要追加预算或从GP承担 | 与Simpson Thacher协商固定月费 |
| R-003 | Q1投资活动增加可能导致行政费超预算 | NAV阶梯费上升 | 已在预算中预留10%缓冲 |
| R-004 | 保险保单将于2026年6月30日到期需续保 | 续保费率可能上升5%-15% | 提前60天启动续保询价 |

### 7.2 后续事项 (Open Items)

| 编号 | 事项 | 负责人 | 截止日期 | 状态 |
|---|---|---|---|---|
| F-001 | 财务总监审批本预提包 | Controller | 2026/04/05 | 待审批 |
| F-002 | Deloitte Q1中期审计费发票核对 | AP Team | 2026/04/10 | 进行中 |
| F-003 | Simpson Thacher 3月发票差异跟进 | Legal Ops | 2026/04/08 | 已提交 |
| F-004 | CITCO Q1 NAV确认与行政费结算 | Fund Admin | 2026/04/15 | 待确认 |
| F-005 | State Street Q1托管费发票核对 | AP Team | 2026/04/12 | 进行中 |
| F-006 | PwC K-1编制启动（预计4月下旬） | Tax Team | 2026/04/30 | 未启动 |
| F-007 | Carried Interest Q2预估评估 | Fund Accounting | 2026/06/30 | 计划中 |

---

## 八、审批签核 / Approval Sign-Off

| 角色 | 姓名 | 签名 | 日期 |
|---|---|---|---|
| 编制人 (Prepared By) | Fund Accounting Team | ____________ | 2026/05/10 |
| 复核人 (Reviewed By) | Senior Fund Accountant | ____________ | __ / __ / ____ |
| 审批人 (Approved By) | Fund Controller | ____________ | __ / __ / ____ |

---

**免责声明 / Disclaimer:** 本预提费用明细表为草稿，仅供财务总监审批参考。所有日记账均未过账。实际费用以审批后的凭证为准。自动冲回分录将在下一期间首日自动执行。数据来源标注于各科目支持文件中，行业基准数据来源于公开市场研究报告和行业协会调查。

---

Sources:
- [Callan 2024 Private Equity Fees and Terms Study](https://www.callan.com/blog/2024-private-equity-fees/)
- [Duane Morris LLP — Private Equity Fund Fees](https://www.duanemorris.com/site/static/private_equity_fund_fees.pdf)
- [Duane Morris LLP — Private Equity Fund Expenses](https://www.duanemorris.com/site/static/private_equity_fund_expenses.pdf)
- [Hamilton Lane — Evaluating Private Equity Fees](https://www.hamiltonlane.com/en-us/knowledge-center/pe-fees)
- [StepStone Group — Uncovering the Costs and Benefits of PE](https://www.stepstonegroup.com/wp-content/uploads/2021/07/StepStone_Uncovering_the-Costs-and-Benefits-of-PE.pdf)
- [Carta — Carried Interest Explained](https://carta.com/learn/private-funds/management/carried-interest/)
- [Carta — Management Fees Guide](https://carta.com/learn/private-funds/management/management-fees/)
- [EQT — How Private Capital Firms Make Money](https://eqtgroup.com/en/thinq/equity/how-private-capital-firms-make-money-fees-and-carried-interest-explained)
- [Linnovate Partners — Management Fees & Distribution Waterfalls](https://linnovatepartners.com/understanding-management-fees-carried-interest-and-distribution-waterfalls/)
- [Invest Europe — Investor Reporting Guidelines (2024)](https://www.investeurope.eu/media/3ydbhksh/investor-reporting-guidelines-pdf_240403.pdf)
- [Finantrix — Fund-Level vs Deal-Level Fee Calculations](https://www.finantrix.com/articles/comparing-fund-level-vs-deal-level-fee-calculations-in-private-equity)
- [ScaleX Invest — Navigating Private Equity Fees](https://www.scalex-invest.com/blog/navigating-private-equity-fees-carried-interest-and-management-fees-explained)
- [Troutman Pepper Locke — Fees & Expenses Survey 2020](https://www.troutman.com/wp-content/uploads/2025/03/PFCFO-FeesExpenses-Nov20-Final.pdf)
- [Cliffwater — The Price of Perpetuity](https://www.cliffwater.com/ResourceArticle/the-price-of-perpetuity?docId=24556)
- [PwC Asset Management Audit Guide (2024)](https://www.pwc.com/us/en/services/asset-management.html)
- [EY Alternative Investments Accounting & Valuation Guide](https://www.ey.com/en_gl/financial-services)
- [KPMG Guide to Fund Accounting (2024)](https://home.kpmg/xx/en/home/campaigns/2024/01/fund-accounting.html)
- [AICPA Audit & Accounting Guide — Investment Companies (ASC 946)](https://www.aicpa-cima.com/topic/audit-assurance)
- [ILPA Quarterly Reporting Standards (Version 3.0)](https://ilpa.org/reporting-standards/)
