[DATA SOURCE: Bain & Company Global Private Equity Report 2026 / McKinsey Global Private Markets Report 2025 & 2026 / PitchBook Global Private Market Funds Dry Powder Dashboard 2026 / PwC Private Equity US Deals 2026 Outlook / S&P Global Market Intelligence / Cherry Bekaert Private Equity Report 2025-2026 / PKF Littlejohn Global PE 2025 Review / Flexera 2025 State of the Cloud Report / Company IR filings (SentinelOne, CrowdStrike, Snyk, Abnormal Security, Huntress, Cyberhaven) / Grata Proprietary Deal Sourcing / SourceCo Deals / Axial M&A Platform / Houlihan Lokey Technology Group / ScaleView Partners / Solganick & Co.]

# PE Deal Sourcing Report

## Growth Equity Fund IV — B2B SaaS / Cybersecurity / Cloud Management

**基金策略**: Growth Equity Fund IV, $1B AUM，单笔投资规模 $100-200M，聚焦 B2B SaaS（网络安全、云管理、身份安全、数据保护）
**日期**: 2026年5月9日
**负责团队**: Deal Sourcing Team

---

## 一、市场概况与基金部署背景

### 1.1 全球PE Dry Powder 现状

根据 PitchBook 2026年全球私募市场基金 Dry Powder 仪表板数据，截至2025年Q2末，全球封闭式私募资本基金持有的 Dry Powder 达到 **$4.63万亿**，较年末增长 **4.6%**。其中：

| 指标 | 数据 | 来源 |
|------|------|------|
| 全球PE Dry Powder | ~$1.2万亿 | PKF Littlejohn 2025 Review |
| 美国PE基金 Dry Powder | ~$880B (2025年9月) | PwC US PE Deals 2026 Outlook |
| Dry Powder 老化比例 | >40%已持有超过4年 | McKinsey Global Private Markets Report 2026 |
| 全球私募资本总 Dry Powder | $4.63万亿 | PitchBook Dashboard 2026 |

**关键信号**: McKinsey 报告指出超过 **16,000家公司** 已被PE持有超过4年，平均持有期达到 **6.6年**。Dry Powder 老化带来巨大部署压力，2026年预计将迎来加速投资期。

### 1.2 2025-2026年PE交易市场回顾与展望

根据 Bain & Company 2026全球PE报告及M&A报告：

| 指标 | 2024年 | 2025年 | 变化 |
|------|--------|--------|------|
| 全球M&A交易总价值 | ~$3.5万亿 | **~$4.8-4.9万亿** | +36-40% YoY |
| 全球M&A交易量 | 基准 | +5-7% YoY | 温和增长 |
| 科技/软件占全部交易比例 | 19% | **22%** | 显著提升 |
| PE退出价值 | 偏低 | **$1.3万亿 (+41%)** | 第二历史高位 |
| PE交易价值增长 | — | **+17%** | 复苏趋势 |

Bain & Company 在其《M&A in Software: Five Secrets to Creating Real Value》报告中明确指出，**AI正成为推动软件M&A交易活动的核心驱动力**。

### 1.3 SaaS M&A 趋势

根据 SaaSMag 2026年数据：

- **2,698宗SaaS交易**于2025年完成，同比增长 **28%**
- 这标志着**SaaS历史上最大的M&A浪潮**
- 驱动因素包括：AI原生产品整合、Cloud成本优化（FinOps）、安全合规需求激增

---

## 二、投资策略与筛选标准

### 2.1 Growth Equity Fund IV 策略参数

| 参数 | 标准 |
|------|------|
| **基金规模** | $1B AUM |
| **单笔投资** | $100-200M（少数股权 / 控股权均可） |
| **目标行业** | B2B SaaS — 网络安全、云管理、身份与访问管理（IAM）、数据保护/DLP、FinOps |
| **目标ARR** | $50M - $300M |
| **增长要求** | YoY ARR增长 >30%（优先 >50%） |
| **毛利率** | >75%（SaaS标准） |
| **NRR** | >110%（净收入留存率） |
| **地理** | 北美为主，兼顾以色列/欧洲高增长标的 |
| **所有权偏好** | Founder-owned 优先；也考虑PE-backed secondary / Corporate carve-out |

### 2.2 核心投资主题

1. **AI-Native Cybersecurity**: 利用AI/ML进行自主威胁检测与响应的安全平台
2. **Cloud Security Posture Management (CSPM)**: 云安全态势管理，伴随多云/混合云增长
3. **Identity & Access Management (IAM)**: 零信任架构下的身份安全
4. **Data Loss Prevention (DLP) / Insider Threat**: AI时代的数据保护
5. **FinOps / Cloud Cost Optimization**: 云成本管理，Flexera 2025报告显示35%企业SaaS浪费YoY增加
6. **MDR/SOC-as-a-Service for SMB**: 中小企业安全运营外包趋势

---

## 三、目标公司发现（Step 1: Discover Companies）

### 3.1 候选公司短名单

基于行业报告、会议参展商名单、竞品分析及公开财务数据，识别以下 **8家** 高优先级目标公司：

---

#### 目标 #1: Abnormal Security (Abnormal AI)

| 属性 | 详情 |
|------|------|
| **公司名称** | Abnormal Security（现品牌 Abnormal AI） |
| **总部** | San Francisco, CA |
| **CEO/Founder** | Evan Reiser (CEO), Sanjay Jeyakumar (CTO) |
| **产品** | AI驱动的行为式邮件安全平台，防御社交工程攻击 |
| **估计ARR** | ~$200-330M（2025年估计） |
| **增长率** | ~100% YoY（历史上持续翻倍增长） |
| **融资/估值** | Series D $250M（Wellington Management领投），估值 $5.1B |
| **客户数** | ~2,400+ |
| **入选理由** | 4年内突破$100M ARR；2025 CNBC Disruptor 50；Forbes Cloud 100三连；邮件安全市场$17.3亿且快速增长；AI-native产品有强护城河 |
| **网站** | abnormal.ai |

---

#### 目标 #2: Huntress

| 属性 | 详情 |
|------|------|
| **公司名称** | Huntress Labs, Inc. |
| **总部** | Ellicott City, MD |
| **CEO/Founder** | Kyle Hanslovan (CEO, Co-Founder) |
| **产品** | 面向SMB的MDR（托管检测与响应）平台，通过MSP渠道交付 |
| **估计ARR** | $100-150M+（2025年） |
| **增长率** | 高速增长至$150M+ ARR |
| **融资/估值** | Series D $150-180M，估值 ~$1.55B；总融资 ~$298M |
| **主要投资方** | Meritech, Sapphire Ventures, ForgePoint Capital |
| **关键指标** | 3M+ endpoints，120,000+ 企业客户 |
| **入选理由** | SMB网络安全市场预计从$25B（2023）增至$70B（2034）；MSP渠道模式带来高留存；IPO预期2025-2026，Growth Equity入场窗口有限 |
| **网站** | huntress.com |

---

#### 目标 #3: Cyberhaven

| 属性 | 详情 |
|------|------|
| **公司名称** | Cyberhaven, Inc. |
| **总部** | San Jose, CA |
| **CEO/Founder** | Howard Ting (CEO) |
| **产品** | AI驱动的数据安全与DLP（数据防泄漏）平台 |
| **估计ARR** | $30-50M+（高速增长中） |
| **增长率** | Bookings增长 200%+ |
| **融资** | 2025年4月完成 $100M融资轮；此前 $88M Series C |
| **入选理由** | AI时代数据保护需求爆发；200%+ bookings增长证明PMF；DLP市场传统产品老化，存在颠覆机会；融资规模暗示ARR快速增长至$50M+ |
| **网站** | cyberhaven.com |

---

#### 目标 #4: Snyk

| 属性 | 详情 |
|------|------|
| **公司名称** | Snyk Ltd. |
| **总部** | Boston, MA（原以色列） |
| **CEO** | Peter McKay (CEO) |
| **产品** | Developer-first安全平台 — SCA, SAST, IaC, Container Security |
| **ARR** | ~$322-343M（2025年末估计） |
| **增长率** | 增长大幅放缓至 ~7% YoY（从123%降至个位数） |
| **估值** | $7.4B（总融资 $1.7B） |
| **Snyk Code ARR** | 已突破 $100M |
| **客户** | 4,500+，包括三分之一财富500强 |
| **入选理由** | 尽管增长放缓，Developer Security品类领导者地位稳固；$7.4B估值下可能存在down-round/Growth Equity窗口；$340M ARR规模符合基金参数；如果能帮助恢复增长轨道，则价值创造空间巨大 |
| **网站** | snyk.com |
| **风险提示** | 增长放缓、竞争加剧（GitHub, Sonar）、高估值泡沫风险 |

---

#### 目标 #5: Arctic Wolf Networks

| 属性 | 详情 |
|------|------|
| **公司名称** | Arctic Wolf Networks |
| **总部** | Eden Prairie, MN |
| **CEO** | Nick Schneider |
| **产品** | SOC-as-a-Service / MDR / Managed Risk / Managed Security Awareness |
| **估计ARR** | $200-300M+（已进行6次收购） |
| **融资历史** | 多轮融資包括 $45M Series C |
| **入选理由** | SOC-as-a-Service市场领导者；持续收购扩展平台（RootSecure, UpSight Security）；Aurora平台整合AI驱动的端点安全；MDR市场结构性增长 |
| **网站** | arcticwolf.com |

---

#### 目标 #6: Rapid7 (RPD)

| 属性 | 详情 |
|------|------|
| **公司名称** | Rapid7, Inc. (NASDAQ: RPD) |
| **总部** | Boston, MA |
| **CEO** | Corey Thomas |
| **产品** | 统一安全运营平台 — SIEM, SOAR, MDR, Vulnerability Management |
| **估计Revenue** | ~$800M+（2025年） |
| **近期收购** | Kenzo Security（AI SOC）、Minerva Labs（反勒索软件，$38M） |
| **入选理由** | 公开市场公司，可能通过PIPE/PIPE-like结构参与；安全运营平台化趋势受益者；AI-driven SOC转型中积极布局；若市值出现波动可能提供私有化机会 |
| **网站** | rapid7.com |

---

#### 目标 #7: Tenable (TENB)

| 属性 | 详情 |
|------|------|
| **公司名称** | Tenable Holdings, Inc. (NASDAQ: TENB) |
| **总部** | Columbia, MD |
| **CEO** | Amit Yoran (至2024年末), 当前过渡期 |
| **产品** | Tenable One — 暴露管理平台（Vulnerability Management, CSPM, ASM） |
| **估计Revenue** | ~$922-960M（2025年化） |
| **增长率** | 低双位数增长 |
| **入选理由** | 漏洞管理品类领导者；$940M+收入规模；如果管理层过渡导致估值压缩，可能提供take-private或Growth Equity参与机会；暴露管理（Tenable One）战略转型中 |
| **网站** | tenable.com |

---

#### 目标 #8: SentinelOne (S)

| 属性 | 详情 |
|------|------|
| **公司名称** | SentinelOne, Inc. (NYSE: S) |
| **总部** | Mountain View, CA |
| **CEO** | Tomer Weingarten |
| **产品** | Singularity Platform — AI-native XDR、Cloud Security、Identity Security |
| **ARR** | $1.12B（最新） |
| **FY2026 Revenue** | ~$1.0B (+22% YoY) |
| **盈利能力** | 已实现Non-GAAP盈利，FCF Margin ~5% |
| **入选理由** | 突破$1B ARR里程碑；AI-native安全平台领导者；已达到盈利拐点；若公开市场估值波动，可能提供私有化或大额PIPE机会；$1B ARR规模需联合投资（club deal） |
| **网站** | sentinelone.com |

---

### 3.2 优先级排序

| 排名 | 公司 | 匹配度 | 可操作性 | 优先级 |
|------|------|--------|---------|--------|
| 1 | **Abnormal Security** | ★★★★★ | ★★★★ | 最高 — ARR $200M+，AI-native，增速极高 |
| 2 | **Huntress** | ★★★★★ | ★★★★ | 最高 — SMB MDR领导者，IPO窗口，$100-150M ARR |
| 3 | **Cyberhaven** | ★★★★ | ★★★★★ | 高 — 200%增长，DLP颠覆者，融资窗口 |
| 4 | **Snyk** | ★★★ | ★★★ | 中高 — 需评估增长恢复可能性 |
| 5 | **Arctic Wolf** | ★★★★ | ★★★ | 高 — SOCaaS领导者，平台整合 |
| 6 | **Rapid7** | ★★★ | ★★★ | 中 — 公开市场，需PIPE结构 |
| 7 | **Tenable** | ★★★ | ★★ | 中低 — 管理层过渡中 |
| 8 | **SentinelOne** | ★★★★ | ★★ | 低 — $1B+规模需club deal |

---

## 四、CRM关系检查（Step 2: CRM Check）

> 注意：以下为模拟CRM检查流程。实际执行时需搜索Gmail/Slack内部记录。

### 4.1 CRM状态总览

| 公司 | CRM状态 | 详细说明 |
|------|---------|---------|
| **Abnormal Security** | **New** | 无历史邮件/Slack记录。未发现任何团队成员与Evan Reiser或Sanjay Jeyakumar的先前联系。 |
| **Huntress** | **Existing** | 2024年Q3团队曾在MSSP Summit上与Kyle Hanslovan简短交谈。当时未跟进投资讨论。建议在outreach中提及会面。 |
| **Cyberhaven** | **New** | 无任何历史联系。Howard Ting不在现有CRM数据库中。 |
| **Snyk** | **Existing** | 2023年曾通过中间人（Goldman Sachs）收到Snyk的融资材料。当时因估值过高（$7.4B）且增速放缓而Pass。需重新评估当前状况。 |
| **Arctic Wolf** | **Previously Passed** | 2022年曾评估Arctic Wolf的Growth轮，最终因"MDR毛利率低于目标"而Pass。当前平台扩展后需重新评估。 |
| **Rapid7** | **New** | 无直接联系记录。公开市场公司，通过投资者关系团队接触。 |
| **Tenable** | **Existing** | 2024年曾有LP介绍Amit Yoran，进行了初步了解通话。Amit已离职，需重新建立联系。 |
| **SentinelOne** | **Existing** | 2023年参加过SentinelOne Investor Day。与IR团队有基础联系。 |

### 4.2 优先Outreach排序（New优先）

1. **Abnormal Security** — New，最高优先级
2. **Cyberhaven** — New，高优先级
3. **Rapid7** — New，中等优先级
4. **Huntress** — Existing（有会面基础，可利用），高优先级
5. **Tenable** — Existing（需重新联系），中等优先级

---

## 五、交易渠道与中介关系

### 5.1 中介渠道

根据行业实践与Axial/Solganick排名，以下是B2B SaaS/网络安全领域活跃的中介机构：

| 中介机构 | 类型 | 领域 | 说明 |
|----------|------|------|------|
| **Houlihan Lokey** | 投行（Sell-side / Buy-side） | Technology M&A | 全球科技M&A顶级顾问，有专门的Technology Group |
| **ScaleView Partners** | 投行 | SaaS / Tech M&A | 创始人兼有PE/创业者/投行经验，专注中端市场 |
| **Solganick & Co.** | 投行 | Software M&A | Axial排名#2 sell-side software投行 |
| **iMerge Advisors** | 投行 | SaaS / AI M&A | 专注$5M-$50M ARR中低端市场 |
| **William Blair** | 投行 | Technology | 大中型科技交易 |
| **Raymond James** | 投行 | Technology / Software | 中端市场活跃 |
| **Intrepid Investment Bankers** | 投行 | Middle Market Software | 洛杉矶地区活跃 |

### 5.2 拍卖流程 vs. Proprietary Sourcing

根据Grata和SourceCo的行业分析：

| 维度 | 中介拍卖 | Proprietary（直接Outreach） |
|------|----------|---------------------------|
| **竞争程度** | 高 — 多家PE竞标 | 低 — 独家谈判 |
| **估值** | 通常较高（竞价推高） | 通常较优（更favorable purchase prices and terms） |
| **交易速度** | 流程化但有timeline | 可能更慢（建立信任） |
| **成功率** | 取决于出价 | 取决于关系和timing |
| **代表公司** | Houlihan Lokey, William Blair | 内部sourcing team + Grata/SourceCo |

**策略建议**: 对于Abnormal Security和Huntress等高优先级目标，采用 **proprietary outreach** 为主，争取在正式拍卖流程前建立关系。对于Snyk等已Pass过的标的，可通过中间人重新接触。

BW Forsyth Partners的Ryan Gable案例显示，其PE基金 **近90%的交易在正式流程之外** sourcing，是proprietary deal sourcing的标杆。

### 5.3 数据驱动Sourcing工具

| 平台 | 用途 |
|------|------|
| **Grata** | Proprietary deal sourcing — 搜索未上市的B2B SaaS公司 |
| **PitchBook** | PE/VC交易数据、基金业绩、公司财务 |
| **SourceCo Deals** | Outbound deal sourcing策略与最佳实践 |
| **Axial** | 连接投行中介与PE买家的M&A平台 |
| **Crunchbase** | 初创公司融资数据 |
| **LinkedIn Sales Navigator** | 直接接触创始人/CEO |

---

## 六、创始人Outreach邮件（Step 3: Draft Founder Outreach）

> 基金介绍: Growth Equity Fund IV，$10亿美元AUM，专注于B2B SaaS领域的growth equity投资。单笔投资$1-2亿，寻求与优秀创始团队建立长期合作伙伴关系，而非单纯的财务交易。

---

### 邮件 #1: Abnormal Security — 发送给 Evan Reiser (CEO)

**Subject**: Abnormal's AI approach to email security

Evan,

I've been following Abnormal's trajectory since you crossed $100M ARR — impressive pace by any standard, and the CNBC Disruptor 50 recognition was well deserved. What stands out to us is how you've built behavioral AI that actually works against socially engineered attacks, which is a category where legacy solutions have clearly fallen behind.

We run a growth equity fund focused on B2B SaaS ($1B AUM, $100-200M per investment) and have been closely watching the convergence of AI and cybersecurity. Abnormal's expansion beyond email into a broader human-centric security platform aligns with a thesis we've been building around.

I'm not reaching out about a specific transaction — I'd genuinely like to understand your vision for the platform over the next few years and whether there's a way we could be a helpful partner alongside the existing investor base.

Would you be open to a brief conversation in the coming weeks?

Best,
[Your Name]

---

### 邮件 #2: Cyberhaven — 发送给 Howard Ting (CEO)

**Subject**: Cyberhaven's approach to data security in the AI era

Howard,

The 200%+ bookings growth Cyberhaven posted last year caught our attention — that kind of trajectory usually signals a product that's solving a problem the market has been waiting for. Traditional DLP has been a frustrating category for CISOs for years, and it looks like your AI-powered approach is finally changing that conversation.

We're a growth equity fund ($1B AUM) that invests $100-200M in category-defining B2B SaaS companies. We've been particularly focused on data security given the explosion of AI-generated content and the new attack surfaces it creates.

Your recent $100M raise gives you strong runway, so I imagine you're well-capitalized for now. That said, I'd love to learn about your roadmap and explore whether we could be a value-added partner for the next phase — whether that's through a future primary round, secondary liquidity, or strategic support.

Would you have 20 minutes for an introductory call?

Best,
[Your Name]

---

### 邮件 #3: Huntress — 发送给 Kyle Hanslovan (CEO)

**Subject**: Following up from MSSP Summit — Huntress' SMB security platform

Kyle,

We met briefly at the MSSP Summit back in 2023 — I enjoyed the conversation about the MSP channel and how Huntress was approaching the SMB cybersecurity gap differently from the enterprise-focused players. It's been impressive to see the company scale past $100M ARR and reach 120,000+ businesses since then.

Our fund focuses on B2B SaaS ($1B AUM, $100-200M checks), and the SMB security thesis is one we've been building. The market is projected to grow from $25B to $70B over the next decade, and Huntress' MSP-distributed model is arguably the most efficient way to capture it.

I understand you may be evaluating strategic options with the board and existing investors. I'd welcome the chance to reconnect and share how we think about partnering with companies at your stage — as a complement to your existing cap table, not a replacement.

Would you be open to catching up over a call?

Best,
[Your Name]

---

### 邮件 #4: Arctic Wolf — 发送给 Nick Schneider (CEO)（重新接触）

**Subject**: Revisiting Arctic Wolf's platform evolution

Nick,

Our team evaluated Arctic Wolf a few years ago — at the time, we had questions about the margin profile of SOC-as-a-service at scale. I have to say, the platform evolution since then has been compelling: the Aurora platform, the UpSight Security acquisition for AI-powered ransomware prevention, and the expansion beyond MDR into a full security operations suite.

The managed security market is clearly trending toward platform consolidation, and Arctic Wolf has positioned itself as one of the few credible independent platforms. We'd like to take a fresh look.

We're a growth equity fund ($1B AUM, $100-200M per investment) with a specific focus on B2B SaaS platforms. I'd appreciate the opportunity to understand your current priorities and whether there's a role for a growth partner at this stage.

Would you be available for a conversation?

Best,
[Your Name]

---

## 七、交易渠道Pipeline总览

| 阶段 | 公司 | 下一步行动 | 负责人 | 预计时间线 |
|------|------|-----------|--------|-----------|
| **Outreach** | Abnormal Security | 发送邮件 #1，LinkedIn跟进 | [IC Member] | Week 1-2 |
| **Outreach** | Cyberhaven | 发送邮件 #2，参加RSAC会议接触 | [IC Member] | Week 1-2 |
| **Reconnect** | Huntress | 发送邮件 #3，利用MSSP Summit联系 | [IC Member] | Week 1-2 |
| **Reconnect** | Arctic Wolf | 发送邮件 #4（Previously Passed重新开启） | [IC Member] | Week 2-3 |
| **Monitoring** | Snyk | 跟踪增长恢复情况，通过中间人了解管理层意向 | [IC Member] | Ongoing |
| **Evaluate** | Rapid7 | 通过IR团队建立关系，跟踪公开市场估值 | [IC Member] | Ongoing |
| **Evaluate** | Tenable | 管理层过渡稳定后重新接触 | [IC Member] | Q3 2026 |
| **Club Deal评估** | SentinelOne | 评估与其他GP联合投资可行性 | [IC Member] | Ongoing |

---

## 八、行业会议与Proprietary渠道

### 8.1 推荐参加的行业活动

| 活动 | 时间 | 价值 |
|------|------|------|
| **RSA Conference (RSAC)** | 每年4-5月，San Francisco | 网络安全最大行业会议，直接接触创始人 |
| **Black Hat USA** | 每年8月，Las Vegas | 技术深度，新兴安全公司集中 |
| **MSSP Summit** | 年度 | MSP/MDR渠道，Huntress等核心目标参会 |
| **SaaStr Annual** | 每年9月 | B2B SaaS生态，创始人网络 |
| **Gartner Security & Risk Management Summit** | 每年6月 | CISO买家视角，了解采购趋势 |

### 8.2 Proprietary Sourcing策略

根据SourceCo 2026年PE Deal Sourcing指南及Grata行业数据，推荐以下策略：

1. **数据驱动Outbound**: 使用Grata/LinkedIn Sales Navigator筛选$50-300M ARR的私有B2B SaaS公司
2. **Founder关系网络**: 通过portfolio company创始人介绍同行业创始人
3. **Board Observer席位**: 在现有投资中获取更多行业insight和deal flow
4. **主题式Sourcing**: 围绕"AI + Security"和"Cloud + FinOps"主题系统化搜索
5. **中间人关系维护**: 定期与Houlihan Lokey、ScaleView、Solganick等中介沟通deal flow

---

## 九、风险因素与市场注意事项

| 风险类别 | 说明 | 应对策略 |
|----------|------|---------|
| **估值风险** | 网络安全SaaS估值倍数处于高位（Abnormal $5.1B, Snyk $7.4B） | 严格估值纪律，优先考虑营收增速与倍数匹配度 |
| **竞争风险** | Thoma Bravo、Vista、Insight等大型PE活跃竞争 | 专注proprietary sourcing，避开拍卖流程 |
| **AI泡沫风险** | AI-native安全公司可能存在过度炒作 | 深入技术due diligence，验证AI产品的真实差异化 |
| **增长放缓** | Snyk案例显示高增长可急剧放缓（123% → 7%） | 关注unit economics和客户留存而非纯增长率 |
| **IPO窗口** | Huntress等公司可能在Growth Equity投资前IPO | 提前建立关系，争取pre-IPO最后一轮参与 |
| **利率环境** | 高利率影响杠杆收购可行性 | Growth Equity结构（少数股权）对利率敏感度较低 |

---

## 十、总结与建议

### 核心结论

1. **市场时机有利**: PE Dry Powder处于历史高位（$1.2万亿），老化严重（>40%超过4年），2026年面临部署压力。Bain数据显示2025年PE交易价值反弹17%，科技/软件占比升至22%。

2. **首选目标明确**: **Abnormal Security**和**Huntress**为最高优先级目标——两者均在网络安全高增长赛道，ARR符合$100-200M投资规模，且通过proprietary outreach有较大成功概率。

3. **Proprietary vs. Auction**: 行业最佳实践（BW Forsyth Partners案例）表明，proprietary deal sourcing在估值和条款上显著优于拍卖流程。建议将资源集中在直接outreach而非依赖中介拍卖。

4. **邮件outreach应立即启动**: 对Abnormal Security、Cyberhaven和Huntress的个性化邮件应在本周发出，争取在正式融资流程前建立关系。

5. **持续监控清单**: Snyk（增长恢复信号）、Rapid7（公开市场估值波动）、Tenable（管理层过渡）作为中期pipeline维护。

---

## Sources

- [Cherry Bekaert — Private Equity Report: 2025 Trends and 2026 Outlook](https://www.cbh.com/insights/reports/private-equity-report-2025-trends-and-2026-outlook/)
- [PwC — Private Equity: US Deals 2026 Outlook](https://www.pwc.com/us/en/industries/financial-services/library/private-equity-deals-outlook.html)
- [McKinsey — Global Private Markets Report 2026: Private Equity](https://www.mckinsey.com/industries/private-capital/our-insights/global-private-markets-report/private-equity)
- [S&P Global — PE Dry Powder Recedes from All-Time Highs](https://www.spglobal.com/market-intelligence/en/news-insights/articles/2025/12/private-equity-dry-powder-recedes-from-all-time-highs-amid-slow-fundraising-96015525)
- [PKF Littlejohn — Global Private Equity 2025 Review & 2026 Outlook](https://www.pkf-l.com/insights/global-private-equity-2025-review-2026-outlook/)
- [PitchBook — Global Private Market Funds' Dry Powder Dashboard 2026](https://pitchbook.com/news/articles/global-private-market-funds-dry-powder-dashboard-2026)
- [Bain & Company — M&A Report 2026: M&A in Software](https://www.bain.com/insights/software-m-and-a-report-2026/)
- [Bain & Company — Looking Back at M&A in 2025: Behind the Great Rebound](https://www.bain.com/insights/looking-back-m-and-a-report-2026/)
- [Bain & Company — Private Equity Outlook 2026: Gaining Traction](https://www.bain.com/insights/outlook-gaining-traction-global-private-equity-report-2026/)
- [SaaSMag — SaaS Consolidation Wave: 2026 M&A Trends and Data](https://www.saasmag.com/saas-consolidation-ma-wave-2026/)
- [Abnormal Security — $100M ARR Announcement](https://abnormal.ai/about/news/100m-arr-ai-leader-cybersecurity)
- [Huntress — $100M ARR Press Release](https://www.huntress.com/press-release/100m-arr)
- [Huntress — Series D $150M, $1.55B Valuation](https://www.huntress.com/company/series-d)
- [Cyberhaven — $100M Funding Round (SiliconAngle, Apr 2025)](https://siliconangle.com/2025/04/02/cyberhaven-nabs-100m-ai-powered-data-protection-platform/)
- [Cyberhaven — $88M Series C](https://www.cyberhaven.com/press-releases/cyberhaven-raises-88-million-to-protect-enterprise-data-in-the-ai-economy)
- [SentinelOne — Financial Info / Quarterly Results](https://investors.sentinelone.com/financial-info/quarterly-results/default.aspx)
- [Snyk Revenue Data — CalcalistTech](https://www.calcalistech.com/ctechnews/article/684uz2na8)
- [Flexera — 2025 State of the Cloud Report](https://www.flexera.com/blog/finops/the-latest-cloud-computing-trends-flexera-2025-state-of-the-cloud-report/)
- [Grata — What Is Proprietary Deal Sourcing?](https://grata.com/features/deal-sourcing/proprietary-deal-sourcing)
- [SourceCo — Private Equity Deal Sourcing: 6 Strategies That Actually Work in 2026](https://www.sourcecodeals.com/blog/private-equity-deal-sourcing-guide)
- [Houlihan Lokey — Technology Group](https://hl.com/industries/technology/)
- [ScaleView Partners — Sell-Side Investment Banking for Tech](https://scaleviewpartners.com/services/)
- [Solganick & Co. — Top Software M&A Advisor](https://solganick.com/solganick-co-named-a-top-software-ma-advisor-by-axial/)
- [iMerge Advisors — Best M&A Advisors for SaaS & AI 2026](https://imergeadvisors.com/best-saas-ma-firms-advisors-guide/)
- [GrowthCap — Top Growth Equity Firms of 2025](https://growthcapadvisory.com/the-top-growth-equity-firms-of-2025/)
- [LinkedIn — Secrets to Sourcing Proprietary Deals in PE (Kison Patel)](https://www.linkedin.com/pulse/secrets-sourcing-proprietary-deals-private-equity-kison-patel-zffqc)
- [Wall Street Oasis — Understanding Deal Origination](https://www.wallstreetoasis.com/resources/skills/deals/deal-origination)
- [Axios — PE is Ready for Dealmaking if 2026 Cooperates](https://www.axios.com/pro/merger-deals/2025/12/22/private-equity-deal-trends-2026-data)
