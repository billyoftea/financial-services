[DATA SOURCE: Federal Reserve FOMC Summary of Economic Projections (March 18, 2026); S&P Dow Jones Indices; Bloomberg; Morningstar; World Gold Council; MSCI; ETFreplay; First Trust Advisors; City National Rochdale; Tiller Private Wealth; Brighton Jones; S&P Global Ratings; J.P. Morgan Asset Management; Nasdaq Dorsey Wright; IEQ Capital; Moneta Group; Congressional Budget Office; FactSet; Statista; Yahoo Finance; iShares/BlackRock; ClearBridge Investments; The London Company; Royce Investment Partners; Franklin Templeton; LSEG FTSE Russell; Seeking Alpha; Morgan Stanley; Goldman Sachs; IEQ Capital; VistaMark; Twelve Points Wealth; Confluence Technologies]

# 客户季度报告 | Client Quarterly Report

**Meridian Wealth Advisors**
2026年第一季度 | Q1 2026 (2026年1月1日 — 2026年3月31日)

---

**客户名称:** 张明辉 & 李婉清 家庭 | Minghui Zhang & Wanqing Li Household
**报告日期:** 2026年5月9日
**顾问:** 王志远, CFA, CFP | Zhiyuan Wang, Senior Wealth Advisor
**基准:** 60/40 组合 (60% S&P 500 / 40% Bloomberg U.S. Aggregate Bond)
**报告周期:** 2026年第一季度 (QTD) 及年初至今 (YTD)

---

## 1. 执行摘要 | Executive Summary

尊敬的张先生和张太太:

2026年第一季度是全球金融市场波动加剧的一个季度。地缘政治不确定性上升、通胀预期走高以及国债收益率曲线整体上移，导致美国股票和债券同时出现下跌——这一现象打破了股票与债券传统的负相关关系。美国标普500指数第一季度总回报为 **-4.3%**，纳斯达克综合指数下跌 **-7.0%**，道琼斯工业平均指数下跌 **-3.2%**。彭博美国综合债券指数基本持平，微跌 **-0.05%**。

尽管市场环境充满挑战，贵家庭的多元化投资组合表现出相对韧性。通过向价值股、国际股票和黄金的战略性配置，贵组合第一季度总回报为 **-1.8%**，显著跑赢基准60/40组合的 **-2.6%**，实现超额收益 **+0.8个百分点**。

本报告详细分析了贵组合在2026年第一季度的业绩表现、资产配置、持仓明细、市场环境及未来展望。

---

## 2. 业绩汇总 | Performance Summary

### 2.1 家庭组合整体业绩 | Household Summary

| 指标 | QTD (Q1 2026) | YTD (Q1 2026) | 1年 | 3年年化 | 5年年化 | 成立至今年化 |
|------|:---:|:---:|:---:|:---:|:---:|:---:|
| **贵组合** | **-1.8%** | **-1.8%** | **+10.4%** | **+7.2%** | **+8.1%** | **+8.6%** |
| **基准 (60/40)** | -2.6% | -2.6% | +8.7% | +6.5% | +7.3% | +7.8% |
| **超额收益 (+/-)** | **+0.8%** | **+0.8%** | **+1.7%** | **+0.7%** | **+0.8%** | **+0.8%** |

> **注释:** 基准为60% S&P 500 Total Return Index + 40% Bloomberg U.S. Aggregate Bond Total Return Index，按月再平衡。所有业绩均已扣除管理费。过往业绩不代表未来表现。

### 2.2 分账户业绩 | Performance by Account

| 账户 | 类型 | 市值 (USD) | QTD | YTD | 基准 |
|------|------|------:|:---:|:---:|------|
| 联合应税账户 | 经纪账户 | $1,285,400 | -2.1% | -2.1% | S&P 500 / Agg 60/40 |
| 张明辉 IRA | 传统 IRA | $620,750 | -1.4% | -1.4% | S&P 500 / Agg 60/40 |
| 李婉清 Roth IRA | Roth IRA | $435,200 | -1.2% | -1.2% | S&P 500 / Agg 60/40 |
| 529 教育储蓄计划 | 529 Plan | $185,600 | -0.8% | -0.8% | Age-Based Portfolio |
| **合计** | | **$2,526,950** | **-1.8%** | **-1.8%** | |

---

## 3. 资产配置概览 | Allocation Overview

### 3.1 当前配置 vs. 目标配置

| 资产类别 | 当前占比 | 市值 (USD) | 目标占比 | 偏离 |
|----------|:------:|----------:|:------:|:----:|
| 美国大盘股 | 32.0% | $808,624 | 30.0% | +2.0% |
| 美国小盘股 | 5.0% | $126,348 | 5.0% | 0.0% |
| 国际发达市场股票 | 12.0% | $303,234 | 12.0% | 0.0% |
| 新兴市场股票 | 6.0% | $151,617 | 5.0% | +1.0% |
| 投资级债券 | 22.0% | $555,929 | 25.0% | -3.0% |
| 高收益债券 | 3.0% | $75,809 | 3.0% | 0.0% |
| TIPS (通胀保值债券) | 5.0% | $126,348 | 5.0% | 0.0% |
| 房地产 (REITs) | 5.0% | $126,348 | 5.0% | 0.0% |
| 黄金及贵金属 | 5.0% | $126,348 | 5.0% | 0.0% |
| 现金及货币市场 | 5.0% | $126,349 | 5.0% | 0.0% |
| **合计** | **100.0%** | **$2,526,950** | **100.0%** | |

> **配置调整建议:** 当前美国大盘股配置略高于目标 (+2.0%)，主要受第一季度末市场反弹前估值影响。投资级债券低于目标 (-3.0%)，建议在第二季度通过再平衡将部分股票收益转入债券。

---

## 4. 持仓明细 | Holdings Detail

### 4.1 联合应税账户 (Joint Taxable) — $1,285,400

| 证券代码 | 证券名称 | 资产类别 | 持有份额 | 价格 (USD) | 市值 (USD) | 组合占比 | QTD回报 |
|----------|----------|----------|--------:|--------:|--------:|:------:|:------:|
| SPY | SPDR S&P 500 ETF | 美国大盘股 | 520 | $558.20 | $290,264 | 11.5% | -4.3% |
| VTV | Vanguard Value ETF | 美国大盘价值 | 380 | $178.40 | $67,792 | 2.7% | +1.2% |
| IWM | iShares Russell 2000 ETF | 美国小盘股 | 310 | $206.50 | $64,015 | 2.5% | +0.6% |
| EFA | iShares MSCI EAFE ETF | 国际发达 | 480 | $78.90 | $37,872 | 1.5% | -1.2% |
| EEM | iShares MSCI EM ETF | 新兴市场 | 420 | $43.20 | $18,144 | 0.7% | +12.9% |
| GLD | SPDR Gold Shares | 黄金 | 250 | $482.50 | $120,625 | 4.8% | +17.4% |
| AGG | iShares Core US Agg Bond | 投资级债券 | 680 | $99.10 | $67,388 | 2.7% | -0.05% |
| BND | Vanguard Total Bond ETF | 投资级债券 | 450 | $72.30 | $32,535 | 1.3% | -0.1% |
| VNQ | Vanguard Real Estate ETF | REITs | 260 | $87.50 | $22,750 | 0.9% | +2.3% |
| SGOV | iShares 0-3M Treasury | 现金等价物 | 950 | $100.80 | $95,760 | 3.8% | +1.1% |
| SGOV | iShares 0-3M Treasury | 现金等价物 | 700 | $100.80 | $70,560 | 2.8% | +1.1% |
| VTV | Vanguard Value ETF | 美国大盘价值 | 620 | $178.40 | $110,608 | 4.4% | +1.2% |
| TLT | iShares 20+ Yr Treasury | 长期国债 | 180 | $93.20 | $16,776 | 0.7% | -2.8% |
| HYG | iShares High Yield Bond | 高收益债 | 350 | $76.50 | $26,775 | 1.1% | +0.9% |
| TIP | iShares TIPS Bond ETF | TIPS | 280 | $113.40 | $31,752 | 1.3% | +1.6% |
| IJS | iShares S&P Small-Cap 600 Value | 小盘价值 | 210 | $138.70 | $29,127 | 1.2% | +5.0% |

### 4.2 张明辉 IRA (Traditional IRA) — $620,750

| 证券代码 | 证券名称 | 资产类别 | 持有份额 | 价格 (USD) | 市值 (USD) | QTD回报 |
|----------|----------|----------|--------:|--------:|--------:|:------:|
| VFIAX | Vanguard 500 Index Adm | 美国大盘股 | 410 | $556.80 | $228,288 | -4.3% |
| VTMFX | Vanguard Tax-Managed Bal | 平衡配置 | 520 | $285.40 | $148,408 | -2.0% |
| DODGX | Dodge & Cox Stock | 美国大盘价值 | 380 | $232.10 | $88,198 | +0.8% |
| VGTSX | Vanguard Total Intl Stock | 国际股票 | 440 | $42.30 | $18,612 | +0.5% |
| VBTLX | Vanguard Total Bond Adm | 投资级债券 | 780 | $10.80 | $8,424 | -0.05% |
| VEXMX | Vanguard Extended Market | 美国小盘股 | 650 | $197.60 | $128,440 | +0.6% |

### 4.3 李婉清 Roth IRA (Roth IRA) — $435,200

| 证券代码 | 证券名称 | 资产类别 | 持有份额 | 价格 (USD) | 市值 (USD) | QTD回报 |
|----------|----------|----------|--------:|--------:|--------:|:------:|
| VIGAX | Vanguard Growth Index Adm | 美国大盘成长 | 310 | $542.30 | $168,113 | -8.2% |
| VVIAX | Vanguard Value Index Adm | 美国大盘价值 | 290 | $186.70 | $54,143 | +1.2% |
| RERFX | American Funds EuroPacific | 国际发达 | 420 | $65.80 | $27,636 | -1.0% |
| VEMAX | Vanguard EM Index Adm | 新兴市场 | 380 | $44.10 | $16,758 | +12.9% |
| VWEHX | Vanguard High Yield Corp | 高收益债 | 600 | $5.20 | $3,120 | +0.8% |
| VAIPX | Vanguard Inflation-Prot Sec | TIPS | 450 | $113.40 | $51,030 | +1.6% |
| DGS | WisdomTree EM SmallCap Div | 新兴市场 | 340 | $72.60 | $24,684 | +14.2% |
| VGSLX | Vanguard Real Estate Index | REITs | 290 | $85.30 | $24,737 | +2.3% |
| PCRIX | PIMCO CommoditiesPlus | 商品 | 180 | $25.40 | $4,572 | +8.5% |
| VTIAX | Vanguard Total Intl Stock | 国际股票 | 380 | $42.30 | $16,074 | +0.5% |

### 4.4 529 教育储蓄计划 — $185,600

| 证券代码 | 证券名称 | 资产类别 | 持有份额 | 价格 (USD) | 市值 (USD) | QTD回报 |
|----------|----------|----------|--------:|--------:|--------:|:------:|
| VANGUARD 529 年龄基础组合 (14-18岁) | 目标日期基金 | 多元配置 | — | — | $185,600 | -0.8% |

> 该529计划采用基于年龄的渐进式配置策略，当前侧重约55%股票/45%债券。

---

## 5. 市场回顾与评论 | Market Commentary

### 5.1 第一季度市场回顾 (Q1 2026 Market Review)

2026年第一季度是全球金融市场极具挑战性的一个季度。地缘政治紧张局势（尤其是中东局势升级）、美国通胀预期走高以及国债收益率曲线整体上移，成为主导市场的三大主题。美国股票和债券同时出现下跌——彭博大宗商品指数录得正回报，而黄金价格突破每盎司 $4,870 创历史新高。据 Nasdaq Dorsey Wright 的 DALI 资产类别排名，国际股票在第一季度末升至第一位。

第一季度核心指数表现如下:

| 指数/资产类别 | Q1 2026 总回报 |
|---------------|:------------:|
| S&P 500 (SPY) | -4.3% |
| Nasdaq Composite | -7.0% |
| Dow Jones Industrial Average | -3.2% |
| Russell 2000 (IWM) | +0.6% |
| Russell 2000 Value | +5.0% |
| Russell 2000 Growth | -2.8% |
| MSCI EAFE (国际发达) | -1.2% |
| MSCI Emerging Markets (EEM) | +12.9% |
| Bloomberg U.S. Agg Bond | -0.05% |
| 黄金 (GLD) | +17.4% |
| 彭博大宗商品指数 | +8.5% |

**关键市场主题:**

1. **风格轮动显著:** 价值股大幅跑赢成长股。Russell 2000 Value 上涨 +5.0%，而 Russell 2000 Growth 下跌 -2.8%。大盘方面同样呈现价值领先格局，Vanguard Value ETF (VTV) 上涨 +1.2%，而 Nasdaq 重挫 -7.0%。

2. **国际股票领先:** MSCI EAFE 仅下跌 -1.2%，显著跑赢 S&P 500 的 -4.3%。新兴市场表现尤为强劲，EEM 录得 +12.9% 的季度回报，主要受益于中国经济刺激预期、估值洼地吸引力及美元阶段性走弱。

3. **黄金创历史新高:** 黄金价格在第一季度突破 $4,870/盎司 (LBMA午盘均价)，据世界黄金协会数据，全球黄金总需求同比增长 2% 至 1,231 吨，需求总价值创历史新高，同比飙升 74%。

4. **股债相关性异常:** 据LongtermTrends数据，截至2026年5月初，股票与债券的相关性高达 0.92，远超历史正常水平。这意味着传统的60/40组合在第一季度未能提供预期的分散化保护。

### 5.2 对贵组合的影响

贵组合在第一季度的超额收益 (+0.8个百分点 vs. 60/40基准) 主要来自以下配置决策:

- **黄金超配 (5%):** 黄金 (+17.4%) 是本季度表现最好的资产，贡献了约 +0.87% 的组合层面收益
- **新兴市场配置 (6%):** EEM (+12.9%) 为组合贡献了约 +0.77% 的超额收益
- **价值股偏好:** VTV (+1.2%) 和 IJS (+5.0%) 有效对冲了成长股的下跌
- **成长股拖累:** VIGAX (-8.2%) 是最大的业绩拖累，但通过其他配置的多元化已得到部分对冲

### 5.3 经济展望 (Outlook)

展望2026年第二季度及下半年，我们对市场持**谨慎乐观**态度:

**宏观经济方面:**
- 美联储3月会议的Summary of Economic Projections将2026年GDP增长预期上调至 **2.4%** (此前为2.3%)
- PCE通胀预计在2026年第四季度达到 **2.7%**，仍高于2%目标
- S&P Global Ratings预测全年GDP增长 **2.2%**，2027-2029年平均 **1.9%**
- J.P. Morgan预计2026年前三季度实际GDP平均增速超过 **3%**

**市场展望:**
- Goldman Sachs维持标普500年终目标 **7,600点**，预计全年总回报约 **12%**，基于全年EPS预期 $305-$309
- 企业盈利依然强劲，FactSet数据显示Q1 2026标普500盈利同比增长 **13.2%**
- 估值方面，MSCI EAFE市盈率 (15.88x) 和MSCI新兴市场市盈率 (14.61x) 仍显著低于标普500，国际股票估值吸引力持续

**投资策略建议:**
- 维持当前的多元化配置策略，暂不大幅调整
- 在Q2考虑适度增加投资级债券配置（当前低于目标3个百分点）
- 关注再平衡机会，特别是在黄金和中国新兴市场板块已大幅上涨后
- 继续持有TIPS配置以对冲通胀上行风险

---

## 6. 交易活动汇总 | Activity Summary

### 6.1 本季度交易 | Trades Executed

| 日期 | 交易类型 | 证券 | 数量 | 金额 (USD) | 说明 |
|------|----------|------|------:|--------:|------|
| 2026/01/15 | 买入 | EEM | +120股 | $5,184 | 新兴市场战术增配 |
| 2026/01/22 | 买入 | GLD | +50股 | $24,125 | 黄金增配至目标权重 |
| 2026/02/10 | 卖出 | VIGAX | -80股 | ($43,384) | 成长股减仓，再平衡 |
| 2026/02/18 | 买入 | VTV | +100股 | $17,840 | 价值股增配 |
| 2026/03/05 | 买入 | TIP | +80股 | $9,072 | 通胀对冲增配 |
| 2026/03/20 | 买入 | IJS | +60股 | $8,322 | 小盘价值战术增配 |

### 6.2 资金流入/流出 | Contributions & Withdrawals

| 日期 | 账户 | 类型 | 金额 (USD) |
|------|------|------|--------:|
| 2026/01/05 | 联合应税账户 | 存入 (工资储蓄) | $15,000 |
| 2026/02/05 | 联合应税账户 | 存入 (工资储蓄) | $15,000 |
| 2026/03/05 | 联合应税账户 | 存入 (工资储蓄) | $15,000 |
| 2026/01/15 | 张明辉 IRA | IRA转入 (2025年度补充) | $7,000 |
| 2026/02/28 | 李婉清 Roth IRA | Roth缴款 (2026年度) | $7,000 |
| 2026/03/15 | 529计划 | 教育储蓄缴款 | $5,000 |

**本季度总缴款:** $64,000

### 6.3 收入明细 | Income Received

| 类别 | 金额 (USD) |
|------|--------:|
| 股息收入 | $8,243 |
| 债券利息 | $5,412 |
| 资本利得分配 | $2,180 |
| **本季度总收入** | **$15,835** |

### 6.4 费用 | Fees

| 项目 | 金额 (USD) |
|------|--------:|
| 投资管理费 (Q1, 0.75%年化) | $4,738 |
| 托管账户维护费 | $75 |
| 交易佣金 | $48 |
| **本季度总费用** | **$4,861** |

---

## 7. 规划备注 | Planning Notes

### 7.1 财务目标进展

| 目标 | 目标金额 | 当前进度 | 状态 |
|------|--------:|:------:|------|
| 退休储备 (2035年退休) | $5,000,000 | $2,337,950 (46.8%) | 正常 |
| 子女教育 (张思远, 2030年入学) | $400,000 | $185,600 (46.4%) | 正常 |
| 应急储备 | $100,000 | $126,349 (126.3%) | 已达标 |
| 慈善捐赠基金 | $200,000 | $77,051 (38.5%) | 略低于计划 |

**退休储备进度分析:** 按当前储蓄率 ($45,000/年 IRA缴款 + $45,000/年应税账户储蓄) 和年化7.5%的预期回报，预计可在2035年达到退休储备目标。建议在2026年4月15日前完成2025年度IRA补充缴款。

### 7.2 建议事项

1. **2025年度 IRA 补充缴款:** 请在2026年4月15日报税截止前完成2025年度IRA补充缴款 ($7,000/人)。张先生已完成，李女士的Roth IRA已缴入。
2. **税务筹划:** 第一季度在联合应税账户中实现的资本损失 ($43,384 VIGAX卖出) 可用于抵扣当年资本利得。建议Q2审查是否需要额外的税收损失收割 (Tax-Loss Harvesting)。
3. **再平衡提醒:** 黄金 (+17.4%) 和新兴市场 (+12.9%) 涨幅较大，已超出目标权重。建议在Q2进行部分获利了结并再平衡。
4. **保险审查:** 家庭伞形责任保险将于2026年7月到期，建议提前联系保险顾问续保。

### 7.3 下次审查

**下次季度审查日期:** 2026年7月15日 (星期二) 上午10:00
**地点:** Meridian Wealth Advisors 办公室 (或视频会议)
**议程:** Q2业绩回顾、年中再平衡、2025税务预估更新、教育储蓄计划评估

---

## 8. 市场数据附录 | Market Data Appendix

### 8.1 Q1 2026 主要指数回报汇总

| 指数 | QTD | YTD | 1年 | 备注 |
|------|:---:|:---:|:---:|------|
| S&P 500 | -4.3% | -4.3% | +10.5% | Q1负回报，1年仍为正 |
| Nasdaq Composite | -7.0% | -7.0% | +12.3% | 成长股重挫 |
| Dow Jones Industrial Avg | -3.2% | -3.2% | +9.8% | 相对抗跌 |
| Russell 2000 | +0.6% | +0.6% | +13.5% | 小盘逆势上涨 |
| Russell 2000 Value | +5.0% | +5.0% | +28.1% | 价值风格大幅领先 |
| Russell 2000 Growth | -2.8% | -2.8% | +23.6% | 成长股落后 |
| MSCI EAFE | -1.2% | -1.2% | +8.9% | 国际发达市场跑赢美股 |
| MSCI Emerging Markets | +12.9% | +12.9% | +46.6% | 新兴市场表现强劲 |
| Bloomberg U.S. Agg Bond | -0.05% | -0.05% | +5.5% | 基本持平 |
| 黄金 (GLD) | +17.4% | +17.4% | +42.8% | 创历史新高 |
| Bloomberg Commodities | +8.5% | +8.5% | +18.2% | 大宗商品普涨 |

### 8.2 关键经济指标 (截至2026年Q1)

| 指标 | 数值 | 来源 |
|------|------|------|
| 美国GDP增长率 (Q1 GDPNow预估) | 1.9% 年化 | 亚特兰大联储 |
| 2026全年GDP增长预期 | 2.2%-2.4% | S&P Global / Fed |
| PCE通胀 (2026 Q4预测) | 2.7% | 美联储SEP |
| 核心PCE通胀 (年末预测) | 2.6%-2.7% | 美联储SEP |
| 标普500 Q1盈利增长 (YoY) | +13.2% | FactSet |
| 标普500全年EPS预期 | $305-$309 | Goldman Sachs |
| 标普500年终目标 | 7,600 | Goldman Sachs |
| MSCI EAFE市盈率 | 15.88x | MSCI (截至4/30/26) |
| MSCI EM市盈率 | 14.61x | MSCI (截至4/30/26) |
| LBMA黄金午盘均价 (Q1) | $4,873/oz | World Gold Council |
| 全球黄金总需求 (Q1) | 1,231吨 (+2% YoY) | World Gold Council |
| 股债相关性 (近期) | 0.92 | LongtermTrends |

### 8.3 美联储政策展望

根据美联储2026年3月18日FOMC会议纪要和经济预测摘要 (SEP):

- 联邦基金利率维持不变，降息路径预期保持稳定
- 2026年GDP增长预测中位数上调至2.4% (12月预测为2.3%)
- 通胀预期上调：2026年Q4 PCE预计为2.7% (12月预测为2.4%)
- 中东局势发展被视为通胀前景的显著上行风险
- 通胀自2021年初以来持续高于2%目标水平

---

## 9. 披露与免责声明 | Disclosures & Disclaimers

**业绩报告说明:**
- 本报告中所有业绩数据均为扣除管理费后的净回报
- 过往业绩不构成对未来表现的保证或承诺
- 投资涉及风险，包括可能损失本金
- 不同账户的回报可能因配置、缴款时间和费用结构而异

**基准说明:**
- 60/40基准 = 60% S&P 500 Total Return Index + 40% Bloomberg U.S. Aggregate Bond Total Return Index，按月再平衡
- 基准回报不反映管理费、交易成本或税费
- 直接投资于指数是不可能的

**估值说明:**
- 所有持仓按2026年3月31日收盘价估值
- 市值数据未经审计
- 某些流动性较低的持仓可能使用最新可用报价

**一般性声明:**
- 本报告由 Meridian Wealth Advisors 编制，仅供指定客户使用
- 本报告不构成投资建议、税务建议或法律建议
- 投资者在做出任何投资决策前应咨询其财务、税务和法律顾问
- 本报告中提及的具体证券仅供说明目的，不构成买入或卖出推荐

**监管信息:**
- Meridian Wealth Advisors 是一家注册投资顾问 (RIA)
- 客户可索取我们最新的 Form ADV Part 2A (Firm Brochure)
- 如有任何疑问，请联系您的专属顾问或致电 (555) 842-0200

---

*Meridian Wealth Advisors | One Financial Plaza, Suite 1800 | New York, NY 10004*
*Tel: (555) 842-0200 | Email: advisor@meridianwealth.com | www.meridianwealth.com*

---

**报告生成日期:** 2026年5月9日
**报告版本:** v1.0
**机密等级:** 仅限客户本人 — 请勿转发

---

## Sources

- [S&P 500 Q1 2026 Performance - Motley Fool](https://www.fool.com/investing/2026/03/25/the-sp-500-is-on-track-to-finish-q1-in-negative-te/)
- [S&P 500 Index in Q1, Broadening Beneath the Surface - First Trust](https://www.ftportfolios.com/Commentary/EconomicResearch/2026/4/9/sp-500-index-in-q1,-broadening-beneath)
- [Q1 2026 Market Update - Tiller Private Wealth](https://tillerpw.com/q1-2026-market-update/)
- [Quarterly Update: Q1 2026 - City National Rochdale](https://www.cnr.com/insights/quarterly-update/q1-2026.html)
- [Q1 2026 Investment Review - J.P. Morgan Private Bank](https://privatebank.jpmorgan.com/eur/en/insights/markets-and-investing/q1-2026-investment-review-constructive-outlook-despite-volatility)
- [Q1 Asset Class Performance Review - Nasdaq Dorsey Wright](https://dorseywright.nasdaq.com/research/bigwire/2026/04/01/04-01-2026/q1-asset-class-performance-review)
- [2026 Q1 Market Review - Twelve Points](https://www.twelvepoints.com/insights/2026-q1-market-review/)
- [Q1 2026 Market Outlook - IEQ Capital](https://ieqcapital.com/q1-2026-market-outlook-asset-allocation-in-a-maturing-cycle/)
- [2026 Q1 Investment Update - Brighton Jones](https://www.brightonjones.com/blog/2026-q1-investment-update/)
- [Long-Term Asset Class Forecasts Q1 2026 - State Street (SSGA)](https://www.ssga.com/us/en/institutional/insights/long-term-asset-class-forecasts-q1-2026)
- [How Largest Bond Funds Did in Q1 2026 - Morningstar](https://www.morningstar.com/funds/how-largest-bond-funds-did-q1-2026)
- [Global Gold Demand Trends Q1 2026 - World Gold Council](https://china.gold.org/goldhub/research/gold-demand-trends/2026/04/29/19595)
- [Summary of Economic Projections March 2026 - Federal Reserve](https://www.federalreserve.gov/monetarypolicy/files/fomcprojtabl20260318.pdf)
- [Economic Outlook US Q2 2026 - S&P Global Ratings](https://www.spglobal.com/ratings/en/regulatory/article/economic-outlook-us-q2-2026-curb-your-enthusiasm-s101676533)
- [Budget and Economic Outlook 2026-2036 - Congressional Budget Office](https://www.cbo.gov/publication/62105)
- [Fed Keeps Rate Cut Forecasts Steady - Yahoo Finance](https://finance.yahoo.com/news/federal-reserve-keeps-rate-cut-forecasts-steady-as-economic-growth-inflation-outlooks-rise-181628371.html)
- [S&P 500 Earnings Season Preview Q1 2026 - FactSet](https://insight.factset.com/sp-500-earnings-season-preview-q1-2026)
- [US Q1 Earnings 13% Growth - IG](https://www.ig.com/en/news-and-trade-ideas/1Q26-US-earnings-preview-260414)
- [S&P 500 Index Forecast - Capital.com / Goldman Sachs](https://capital.com/en-int/market-updates/sp500-index-forecast-16-04-2026)
- [Q1 2026 Factor Performance Analysis - Confluence Technologies](https://www.confluence.com/report/q1-2026-factor-performance-analysis/)
- [iShares MSCI Emerging Markets ETF (EEM) - BlackRock](https://www.ishares.com/us/products/239637/ishares-msci-emerging-markets-etf)
- [International Equity 1Q2026 vs MSCI EAFE - The London Company](https://www.tlcadvisory.com/qtd-international-equity-1q2026-vs-msci-eafe/)
- [ClearBridge Commentary International Growth EAFE 1Q26](https://www.clearbridge.com/perspectives/commentaries/international-growth-eafe)
- [Small Cap Recap - Royce Investment Partners](https://www.royceinvest.com/insights/small-cap-recap)
- [Russell US Reports April 2026 - LSEG FTSE Russell](https://www.lseg.com/en/ftse-russell/market-insights/russell-us-reports/april-2026)
- [US Small Caps Resilience - Franklin Templeton](https://www.franklintempleton.lu/articles/2026/royce-investment-partners/us-small-caps-have-shown-their-resilience-amid-the-fog-of-war)
- [6 Charts That Defined US Markets in Q1 - Morningstar](https://www.morningstar.com/markets/6-charts-that-define-first-quarter-markets)
- [Q1 2026 in 10 Stories - Investing.com](https://www.investing.com/analysis/q1-2026-in-10-stories-200678146)
- [Q2 2026 CIO Chartbook - TIAA](https://www.tiaa.org/public/pdf/cio_chartbook.pdf)
- [Benchmark Review Monthly Recap March 2026 - CCMG](https://ccmg.com/benchmark-review-monthly-recap-march-2026/)
- [Q1 2026 Recap - Seeking Alpha](https://seekingalpha.com/article/4887991-q1-2026-recap)
- [Q1 2026 Market Review - VistaMark](https://vistamarkllc.com/q1-2026-market-review-geopolitical-disruption-a-style-rotation-and-the-case-for-patience/)
- [FOMC Minutes March 18, 2026 - Federal Reserve](https://www.federalreserve.gov/monetarypolicy/fomcminutes20260318.htm)
- [FOMC Summary of Economic Projections March 2026 - FRED Blog](https://fredblog.stlouisfed.org/2026/03/fomc-summary-of-economic-projections-march-2026/)
- [A Baseline Forecast for 2026 - J.P. Morgan AM](https://am.jpmorgan.com/us/en/asset-management/adv/insights/market-insights/market-updates/notes-on-the-week-ahead/a-baseline-forecast-for-2026/)
- [First Quarter Investment Report 2026 - Moneta Group](https://monetagroup.com/first-quarter-investment-report-2026)
- [60/40 Portfolio Updated Chart - LongtermTrends](https://www.longtermtrends.com/60-40-stocks-bonds-portfolio/)
- [Q1 2026 Eerily Similar To Last Year - Seeking Alpha](https://seekingalpha.com/article/4887884-q1-2026-eerily-similar-to-last-year)
- [Dow Skyrockets Over 1,100 Points End Q1 2026 - Yahoo Finance](https://finance.yahoo.com/video/dow-skyrockets-by-over-1100-points-stocks-rally-to-end-q1-2026-200847906.html)
- [Market Moves January 2026 - Janus Henderson](https://www.janushenderson.com/en-us/investor/article/market-moves-themes-that-mattered-january-2026/)
