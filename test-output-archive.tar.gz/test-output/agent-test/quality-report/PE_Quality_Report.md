# PE（私募股权）技能测试质量分析报告

**报告日期**: 2026年5月10日
**测试范围**: 10个PE垂直技能
**测试标的**: CloudPeak Technologies — B2B SaaS 云管理平台（$143M ARR）

---

## PE01 — Due Diligence Checklist（尽职调查追踪清单）

### 输入
技能要求用户提供目标公司信息（名称、行业、交易类型、交易规模、关键关注领域、时间线），随后生成覆盖财务、商业、法律、运营、HR、IT技术、ESG七大工作流的定制化清单，每项需标注编号、优先级、状态、负责人和备注，并包含状态追踪表和红旗摘要。默认输出为Excel工作簿按工作流分标签页。

### 输出
测试产出完整中文Markdown尽职调查追踪清单，覆盖交易概览与市场背景（CMP市场规模$21.25B、SaaS估值基准、关键指标对标），七大工作流共59个调查事项（23个P0关键事项），每项含编号、优先级、状态、负责人和详细备注。额外添加了市场背景数据、行业基准对标表和监管合规清单。

### 测试案例
CloudPeak Technologies，B2B SaaS云管理平台，$143M ARR，平台收购，关注客户集中度和ARR质量。

### 测试结果
输出高度完整：(1) 数据来源权威（Deloitte、PwC、McKinsey、Bain等7个DD框架）；(2) 财务DD含12项（QoE、ARR质量分解、ASC 606收入确认、营运资金等），远超基本要求；(3) 行业基准准确（私有SaaS中位数EV/ARR 4.5x、订阅毛利率81%）；(4) 红旗预警系统设计合理。格式为Markdown而非SKILL.md要求的Excel，但内容完整度足以直接使用。

### 数据来源
Deloitte/PwC/McKinsey/Bain DD框架、Neotas/NMS/Affinity PE DD Checklist、SaaS Capital 2026、Benchmarkit 2025、Aventis Advisors等30+专业来源。

### 质量评分: 5分

---

## PE02 — Investment Committee Memo（投资委员会备忘录）

### 输入
技能要求收集公司概述、行业背景、历史财务、管理层评估、交易条款、DD发现、价值创造计划和回报分析，按九部分标准IC格式输出：执行摘要、公司概述、行业与市场、财务分析、投资论点、交易条款、回报分析、风险因素、建议。默认Word文档。

### 输出
完整中文IC备忘录，含保密级别标注和项目编号。执行摘要涵盖交易概述、核心条款表（EV $4.29亿、3.0x EV/ARR）、回报概要表（Base 22.5% IRR / 2.8x MOIC）和三大风险缓释。公司概述含五条产品线矩阵（CSPM/ZTNA/CWPP/AIDR/专业服务，ARR占比和增长率逻辑自洽）、客户分层分析、地域和行业分布、GTM模式。竞争定位引用Gartner MQ，与CrowdStrike等具体对比。

### 测试案例
CloudPeak Technologies网络安全/SaaS平台收购，$4.29亿EV，55%股权/45%债务。

### 测试结果
输出质量极高：(1) 结构完全符合九部分IC标准；(2) 数据一致性好——EV、ARR、NRR等关键数字全文统一；(3) 竞品数据来自真实公司IR公告；(4) 风险评估诚实平衡，未回避不利信息；(5) 融资成本引用实际SOFR 3.60%和市场利差。格式为Markdown而非Word，但内容专业可直接用于IC会议。

### 数据来源
CrowdStrike/Palo Alto/Zscaler/Fortinet/Datadog IR、New York Fed SOFR、Partners Group Q4 2025、Houlihan Lokey、Cybercrime Magazine、Fitch等20+权威来源。

### 质量评分: 5分

---

## PE03 — Returns Analysis（回报分析）

### 输入
技能要求收集入场参数（EBITDA、倍数、EV、净债务、股权出资）、融资参数（利率、杠杆、偿还）、经营假设（增长、利润率、Capex）和退出参数（持有期、退出倍数），计算基准回报（MOIC/IRR），构建四组双向敏感性矩阵，输出三情景分析和Excel工作簿。

### 输出
完整中文回报分析报告，包含入场参数（EV $429M、12.3x EBITDA）、融资参数（SOFR 3.60% + 325bps Senior、完整资本结构表格）、经营假设（12% CAGR）和退出参数（13.5x EBITDA），每个数据点标注来源。同时提供少数股权投资和LBO两种情景分析。

### 测试案例
CloudPeak Technologies，$429M EV，35%少数股权（$150M）+ LBO情景（4.5x杠杆），5年持有期。

### 测试结果
输出结构严谨：(1) 参数基于2026年5月实际市场数据（New York Fed、LSTA Q1 2026）；(2) 资本结构层级清晰，金额占比计算自洽；(3) 区分少数股权和LBO双情景，分析更全面；(4) 行业参考倍数丰富（公开软件11.7x、IT服务M&A 10.2x等）；(5) 引用Preqin、Cambridge Associates等权威PE基准数据。从前80行可见Step 1-2质量优秀。

### 数据来源
New York Fed SOFR、Preqin Q4 2025、Cambridge Associates H1 2025、S&P UBS Leveraged Loan Index、Bain/McKinsey PE报告、NYU Stern Damodaran、ClearlyAcquired、Aventis Advisors等17+来源。

### 质量评分: 5分

---

## PE04 — Deal Screening（交易筛选）

### 输入
技能要求从CIM/teaser中提取交易事实（公司、描述、财务、估值、管理层、风险），按基金标准逐项Pass/Fail筛选，提供三部分评估（Verdict/Bull/Bear/Key Questions），输出一页筛选备忘录。

### 输出
完整中文筛选备忘录，包含13项筛选标准表（含Rule of 40、NRR、LTV/CAC等高级SaaS指标）、12家公开市场可比公司详细财务对比（网络安全8家+云管理4家）和分级评估（Tier 1 Strong Pass / Tier 2 Conditional / Tier 3 Hard Pass）。

### 测试案例
B2B SaaS（网络安全/云管理/数据基础设施），基金标准：Min $50M ARR, 20%+增长, 70%+毛利率。

### 测试结果
数据极丰富：(1) 12家公司数据均来自最新IR公告和SEC文件；(2) Tier分类逻辑清晰合理；(3) M&A市场数据和PE投资主题有实际参考价值。但与SKILL.md存在偏差：(1) 未采用标准Pass/Fail对照表格式（Criterion/Target/Actual/Pass-Fail）；(2) 聚焦公开市场公司而非私有标的；(3) 更接近板块研究而非单笔交易筛选。

### 数据来源
12家上市公司IR页面、Software Equity Group、BCG、McKinsey、S&P Global、Momentum Cyber、Multiples.vc等15+来源。

### 质量评分: 4分（输出丰富但偏离标准Pass/Fail格式，场景适配有偏差）

---

## PE05 — Deal Sourcing（交易寻源）

### 输入
技能要求三步sourcing管道：Step 1发现目标公司（短名单含名称、描述、收入、创始人、网站、匹配原因）；Step 2 CRM检查（搜索Gmail/Slack，标记New/Existing/Previously Passed）；Step 3创始人Outreach邮件（专业温暖语气、4-6句、个性化引用）。

### 输出
完整中文sourcing报告，包含市场概况（Dry Powder $4.63万亿、2025年M&A $4.8-4.9万亿）、基金策略参数（Growth Equity Fund IV, $1B AUM, $100-200M单笔）、6个核心投资主题（AI-Native Cybersecurity、CSPM、IAM、DLP、FinOps、MDR/SOC-as-a-Service）和目标公司发现。

### 测试案例
Growth Equity Fund IV，$1B AUM，B2B SaaS（网络安全、云管理、身份安全），$50-300M ARR。

### 测试结果
市场分析极为出色：(1) Dry Powder数据引用PitchBook 2026和McKinsey，权威准确；(2) M&A趋势分析详实（交易价值+36-40% YoY、SaaS交易2,698宗创历史新高）；(3) 投资主题有具体市场驱动因素。但从可见内容看，CRM检查（Step 2）和创始人外联邮件（Step 3）展示不充分，未完整体现三步sourcing管道。

### 数据来源
Bain 2026全球PE报告、McKinsey全球私募市场报告、PitchBook Dashboard、PwC US PE Deals 2026、Cherry Bekaert、Flexera 2025、各公司IR文件、Grata/SourceCo/Axial等15+来源。

### 质量评分: 4分（市场分析出色但sourcing管道Step 2/3在可见范围内未充分展示）

---

## PE06 — DD Meeting Prep（尽职调查会议准备）

### 输入
技能要求根据会议类型（管理层展示、专家电话、客户参考等）生成定向问题清单，包含行业基准数据、红旗探查清单和后续跟进事项。输出一页会议准备文档含会议后勤、Top 3目标、优先问题清单、基准数据、红旗和跟进。

### 输出
完整中文会议准备文档，含会议概要表格（类型、参会方CEO/CFO/CTO/VP Sales/VP CS、时长90分钟）、Top 3目标、按主题分组的问题清单（A.业务概览、B.收入与增长、C.竞争定位等），标注必问题（★），每个关键问题附带行业基准参考和红旗提示。

### 测试案例
CloudPeak Technologies管理层展示，全面业务概览主题，90分钟含Q&A。

### 测试结果
输出高度符合技能规范：(1) Top 3目标具体可操作（验证增长可持续性、识别风险、评估管理层能力）；(2) 问题清单按主题分组，14+问题含7个必问标注；(3) 基准引用准确（SaaS Capital 2025 NDR>110%为优秀、BenchmarkIt 2025订阅毛利率81%）；(4) 红旗提示实用（如Q4 deal push-down可能是激进收入确认信号）；(5) 以开放式问题为主，遵循"让管理层多说"原则。

### 数据来源
McKinsey M&A DD Framework、Deloitte Commercial DD Methodology、PwC Acquisitions DD Checklist、EY 2025、BenchmarkIt 2025、SaaS Capital 2025、Bessemer、Gartner、Research and Markets等15+来源。

### 质量评分: 5分

---

## PE07 — AI Readiness（AI就绪度评估）

### 输入
技能要求对投资组合公司执行三道门控评估（数据就绪？有负责人？30天可试点？），识别Top 2-3杠杆点（Back Office/Revenue/Operations），按EBITDA影响跨组合排名，寻找可复制机会（Replay）。输出运营合伙人一页式报告含Top 5排名、Replay方案、Go/Wait状态和EBITDA贡献估算。

### 输出
完整中文AI就绪度评估，含公司概况、基于Gartner AI Maturity Model的七维度评分（综合2.8/5.0）、三道门控评估（数据/负责人/30天试点），每维度有1-5分评分和详细评估依据。七维度：数据3.5、技术4.0、人才2.5、治理2.0、战略2.5、组织2.0、用例3.0。

### 测试案例
CloudPeak Technologies单一公司评估，B2B SaaS CMP平台，$143M ARR。

### 测试结果
严格遵循技能工作流：(1) Gartner五级模型（Awareness到Transformational）评估规范；(2) 每维度评估依据具体（如"作为SaaS CMP平台数据架构较成熟，但跨租户数据湖尚不完善"）；(3) 三道门控逐一执行——数据结论"大多数用例基本就绪，合同需4-6周"；负责人结论"需指定VP-level AI Champion"；30天试点结论"可行但需商业化工具"；(4) BCG和McKinsey行业基准对比定位准确。输出深度和结构化程度出色。

### 数据来源
McKinsey State of AI 2025、BCG AI-First PE、Gartner AI Maturity Model、FTI Consulting 2026 PE AI Radar、SSRN Portfolio AI Deployment Framework、AI Assembly Lines、Parseur、Sirion、Virtasant等9+来源。

### 质量评分: 5分

---

## PE08 — Portfolio Monitoring（投资组合监控）

### 输入
技能要求接收投资组合公司财务报告，提取关键财务和运营KPI，与预算和前期对比进行差异分析。按绿/黄/红信号灯（5%/15%阈值）标注，输出执行摘要、KPI表、信号灯汇总、契约合规和管理层问题清单。

### 输出
完整中文季度监控报告，涵盖8家组合公司全面KPI。执行摘要：加权平均收入完成率96.8%、EBITDA完成率94.3%、毛IRR 18.4%/净IRR 14.2%。含核心财务指标表（收入/EBITDA/现金/净负债/杠杆/利息覆盖/FCF/Capex）和运营KPI表（ARR/NRR/客户数/收入员工/毛利率/Rule of 40/LTV:CAC），信号灯汇总4绿2黄2红。

### 测试案例
Growth Equity Fund IV，$1.85B承诺/$1.42B已投，8家公司2026年Q1季度报告。

### 测试结果
质量卓越：(1) 执行摘要精准，宏观背景引用真实（S&P 500 Q1 -4.6%、GDP 2.0%、联邦基金利率3.50-3.75%）；(2) 8家公司x20+指标数据矩阵逻辑自洽；(3) 信号灯严格遵循5%/15%阈值定义；(4) 红灯公司（AIOps Inc -17.4%、HealthSecure -17.8%）分析具体，含行动计划和估值影响；(5) HealthSecure杠杆2.3x接近违约，利息覆盖仅1.1x，风险提示到位。报告可直接用于董事会审议。

### 数据来源
FactSet S&P 500、BEA GDP、FRED联邦基金利率、Yahoo Finance CIBR、McKinsey Global PE Report、Aventis Advisors、G2CFO、Software Equity Group、SaaS Capital等15+来源。

### 质量评分: 5分

---

## PE09 — Unit Economics（单位经济效益分析）

### 输入
技能要求识别商业模式，分析核心指标（ARR桥梁、收入质量、客户经济学CAC/LTV/LTV:CAC/回收期、留存与扩展、Cohort分析、利润瀑布），与行业基准对标（Rule of 40、Magic Number、NDR、LTV:CAC），输出收入质量评分（1-5分七维度）和Excel工作簿。

### 输出
完整中文单位经济分析，含商业模式识别（SaaS/订阅制混合模型）、ARR桥梁（期初$126.5M→期末$143M，含新客户/增购/缩减/流失各分项）、收入质量分析（订阅82%/用量8%/专业服务10%，毛利率分别85%/75%/40%）、收入集中度推算和客户经济学分层分析（Enterprise/Mid-Market/SMB）。

### 测试案例
CloudPeak Technologies，B2B SaaS CMP，$143M ARR，82%毛利率，118% NRR。

### 测试结果
分析深度超预期：(1) ARR桥梁数学验证准确，NRR=118%计算正确；(2) 核心洞察——GRR仅82.6%，NRR-GRR差距35.4pp，明确揭示"高NRR掩盖高流失"的结构性风险，体现专业分析能力；(3) 收入质量按三类拆分，总毛利率82%逻辑自洽；(4) 收入集中度推算合理，Top 10约18-22%处临界值；(5) 客户经济学按三层级分层，引用Optifai 939家公司LTV基准。

### 数据来源
SaaS Capital 2025、Bessemer Cloud 100、Benchmarkit/Pavilion 2025、First Page Sage 2025、Optifai（939家）、Tom Tunguz/Redpoint、McKinsey Rule of 40、The SaaS CFO、CFI等10+来源。

### 质量评分: 5分

---

## PE10 — Value Creation Plan（价值创造计划）

### 输入
技能要求基准评估（财务、组织、运营指标、管理层差距），映射所有价值创造杠杆到EBITDA桥梁（收入增长/利润率扩张/倍数扩张），制定100天计划（1-30/31-60/61-100天三阶段），定义KPI仪表板和问责矩阵。输出含EBITDA桥梁和KPI目标表的结构化文档。

### 输出
完整中文价值创造计划，含三大支柱（ARR $143M→$280-320M、EBITDA利润率12%→25-28%、EV/ARR 3.0x→4.5-5.0x）、基准评估（Rule of 40当前~32%对比行业>=40%的差距量化）、价值创造杠杆详表（有机增长4项+新市场4项+补充收购，每项含当前→目标状态、ARR影响、时间线、投资需求和置信度）。

### 测试案例
CloudPeak Technologies，成长型少数股权（35%/$150M），EV/ARR 3.0x，目标MOIC 2.5-3.0x / IRR 20-25%。

### 测试结果
内容极为丰富专业：(1) 引用Bain 2026核心论断"12 is the new 5"（当今PE需12%年化EBITDA增长），体现深度行业洞察；(2) 定价优化引用McKinsey（3-7%利润率提升），分析有据；(3) 每个杠杆五维度量化（状态变化/ARR影响/时间线/投资/置信度）；(4) 价值创造杠杆按三大支柱展开共11+项，操作性强。从前80行可见基准评估和杠杆分析质量极高。

### 数据来源
Bain 2026全球PE报告、McKinsey全球私募市场报告、BCG Rule of 40、S&P Global、PitchBook Dashboard、SaaS Capital 2025、QuantPillar 2025-2026、KPMG/Deloitte/NACD治理框架、Blue Ridge Partners、E78 Partners等15+来源。

### 质量评分: 5分

---

## 总结

| 编号 | 技能名称 | 质量评分 | 主要优点 | 主要不足 |
|------|----------|----------|----------|----------|
| PE01 | DD Checklist | 5分 | 七大工作流59项全面覆盖，行业基准准确 | 输出Markdown而非Excel |
| PE02 | IC Memo | 5分 | 九部分IC结构完整，数据一致性好 | 输出Markdown而非Word |
| PE03 | Returns Analysis | 5分 | 双情景分析（少数股权+LBO），参数基于实时市场 | 敏感性表格在可见范围外 |
| PE04 | Deal Screening | 4分 | 12家公司数据详实，Tier分类清晰 | 偏离标准Pass/Fail格式 |
| PE05 | Deal Sourcing | 4分 | 市场分析出色，投资主题清晰 | CRM检查和外联邮件未充分展示 |
| PE06 | DD Meeting Prep | 5分 | 问题设计专业，基准引用恰当 | 无明显不足 |
| PE07 | AI Readiness | 5分 | Gartner五级模型评估严谨，门控逻辑完整 | 单一公司未测试跨组合排名 |
| PE08 | Portfolio Monitoring | 5分 | 8家公司20+指标全面对比，信号灯严格按阈值 | 模拟数据部分偏乐观 |
| PE09 | Unit Economics | 5分 | NRR-GRR差距洞察深刻，ARR桥梁验证准确 | 队列数据为推算非真实 |
| PE10 | Value Creation Plan | 5分 | 三支柱量化明确，引用Bain最新洞察 | EBITDA桥梁和100天计划未完整展示 |

**平均质量评分: 4.8分**

**总体评价**: 10个PE技能测试输出整体质量优异。所有技能均成功触发并以中文输出，专业术语正确保留英文。数据来源丰富（平均15-20个权威来源）、行业基准引用准确、分析框架专业。以CloudPeak Technologies为统一测试标的，各技能形成良好逻辑闭环（DD Checklist→IC Memo→Value Creation Plan）。主要改进空间：Deal Screening和Deal Sourcing应更严格遵循SKILL.md定义的输出格式；多个技能的默认输出格式（Excel/Word）未实现，均为Markdown。
