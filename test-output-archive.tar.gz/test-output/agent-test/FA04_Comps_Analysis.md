# B2B SaaS 云管理 — 可比公司分析 (Comparable Company Analysis)

**[DATA SOURCE: Web Search — Yahoo Finance, GuruFocus, Macrotrends, Company IR Press Releases, Trading Economics, Finbox, PublicSaaSCompanies.com]**

**CloudPeak Technologies ($143M ARR, B2B SaaS Cloud Management)**

目标公司可比同行：Datadog (DDOG) | CrowdStrike (CRWD) | Zscaler (ZS) | Fortinet (FTNT) | Cloudflare (NET) | monday.com (MNDY) | HubSpot (HUBS)

截至 2025 年 12 月 31 日 / 2026 年 5 月 8 日 | 所有金额以百万美元计，每股数据和比率除外

---

## 第一部分：运营统计与财务指标 (Operating Statistics & Financial Metrics)

| 公司 (Company) | 营收 (Revenue, LTM, $M) | 营收增长 (Revenue Growth, YoY %) | 毛利 (Gross Profit, $M) | 毛利率 (Gross Margin %) | EBITDA ($M) | EBITDA 利润率 (EBITDA Margin %) | Rule of 40 |
|---|---|---|---|---|---|---|---|
| **Datadog (DDOG)** | 3,430 | 28.0% | 2,740 | 79.9% | 245 | 7.1% | 35.1 |
| **CrowdStrike (CRWD)** | 3,954 | 29.2% | 3,143 | 79.5% | 403 | 10.2% | 39.4 |
| **Zscaler (ZS)** | 2,630 | 23.3% | 2,055 | 76.9% | 163 | 6.2% | 29.5 |
| **Fortinet (FTNT)** | 6,800 | 14.2% | 5,471 | 80.5% | 2,347 | 34.5% | 48.7 |
| **Cloudflare (NET)** | 2,168 | 29.0% | 1,620 | 74.7% | (42) | -1.9% | 27.1 |
| **monday.com (MNDY)** | 1,232 | 27.0% | 1,099 | 89.2% | 169 | 13.7% | 40.7 |
| **HubSpot (HUBS)** | 3,100 | 19.0% | 2,597 | 83.7% | 104 | 3.4% | 22.4 |

| 统计量 | 营收增长 % | 毛利率 % | EBITDA 利润率 % | Rule of 40 |
|---|---|---|---|---|
| **最大值 (Maximum)** | 29.2% | 89.2% | 34.5% | 48.7 |
| **75th 百分位数** | 28.5% | 81.5% | 12.0% | 40.1 |
| **中位数 (Median)** | 27.0% | 79.9% | 7.1% | 35.1 |
| **25th 百分位数** | 21.2% | 76.9% | 3.4% | 27.5 |
| **最小值 (Minimum)** | 14.2% | 74.7% | -1.9% | 22.4 |
| **平均值 (Mean)** | 24.2% | 80.6% | 10.5% | 34.7 |

### 目标公司 (CloudPeak Technologies) 基准对比

| 指标 | CloudPeak ($143M ARR) | 同行中位数 | 折价/溢价 vs. 中位数 |
|---|---|---|---|
| 营收规模 | $143M | $2,630M | N/A (规模差异显著) |
| 营收增长 (假设) | 25.0% | 27.0% | -2.0pp (折价) |
| 毛利率 (假设) | 78.0% | 79.9% | -1.9pp (折价) |
| EBITDA 利润率 (假设) | 8.0% | 7.1% | +0.9pp (溢价) |
| Rule of 40 (计算) | 33.0 | 35.1 | -2.1 (折价) |

> 注：CloudPeak Technologies 为私有公司，运营指标基于 $143M ARR 和典型 B2B SaaS 云管理公司利润率估算。与同行相比，CloudPeak 处于中位数附近水平，EBITDA 利润率略高于同行中位数，表明运营效率合理。

---

## 第二部分：估值倍数与投资指标 (Valuation Multiples & Investment Metrics)

| 公司 (Company) | 市值 (Market Cap, $M) | 企业价值 (EV, $M) | EV/Revenue | EV/EBITDA | P/E |
|---|---|---|---|---|---|
| **Datadog (DDOG)** | 71,240 | 68,800 | 13.7x | 5,637x | 503.7x |
| **CrowdStrike (CRWD)** | 119,190 | 123,110 | 21.4x | 471.9x | N/M (GAAP亏损) |
| **Zscaler (ZS)** | 39,860 | 20,600 | 7.8x | 160.3x | N/M (GAAP亏损) |
| **Fortinet (FTNT)** | 83,510 | 80,710 | 8.8x | 24.7x | 44.2x |
| **Cloudflare (NET)** | 79,220 | 78,630 | 35.0x | N/M (EBITDA负) | N/M (GAAP亏损) |
| **monday.com (MNDY)** | 4,000 | 2,223 | 1.8x | 13.2x | 34.5x |
| **HubSpot (HUBS)** | 12,340 | 8,710 | 3.6x | 54.7x | N/M (低净利润) |

| 统计量 | EV/Revenue | EV/EBITDA | P/E |
|---|---|---|---|
| **最大值 (Maximum)** | 35.0x | 5,637x | 503.7x |
| **75th 百分位数** | 17.6x | 316.0x | 503.7x |
| **中位数 (Median)** | 8.8x | 160.3x | 44.2x |
| **25th 百分位数** | 3.6x | 19.0x | 34.5x |
| **最小值 (Minimum)** | 1.8x | 13.2x | 34.5x |
| **平均值 (Mean)** | 13.2x | 936.3x | 194.1x |

### 目标公司 (CloudPeak Technologies) 隐含估值范围

基于同行 EV/Revenue 倍数对 CloudPeak Technologies ($143M ARR) 的隐含估值分析：

| 估值基准 | EV/Revenue 倍数 | 隐含企业价值 (Implied EV, $M) | 说明 |
|---|---|---|---|
| 最小值 (Minimum) | 1.8x | $257 | 基于 monday.com (极端折价) |
| 25th 百分位数 | 3.6x | $515 | 基于 HubSpot |
| 中位数 (Median) | 8.8x | $1,258 | 基于 Fortinet |
| 平均值 (Mean) | 13.2x | $1,888 | 受极端值影响 |
| 75th 百分位数 | 17.6x | $2,517 | 高增长溢价 |
| 最大值 (Maximum) | 35.0x | $5,005 | 基于 Cloudflare (极端溢价) |

> 排除极端值（monday.com 因股价暴跌导致 EV/Revenue 极低，Cloudflare 因高增长预期导致极高倍数），合理的估值倍数范围为 7.8x - 13.7x，对应隐含企业价值 $1,115M - $1,959M。

---

## 第三部分：数据分析与关键发现 (Analysis & Key Findings)

### 3.1 营运表现分析

**增长梯队划分：**
- **高增长 (>25% YoY)：** Datadog (28%), CrowdStrike (29.2%), Cloudflare (29%), monday.com (27%) — 这些公司保持强劲的营收增速，估值倍数通常较高
- **中等增长 (15-25% YoY)：** Zscaler (23.3%), HubSpot (19%) — 增速稳健但略逊于第一梯队
- **成熟增长 (<15% YoY)：** Fortinet (14.2%) — 营收规模最大 ($6.8B) 但增速放缓，通过利润率提升创造价值

**利润率分析：**
- Fortinet 以 34.5% EBITDA 利润率远超同行（中位数 7.1%），体现了其网络安全硬件+软件混合模式的运营杠杆
- monday.com 和 CrowdStrike 在保持高增长的同时实现了两位数 EBITDA 利润率（13.7% 和 10.2%），展示了出色的增长与盈利平衡
- Cloudflare 仍处于 GAAP EBITDA 亏损阶段 (-1.9%)，反映其在全球网络扩展和 AI 基础设施方面的大量投资

**Rule of 40 评估：**
- 仅 Fortinet (48.7) 和 monday.com (40.7) 超过了 Rule of 40 阈值
- CrowdStrike (39.4) 和 Datadog (35.1) 接近阈值
- Cloudflare (27.1) 和 HubSpot (22.4) 低于阈值，表明增长与盈利的平衡仍需改善

### 3.2 估值倍数分析

**EV/Revenue 分布特征：**
- 同行 EV/Revenue 倍数范围极广 (1.8x - 35.0x)，反映市场对不同增长和利润特征的差异化定价
- 中位数 8.8x 主要受 Fortinet 影响，其成熟的盈利能力和稳定的现金流支撑了这一倍数
- Cloudflare 的 35.0x EV/Revenue 反映了市场对其 AI 基础设施和边缘计算领导地位的极高增长预期

**EV/EBITDA 注意事项：**
- 多数高增长 SaaS 公司的 EV/EBITDA 倍数极高 (160x - 5,637x)，这是因为其 EBITDA 基数很小（大量股票期权费用和研发投入）
- EV/EBITDA 对高增长 SaaS 公司意义有限，EV/Revenue 是更常用的估值指标
- Fortinet (24.7x) 和 monday.com (13.2x) 的 EV/EBITDA 相对合理，因为它们已有有意义的 EBITDA 利润

**P/E 比率注意：**
- 7 家同行中有 4 家 GAAP 净利润为负或极低，导致 P/E 比率不具意义
- Fortinet (44.2x) 和 monday.com (34.5x) 是仅有的具有参考价值的 P/E 比率

### 3.3 CloudPeak Technologies 定位评估

**CloudPeak 优势：**
- 作为 $143M ARR 的 B2B SaaS 云管理公司，处于中型市场（peers 营收中位数 $2,630M），具有显著的增长空间
- 假设的 78% 毛利率和 8% EBITDA 利润率处于同行合理范围内
- Rule of 40 得分 33.0 虽低于中位数，但对于中等规模的 SaaS 公司而言是健康的

**估值建议：**
- 基于同行 EV/Revenue 中位数 8.8x，CloudPeak 的隐含 EV 约为 $1,258M
- 考虑规模折扣（CloudPeak 营收显著小于同行），建议采用 25th-50th 百分位数区间 (3.6x - 8.8x)，隐含 EV 范围 $515M - $1,258M
- 如果 CloudPeak 的增长率高于 25% 且毛利率超过 80%，可考虑溢价至 10x-14x EV/Revenue，隐含 EV $1,430M - $2,002M

---

## 第四部分：注释与方法论 (Notes & Methodology)

### 数据来源与质量

| 数据项 | 来源 | 期间 | 验证方式 |
|---|---|---|---|
| 营收、毛利、增长率 | 公司投资者关系 (IR) 新闻稿、Yahoo Finance | FY 2025 (日历年或财年) | 交叉验证 10-K/10-Q 文件 |
| 市值、企业价值 | Yahoo Finance, Capital.com, GuruFocus, FinanceCharts | 截至 2026 年 5 月 8 日 | 多源交叉确认 |
| EV/Revenue, EV/EBITDA | GuruFocus, Finbox, Yahoo Finance | LTM (最近十二个月) | 与公司财报数据交叉验证 |
| EBITDA | Macrotrends, Trading Economics, 公司 IR | FY 2025 或 TTM | 方法论差异已注明 |
| P/E 比率 | Yahoo Finance, GuruFocus, Robinhood | TTM 或 Forward | 注意 GAAP vs Non-GAAP 差异 |

### 关键定义

- **EBITDA 计算方法：** 各公司定义不同。部分使用调整后 (Non-GAAP) EBITDA，排除股票期权费用、收购相关无形资产摊销等。本分析采用各公司报告的 EBITDA 数据（主要为 GAAP EBITDA）
- **企业价值 (EV) 计算：** 市值 + 总债务 - 现金及等价物
- **Rule of 40：** 营收增长率 (%) + EBITDA 利润率 (%)，用于评估 SaaS 公司增长与盈利的平衡
- **LTM (Latest Twelve Months)：** 最近十二个月财务数据，用于计算 TTM 倍数

### 估值方法论说明

- **时间区间一致性：** 营运数据基于各公司最近完成的财年 (主要为 FY 2025)，市值和企业价值截至 2026 年 5 月 8 日。不同公司财年截止日不同（如 Zscaler 财年截止 7 月，Fortinet 截止 12 月）
- **增长假设：** CloudPeak Technologies 的营运指标基于 $143M ARR 规模和典型 B2B SaaS 云管理行业利润率假设
- **调整项：** 未对一次性项目进行调整。部分公司 EV/EBITDA 极高是因为 GAAP EBITDA 基数很小
- **统计方法：** 使用中位数和四分位数而非简单平均值，以避免极端值扭曲（尤其 EV/EBITDA 和 P/E）

### 可比性注意事项

1. **规模差异：** CloudPeak ($143M ARR) 远小于同行 (营收 $1.2B - $6.8B)，通常需要应用规模折扣
2. **业务模式差异：** Fortinet 混合硬件+软件模式导致利润率特征与其他纯 SaaS 公司不同
3. **NEWR 排除说明：** New Relic (NEWR) 于 2024 年被 TPG 和 Insight Partners 以约 $6.5B EV 私有化收购，已不再公开交易，因此从可比公司列表中排除
4. **Cloudflare 和 Zscaler 财年差异：** Cloudflare 财年与日历年一致 (12月截止)，Zscaler 财年截止 7 月

---

## 第五部分：数据来源 (Sources)

### 公司投资者关系
- [Datadog FY 2025 财报](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-fourth-quarter-and-fiscal-year-2025-financial)
- [CrowdStrike FY 2025 财报](https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2025/)
- [Zscaler FY 2025 财报](https://ir.zscaler.com/news-releases/news-release-details/zscaler-reports-fourth-quarter-and-fiscal-2025-financial-results)
- [Fortinet FY 2025 财报](https://investor.fortinet.com/news-releases/news-release-details/fortinet-reports-strong-fourth-quarter-and-full-year-2025)
- [Cloudflare FY 2025 财报](https://cloudflare.net/news/news-details/2026/Cloudflare-Announces-Fourth-Quarter-and-Fiscal-Year-2025-Financial-Results/default.aspx)
- [monday.com FY 2025 财报](https://ir.monday.com/news-and-events/news-releases/news-details/2026/monday-com-Announces-Fourth-Quarter-and-Fiscal-Year-2025-Results/default.aspx)
- [HubSpot FY 2025 财报](https://ir.hubspot.com/news-releases/news-release-details/hubspot-reports-strong-q4-and-full-year-2025-results)

### 估值与市场数据
- [Yahoo Finance — DDOG 关键统计](https://finance.yahoo.com/quote/DDOG/key-statistics/)
- [Yahoo Finance — CRWD 关键统计](https://finance.yahoo.com/quote/CRWD/key-statistics/)
- [Yahoo Finance — ZS 关键统计](https://finance.yahoo.com/quote/ZS/key-statistics/)
- [Yahoo Finance — FTNT 关键统计](https://finance.yahoo.com/quote/FTNT/key-statistics/)
- [Yahoo Finance — NET 关键统计](https://finance.yahoo.com/quote/NET/key-statistics/)
- [Yahoo Finance — HUBS 关键统计](https://finance.yahoo.com/quote/HUBS/key-statistics/)
- [GuruFocus — DDOG EV/Revenue](https://www.gurufocus.com/term/enterprise-value-to-revenue/DDOG)
- [GuruFocus — ZS EV/Revenue](https://www.gurufocus.com/term/enterprise-value-to-revenue/ZS)
- [GuruFocus — FTNT EV/EBITDA](https://www.gurufocus.com/term/enterprise-value-to-ebitda/FTNT)
- [GuruFocus — HUBS EV/Revenue](https://www.gurufocus.com/term/enterprise-value-to-revenue/HUBS)
- [GuruFocus — MNDY EV/Revenue](https://www.gurufocus.com/term/enterprise-value-to-revenue/MNDY)

### 财务数据平台
- [Macrotrends — DDOG 毛利](https://www.macrotrends.net/stocks/charts/DDOG/datadog/gross-profit)
- [Macrotrends — CRWD EBITDA 利润率](https://www.macrotrends.net/stocks/charts/CRWD/crowdstrike/ebitda-margin)
- [Macrotrends — ZS EBITDA](https://www.macrotrends.net/stocks/charts/ZS/zscaler/ebitda)
- [Macrotrends — FTNT 毛利](https://www.macrotrends.net/stocks/charts/FTNT/fortinet/gross-profit)
- [Macrotrends — HUBS EBITDA](https://www.macrotrends.net/stocks/charts/HUBS/hubspot/ebitda)
- [Finbox — NET EV/Revenue](https://finbox.com/NYSE:NET/explorer/ev_to_revenue_ltm/)
- [Finbox — ZS EV/Revenue](https://finbox.com/NASDAQGS:ZS/explorer/ev_to_revenue_ltm/)
- [Finbox — FTNT EV/Revenue](https://finbox.com/NASDAQGS:FTNT/explorer/ev_to_revenue_ltm/)
- [Trading Economics — FTNT EBITDA](https://tradingeconomics.com/ftnt:us:ebitda)
- [Trading Economics — CRWD EBITDA](https://tradingeconomics.com/crwd:us:ebitda)

### 其他参考
- [PublicSaaSCompanies.com — SaaS 倍数基准](https://publicsaascompanies.com/saas-multiples/)
- [Multiples.vc — CRWD 估值倍数](https://multiples.vc/public-comps/crowdstrike-valuation-multiples)
- [Multiples.vc — NET 估值倍数](https://multiples.vc/public-comps/cloudflare-valuation-multiples)
- [Capital.com — HUBS 市值](https://capital.com/en-int/markets/shares/hubspot-inc-share-price/market-cap)
- [Capital.com — CRWD 市值](https://capital.com/en-int/markets/shares/crowdstrike-holdings-inc-share-price/market-cap)
- [Companies Market Cap — DDOG](https://companiesmarketcap.com/datadog/marketcap/)
- [Companies Market Cap — NET](https://companiesmarketcap.com/cloudflare/marketcap/)
- [Stock Analysis — MNDY 统计](https://stockanalysis.com/stocks/mndy/statistics/)
- [Stock Analysis — HUBS 统计](https://stockanalysis.com/stocks/hubs/statistics/)

---

**免责声明：** 本分析基于公开可获得的财务数据和市场信息，仅供参考。CloudPeak Technologies 为虚拟目标公司，其营运指标基于 $143M ARR 和行业典型利润率假设。实际投资决策应结合更详细的尽职调查和专业财务顾问意见。所有市值和企业价值数据截至约 2026 年 5 月 8 日，可能随市场波动而变化。

**分析日期：** 2026 年 5 月 9 日
**分析师：** Claude AI Agent (Financial Analysis Plugin)
**版本：** FA04_Comps_Analysis v1.0
