[DATA SOURCE: WebSearch — McKinsey M&A Due Diligence Framework; Deloitte Commercial & Operational DD Methodology; PwC Acquisitions Due Diligence Checklist; EY 2025 Operational DD Questions; BenchmarkIt 2025 SaaS Performance Metrics; SaaS Capital 2025 Retention Benchmarks; Bessemer Venture Partners Cloud Computing Metrics (BVP Atlas); Grand View Research Cloud Computing Market 2025-2030; Gartner Public Cloud Spending Forecast 2025; Research and Markets SaaS Management Market 2025-2030; KMS Technology PE Software DD Checklist; TechCXO Tech DD for Private Equity; RSM US Technology DD in PE; NMS Consulting PE DD Checklist; Affinity Complete PE DD Checklist; Plante Moran 7-Step DD Checklist]

---

# CloudPeak Technologies — 尽职调查会议准备

**目标公司**: CloudPeak Technologies
**业务描述**: B2B SaaS 云管理平台
**ARR**: $143M (年度经常性收入)
**文件日期**: 2026年5月9日

---

## 一、会议概要 (Meeting Logistics)

| 项目 | 详情 |
|------|------|
| **会议类型** | 管理层展示 (Management Presentation) |
| **参会方** | CloudPeak CEO, CFO, CTO, VP Sales, VP Customer Success |
| **我方团队** | 投资合伙人, 运营合伙人, 商业DD顾问, 技术DD顾问 |
| **时长** | 90分钟 (含15分钟Q&A) |
| **形式** | 现场会议 + 数据室同步审查 |
| **主题范围** | 全面业务概览 (Full Business Overview) |

---

## 二、会议目标 (Top 3 Objectives)

1. **验证增长故事的可持续性**: 确认$143M ARR的增长驱动因素(价格/量/新客户), 评估未来3-5年增长路径的可信度
2. **识别关键风险和隐患**: 深入了解客户集中度、竞争威胁、技术债务和团队稳定性, 发现CIM和数据室中未揭示的风险
3. **评估管理层能力和透明度**: 通过开放性问题观察管理层对业务的理解深度、诚实度和执行能力, 为后续专家访谈和客户背调建立基准

---

## 三、问题清单 (Prioritized Question List)

> 框架参考: McKinsey M&A Due Diligence Framework, Deloitte Commercial DD Methodology, PwC Acquisitions DD Checklist
> 问题标注: ★ = 必问 (Must-Ask), 其余为根据会议进展灵活追问

### A. 业务概览 / Business Overview (热身)

**Q1** ★ 请简要介绍CloudPeak的创立故事和关键发展里程碑 — 什么时刻定义了今天的CloudPeak?

**Q2** ★ 如果用一两句话向不了解这个行业的人描述CloudPeak的业务, 你会怎么说?

**Q3** 过去三年中最让你自豪的成就是什么? 如果重来一次, 有什么你会做不同的决定?

**Q4** CloudPeak的企业文化是什么样的? 你如何保持团队在快速增长中的凝聚力?

---

### B. 收入与增长 / Revenue & Growth

**Q5** ★ 请详细拆解$143M ARR — 按客户规模(enterprise/mid-market/SMB)、地理区域和产品线的分布是怎样的?

**Q6** ★ 增长的主要驱动力是什么? 价格增长 vs. 座位扩展 vs. 新客户获取各贡献了多少? (参考: SaaS Capital 2025 Benchmark — 优质B2B SaaS净美元留存率应>110%)

**Q7** ★ 销售周期的典型时长是多少? 从初次接触到签约的转化漏斗是怎样的? Win rate近两年的趋势如何?

**Q8** ARR中新增ARR vs. 扩展ARR vs. 续约ARR的构成比例是什么? Net Dollar Retention (NDR) 和 Gross Dollar Retention (GDR) 分别是多少?
> 基准参考: BenchmarkIt 2025 — 中位数订阅毛利率81%, NDR >110%为优秀, GDR >90%为健康

**Q9** 你们最大的增长机会在哪里(未来3-5年)? 有哪些尚未充分渗透的市场或用例?

**Q10** ARR增速是否有季节性波动? Q4 deal push-down的情况是否普遍存在?
> 红旗提示: 大量季末集中签约可能是激进收入确认的信号 (来源: Streamliners PE DD Pitfalls)

---

### C. 竞争定位 / Competitive Positioning

**Q11** ★ 在竞标中你们最常输给谁? 输掉的主要原因是什么 — 价格、功能还是品牌?

**Q12** ★ CloudPeak的护城河是什么? 如果一个资金充足的竞争对手复制你们的产品, 客户有多难迁移?

**Q13** 客户在评估你们和替代方案(Vmware Aria, Flexera, CloudHealth by Broadcom等)时, 最看重哪些维度?

**Q14** 云管理平台市场中, 你们认为自己是领导者还是挑战者? 市场份额的大致估计是多少?
> 市场基准: SaaS管理市场2025年规模约$4.58B, 预计2030年达到$9.37B, CAGR 15.4% (来源: Research and Markets)

**Q15** 开源解决方案或云原生厂商(AWS Cost Explorer, Azure Cost Management)的免费工具对你们的威胁有多大?

---

### D. 财务深度挖掘 / Financial Deep-Dive

**Q16** ★ 请详细拆解毛利率结构 — 订阅毛利率 vs. 专业服务毛利率 vs. 总毛利率。与行业基准比较如何?
> 基准参考: BenchmarkIt 2025 — 订阅收入毛利率中位数81%, 总收入毛利率77%; SaaS & Co — 成熟SaaS运营利润率15-25%

**Q17** ★ 毛利率变动趋势如何? 云基础设施成本(托管在AWS/Azure/GCP上的成本)占收入的比例是多少? 过去两年有何变化?

**Q18** EBITDA margin的桥接分析 — 过去两年margin变化的主要驱动因素是什么? 有哪些一次性或非经常性项目需要我们了解?

**Q19** 资本支出的构成是怎样的? 维护性capex vs. 增长性capex的区分? 技术基础设施投资的未来计划?

**Q20** 营运资金的季节性如何? 递延收入和预付费用的趋势? 现金转换周期?

**Q21** ★ 客户获取成本(CAC)和客户生命周期价值(LTV)分别是多少? LTV/CAC比率? (参考: Bessemer Venture Partners Cloud Metrics — CAC, LTV, CMRR为云公司核心指标)

**Q22** 研发支出占收入的比例是多少? 与行业基准(R&D占收入34% for private SaaS, 23% for public — BenchmarkIt 2025)比较如何?

---

### E. 运营与团队 / Operations & Team

**Q23** ★ 请介绍核心管理团队的背景和关键人员 — 谁是不可替代的? 有哪些关键人员离职风险?

**Q24** 目前有哪些岗位正在招聘? 哪些岗位最难填补? 团队扩张计划是什么?

**Q25** ARR per FTE (每位全职员工的ARR贡献) 是多少?
> 基准参考: BenchmarkIt 2025 — $50M-$100M ARR段位中, ARR per FTE中位数约$200K

**Q26** 客户成功团队的规模和结构如何? 客户健康度评分体系是否存在?

**Q27** 运营层面, 什么问题最让你夜不能寐?

---

### F. 技术与架构 / Technical & Architecture

**Q28** ★ 请概述CloudPeak的技术架构 — 单体架构还是微服务? 云原生还是传统部署? 技术栈是什么?

**Q29** ★ 技术债务的规模有多大? 是否有已知的架构瓶颈可能制约未来扩展?
> 框架参考: KMS Technology PE Software DD Checklist — "Is the software architecture scalable and future-proof?"; RSM US — "Understand technical debt and potential cost to address"

**Q30** 系统的正常运行时间(Uptime) SLA是多少? 过去12个月的实际表现? 有过重大事故吗?

**Q31** 数据安全和合规状况 — SOC 2 Type II, ISO 27001, GDPR合规情况? 最近一次渗透测试的结果?

**Q32** AI/ML能力在产品中的应用程度? 是否有AI驱动的功能(成本优化建议、异常检测等)?

**Q33** CI/CD管道的成熟度如何? 部署频率? 从代码提交到生产发布的平均时间?
> 框架参考: TechCXO — "Tech DD reveals hidden risks, scalability gaps, AI strategy weaknesses, and cybersecurity exposure"

---

### G. 法律与合规 / Legal & Compliance

**Q34** 当前是否有任何未决诉讼或监管调查?

**Q35** IP保护状况 — 核心专利、商标、商业秘密保护措施?

**Q36** 数据隐私政策是否完全符合GDPR、CCPA以及各州新兴隐私法规?

---

### H. ESG / 环境、社会与治理

**Q37** CloudPeak是否有ESG政策或可持续发展报告?

**Q38** 管理层和董事会的多元化状况? 是否有DEI(多元化、公平性和包容性)倡议?

**Q39** 云管理平台如何帮助客户减少碳足迹? 这是销售对话的一部分吗?

---

### I. 前瞻展望 / Forward Look

**Q40** ★ 请概述明年的预算/业务计划 — 收入增长目标、利润率目标、关键投资领域?

**Q41** 计划中最具信心和最不确定的假设分别是什么?

**Q42** 哪些因素可能导致大幅超出或低于计划?

**Q43** 如果获得我们的投资, 在第一个100天内你会优先做哪些事情?

**Q44** ★ 有什么我们还没问到但你应该告诉我们的事情? ("What haven't we asked about that we should?")

---

## 四、关键基准数据 (Benchmarks to Reference)

> 数据来源: BenchmarkIt 2025, SaaS Capital 2025, BVP Atlas, Gartner 2025, Research and Markets 2025

| 指标 | 行业基准 | CloudPeak待验证 | 数据来源 |
|------|----------|-----------------|----------|
| **订阅毛利率** | 81% (中位数) | ? | BenchmarkIt 2025 |
| **总收入毛利率** | 77% (中位数) | ? | BenchmarkIt 2025 |
| **净美元留存率 (NDR)** | >110% 优秀; 100-110% 良好 | ? | SaaS Capital 2025 |
| **总美元留存率 (GDR)** | >90% 健康 | ? | SaaS Capital 2025 |
| **ARR per FTE** | ~$200K ($50M-$100M ARR段) | ? | BenchmarkIt 2025 |
| **R&D占收入比** | 34% (私有SaaS) / 23% (上市SaaS) | ? | BenchmarkIt 2025 |
| **运营利润率** | 15-25% (成熟SaaS) | ? | SaaS & Co 2025 |
| **总支出占ARR比** | 95% (bootstrap) / 107% (VC支持) | ? | SaaS Capital 2025 |
| **SaaS管理市场规模** | $4.58B (2025) → $9.37B (2030) | — | Research and Markets |
| **云服务市场增速** | CAGR 20.4% (2025-2030) | — | Grand View Research |
| **公共云支出** | $723.4B (2025), +21% YoY | — | Gartner 2025 |
| **SaaS估值倍数** | 3-5x ARR (中小); 更高(成长期) | ? | Axial / Software Equity |
| **CAC回收期** | <12个月为优秀 | ? | Bessemer (BVP Atlas) |
| **LTV/CAC比率** | >3x 为健康 | ? | Bessemer (BVP Atlas) |

---

## 五、红旗检查清单 (Red Flags to Probe)

> 参考: McKinsey DD Framework, PwC PE DD Checklist, Carta PE DD Guide, EY 2025 Operational DD

### 财务类红旗
- [ ] **季末收入集中**: Q4或季末是否存在大量交易集中签约(可能是激进收入确认) — 来源: Streamliners PE DD Pitfalls
- [ ] **客户集中度过高**: 前5大客户是否贡献超过25%的ARR? 前10大是否超过40%?
- [ ] **毛利率异常**: 总毛利率低于70%或显著下降趋势 — 云基础设施成本是否随规模失控?
- [ ] **非经常性项目过多**: EBITDA调整项是否频繁且金额较大? 是否存在反复出现的"一次性"费用?
- [ ] **现金与收入不匹配**: 收入增长显著快于经营性现金流增长

### 商业类红旗
- [ ] **流失率上升**: Net Dollar Retention持续下降或低于100%
- [ ] **销售效率下降**: CAC持续上升, 销售周期拉长, Win rate下降
- [ ] **定价权缺失**: 续约时是否需要大幅折扣? 价格上涨客户是否大量流失?
- [ ] **市场竞争加剧**: 免费工具(AWS/Azure/GCP原生工具)是否开始侵蚀低端市场?

### 技术类红旗
- [ ] **技术债务沉重**: 是否存在大量遗留代码需要重写? — 来源: RSM US Technology DD
- [ ] **架构不可扩展**: 单体架构是否已成为瓶颈? 微服务迁移的进度和成本?
- [ ] **安全事故历史**: 是否有过数据泄露或重大安全事件?
- [ ] **关键人员依赖**: 核心技术是否只掌握在少数几个人手中? — 来源: KMS Technology PE DD

### 运营/团队类红旗
- [ ] **管理层频繁变动**: 过去12个月是否有C-level或VP级别离职?
- [ ] **招聘困难**: 关键岗位长期空缺是否影响业务执行?
- [ ] **文化风险**: 员工满意度调查结果? Glassdoor评分?

### 法律/合规类红旗
- [ ] **未决诉讼**: 是否存在可能影响估值的重大法律风险?
- [ ] **IP风险**: 是否存在开源代码合规问题或IP侵权风险?
- [ ] **数据隐私**: 是否有过GDPR/CCPA违规或罚款?

---

## 六、会议议程建议 (Suggested Meeting Agenda)

| 时间段 | 主题 | 负责方 |
|--------|------|--------|
| 0:00-0:15 | 开场与业务概览 (Q1-Q4) | CloudPeak CEO |
| 0:15-0:35 | 收入增长与商业模型深度挖掘 (Q5-Q10) | CloudPeak CFO + VP Sales |
| 0:35-0:50 | 竞争定位与市场 (Q11-Q15) | CloudPeak CEO + VP Sales |
| 0:50-1:05 | 财务深度: 利润率、现金流、单位经济 (Q16-Q22) | CloudPeak CFO |
| 1:05-1:15 | 技术、架构与安全 (Q28-Q33) | CloudPeak CTO |
| 1:15-1:25 | 运营、团队与前瞻展望 (Q23-Q27, Q40-Q43) | CloudPeak CEO + 全体 |
| 1:25-1:30 | 收尾与开放问题 (Q44) | 双方 |

---

## 七、会后跟进事项 (Follow-Up Action Items)

> 参考: Deloitte "Questions into Answers" DD Approach, NMS Consulting PE DD Checklist & 100-Day Plan

### 数据请求清单 (Data Room Follow-Up)
- [ ] **客户级数据**: 按客户逐月ARR明细, 包含签约日期、产品线、定价层级、流失/续约历史
- [ ] **销售漏斗数据**: 过去8个季度的pipeline数据 — 新建线索、各阶段转化率、胜率、平均销售周期
- [ ] **财务明细**: 月度P&L(过去24个月), 现金流量表, 递延收入明细, EBITDA调整项完整列表
- [ ] **技术文档**: 系统架构图, 技术债务评估报告, 安全审计报告(SOC 2), 正常运行时间日志
- [ ] **人员数据**: 完整组织架构图, 关键人员简历, 过去12个月员工流失率, 待填补岗位列表
- [ ] **合同审阅**: Top 20客户合同摘要, 供应商合同(特别是云基础设施), 关键员工雇佣协议

### 后续会议安排
- [ ] **专家网络访谈**: 安排2-3位云管理平台行业专家的背景调研 (参考SKILL.md Expert Network Call框架)
- [ ] **客户背调**: 确认5-8位客户参考, 包含长期客户和相对新客户 (参考SKILL.md Customer Reference框架)
- [ ] **技术DD深度审查**: 安排与CTO的单独技术深度会议, 可能需要外部技术DD顾问参与
- [ ] **法律DD启动**: 与法律顾问分享会议记录, 启动法律和合规尽调工作流

### 内部讨论要点
- [ ] 管理层能力评估: 基于会议观察, 评估CEO/CFO/CTO的能力和留任意愿
- [ ] 估值假设更新: 根据新信息更新财务模型中的增长率和利润率假设
- [ ] 风险矩阵更新: 将新发现的红旗和风险纳入投资委员会备忘录的风险部分

---

## 八、访谈技巧与注意事项

> 来源: SKILL.md Diligence Meeting Prep Best Practices

1. **开放式问题优先**: 让管理层充分表达, 然后针对具体细节追问 — 避免诱导性问题
2. **不引导证人**: 使用中性措辞提问, 不使用"难道不是...吗?"式的问题
3. **观察非语言信号**: 记录管理层在回答特定问题时的肢体语言和自信程度, 不仅记录答案本身
4. **始终以开放问题结尾**: "有什么我们没问到但应该知道的?" — 往往能得到最有价值的披露
5. **控制问题数量**: 90分钟会议最多覆盖15-20个核心问题, 标注★的必问题目优先确保
6. **记录待跟进项**: 会议中遇到需要深入数据验证的回答, 标记为会后数据请求, 不占用现场时间

---

## Sources

以下为本报告所引用的具体数据来源和框架:

- [McKinsey — M&A Strategy & Due Diligence](https://www.mckinsey.com/capabilities/m-and-a/how-we-help-clients/m-and-a-strategy-due-diligence)
- [McKinsey — Global Private Markets Report 2024](https://www.mckinsey.com/industries/private-capital/our-insights/global-private-markets-report-2024)
- [McKinsey — Global Private Equity Report 2026](https://www.mckinsey.com/industries/private-capital/our-insights/global-private-markets-report/private-equity)
- [Deloitte — Commercial Due Diligence](https://www.deloitte.com/se/sv/services/consulting-financial/services/commercial-due-diligence.html)
- [Deloitte — Operational Due Diligence Explained](https://www.deloitte.com/no/no/services/consulting-financial/perspectives/operational-due-diligence-explained.html)
- [Deloitte — 4 Key IT Due Diligence Opportunities in PE](https://www.deloitte.com/ch/en/services/consulting/perspectives/4-key-it-due-diligence-opportunities-to-add-value-in-pe-buy-side-investments.html)
- [PwC — Due Diligence for Mergers and Acquisitions](https://www.pwc.com/us/en/services/consulting/deals/acquisitions/due-diligence.html)
- [PwC Korea — What We Bring to Private Equity Clients (PDF)](https://www.pwc.com/kr/en/publications/samilpwc_private-equity.pdf)
- [EY — The Questions Operational Due Diligence Should Be Asking in 2025](https://www.ey.com/en_ch/insights/private-equity/the-questions-operational-due-diligence-should-be-asking-in-2025)
- [BenchmarkIt — 2025 SaaS Performance Metrics](https://www.benchmarkit.ai/2025benchmarks)
- [SaaS Capital — What is a Good Retention Rate for a Private SaaS Company in 2025?](https://www.saas-capital.com/blog-posts/what-is-a-good-retention-rate-for-a-private-saas-company/)
- [SaaS Capital — 2025 Spending Benchmarks for Private B2B SaaS Companies](https://www.saas-capital.com/blog-posts/spending-benchmarks-for-private-b2b-saas-companies/)
- [Bessemer Venture Partners — The Five Accounting Metrics for Cloud Companies (BVP Atlas)](https://www.bvp.com/atlas/cloud-computing-metrics)
- [Gartner — Worldwide Public Cloud End-User Spending to Total $723B in 2025](https://www.gartner.com/en/newsroom/press-releases/2024-11-19-gartner-forecasts-worldwide-public-cloud-end-user-spending-to-total-723-billion-dollars-in-2025)
- [Grand View Research — Cloud Computing Market Size 2025-2030](https://www.grandviewresearch.com/horizon/outlook/cloud-computing-market-size/global)
- [Research and Markets — SaaS Management Market Forecast to 2030](https://www.researchandmarkets.com/reports/6214288/saas-management-market-platform-global-forecast)
- [KMS Technology — Private Equity Checklist: Software Due Diligence](https://kms-technology.com/blog/the-ultimate-private-equity-checklist-software-due-diligence-development/)
- [TechCXO — Tech Due Diligence for Private Equity](https://www.techcxo.com/insights-tech-due-diligence-for-private-equity/)
- [RSM US — The Critical Role of Technology Due Diligence in Private Equity](https://rsmus.com/insights/industries/private-equity/the-critical-role-of-technology-due-diligence-in-private-equity.html)
- [NMS Consulting — Private Equity Due Diligence Checklist](https://nmsconsulting.com/private-equity-due-diligence-checklist/)
- [Affinity — The Complete Private Equity Due Diligence Checklist](https://www.affinity.co/guides/due-diligence-checklist-for-private-equity-firms)
- [Plante Moran — Due Diligence Checklist: 7 Critical Steps (2025)](https://www.plantemoran.com/explore-our-thinking/insight/2025/10/due-diligence-checklist)
- [Carta — Private Equity Due Diligence: How to Evaluate Deals](https://carta.com/learn/private-funds/management/deal-flow/due-diligence/)
- [Streamliners — Common Pitfalls in Private Equity Due Diligence](https://streamliners.us/common-pitfalls-in-private-equitys-operational-due-diligence-and-how-to-avoid-them/)
- [Software Equity — ARR for SaaS Leaders: Impact on Valuation](https://softwareequity.com/blog/arr)
- [Software Equity — SaaS M&A Due Diligence Checklist](https://softwareequity.com/blog/due-diligence-checklist)
- [Axial — 6 Key SaaS Metrics That Determine Your Valuation Range](https://www.axial.net/forum/key-saas-metrics/)
- [CloudZero — SaaS Gross Margin Benchmarks 2025](https://www.cloudzero.com/blog/saas-gross-margin-benchmarks/)
- [SaaS & Co — Revenue Operations Benchmarks for 2025](https://www.saasandco.com/sf-admin-health-check/f/revenue-operations-benchmarks-for-2025)
- [High Alpha — Net Revenue Retention: Why It's Crucial for SaaS Growth in 2025](https://www.highalpha.com/blog/net-revenue-retention-2025-why-its-crucial-for-saas-growth)
