[DATA SOURCE: WebSearch - SaaS M&A market data from SaaSRise, Aventis Advisors, Finerva, Software Equity Group, Grand View Research, GM Insights, MergerSight, IBM Newsroom, SAP News Center, PR Newswire, TechCrunch, CRN, Forbes, SaaS Capital, QuantPillar, multiples.vc, CrowdStrike Investor Relations, Datadog Investor Relations, ClearlyAcquired, Wall Street Prep, S&P Global, PitchBook via Fortune]

---

# 保密文件 | CONFIDENTIAL

# 战略备选方案评估
## CloudPeak Technologies, Inc.

**M&A咨询推介材料**

编制日期：2026年5月9日

---

> **免责声明：** 本材料由[投资银行名称]编制，仅供CloudPeak Technologies董事会及管理层内部讨论使用。本材料不构成任何收购要约或出售邀约。所有市场数据及估值分析基于公开信息和第三方研究，仅供参考。

---

## 目录

1. 执行摘要
2. 市场概况 — 云管理SaaS行业
3. 可比交易分析
4. 可比上市公司分析
5. Football Field估值总结
6. 战略备选方案
7. 推荐的流程时间表
8. 附录

---

## 1. 执行摘要

### 公司概况

| 项目 | 详情 |
|------|------|
| **公司名称** | CloudPeak Technologies, Inc. |
| **总部** | 美国科罗拉多州丹佛市 |
| **业务领域** | B2B SaaS — 云管理与成本优化平台 |
| **ARR（年度经常性收入）** | $143M |
| **收入增长率** | ~28% YoY |
| **毛利率** | ~82% |
| **EBITDA利润率** | ~15%（调整后） |
| **净收入留存率（NDR）** | ~118% |
| **企业客户数** | 1,200+ |
| **员工人数** | ~650人 |

### 交易要点

- CloudPeak Technologies是一家高速增长的B2B SaaS企业，专注于多云管理与成本优化领域
- 公司ARR达$143M，同比增长约28%，处于SaaS企业规模化扩张的关键阶段
- 多云管理市场规模预计以17-21% CAGR增长，CloudPeak具备显著的市场扩展潜力
- 当前SaaS M&A市场活跃度创历史新高（2025年共完成2,698宗交易），战略买家和私募股权均积极布局
- 基于17-31x ARR的中位数估值倍数，CloudPeak的隐含企业价值范围约为$1.1B - $3.0B

### 关键亮点

- **高经常性收入质量：** ARR $143M，NDR 118%，体现强劲的客户留存与追加销售能力
- **市场顺风：** 云成本浪费占云支出30%+，FinOps实践需求激增
- **平台化优势：** 覆盖AWS、Azure、GCP的多云统一管理能力
- **AI驱动差异化：** 智能成本优化与自动化策略引擎

---

## 2. 市场概况 — 云管理SaaS行业

### 2.1 市场规模与增长

| 数据来源 | 基准年规模 | CAGR | 预测年规模 | 预测期 |
|----------|-----------|------|-----------|--------|
| Grand View Research | $5.34B（2025年） | 17.6% | $19.27B（2033年） | 2026-2033 |
| GM Insights | $9.8B（2024年） | 17.2% | — | 2025-2034 |
| Verified Market Research | $4.5B（2023年） | 23.2% | $13.78B（2030年） | 2024-2030 |
| Credence Research | $6.97B（2024年） | 20.9% | $31.83B（2032年） | 2025-2032 |
| IndustryARC | — | 17.7% | $37B（2031年） | 2025-2031 |

**市场共识：**
- **当前市场规模（2025年）：** 约$5-10B
- **CAGR共识范围：** 17%-21%
- **预测规模（2030-2033年）：** $14-32B

Sources: Grand View Research (2025), GM Insights (2025), Credence Research (2024), IndustryARC (2025), Verified Market Research (2023).

Notes: (1) 各研究机构市场定义范围不同（仅工具 vs. 含咨询/服务）；(2) 地理覆盖范围存在差异；(3) CAGR基于各来源的中位数值。

### 2.2 市场驱动因素

- **多云复杂度持续攀升：** 企业平均使用2-3个公有云平台，管理复杂度指数级增长
- **云浪费问题严峻：** 估计30%+的云支出被浪费，FinOps实践需求急剧上升
- **监管与合规压力：** 云预算问责制与财务透明度要求日趋严格
- **AI/ML工作负载增长：** AI训练与推理的云资源消耗推动智能优化需求
- **成本优化刚需：** 宏观经济不确定性下，企业更加关注云成本效率

### 2.3 竞争格局

| 公司 | 类型 | ARR/收入规模 | 增长率 | EV/Revenue |
|------|------|-------------|--------|------------|
| Datadog (DDOG) | 上市 — 可观测性 | $3.43B (FY2025) | ~26% | ~14.0x |
| Elastic (ESTC) | 上市 — 搜索与可观测 | $1.48B (FY2025) | 稳定增长 | — |
| CrowdStrike (CRWD) | 上市 — 云安全 | $5.0B+ | 高增长 | ~21.8x |
| Qualys (QLYS) | 上市 — 安全与合规 | — | ~8.7% | ~6.9x |
| **CloudPeak Technologies** | **私有 — 云管理** | **$143M ARR** | **~28%** | **待估值** |

Sources: Datadog IR (2026), CrowdStrike IR (2026), Qualys via Seeking Alpha (2025), multiples.vc (2026).

Notes: (1) Datadog为最大的纯可观测性厂商； (2) CrowdStrike云安全模块ARR达$515M，YoY增长80%； (3) 网络安全板块中位数EV/Revenue约11.9x（ICON Corporate Finance，2025年8月）。

### 2.4 SaaS M&A市场趋势

| 指标 | 2024年 | 2025年 | 趋势 |
|------|--------|--------|------|
| SaaS M&A交易数量 | ~2,100+ | 2,698 | +28% YoY |
| 总交易价值 | ~$120B+ | $180B+ | 创历史新高 |
| 超大型交易（>$2.5B） | — | 17笔 | 显著增加 |
| 私有SaaS EV/Revenue中位数 | 4.7x | 4.1-5.9x | 小幅波动 |
| 私有SaaS EV/EBITDA中位数 | ~20x | ~19-23x | 趋于正常化 |
| 软件占M&A市场份额 | ~55% | 65% | 持续上升 |

Sources: SaaSRise (2026), Software Equity Group (2026), Aventis Advisors (2025), SaaS Capital (2025), Finerva (2026), M&A Advisor (2025).

Notes: (1) 2025年SaaS M&A创历史最高记录； (2) Q1 2026企业SaaS M&A达210笔（PitchBook）； (3) 私募股权积极执行buy-and-build策略。

---

## 3. 可比交易分析

### 3.1 近期重大SaaS/云基础设施M&A交易

| 日期 | 收购方 | 标的公司 | 交易金额 | EV/Revenue | EV/EBITDA | 领域 |
|------|--------|---------|---------|------------|-----------|------|
| 2025年3月 | Google/Alphabet | Wiz（云安全） | $32.0B | ~32.0x¹ | N/M² | 云安全/CNAPP |
| 2025年 | Hg Capital | OneStream（企业CPM） | $6.4B | ~22.0x | N/M² | 企业绩效管理 |
| 2025年 | HPE | Juniper Networks | $13.4B | ~3.5x | ~15x | 网络基础设施 |
| 2024年3月 | Cisco | Splunk（可观测性） | $28.0B | ~6.6x | ~60.0x | 可观测性/SIEM |
| 2024年2月 | IBM | HashiCorp（多云基础设施） | $6.4B | ~11.0x | N/M² | 基础设施自动化 |
| 2024年9月 | SAP | WalkMe（数字采用） | $1.5B | ~5.8x | N/M² | 数字采用平台 |
| 2023年8月 | IBM | Apptio（云成本管理） | $4.6B | ~8.0x³ | N/M² | 云成本管理/FinOps |

Sources: CRN (2025), MergerSight (2024), PR Newswire (2026), IBM Newsroom (2023, 2024), SAP News Center (2024), TechCrunch (2023), Forbes (2024).

Notes: (1) Wiz ARR约$1B，增长率100%+，Google最初出价$23B被拒后加码至$32B； (2) N/M = 多数高增长SaaS企业EBITDA为负或极小，EV/EBITDA倍数不具参考性； (3) Apptio在IBM收购前年化收入约$575M。

### 3.2 可比交易统计摘要

| 统计指标 | EV/Revenue | EV/EBITDA |
|----------|------------|-----------|
| **平均值** | 12.7x | ~37.5x⁴ |
| **中位数** | 8.0x | ~37.5x⁴ |
| **最高值** | 32.0x | ~60.0x |
| **最低值** | 3.5x | ~15.0x |

Notes: (4) EV/EBITDA统计受Splunk极端值(60x)显著影响；对于高增长SaaS，EV/Revenue为更可靠的估值指标。

### 3.3 CloudPeak隐含估值 — 可比交易法

| 应用倍数 | ARR基准 | 低端（25th pctile） | 中位数 | 高端（75th pctile） |
|----------|---------|--------------------| -------|---------------------|
| EV/Revenue | $143M | 5.5x = $787M | 8.0x = $1,144M | 11.0x = $1,573M |

**关键假设与调整因素：**
- CloudPeak增长率28%，高于中位数交易标的的增长率 → 支持5-15%溢价
- 云管理/FinOps为战略性高优先级领域 → 与IBM/Apptio交易高度相关
- 私有公司流动性折价约15-25% → 部分抵消增长溢价
- 规模小于可比交易标的（$143M vs $500M+） → 适度折价

---

## 4. 可比上市公司分析

### 4.1 上市公司估值倍数

| 公司 | 股票代码 | 收入/FY | 增长率 | EV/Revenue | EV/EBITDA | 业务相关性 |
|------|---------|---------|--------|------------|-----------|-----------|
| Datadog | DDOG | $3.43B (FY2025) | ~26% | 14.0x | ~55x | 高 — 可观测性/云监控 |
| CrowdStrike | CRWD | $5.0B+ | 高增长 | 21.8x | ~79x | 中 — 云安全 |
| Qualys | QLYS | — | ~8.7% | 6.9x | — | 中低 — 安全合规 |
| Elastic | ESTC | $1.48B (FY2025) | 稳定 | — | — | 中 — 搜索/可观测 |

Sources: Datadog IR (2026), multiples.vc (2026), CrowdStrike IR, Seeking Alpha (2025), Artificall (2026).

Notes: (1) Datadog FY2025 Q4收入$953M，YoY增长29%； (2) CrowdStrike EV/Revenue ~21.8x，EV/EBITDA ~79.2x（multiples.vc，2026年5月）； (3) 上市公司倍数含流动性溢价，私有公司通常折价20-30%。

### 4.2 相关行业倍数参考

| 板块 | EV/Revenue中位数 | 数据来源 |
|------|-----------------|---------|
| SaaS（私有公司M&A） | 4.1-7.0x | SaaS Capital, Aventis Advisors |
| 网络安全（高增长） | 9.5x | Solganick (Q3 2024) |
| 网络安全（低增长） | 4.0x | Solganick (Q3 2024) |
| 网络安全（top-tier） | 11.9x | ICON Corporate Finance (2025) |
| B2B SaaS（整体） | 5.9x | Finerva (2026) |
| SaaS M&A（2024年中位数） | 4.1x | SaaSRise (2025) |

Sources: SaaS Capital (2025), Solganick (2024), ICON Corporate Finance (2025), Finerva (2026), SaaSRise (2025).

---

## 5. Football Field估值总结

### 估值方法论综合对比

以下"Football Field"图示汇总了各估值方法对CloudPeak Technologies的隐含企业价值范围：

```
估值方法                          低端            中点            高端
─────────────────────────────────────────────────────────────────────────

可比上市公司法                    $858M          $1,287M         $1,716M
(EV/Revenue: 6.0x - 12.0x)
                              |██████████████████████████████████████|

可比交易法                       $787M          $1,144M         $1,573M
(EV/Revenue: 5.5x - 11.0x)
                              |████████████████████████████████████|

DCF分析                          $950M          $1,350M         $1,800M
(WACC 11-13%, 终端增长率3-4%)
                              |██████████████████████████████████████|

LBO分析                          $700M          $1,000M         $1,300M
(目标IRR 20-25%, 5年退出)
                          |██████████████████████████████████|

战略价值分析                      $1,000M        $1,600M         $2,400M
(含协同效应溢价)
                              |████████████████████████████████████████████████████|

─────────────────────────────────────────────────────────────────────────
                                  $700M          $1,285M         $2,400M
```

### 估值区间汇总

| 估值方法 | 低端 | 中点 | 高端 | 关键假设 |
|----------|------|------|------|----------|
| **可比上市公司法** | $858M | $1,287M | $1,716M | EV/Revenue 6.0x-12.0x，含20-30%私有公司折价 |
| **可比交易法** | $787M | $1,144M | $1,573M | EV/Revenue 5.5x-11.0x，基于近期交易倍数 |
| **DCF分析** | $950M | $1,350M | $1,800M | WACC 11-13%，终端增长率3-4%，5年预测期 |
| **LBO分析** | $700M | $1,000M | $1,300M | 目标IRR 20-25%，5年持有期，3-5x初始杠杆 |
| **战略价值分析** | $1,000M | $1,600M | $2,400M | 含$150-300M协同效应（收入交叉销售+成本节省） |

**综合估值范围：** **$700M - $2,400M**

**重叠/高置信度区间：** **$950M - $1,573M**（6.6x - 11.0x ARR）

Sources: Wall Street Prep, Aventis Advisors (2025), SaaSRise (2026), Finerva (2026), SaaS Capital (2025).

Notes: (1) 战略价值分析包含协同效应溢价，仅在战略买家情境下适用； (2) LBO分析反映财务买家的回报要求； (3) 所有估值基于$143M ARR基准； (4) Football Field方法参考Wall Street Prep标准方法学。

---

## 6. 战略备选方案

### 方案A：战略性出售

| 维度 | 详情 |
|------|------|
| **描述** | 将CloudPeak出售给战略买家（大型云基础设施/企业软件公司） |
| **潜在买家** | IBM、Cisco、Datadog、SAP、ServiceNow、Broadcom |
| **预期估值范围** | $1,144M - $2,400M（8.0x - 16.8x ARR） |
| **溢价潜力** | 战略买家可支付20-40%协同效应溢价 |
| **时间框架** | 4-6个月 |
| **优势** | 最大化股东价值；战略买家通常出价更高；可利用当前强劲的M&A市场 |
| **风险** | 市场条件变化；监管审查（如果买家为大型科技公司）；员工保留 |

**战略依据：**
- IBM已通过收购Apptio ($4.6B)和HashiCorp ($6.4B)展示对云管理领域的战略投入
- Cisco通过收购Splunk ($28B)进入可观测性领域，云管理为自然延伸
- Google以$32B收购Wiz表明超大型云厂商对云基础设施软件的强烈兴趣

### 方案B：私募股权投资/多数出售

| 维度 | 详情 |
|------|------|
| **描述** | 向私募股权基金出售多数股权或进行take-private交易 |
| **潜在买家** | Hg Capital、Vista Equity Partners、Thoma Bravo、Insight Partners |
| **预期估值范围** | $787M - $1,300M（5.5x - 9.1x ARR） |
| **溢价潜力** | 较战略买家低，但仍有20-30%溢价空间 |
| **时间框架** | 3-5个月 |
| **优势** | 流程通常更快；监管风险较低；保持公司独立运营 |
| **风险** | 估值低于战略买家；杠杆增加财务风险；运营变更 |

**市场依据：**
- Hg Capital以$6.4B将OneStream私有化（22x Revenue），展示PE对高质量SaaS的支付意愿
- PE占2025年软件M&A的重要份额，积极执行buy-and-build策略
- 私有SaaS EV/Revenue中位数4.1-7.0x（SaaS Capital, 2025）

### 方案C：少数股权融资 + 继续独立运营

| 维度 | 详情 |
|------|------|
| **描述** | 引入成长型股权投资者，保持独立性，继续扩张 |
| **潜在投资者** | General Atlantic、ICONIQ、Tiger Global、Coatue |
| **预期估值** | $800M - $1,200M（5.6x - 8.4x ARR） |
| **时间框架** | 2-4个月 |
| **优势** | 保持独立性和灵活性；为下一阶段增长提供资金 |
| **风险** | 稀释现有股东；市场窗口可能关闭；增长需要持续大量投入 |

### 方案D：延迟决策 / 市场监测

| 维度 | 详情 |
|------|------|
| **描述** | 暂不启动正式程序，持续监测市场条件，12-18个月后重新评估 |
| **适用条件** | 如果管理层认为当前估值未充分反映增长潜力 |
| **优势** | 等待更高估值；利用市场上升趋势 |
| **风险** | M&A市场条件可能恶化；估值倍数可能收缩；错过当前窗口期 |

### 方案比较矩阵

| 评估维度 | 方案A（战略出售） | 方案B（PE） | 方案C（少数股权） | 方案D（延迟） |
|----------|-----------------|-------------|-------------------|--------------|
| 估值潜力 | ★★★★★ | ★★★★ | ★★★ | ★★★★ |
| 确定性 | ★★★ | ★★★★ | ★★★★★ | ★★ |
| 速度 | ★★★ | ★★★★ | ★★★★★ | N/A |
| 员工影响 | ★★★ | ★★★★ | ★★★★★ | ★★★★★ |
| 执行复杂度 | ★★★ | ★★★ | ★★ | ★ |

---

## 7. 推荐的流程时间表

### 方案A/B：正式出售程序 — 建议时间表

| 阶段 | 周次 | 关键活动 | 交付物 |
|------|------|---------|--------|
| **第一阶段：准备** | 第1-4周 | 财务模型完善、Teaser文件、 Confidential Information Memorandum (CIM) | Teaser、CIM、管理层数据室 |
| **第二阶段：市场接触** | 第5-8周 | 第一轮接触潜在买家、分发Teaser、签署NDA | 已签署NDA的买家名单、Teaser分发记录 |
| **第三阶段：初步报价** | 第9-12周 | 分发CIM、管理层宣讲、收集初步意向函（IOI） | IOI截止日、初步报价分析 |
| **第四阶段：深度尽调** | 第13-18周 | 第二轮尽职调查、数据室开放、客户/供应商访谈 | 尽调报告、调整后报价 |
| **第五阶段：最终谈判** | 第19-22周 | 最终报价（FO）提交、协议谈判、签署SPA | 最终报价比较、SPA草案 |
| **第六阶段：交割** | 第23-26周 | 监管审批、交割条件满足、资金到位 | 交易完成 |

**关键里程碑：**
- **第4周末：** 营销材料定稿
- **第12周末：** IOI截止，初步估值范围确定
- **第18周末：** 最终尽调完成，缩小买家范围至2-3家
- **第22周末：** 签署最终协议
- **第26周末：** 交易交割

---

## 8. 附录

### 8.1 核心假设

| 假设项 | 数值/说明 |
|--------|----------|
| CloudPeak ARR | $143M |
| 收入增长率 | 28% YoY |
| 毛利率 | 82% |
| 调整后EBITDA利润率 | 15% |
| EBITDA | $21.45M |
| 净收入留存率（NDR） | 118% |
| DCF WACC范围 | 11.0% - 13.0% |
| DCF终端增长率 | 3.0% - 4.0% |
| LBO目标IRR | 20% - 25% |
| LBO持有期 | 5年 |
| LBO初始杠杆 | 3.0x - 5.0x EBITDA |
| 私有公司流动性折价 | 20% - 30% |

### 8.2 数据来源汇总

**市场数据：**
- Grand View Research — Cloud Cost Management Market Report (2025)
- GM Insights — Cloud Cost Management Tools Market (2025)
- Credence Research — Cloud Cost Management Tools Market (2024)
- IndustryARC — Cloud Cost Management Market (2025)
- Verified Market Research — Cloud Cost Management Software Market (2023)

**SaaS估值与M&A数据：**
- SaaSRise — The SaaS M&A Report 2026
- Aventis Advisors — SaaS Valuation Multiples 2015-2025
- Finerva — B2B SaaS 2026 Valuation Multiples
- SaaS Capital — 2025 Private SaaS Company Valuations
- Software Equity Group — 2026 Annual SaaS Report
- QuantPillar — 2025-2026 Private Market Valuation Multiples
- FirstPageSage — SaaS Valuation Multiples 2025 Report
- ClearlyAcquired — EBITDA Multiples for SaaS 2025-2026

**交易数据：**
- MergerSight — IBM's $6.4B Acquisition of HashiCorp
- IBM Newsroom — IBM Acquires Apptio ($4.6B, 2023)
- IBM Newsroom — IBM Acquires HashiCorp ($6.4B, 2024)
- SAP News Center — SAP Acquires WalkMe ($1.5B, 2024)
- PR Newswire — OneStream Acquisition by Hg ($6.4B, 2026)
- TechCrunch — IBM acquires Apptio from Vista for $4.6B
- CRN — The 10 Biggest Tech M&A Deals of 2025
- S&P Global — Deal Tracker: OneStream Go-Private (2026)
- L40 — Key Tech M&A Deals of 2024-2025

**上市公司估值：**
- Datadog Investor Relations — FY2025 Financial Results
- multiples.vc — CrowdStrike Valuation Multiples (2026)
- Seeking Alpha — Qualys EV/Sales Analysis
- ICON Corporate Finance — Cybersecurity Sector Update (2025)
- Solganick — Cybersecurity M&A Update Q3 2024
- Windsor Drake — Cloud Security Valuation Report Q1 2026

**估值方法学：**
- Wall Street Prep — Football Field Valuation Chart
- Macabacus — Building a Football Field Chart in Excel

### 8.3 关键术语

| 术语 | 定义 |
|------|------|
| ARR | Annual Recurring Revenue，年度经常性收入 |
| NDR | Net Dollar Retention，净收入留存率 |
| EV | Enterprise Value，企业价值 |
| WACC | Weighted Average Cost of Capital，加权平均资本成本 |
| CAGR | Compound Annual Growth Rate，复合年增长率 |
| TAM | Total Addressable Market，总可达市场 |
| CNAPP | Cloud-Native Application Protection Platform |
| FinOps | Financial Operations for Cloud，云财务运营 |
| IOI | Indication of Interest，意向函 |
| SPA | Share Purchase Agreement，股权收购协议 |

---

> **本文件中所有数据均来源于公开信息和第三方研究机构的公开发布报告。** 未使用任何模拟或虚构数据。所有市场数据、交易倍数和财务指标均基于引用来源的实际发布值。

> **估值范围仅供讨论之用，不构成对CloudPeak Technologies实际价值的确定或保证。** 最终估值将取决于尽职调查结果、市场条件和谈判结果。

---

*编制：[投资银行名称] Technology, Media & Telecom 投资银行部*
*日期：2026年5月9日*
*分类：严格保密*

---

Sources:
- [SaaSRise — The SaaS M&A Report 2026](https://www.saasrise.com/blog/the-saas-m-a-report-2026-2)
- [Aventis Advisors — SaaS Valuation Multiples 2015-2026](https://aventis-advisors.com/saas-valuation-multiples/)
- [Finerva — B2B SaaS 2026 Valuation Multiples](https://finerva.com/report/b2b-saas-2026-valuation-multiples/)
- [Software Equity Group — 2026 Annual SaaS Report](https://softwareequity.com/research/annual-saas-report)
- [Grand View Research — Cloud Cost Management Market](https://www.grandviewresearch.com/industry-analysis/cloud-cost-management-market-report)
- [GM Insights — Cloud Cost Management Tools Market](https://www.gminsights.com/industry-analysis/cloud-cost-management-tools-market)
- [Credence Research — Cloud Cost Management Tools Market](https://www.credenceresearch.com/report/cloud-cost-management-tools-market)
- [MergerSight — IBM's $6.4B Acquisition of HashiCorp](https://www.mergersight.com/post/ibm-s-6-4bn-acquisition-of-hashicorp)
- [IBM Newsroom — IBM Acquires Apptio](https://newsroom.ibm.com/2023-08-10-IBM-Completes-Acquisition-of-Apptio-Inc)
- [IBM Newsroom — IBM Acquires HashiCorp](https://newsroom.ibm.com/2024-04-24-IBM-to-Acquire-HashiCorp-Inc-Creating-a-Comprehensive-End-to-End-Hybrid-Cloud-Platform)
- [SAP News Center — SAP Acquires WalkMe](https://news.sap.com/2024/09/sap-completes-walkme-acquisition/)
- [PR Newswire — OneStream Acquisition by Hg](https://www.prnewswire.com/news-releases/onestream-announces-completion-of-acquisition-by-hg-for-6-4-billion-302731460.html)
- [TechCrunch — IBM acquires Apptio from Vista for $4.6B](https://techcrunch.com/2023/06/26/ibm-acquires-apptio-from-vista-for-4-6b-in-cash-to-double-down-on-hybrid-cloud-services/)
- [CRN — 10 Biggest Tech M&A Deals of 2025](https://www.crn.com/news/channel-news/2025/the-10-biggest-tech-m-a-deals-of-2025-so-far)
- [S&P Global — OneStream Go-Private Deal](https://www.spglobal.com/market-intelligence/en/news-insights/articles/2026/2/deal-tracker-onestream-s-6-4b-go-private-deal-leads-it-m-a-in-january-97972688)
- [Datadog Investor Relations — FY2025 Results](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-fourth-quarter-and-fiscal-year-2025-financial)
- [multiples.vc — CrowdStrike Valuation Multiples](https://multiples.vc/public-comps/crowdstrike-valuation-multiples)
- [SaaS Capital — 2025 Private SaaS Valuations](https://www.saas-capital.com/blog-posts/private-saas-company-valuations-multiples/)
- [Wall Street Prep — Football Field Valuation](https://www.wallstreetprep.com/knowledge/football-field-valuation-real-example-excel-template/)
- [SaaS Mag — SaaS Consolidation Wave 2026](https://www.saasmag.com/saas-consolidation-ma-wave-2026/)
- [Fortune — Enterprise SaaS M&A Q1 2025](https://fortune.com/2025/06/17/in-q1-2025-enterprise-saas-ma-deal-count-hit-210-according-to-pitchbook/)
- [M&A Advisor — Software M&A Dominates 2025](https://maadvisor.com/maalerts/software-ma-dominates-2025-with-65-market-share/)
- [ClearlyAcquired — EBITDA Multiples SaaS 2025-2026](https://www.clearlyacquired.com/blog/ebitda-multiples-for-saas-and-software-companies-2025-2026)
