[DATA SOURCE: Web Search — Apple Newsroom, CNBC, MacRumors, Seeking Alpha, Yahoo Finance, Forbes, Counterpoint Research, TechCrunch, Computerworld, Motley Fool, TipRanks, Benzinga, TickerNerd, Alpha Spread, Wedbush, Morgan Stanley, BofA Securities, Capital.com, CompaniesMarketCap.com, Morningstar, Statcounter, Macrotrends, Stock Titan, Shacknews, Sahm Capital]

# Apple (AAPL) 投资论点追踪报告

**报告日期:** 2026年5月10日
**分析师:** AI Research Desk
**股票代码:** AAPL (NASDAQ)
**当前股价:** ~$293.32 (截至2026年5月8日, Morningstar)
**市值:** ~$4.35万亿 (截至2026年5月9日, Capital.com)
**P/E (TTM):** ~35.48x

---

## 一、论点定义 (Thesis Definition)

### 基本信息

| 项目 | 内容 |
|------|------|
| **公司** | Apple Inc. (AAPL) |
| **持仓方向** | Long (做多) |
| **核心论点** | Long AAPL — iPhone 17超级升级周期 + Services高利润增长引擎 + Apple Intelligence/AI生态布局推动收入增长和利润率扩张，目标受益于AI驱动的设备换代与平台货币化 |
| **当前信心度** | **高** (High) |

### 核心支柱 (Key Pillars)

1. **iPhone 17超级升级周期**: 全球安装基数老化的设备进入换代窗口，iPhone 17系列成为2026年Q1全球最畅销手机
2. **Services高利润增长引擎**: Services收入持续双位数增长(16.3% YoY)，毛利率高达76.7%，贡献利润率扩张
3. **AI生态布局与Siri 2.0**: WWDC 2026即将推出iOS 27和Siri 2.0，开放第三方AI模型集成，差异化隐私策略
4. **资本回报增强**: 新增$1000亿回购授权，股息提升4%至$0.27/股，十年累计回报$8470亿
5. **利润率持续扩张**: 整体毛利率达到~49%，受益于Services收入占比提升的结构性改善

### 关键风险 (Key Risks)

1. **中国市场竞争加剧**: 华为在中国市场以20%份额领先，本土品牌忠诚度上升威胁Apple中国收入
2. **监管压力**: EU DMA合规要求开放第三方应用商店，反垄断审查持续
3. **估值过高风险**: P/E ~35.48x处于历史高位，市场已price in大量乐观预期
4. **供应链约束**: Q2财报中提及持续存在的供应限制可能影响产量
5. **AI执行风险**: Siri 2.0和Apple Intelligence的实际用户体验和开发者采用率存在不确定性

### 目标价格与退出触发

| 项目 | 内容 |
|------|------|
| **目标价格** | $310–$325 (基于分析师中位数); Wedbush目标$350–$400 |
| **止损/退出触发** | iPhone出货量连续两季度低于预期; Services增长降至个位数; 中国市场份额持续流失 |

---

## 二、更新日志 (Update Log)

| 日期 | 数据点 | 论点影响 | 行动 | 信心度 |
|------|--------|---------|------|--------|
| 2026-01-29 | Q1 FY2026收入$1438亿(+16% YoY), EPS $2.84(+19%) | 强化支柱1&2 | 维持 | 高 |
| 2026-04-16 | Q1 2026全球智能手机市场份额Apple以21%领先Samsung的20% (Counterpoint) | 强化支柱1 | 维持 | 高 |
| 2026-04-30 | Q2 FY2026收入$1112亿(+17% YoY), 创Q2历史纪录 | 强化支柱1&2 | 维持 | 高 |
| 2026-04-30 | Q2 Services收入$309.8亿(+16.3% YoY), 超华尔街预期$304亿 | 强化支柱2 | 维持 | 高 |
| 2026-04-30 | 毛利率~49%扩张，Services GM 76.7% | 强化支柱5 | 维持 | 高 |
| 2026-04-30 | 新增$1000亿回购授权，股息提升4%至$0.27 | 强化支柱4 | 维持 | 高 |
| 2026-05-05 | Bloomberg报道iOS 27将支持用户选择第三方LLM驱动Siri | 强化支柱3 | 维持 | 高 |
| 2026-05-08 | Wedbush维持$350目标价（最高$400），称iPhone 17周期"好于预期" | 强化整体 | 维持 | 高 |
| 2026-05-09 | 股价~$293，市值$4.35万亿，仍低于分析师平均目标$305–$313 | 中性 | 维持 | 高 |

---

## 三、论点记分卡 (Thesis Scorecard)

| 支柱 | 原始预期 | 当前状态 | 趋势 |
|------|---------|---------|------|
| **iPhone 17超级升级周期** | FY2026出货230M+台 | Q1 iPhone 17系列成全球最畅销，分析师预计240–250M台 | ✅ 超预期 |
| **Services双位数增长** | YoY +12–15% | Q1 +14%, Q2 +16.3%, H1 +15% | ✅ 超预期 |
| **Services毛利率扩张** | 维持75%+ | Q2达76.7% (+20bps QoQ) | ✅ 稳定/改善 |
| **整体毛利率提升** | 47–48% | Q2达~49%，Q3指引47.5–48.5% | ✅ 超预期 |
| **AI/Siri 2.0推出** | WWDC 2026发布 | 6月8日确认，第三方LLM集成+系统级Siri重构 | ⏳ 待验证 |
| **资本回报** | 持续大规模回购 | 新增$1000亿授权，季度回购~$200–250亿 | ✅ 符合预期 |
| **中国市场份额** | 维持竞争力 | 华为以20%份额领先中国，Apple紧随其后 | ⚠️ 关注 |
| **估值合理性** | P/E 30–35x可接受 | 当前P/E ~35.48x，接近区间上沿 | ⚠️ 关注 |

---

## 四、关键财务数据摘要 (Key Financial Data)

### 收入与盈利趋势

| 指标 | Q1 FY2026 (Dec 2025) | Q2 FY2026 (Mar 2026) | H1 FY2026 |
|------|---------------------|---------------------|-----------|
| **总收入** | $1438亿 | $1112亿 | $2549亿 |
| **YoY增长** | +16% | +17% | +16% |
| **净利润** | $421亿 | $296亿 | — |
| **EPS (稀释)** | $2.84 | $2.01 | — |
| **EPS增长** | +19% | +22% | — |

### 分部收入 (Q2 FY2026)

| 业务部门 | Q2收入 | YoY变化 |
|---------|--------|---------|
| **iPhone** | $569.9亿 | 核心增长驱动 |
| **Services** | $309.8亿 | +16.3% |
| **Mac** | $84亿 | — |
| **iPad** | $69.1亿 | — |

### 利润率结构

| 指标 | Q2 FY2026 | Q3指引 |
|------|----------|--------|
| **整体毛利率** | ~49% | 47.5–48.5% |
| **产品毛利率** | 38.7% | — |
| **Services毛利率** | 76.7% | — |

### TTM数据 (截至2026年3月31日)

| 指标 | 数值 |
|------|------|
| **TTM收入** | $4514亿 (+12.76% YoY) |
| **FY2025年收入** | $4162亿 |

---

## 五、催化剂日历 (Catalyst Calendar)

| 日期 | 事件 | 预期影响 | 备注 |
|------|------|---------|------|
| 2026-05-14 | 股息派发 ($0.27/股) | 低 — 常规回报 | 股息提升4% |
| 2026-06-08–12 | **WWDC 2026** | **高** — iOS 27 + Siri 2.0发布 | Apple Park, 第三方LLM集成，开发者工具更新 |
| 2026-07月 | Q3 FY2026财报 | 高 — 检验iPhone 17持续动力 | 指引收入+14–17% YoY |
| 2026-09月 | iPhone 18系列发布(预期) | 高 — 下一代产品周期 | iOS 27公版发布预计9月14日前后 |
| 2026-10月 | Q4 FY2026财报 / FY2026全年 | 高 — 全年业绩总结 | — |
| 2026-11月 | 2027财年展望/指引 | 中高 — 市场关注AI货币化时间表 | — |

---

## 六、竞争格局 (Competitive Landscape)

### 全球智能手机市场份额 (Q1 2026)

| 品牌 | 市场份额 | YoY变化 | 对Apple的影响 |
|------|---------|---------|-------------|
| **Apple** | 21% (Counterpoint) | 正增长，唯一增长的主要品牌 | 领先地位 |
| **Samsung** | 20–21.7% (IDC) | +3.6% (IDC) | 接近追赶，全价格段竞争 |
| **Huawei** | ~20% (中国市场) | 5年高点 | **中国市场的重大威胁** |
| **Xiaomi** | ~8.7% | 新兴市场增长 | 间接竞争 |

### 关键竞争观察

- Apple在Q1 2026成为全球最大智能手机厂商(按Counterpoint口径)
- 但Samsung在出货量维度差距极小(IDC口径仅差0.6%)
- **华为在中国市场以1390万台出货、20%份额领先，为5年新高**，这是Apple中国战略的最大风险
- Apple在Statcounter全球移动设备使用份额中达32.55%，远超Samsung的19.11%

---

## 七、华尔街分析师共识 (Street Consensus)

### 评级分布

| 来源 | 评级 | 分析师数量 | 买入 | 持有 | 卖出 |
|------|------|-----------|------|------|------|
| Public.com | Buy | 28 | — | — | — |
| TipRanks | — | 85 | 59 | 22 | 4 |
| Yahoo Finance (BofA) | Moderate Buy | 23 | 14 | 8 | 1 |
| Investing.com | Buy | 42 | 31 | 15 | 2 |

### 目标价格

| 来源 | 共识目标价 | 价格区间 |
|------|-----------|---------|
| Benzinga (30位分析师) | $304.16 | $215–$400 |
| TipRanks | $312.60 | — |
| TickerNerd (78位中位数) | $310.00 | $215–$355 |
| Public.com (2026预测) | $297.02 | — |
| BofA Securities | $325.00 | — |
| **Wedbush (最看多)** | **$350–$400** | — |

**隐含上行空间:** 基于当前股价~$293，共识目标$305–$313隐含约**4–7%上行空间**。

---

## 八、资本回报分析 (Capital Return)

| 指标 | 详情 |
|------|------|
| **2026年新增回购授权** | $1000亿 |
| **季度回购节奏** | ~$200–250亿/季度 |
| **季度股息** | $0.27/股 (2026年4月提升4%) |
| **股息派发日** | 2026年5月14日 |
| **过去十年累计股东回报** | ~$8470亿 |
| **2025年回购** | $1100亿授权 |
| **2024年回购** | $1000亿授权 |

---

## 九、论点完整性评估 (Thesis Integrity Assessment)

### 论点是否仍然成立？

**是的，论点依然稳固且正在被验证。**

- iPhone 17升级周期"好于预期"(Morgan Stanley原话)，出货量有望达240–250M台
- Services引擎持续超预期，Q2收入$309.8亿(vs预期$304亿)，毛利率76.7%仍在扩张
- 毛利率结构性改善趋势明确，整体GM ~49%为近年高位
- AI催化剂尚未完全释放 — WWDC 2026(6月8日)将是Siri 2.0和iOS 27的关键验证点
- 资本回报力度不减，$1000亿新回购+4%股息提升

### 需要警惕的信号

1. **中国市场**: 华为Q1以20%份额领先中国，Apple面临本土品牌复兴压力
2. **估值高位**: P/E ~35.48x，市场已对乐观情景给予大量溢价
3. **AI执行**: Siri 2.0的实际体验能否匹敌竞争产品尚待验证
4. **供应链**: 公司在Q2财报中提及持续供应约束，可能限制上行空间

### 可证伪性检查 (Falsifiability Check)

以下任一情况出现将证伪本论点：
- iPhone FY2026出货低于220M台(当前预期240–250M)
- Services增长连续两季度降至10%以下
- 毛利率回落至45%以下且非一次性因素
- Siri 2.0/Apple Intelligence用户满意度或开发者采用率显著低于预期
- 中国市场收入连续两个半年度同比下降

---

## 十、投资行动建议 (Recommended Action)

| 项目 | 建议 |
|------|------|
| **当前行动** | **维持持仓 (Hold Position)** |
| **加仓条件** | WWDC后Siri 2.0获得积极反馈且股价回调至$270以下 |
| **减仓条件** | Q3收入增长低于10%或中国收入持续下滑 |
| **退出条件** | 上述可证伪条件触发任意两条 |

### 下次审查时间: 2026年7月 (Q3 FY2026财报发布后)

---

## Sources

- [Apple Newsroom - Q2 FY2026 Results](https://www.apple.com/newsroom/2026/04/apple-reports-second-quarter-results/)
- [Apple Newsroom - Q1 FY2026 Results](https://www.apple.com/newsroom/2026/01/apple-reports-first-quarter-results/)
- [CNBC - AAPL Q2 2026 Earnings](https://www.cnbc.com/2026/04/30/apple-aapl-q2-2026-earnings-report.html)
- [MacRumors - Apple Q2 2026 Earnings](https://www.macrumors.com/2026/04/30/apple-2q-2026-earnings/)
- [Seeking Alpha - Apple iPhone and Services Drive Growth](https://seekingalpha.com/article/4898874-apple-iphone-and-services-drive-growth-but-margin-and-supply-risks-loom)
- [Forbes - Apple Now Largest Smartphone Maker](https://www.forbes.com/sites/johnkoetsier/2026/04/16/apple-now-largest-smartphone-maker-also-samsung-now-largest/)
- [Counterpoint Research - Global Smartphone Shipments Q1 2026](https://counterpointresearch.com/en/insights/global-smartphone-shipments-q1-2026)
- [TechCrunch - Apple iOS 27 AI Models](https://techcrunch.com/2026/05/05/apple-plans-to-make-ios-27-a-choose-your-own-adventure-of-ai-models/)
- [Computerworld - WWDC 2026 AI Leap](https://www.computerworld.com/article/4168225/wwdc-2026-how-apple-can-take-a-great-leap-in-ai.html)
- [Motley Fool - Apple AI Strategy Pivot](https://www.fool.com/investing/2026/04/02/apple-ai-strategy-pivot-great-news-stock/)
- [MacRumors - Apple AI Strategy Pay Off in 2026](https://www.macrumors.com/2025/12/30/apple-ai-strategy-could-pay-off-in-2026/)
- [Tom's Guide - WWDC 2026 Preview](https://www.tomsguide.com/phones/iphones/wwdc-2026)
- [CNET - iPhone 17 Best Selling Q1 2026](https://www.cnet.com/tech/mobile/apples-iphone-17-is-the-best-selling-phone-for-the-first-quarter-of-2026/)
- [Capital.com - Apple Market Cap](https://capital.com/en-int/markets/shares/apple-inc-share-price/market-cap)
- [CompaniesMarketCap.com - Apple](https://companiesmarketcap.com/apple/marketcap/)
- [Yahoo Finance - AAPL](https://finance.yahoo.com/quote/AAPL/history/)
- [Morningstar - AAPL](https://www.morningstar.com/stocks/xnas/aapl/quote)
- [Alpha Spread - AAPL Q2 2026 Earnings Call](https://www.alphaspread.com/security/nasdaq/aapl/investor-relations/earnings-call/q2-2026)
- [Stock Titan - Apple Q2 2026 Revenue](https://www.stocktitan.net/sec-filings/AAPL/10-q-apple-inc-quarterly-earnings-report-8c3913d3d431.html)
- [MLQ.ai - AAPL Q2 2026 Earnings](https://mlq.ai/stocks/AAPL/q2-2026-earnings/)
- [Macrotrends - Apple Revenue](https://www.macrotrends.net/stocks/charts/AAPL/apple/revenue)
- [Shacknews - Apple $100B Buyback](https://www.shacknews.com/article/148945/apple-aapl-100-billion-share-buyback-q2-2026)
- [Sahm Capital - Apple Buyback and Dividend](https://www.sahmcapital.com/news/content/apple-authorizes-up-to-100b-share-buyback-boosts-dividend-from-026-to-027-per-share-2026-04-30)
- [Forbes - Apple $850B Return](https://www.forbes.com/sites/greatspeculations/2026/01/21/apple-beats-every-other-stock-with-850-billion-return/)
- [TipRanks - AAPL Forecast](https://www.tipranks.com/stocks/aapl/forecast)
- [Public.com - AAPL Forecast](https://public.com/stocks/aapl/forecast-price-target)
- [Statcounter - Mobile Vendor Market Share](https://gs.statcounter.com/vendor-market-share/mobile)
- [Variety - Apple Services Revenue Q2 2026](https://variety.com/2026/digital/news/apple-earnings-march-2026-quarter-services-revenue-1236734606/)
- [HeyGoTrade - Apple $100B Buyback Playbook](https://www.heygotrade.com/en/blog/apple-100b-buyback-capital-return-playbook/)
