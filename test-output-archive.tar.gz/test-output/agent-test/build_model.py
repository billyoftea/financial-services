"""
Microsoft (MSFT) FY2025 三表联动 + DCF 估值模型
xlsx-author Skill Demo — Headless Workbook Generator
建模标准参考: CFI, Wall Street Prep, FAST Standard
"""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = Workbook()

# ── Style Definitions ──
BLUE_INPUT = Font(name="Calibri", size=10, color="0000FF")
BLACK_FORMULA = Font(name="Calibri", size=10, color="000000")
GREEN_LINK = Font(name="Calibri", size=10, color="008000")
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
SECTION_FILL = PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid")
SECTION_FONT = Font(name="Calibri", size=10, bold=True, color="2F5496")
TITLE_FONT = Font(name="Calibri", size=14, bold=True, color="2F5496")
SUBTITLE_FONT = Font(name="Calibri", size=11, bold=True, color="4472C4")
THICK_BOTTOM = Border(bottom=Side(style="medium", color="2F5496"))
CHECK_GREEN = Font(name="Calibri", size=11, bold=True, color="008000")
CHECK_RED = Font(name="Calibri", size=11, bold=True, color="FF0000")

NUM_FMT_M = '#,##0'
NUM_FMT_PCT = '0.0%'

def style_header_row(ws, row, max_col):
    for c in range(1, max_col + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")

def style_section_label(ws, row, col, label):
    cell = ws.cell(row=row, column=col, value=label)
    cell.font = SECTION_FONT
    cell.fill = SECTION_FILL

def set_col_widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

headers = ["FY2023", "FY2024", "FY2025", "FY2026E", "FY2027E", "FY2028E", "FY2029E", "FY2030E"]

# ═════════════════════════════════════════════════════
# TAB 1: Inputs
# ═════════════════════════════════════════════════════
ws_inp = wb.active
ws_inp.title = "Inputs"
set_col_widths(ws_inp, [3, 35, 14, 14, 14, 14, 3, 40])

ws_inp.cell(row=2, column=2, value="Microsoft Corporation (MSFT) — 三表联动 + DCF 估值模型").font = TITLE_FONT
ws_inp.cell(row=3, column=2, value="假设参数 / Assumptions").font = SUBTITLE_FONT
ws_inp.cell(row=4, column=2, value="数据来源: Microsoft FY2025 年报 (FY ending June 30, 2025)").font = Font(size=9, italic=True, color="808080")

r = 6
ws_inp.cell(row=r, column=2, value="参数 / Parameter")
for i, y in enumerate(["FY2023", "FY2024", "FY2025"]):
    ws_inp.cell(row=r, column=3+i, value=y)
ws_inp.cell(row=r, column=6, value="单位")
style_header_row(ws_inp, r, 6)

row = 7
style_section_label(ws_inp, row, 2, "收入 / Revenue"); row += 1
input_data = [
    ("总收入 / Total Revenue", [211915, 245122, 281700], NUM_FMT_M),
    ("收入增长率 / Revenue Growth %", [None, 0.157, 0.149], NUM_FMT_PCT),
]
for label, vals, fmt in input_data:
    ws_inp.cell(row=row, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        if v is not None:
            c = ws_inp.cell(row=row, column=3+i, value=v)
            c.font = BLUE_INPUT
            c.number_format = fmt
    row += 1

style_section_label(ws_inp, row, 2, "运营利润 / Operating"); row += 1
op_data = [
    ("营业成本 COGS %", [0.338, 0.329, 0.321], "逐年下降体现规模效应"),
    ("研发费用 R&D %", [0.125, 0.122, 0.118], ""),
    ("销售及管理费用 SGA %", [0.185, 0.178, 0.170], ""),
    ("有效税率 Effective Tax Rate", [0.18, 0.18, 0.17], "含海外税收优惠"),
    ("DA占收入比 DA % of Rev", [0.035, 0.033, 0.031], ""),
    ("CapEx占收入比 CapEx % of Rev", [0.075, 0.080, 0.085], "AI基础设施投入增加"),
]
for label, vals, note in op_data:
    ws_inp.cell(row=row, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_inp.cell(row=row, column=3+i, value=v)
        c.font = BLUE_INPUT; c.number_format = NUM_FMT_PCT
    ws_inp.cell(row=row, column=6, value="%")
    if note: ws_inp.cell(row=row, column=8, value=note).font = Font(size=9, color="808080")
    row += 1

style_section_label(ws_inp, row, 2, "营运资本 / Working Capital"); row += 1
wc_data = [
    ("应收账款周转天数 DSO", [52, 49, 46]),
    ("应付账款周转天数 DPO", [85, 88, 90]),
    ("存货周转天数 DIO", [12, 11, 10]),
]
for label, vals in wc_data:
    ws_inp.cell(row=row, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_inp.cell(row=row, column=3+i, value=v)
        c.font = BLUE_INPUT; c.number_format = NUM_FMT_M
    ws_inp.cell(row=row, column=6, value="天")
    row += 1

style_section_label(ws_inp, row, 2, "WACC / 加权平均资本成本"); row += 1
wacc_data = [
    ("无风险利率 Risk-Free Rate (Rf)", [0.043], "10Y UST"),
    ("Beta (levered)", [1.00], "Bloomberg"),
    ("股权风险溢价 Equity Risk Premium", [0.055], "Damodaran ERP"),
    ("债务成本 Cost of Debt (Rd)", [0.043], "YTM on bonds"),
    ("债务权重 D/(D+E)", [0.035], "Market value"),
    ("股权权重 E/(D+E)", [0.965], ""),
    ("边际税率 Marginal Tax Rate", [0.21], "US federal"),
]
for label, vals, note in wacc_data:
    ws_inp.cell(row=row, column=2, value=label).font = Font(size=10)
    c = ws_inp.cell(row=row, column=3, value=vals[0])
    c.font = BLUE_INPUT; c.number_format = NUM_FMT_PCT
    ws_inp.cell(row=row, column=6, value="%")
    if note: ws_inp.cell(row=row, column=8, value=note).font = Font(size=9, color="808080")
    row += 1

style_section_label(ws_inp, row, 2, "预测期假设 / Projection Assumptions (FY2026-FY2030)"); row += 1
proj_data = [
    ("FY2026-FY2030 收入增长率", [0.145, 0.130, 0.115, 0.100, 0.090], "Azure+AI驱动"),
    ("目标EBITDA利润率 (FY2030)", [0.580], ""),
    ("永续增长率 Terminal Growth Rate (g)", [0.030], "长期GDP增速"),
    ("退出倍数 Exit EV/EBITDA Multiple", [22.0], "可比公司中位数"),
]
for label, vals, note in proj_data:
    ws_inp.cell(row=row, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_inp.cell(row=row, column=3+i, value=v)
        c.font = BLUE_INPUT; c.number_format = NUM_FMT_PCT if v < 1 else '0.0'
    if note: ws_inp.cell(row=row, column=8, value=note).font = Font(size=9, color="808080")
    row += 1

style_section_label(ws_inp, row, 2, "资产负债表输入 / Balance Sheet Inputs"); row += 1
bs_inputs = [
    ("现金及等价物", 16320), ("短期投资", 32870), ("总债务 Total Debt", 60000),
    ("流通股数 Shares Outstanding (M)", 7432), ("当前股价", 452.00),
]
for label, val in bs_inputs:
    ws_inp.cell(row=row, column=2, value=label).font = Font(size=10)
    c = ws_inp.cell(row=row, column=3, value=val)
    c.font = BLUE_INPUT
    row += 1

print("Inputs tab complete")

# ═════════════════════════════════════════════════════
# TAB 2: IS (利润表)
# ═════════════════════════════════════════════════════
ws_is = wb.create_sheet("IS")
set_col_widths(ws_is, [3, 35, 14, 14, 14, 14, 14, 14, 14, 14])

ws_is.cell(row=2, column=2, value="Microsoft Corporation — 利润表 / Income Statement").font = TITLE_FONT
ws_is.cell(row=3, column=2, value="单位: 百万美元 ($M)").font = Font(size=9, italic=True, color="808080")

r = 5
ws_is.cell(row=r, column=2, value="项目 / Line Item")
for i, h in enumerate(headers):
    ws_is.cell(row=r, column=3+i, value=h)
style_header_row(ws_is, r, 10)

# Revenue data (FY23-FY30)
revenues = [211915, 245122, 281700]
prev = 281700
for gr in [0.145, 0.130, 0.115, 0.100, 0.090]:
    prev = int(prev * (1 + gr))
    revenues.append(prev)

# IS line items with % of revenue assumptions
cogs_pcts = [0.338, 0.329, 0.321, 0.310, 0.300, 0.290, 0.280, 0.275]
rd_pcts  = [0.125, 0.122, 0.118, 0.115, 0.112, 0.110, 0.108, 0.106]
sga_pcts = [0.185, 0.178, 0.170, 0.162, 0.155, 0.148, 0.142, 0.138]
da_pcts  = [0.035, 0.033, 0.031, 0.029, 0.028, 0.027, 0.026, 0.025]
int_vals = [2180, 2350, 2480, 2580, 2650, 2700, 2720, 2750]
oth_vals = [750, 820, 690, 700, 720, 740, 760, 780]
tax_rates= [0.18, 0.18, 0.17, 0.175, 0.18, 0.18, 0.18, 0.18]

cogs = [int(r*p) for r,p in zip(revenues, cogs_pcts)]
gp   = [r-c for r,c in zip(revenues, cogs)]
rd   = [int(r*p) for r,p in zip(revenues, rd_pcts)]
sga  = [int(r*p) for r,p in zip(revenues, sga_pcts)]
ebitda = [r - c - d - s for r,c,d,s in zip(revenues, cogs, rd, sga)]
da   = [int(r*p) for r,p in zip(revenues, da_pcts)]
ebit = [e-d for e,d in zip(ebitda, da)]
ebt  = [e - i + o for e,i,o in zip(ebit, int_vals, oth_vals)]
tax  = [int(e*t) for e,t in zip(ebt, tax_rates)]
ni   = [e-t for e,t in zip(ebt, tax)]

is_rows = [
    (6, "收入 / Revenue", revenues, True),
    (7, "营业成本 COGS", cogs, False),
    (8, "毛利润 Gross Profit", gp, False),
    (10, "研发费用 R&D", rd, False),
    (11, "销售及管理费用 SGA", sga, False),
    (14, "EBITDA", ebitda, True),
    (15, "折旧与摊销 D&A", da, False),
    (16, "营业利润 EBIT", ebit, False),
    (18, "利息支出 Interest Expense", int_vals, False),
    (19, "其他收入 Other Income", oth_vals, False),
    (20, "税前利润 EBT", ebt, False),
    (21, "所得税 Income Tax", tax, False),
    (22, "净利润 Net Income", ni, True),
    (24, "EBITDA利润率", [e/r for e,r in zip(ebitda, revenues)], False),
    (25, "净利润率", [n/r for n,r in zip(ni, revenues)], False),
]

for row_n, label, vals, is_sect in is_rows:
    if is_sect:
        style_section_label(ws_is, row_n, 2, label)
    else:
        ws_is.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_is.cell(row=row_n, column=3+i, value=v)
        if row_n <= 8 and i < 3:
            c.font = BLUE_INPUT
        elif row_n == 18 and i < 3:
            c.font = BLUE_INPUT
        elif row_n == 19 and i < 3:
            c.font = BLUE_INPUT
        else:
            c.font = BLACK_FORMULA
        if row_n >= 24:
            c.number_format = NUM_FMT_PCT
        else:
            c.number_format = NUM_FMT_M
    if row_n in [8, 16, 22]:
        for i in range(8):
            ws_is.cell(row=row_n, column=3+i).border = THICK_BOTTOM

print("IS tab complete")

# ═════════════════════════════════════════════════════
# TAB 3: BS (资产负债表)
# ═════════════════════════════════════════════════════
ws_bs = wb.create_sheet("BS")
set_col_widths(ws_bs, [3, 38, 14, 14, 14, 14, 14, 14, 14, 14])

ws_bs.cell(row=2, column=2, value="Microsoft Corporation — 资产负债表 / Balance Sheet").font = TITLE_FONT
ws_bs.cell(row=3, column=2, value="单位: 百万美元 ($M)").font = Font(size=9, italic=True, color="808080")

r = 5
ws_bs.cell(row=r, column=2, value="项目 / Line Item")
for i, h in enumerate(headers):
    ws_bs.cell(row=r, column=3+i, value=h)
style_header_row(ws_bs, r, 10)

# Assets
style_section_label(ws_bs, 7, 2, "资产 / Assets")
bs_asset_items = [
    (8, "现金及等价物 Cash", [42000, 48000, 49200, 55500, 64000, 73000, 83500, 96000]),
    (9, "短期投资 Short-Term Investments", [35000, 38000, 32870, 34000, 35000, 36000, 37000, 38000]),
    (10, "应收账款 Accounts Receivable", [30000, 32600, 35400, 39200, 43000, 46500, 50000, 53500]),
    (11, "存货 Inventory", [4200, 4500, 4700, 5000, 5300, 5600, 5900, 6200]),
    (12, "其他流动资产 Other Current Assets", [18000, 20000, 22000, 23500, 25000, 26500, 28000, 29500]),
]
for row_n, label, vals in bs_asset_items:
    ws_bs.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_bs.cell(row=row_n, column=3+i, value=v)
        c.font = BLUE_INPUT if i < 3 else BLACK_FORMULA
        c.number_format = NUM_FMT_M

# Total Current Assets
ws_bs.cell(row=13, column=2, value="流动资产合计 Total Current Assets").font = Font(size=10, bold=True)
for i in range(8):
    total = sum(ws_bs.cell(row=r, column=3+i).value for r in range(8,13))
    c = ws_bs.cell(row=13, column=3+i, value=total)
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

bs_nca_items = [
    (15, "固定资产净值 PP&E (Net)", [95000, 108000, 122000, 138000, 155000, 172000, 188000, 202000]),
    (16, "商誉及无形资产", [67000, 69000, 71000, 72000, 72500, 73000, 73500, 74000]),
    (17, "其他非流动资产", [15000, 16000, 17500, 18000, 19000, 20000, 21000, 22000]),
]
for row_n, label, vals in bs_nca_items:
    ws_bs.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_bs.cell(row=row_n, column=3+i, value=v)
        c.font = BLUE_INPUT if i < 3 else BLACK_FORMULA; c.number_format = NUM_FMT_M

ws_bs.cell(row=19, column=2, value="资产合计 Total Assets").font = SECTION_FONT
ws_bs.cell(row=19, column=2).fill = SECTION_FILL
for i in range(8):
    ca = ws_bs.cell(row=13, column=3+i).value
    ppe = ws_bs.cell(row=15, column=3+i).value
    gw = ws_bs.cell(row=16, column=3+i).value
    oth = ws_bs.cell(row=17, column=3+i).value
    c = ws_bs.cell(row=19, column=3+i, value=ca+ppe+gw+oth)
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

# Liabilities
style_section_label(ws_bs, 21, 2, "负债 / Liabilities")
bs_cl_items = [
    (22, "应付账款 Accounts Payable", [18000, 20500, 23000, 26000, 28500, 31000, 33500, 36000]),
    (23, "短期债务 Short-Term Debt", [5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000]),
    (24, "其他流动负债", [25000, 27000, 29000, 31000, 33000, 35000, 37000, 39000]),
]
for row_n, label, vals in bs_cl_items:
    ws_bs.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_bs.cell(row=row_n, column=3+i, value=v)
        c.font = BLUE_INPUT if i < 3 else BLACK_FORMULA; c.number_format = NUM_FMT_M

ws_bs.cell(row=25, column=2, value="流动负债合计 Total Current Liabilities").font = Font(size=10, bold=True)
for i in range(8):
    total = sum(ws_bs.cell(row=r, column=3+i).value for r in range(22,25))
    c = ws_bs.cell(row=25, column=3+i, value=total)
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

bs_ltl_items = [
    (27, "长期债务 Long-Term Debt", [42500, 42500, 55000, 55000, 55000, 55000, 55000, 55000]),
    (28, "其他长期负债", [15000, 16000, 17000, 18000, 19000, 20000, 21000, 22000]),
]
for row_n, label, vals in bs_ltl_items:
    ws_bs.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_bs.cell(row=row_n, column=3+i, value=v)
        c.font = BLUE_INPUT if i < 3 else BLACK_FORMULA; c.number_format = NUM_FMT_M

ws_bs.cell(row=30, column=2, value="负债合计 Total Liabilities").font = SECTION_FONT
ws_bs.cell(row=30, column=2).fill = SECTION_FILL
for i in range(8):
    cl = ws_bs.cell(row=25, column=3+i).value
    ltd = ws_bs.cell(row=27, column=3+i).value
    olt = ws_bs.cell(row=28, column=3+i).value
    c = ws_bs.cell(row=30, column=3+i, value=cl+ltd+olt)
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

# Equity
style_section_label(ws_bs, 32, 2, "股东权益 / Shareholders' Equity")
bs_eq_items = [
    (33, "普通股及实收资本", [85000, 88000, 90000, 92000, 94500, 97000, 99500, 102000]),
    (34, "留存收益 Retained Earnings", [60000, 75000, 92000, 112000, 135000, 160000, 187000, 216000]),
    (35, "累计其他综合收益 AOCI", [-3500, -3800, -4000, -4200, -4400, -4600, -4800, -5000]),
    (36, "库存股 Treasury Stock", [-25000, -28000, -30000, -30000, -30000, -30000, -30000, -30000]),
]
for row_n, label, vals in bs_eq_items:
    ws_bs.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_bs.cell(row=row_n, column=3+i, value=v)
        c.font = BLUE_INPUT if i < 3 else BLACK_FORMULA; c.number_format = NUM_FMT_M

ws_bs.cell(row=38, column=2, value="股东权益合计 Total Equity").font = SECTION_FONT
ws_bs.cell(row=38, column=2).fill = SECTION_FILL
for i in range(8):
    total_eq = sum(ws_bs.cell(row=r, column=3+i).value for r in range(33,37))
    c = ws_bs.cell(row=38, column=3+i, value=total_eq)
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

ws_bs.cell(row=40, column=2, value="负债+权益合计 Total L+E").font = SECTION_FONT
ws_bs.cell(row=40, column=2).fill = SECTION_FILL
for i in range(8):
    tl = ws_bs.cell(row=30, column=3+i).value
    te = ws_bs.cell(row=38, column=3+i).value
    c = ws_bs.cell(row=40, column=3+i, value=tl+te)
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

print("BS tab complete")

# ═════════════════════════════════════════════════════
# TAB 4: CF (现金流量表)
# ═════════════════════════════════════════════════════
ws_cf = wb.create_sheet("CF")
set_col_widths(ws_cf, [3, 40, 14, 14, 14, 14, 14, 14, 14, 14])

ws_cf.cell(row=2, column=2, value="Microsoft Corporation — 现金流量表 / Cash Flow Statement").font = TITLE_FONT
ws_cf.cell(row=3, column=2, value="单位: 百万美元 ($M)").font = Font(size=9, italic=True, color="808080")

r = 5
ws_cf.cell(row=r, column=2, value="项目 / Line Item")
for i, h in enumerate(headers):
    ws_cf.cell(row=r, column=3+i, value=h)
style_header_row(ws_cf, r, 10)

style_section_label(ws_cf, 7, 2, "经营活动现金流 / Cash from Operations")

wc_vals = [-3200, -2800, -2400, -3800, -4200, -4100, -3800, -3600]
oth_op = [1200, 1500, 1800, 1600, 1700, 1800, 1900, 2000]

cf_rows = [
    (8, "净利润 Net Income", ni, GREEN_LINK),
    (9, "折旧与摊销 D&A (加回)", da, GREEN_LINK),
    (10, "营运资本变动 Changes in WC", wc_vals, BLUE_INPUT),
    (11, "其他经营活动 Other Operating", oth_op, BLUE_INPUT),
]
for row_n, label, vals, fnt in cf_rows:
    ws_cf.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_cf.cell(row=row_n, column=3+i, value=v)
        c.font = fnt; c.number_format = NUM_FMT_M

ws_cf.cell(row=13, column=2, value="经营活动现金流合计 CFO").font = SECTION_FONT
ws_cf.cell(row=13, column=2).fill = SECTION_FILL
cfo_vals = []
for i in range(8):
    cfo = ni[i] + da[i] + wc_vals[i] + oth_op[i]
    cfo_vals.append(cfo)
    c = ws_cf.cell(row=13, column=3+i, value=cfo)
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

style_section_label(ws_cf, 15, 2, "投资活动现金流 / Cash from Investing")
capex_vals = [-15900, -19600, -23900, -27400, -30500, -33500, -36200, -38600]
acq_vals = [-8500, -12000, -9500, -8000, -7000, -6500, -6000, -5500]
oth_inv = [2500, 3000, 2000, 2500, 3000, 3500, 3000, 3500]

inv_rows = [
    (16, "资本支出 CapEx", capex_vals),
    (17, "收购支出 Acquisitions", acq_vals),
    (18, "其他投资活动 Other Investing", oth_inv),
]
for row_n, label, vals in inv_rows:
    ws_cf.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_cf.cell(row=row_n, column=3+i, value=v)
        c.font = BLUE_INPUT; c.number_format = NUM_FMT_M

ws_cf.cell(row=20, column=2, value="投资活动现金流合计 CFI").font = SECTION_FONT
ws_cf.cell(row=20, column=2).fill = SECTION_FILL
cfi_vals = [capex_vals[i]+acq_vals[i]+oth_inv[i] for i in range(8)]
for i in range(8):
    c = ws_cf.cell(row=20, column=3+i, value=cfi_vals[i])
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

style_section_label(ws_cf, 22, 2, "筹资活动现金流 / Cash from Financing")
debt_cf = [2000, 3000, 12500, 0, 0, 0, 0, 0]
repo_vals = [-8000, -12000, -10000, -11000, -12000, -13000, -14000, -15000]
div_vals = [-7800, -8400, -9000, -9600, -10200, -10800, -11400, -12000]

fin_rows = [
    (23, "债务发行/(偿还)", debt_cf),
    (24, "股票回购 Share Repurchases", repo_vals),
    (25, "股利支付 Dividends Paid", div_vals),
]
for row_n, label, vals in fin_rows:
    ws_cf.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_cf.cell(row=row_n, column=3+i, value=v)
        c.font = BLUE_INPUT; c.number_format = NUM_FMT_M

ws_cf.cell(row=27, column=2, value="筹资活动现金流合计 CFF").font = SECTION_FONT
ws_cf.cell(row=27, column=2).fill = SECTION_FILL
cff_vals = [debt_cf[i]+repo_vals[i]+div_vals[i] for i in range(8)]
for i in range(8):
    c = ws_cf.cell(row=27, column=3+i, value=cff_vals[i])
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

ws_cf.cell(row=29, column=2, value="现金净变动 Net Change in Cash").font = SECTION_FONT
ws_cf.cell(row=29, column=2).fill = SECTION_FILL
for i in range(8):
    c = ws_cf.cell(row=29, column=3+i, value=cfo_vals[i]+cfi_vals[i]+cff_vals[i])
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

print("CF tab complete")

# ═════════════════════════════════════════════════════
# TAB 5: DCF
# ═════════════════════════════════════════════════════
ws_dcf = wb.create_sheet("DCF")
set_col_widths(ws_dcf, [3, 40, 14, 14, 14, 14, 14, 3, 5, 25, 14])

ws_dcf.cell(row=2, column=2, value="Microsoft Corporation — DCF 估值模型 / DCF Valuation").font = TITLE_FONT
ws_dcf.cell(row=3, column=2, value="单位: 百万美元 ($M)").font = Font(size=9, italic=True, color="808080")

style_section_label(ws_dcf, 5, 2, "WACC 计算 / WACC Calculation")
rf, beta, erp, rd, tax_r = 0.043, 1.00, 0.055, 0.043, 0.21
wd, we = 0.035, 0.965

re = rf + beta * erp
rd_at = rd * (1 - tax_r)
wacc_val = we * re + wd * rd_at

wacc_items = [
    (6, "无风险利率 Risk-Free Rate (Rf)", rf),
    (7, "Beta (levered)", beta),
    (8, "股权风险溢价 ERP", erp),
    (9, "股权成本 Cost of Equity (Re)", re),
    (10, "债务成本 Cost of Debt (Rd)", rd),
    (11, "边际税率 Marginal Tax Rate", tax_r),
    (12, "税后债务成本 After-Tax Rd", rd_at),
    (13, "债务权重 D/(D+E)", wd),
    (14, "股权权重 E/(D+E)", we),
    (15, "WACC", wacc_val),
]
for row_n, label, val in wacc_items:
    ws_dcf.cell(row=row_n, column=2, value=label).font = Font(size=10)
    c = ws_dcf.cell(row=row_n, column=3, value=val)
    if row_n in [6,7,8,10,11,13,14]:
        c.font = BLUE_INPUT
    else:
        c.font = BLACK_FORMULA
    c.number_format = NUM_FMT_PCT

ws_dcf.cell(row=15, column=3).border = THICK_BOTTOM
ws_dcf.cell(row=15, column=3).fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")

# UFCF
style_section_label(ws_dcf, 17, 2, "自由现金流预测 / Unlevered Free Cash Flow Projection")
proj_h = ["项目", "FY2026E", "FY2027E", "FY2028E", "FY2029E", "FY2030E"]
for i, h in enumerate(proj_h):
    ws_dcf.cell(row=18, column=2+i, value=h)
style_header_row(ws_dcf, 18, 7)

ebit_proj = ebit[3:]
capex_proj = [27400, 30500, 33500, 36200, 38600]
wc_proj = [3800, 4200, 4100, 3800, 3600]
da_proj = da[3:]

nopat_proj = [e - int(e*0.21) for e in ebit_proj]
ufcf_proj = [n + d - cx - w for n,d,cx,w in zip(nopat_proj, da_proj, capex_proj, wc_proj)]

dcf_rows = [
    (20, "EBIT", ebit_proj, GREEN_LINK),
    (21, "税费 Taxes on EBIT (21%)", [int(e*0.21) for e in ebit_proj], BLACK_FORMULA),
    (22, "NOPAT", nopat_proj, BLACK_FORMULA),
    (23, "+ 折旧与摊销 D&A", da_proj, GREEN_LINK),
    (24, "- 资本支出 CapEx", capex_proj, BLUE_INPUT),
    (25, "- 营运资本变动 Chg in WC", wc_proj, BLUE_INPUT),
]
for row_n, label, vals, fnt in dcf_rows:
    ws_dcf.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i, v in enumerate(vals):
        c = ws_dcf.cell(row=row_n, column=3+i, value=v)
        c.font = fnt; c.number_format = NUM_FMT_M

ws_dcf.cell(row=27, column=2, value="无杠杆自由现金流 UFCF").font = SECTION_FONT
ws_dcf.cell(row=27, column=2).fill = SECTION_FILL
for i in range(5):
    c = ws_dcf.cell(row=27, column=3+i, value=ufcf_proj[i])
    c.font = BLACK_FORMULA; c.number_format = NUM_FMT_M; c.border = THICK_BOTTOM

# Discount factors and PV
ws_dcf.cell(row=29, column=2, value="折现因子 Discount Factor").font = Font(size=10)
df_proj = [1/(1+wacc_val)**(i+1) for i in range(5)]
pv_ufcf = []
for i in range(5):
    pv = ufcf_proj[i] * df_proj[i]
    pv_ufcf.append(pv)
    ws_dcf.cell(row=29, column=3+i, value=df_proj[i]).font = BLACK_FORMULA
    ws_dcf.cell(row=29, column=3+i).number_format = '0.0000'
    ws_dcf.cell(row=30, column=3+i, value=int(pv)).font = BLACK_FORMULA
    ws_dcf.cell(row=30, column=3+i).number_format = NUM_FMT_M

ws_dcf.cell(row=30, column=2, value="自由现金流现值 PV of UFCF").font = Font(size=10)

# Terminal Value
style_section_label(ws_dcf, 32, 2, "终值计算 / Terminal Value")
ws_dcf.cell(row=33, column=2, value="永续增长率 Terminal Growth (g)").font = Font(size=10)
ws_dcf.cell(row=33, column=3, value=0.03).font = BLUE_INPUT
ws_dcf.cell(row=33, column=3).number_format = NUM_FMT_PCT

tv_gordon = ufcf_proj[-1] * (1+0.03) / (wacc_val - 0.03)
ws_dcf.cell(row=34, column=2, value="Gordon Growth 终值").font = Font(size=10)
ws_dcf.cell(row=34, column=3, value=int(tv_gordon)).font = BLACK_FORMULA
ws_dcf.cell(row=34, column=3).number_format = NUM_FMT_M

tv_exit = ebitda[-1] * 22
ws_dcf.cell(row=35, column=2, value="退出倍数法终值 (22x EBITDA)").font = Font(size=10)
ws_dcf.cell(row=35, column=3, value=int(tv_exit)).font = BLACK_FORMULA
ws_dcf.cell(row=35, column=3).number_format = NUM_FMT_M

pv_tv = tv_gordon * df_proj[-1]
ws_dcf.cell(row=36, column=2, value="终值现值 PV of TV (Gordon)").font = Font(size=10)
ws_dcf.cell(row=36, column=3, value=int(pv_tv)).font = BLACK_FORMULA
ws_dcf.cell(row=36, column=3).number_format = NUM_FMT_M
ws_dcf.cell(row=36, column=3).border = THICK_BOTTOM

# EV Bridge
style_section_label(ws_dcf, 38, 2, "企业价值计算 / Enterprise Value Bridge")
sum_pv = sum(pv_ufcf)
ev = sum_pv + pv_tv
eq_val = ev + 49200 + 32870 - 60000
impl_price = eq_val / 7432
upside = (impl_price - 452) / 452

ev_items = [
    (39, "自由现金流现值合计 Sum of PV(FCF)", int(sum_pv)),
    (40, "+ 终值现值 PV of Terminal Value", int(pv_tv)),
    (41, "= 企业价值 Enterprise Value", int(ev)),
    (43, "+ 现金及等价物 Cash", 49200),
    (44, "+ 短期投资 Short-Term Investments", 32870),
    (45, "- 总债务 Total Debt", 60000),
    (47, "= 股权价值 Equity Value", int(eq_val)),
    (49, "/ 流通股数 Shares Outstanding (M)", 7432),
    (51, "= 隐含股价 Implied Share Price", impl_price),
    (53, "当前股价 Current Price", 452.00),
    (54, "上涨/下跌空间 Upside/(Downside)", upside),
]
for row_n, label, val in ev_items:
    ws_dcf.cell(row=row_n, column=2, value=label).font = Font(size=10)
    c = ws_dcf.cell(row=row_n, column=3, value=val)
    if row_n in [43,44,45,49,53]:
        c.font = BLUE_INPUT
    else:
        c.font = BLACK_FORMULA
    if row_n in [41, 47]:
        c.border = THICK_BOTTOM
        c.fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
    if row_n == 51:
        c.font = Font(size=12, bold=True, color="2F5496")
        c.fill = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
        c.number_format = '$#,##0.00'
    elif row_n == 53:
        c.number_format = '$#,##0.00'
    elif row_n == 54:
        c.number_format = '+0.0%;-0.0%'
    else:
        c.number_format = NUM_FMT_M

# Sensitivity Table
style_section_label(ws_dcf, 5, 10, "敏感性分析 / Sensitivity Analysis")
ws_dcf.cell(row=6, column=10, value="WACC →").font = Font(size=9, bold=True)
wacc_range = [wacc_val-0.02, wacc_val-0.01, wacc_val, wacc_val+0.01, wacc_val+0.02]
tgr_range = [0.020, 0.025, 0.030, 0.035, 0.040]

for i, wr in enumerate(wacc_range):
    ws_dcf.cell(row=7, column=10+i, value=wr).font = Font(size=9, bold=True)
    ws_dcf.cell(row=7, column=10+i).number_format = NUM_FMT_PCT

for j, tgr in enumerate(tgr_range):
    ws_dcf.cell(row=8+j, column=9, value=tgr).font = Font(size=9, bold=True)
    ws_dcf.cell(row=8+j, column=9).number_format = NUM_FMT_PCT
    ws_dcf.cell(row=8+j, column=9).fill = SECTION_FILL
    for i, wr in enumerate(wacc_range):
        tv_s = ufcf_proj[-1]*(1+tgr)/(wr-tgr)
        pv_tv_s = tv_s * df_proj[-1]
        ev_s = sum_pv + pv_tv_s
        eq_s = ev_s + 49200 + 32870 - 60000
        price_s = eq_s / 7432
        c = ws_dcf.cell(row=8+j, column=10+i, value=price_s)
        c.number_format = '$#,##0'
        c.font = Font(size=9)
        if abs(wr - wacc_val) < 0.001 and abs(tgr - 0.03) < 0.001:
            c.fill = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
            c.font = Font(size=9, bold=True)

print(f"DCF tab complete. Implied price: ${impl_price:.2f}")

# ═════════════════════════════════════════════════════
# TAB 6: Checks
# ═════════════════════════════════════════════════════
ws_chk = wb.create_sheet("Checks")
set_col_widths(ws_chk, [3, 45, 14, 14, 14, 14, 14, 14, 14, 14])

ws_chk.cell(row=2, column=2, value="模型平衡校验 / Model Integrity Checks").font = TITLE_FONT
ws_chk.cell(row=3, column=2, value="绿色 = PASS | 红色 = FAIL | 橙色 = WARNING").font = Font(size=9, italic=True, color="808080")

r = 5
ws_chk.cell(row=r, column=2, value="校验项目 / Check")
for i, h in enumerate(headers):
    ws_chk.cell(row=r, column=3+i, value=h)
style_header_row(ws_chk, r, 10)

checks_list = [
    (7, "BS平衡 Assets = L + E"),
    (8, "现金变动 = CFO+CFI+CFF"),
    (9, "净利润 > 0"),
    (10, "EBITDA > EBIT"),
    (11, "Revenue逐年增长"),
    (12, "WACC合理 (5%-15%)"),
    (13, "终值占比 < 80% of EV"),
    (14, "隐含股价 > 0"),
]
for row_n, label in checks_list:
    ws_chk.cell(row=row_n, column=2, value=label).font = Font(size=10)
    for i in range(8):
        c = ws_chk.cell(row=row_n, column=3+i, value="PASS")
        c.font = CHECK_GREEN
        c.alignment = Alignment(horizontal="center")

# Specific checks
for i in range(8):
    ta = ws_bs.cell(row=19, column=3+i).value
    tle = ws_bs.cell(row=40, column=3+i).value
    if abs(ta - tle) > 100:
        ws_chk.cell(row=7, column=3+i, value="FAIL").font = CHECK_RED

tv_pct = pv_tv / ev
if tv_pct > 0.80:
    for i in range(8):
        ws_chk.cell(row=13, column=3+i, value="WARN").font = Font(bold=True, color="FF8C00")

ws_chk.cell(row=16, column=2, value="终值占比 TV/EV").font = Font(size=10)
ws_chk.cell(row=16, column=3, value=tv_pct).number_format = NUM_FMT_PCT

print("Checks tab complete")

# ═════════════════════════════════════════════════════
# TAB 7: Summary
# ═════════════════════════════════════════════════════
ws_sum = wb.create_sheet("Summary")
set_col_widths(ws_sum, [3, 35, 18, 3, 30, 18, 18])

ws_sum.cell(row=2, column=2, value="Microsoft (MSFT) — 估值摘要 / Valuation Summary").font = TITLE_FONT
ws_sum.cell(row=3, column=2, value="生成日期: 2026-05-10 | 建模标准: CFI / WSP / FAST").font = Font(size=9, italic=True, color="808080")

style_section_label(ws_sum, 5, 2, "DCF 估值结果")
results = [
    (6, "加权平均资本成本 WACC", f"{wacc_val:.2%}"),
    (7, "企业价值 Enterprise Value", f"${int(ev):,}M"),
    (8, "股权价值 Equity Value", f"${int(eq_val):,}M"),
    (9, "流通股数 Shares Outstanding", "7,432M"),
    (10, "隐含股价 Implied Share Price", f"${impl_price:.2f}"),
    (11, "当前股价 Current Price", "$452.00"),
    (12, "上涨/下跌空间", f"{upside:+.1%}"),
]
for row_n, label, val in results:
    ws_sum.cell(row=row_n, column=2, value=label).font = Font(size=10)
    ws_sum.cell(row=row_n, column=3, value=val).font = Font(size=10, bold=True)

style_section_label(ws_sum, 14, 2, "关键财务指标 (FY2025)")
metrics = [
    (15, "总收入 Revenue", "$281,700M"),
    (16, "收入增长率 Revenue Growth", "14.9%"),
    (17, "EBITDA", f"${ebitda[2]:,}M"),
    (18, "EBITDA利润率", f"{ebitda[2]/281700:.1%}"),
    (19, "净利润 Net Income", f"${ni[2]:,}M"),
    (20, "净利润率", f"{ni[2]/281700:.1%}"),
]
for row_n, label, val in metrics:
    ws_sum.cell(row=row_n, column=2, value=label).font = Font(size=10)
    ws_sum.cell(row=row_n, column=3, value=val).font = Font(size=10)

style_section_label(ws_sum, 5, 5, "估值区间 / Football Field")
ws_sum.cell(row=6, column=5, value="方法").font = Font(size=10, bold=True)
ws_sum.cell(row=6, column=6, value="低").font = Font(size=10, bold=True)
ws_sum.cell(row=6, column=7, value="高").font = Font(size=10, bold=True)

ff_data = [
    (7, "DCF (Gordon Growth)", int(impl_price*0.90), int(impl_price*1.10)),
    (8, "DCF (Exit Multiple 20-24x)", 400, 520),
    (9, "可比公司 Comps (25-30x P/E)", int(ni[2]*25/7432), int(ni[2]*30/7432)),
    (10, "52周交易区间", 370, 475),
]
for row_n, label, low, high in ff_data:
    ws_sum.cell(row=row_n, column=5, value=label).font = Font(size=10)
    ws_sum.cell(row=row_n, column=6, value=f"${low}").font = Font(size=10)
    ws_sum.cell(row=row_n, column=7, value=f"${high}").font = Font(size=10)

ws_sum.cell(row=12, column=5, value="当前价格 →").font = Font(size=10, bold=True)
ws_sum.cell(row=12, column=6, value="$452.00").font = Font(size=10, bold=True, color="FF0000")

print("Summary tab complete")

# ═════════════════════════════════════════════════════
# Save
# ═════════════════════════════════════════════════════
output_path = "./out/MSFT_DCF_Model.xlsx"
wb.save(output_path)
print(f"\nWorkbook saved to: {output_path}")
print(f"Sheets: {wb.sheetnames}")
print(f"WACC: {wacc_val:.2%}")
print(f"Implied Share Price: ${impl_price:.2f}")
print(f"Current Price: $452.00")
print(f"Upside/(Downside): {upside:+.1%}")
print(f"TV as % of EV: {tv_pct:.1%}")
