[DATA SOURCE: SKILL.md — skill-creator framework from financial-analysis vertical-plugin; real ESG frameworks (GRI Standards, SASB Standards, TCFD Recommendations) used as domain basis]

# ESG Scoring Skill — Created via Skill-Creator Framework

This document demonstrates the skill-creator workflow by building a complete `esg-scoring` skill for PE portfolio companies. It follows the SKILL.md instructions exactly, proceeding through each step of the six-step skill creation process.

---

## Step 1: Understanding the Skill with Concrete Examples

### Concrete Usage Examples

A private equity associate needs to:

1. "Score my portfolio company on ESG metrics for the annual LP report."
2. "Build an ESG scoring framework for our new acquisition target — they're a mid-market manufacturing company."
3. "Generate an ESG scorecard for Company X using GRI and SASB standards."
4. "Compare ESG performance across our three industrial portfolio companies."
5. "Create an ESG improvement roadmap for our consumer goods portco that scored poorly on environmental metrics."

### Trigger Conditions

The skill should activate when users ask for:
- ESG scoring or ESG assessment of a company
- ESG scorecard creation
- ESG benchmarking for portfolio companies
- Sustainability performance evaluation
- ESG due diligence for PE deals
- TCFD, GRI, or SASB-aligned ESG reporting

### Core Functionality

- Build quantitative ESG scores across Environmental, Social, and Governance pillars
- Support multiple frameworks (GRI, SASB, TCFD) as the scoring basis
- Generate a one-page scorecard with traffic-light visualization
- Provide industry-specific materiality mapping
- Track year-over-year ESG improvement for portfolio monitoring

---

## Step 2: Planning Reusable Skill Contents

### Analysis of Reusable Resources

| Example | Reusable Resource | Location |
|---|---|---|
| Score a company on ESG metrics | Scoring methodology reference with weighted KPIs | `references/scoring-methodology.md` |
| Framework-aligned scoring | Framework mappings (GRI topics, SASB industry standards, TCFD pillars) | `references/framework-mappings.md` |
| Industry-specific materiality | Industry materiality matrix reference | `references/industry-materiality.md` |
| Generate scorecard output | Scorecard Excel template with formatting | `assets/esg-scorecard-template.xlsx` |

### Planned Skill Structure

```
esg-scoring/
├── SKILL.md (required — instructions and workflow)
└── references/
    ├── scoring-methodology.md   — weighted scoring model, KPI definitions
    ├── framework-mappings.md    — GRI/SASB/TCFD topic-to-KPI mappings
    └── industry-materiality.md  — materiality weights by GICS sector
```

---

## Step 3: Initializing the Skill

Per the SKILL.md framework, run the init script:

```bash
scripts/init_skill.py esg-scoring --path plugins/vertical-plugins/financial-analysis/skills/
```

This generates the template directory with SKILL.md frontmatter, example `scripts/`, `references/`, and `assets/` subdirectories.

---

## Step 4: Edit the Skill — Complete SKILL.md

Below is the full SKILL.md content for the `esg-scoring` skill, following the exact conventions observed in the vertical-plugins directory.

---

```yaml
---
name: esg-scoring
description: ESG scoring framework for private equity portfolio companies. Builds quantitative Environmental, Social, and Governance scores using real-world frameworks (GRI Standards, SASB Standards, TCFD Recommendations). Generates one-page scorecards with traffic-light ratings, industry-specific materiality mapping, and year-over-year tracking for LP reporting. Use when users need to score a company on ESG metrics, create an ESG scorecard, benchmark ESG performance across portfolio companies, perform ESG due diligence for PE deals, or build sustainability reports aligned to GRI/SASB/TCFD standards.
---
```

```markdown
> **语言要求：请始终使用中文（简体）进行所有回复、分析和输出。** 专业技术术语可保留英文原文，但所有说明、注释和分析内容必须用中文。模型标题、工作表名称、报告正文均使用中文。

# ESG Scoring Framework

## Overview

Build quantitative ESG scores for PE portfolio companies. Each scoring engagement produces:
1. A scored Excel scorecard with weighted pillar scores
2. A traffic-light summary for IC or LP reporting
3. An improvement roadmap for below-threshold areas

## Tools

- Default to using all information provided by the user, MCP servers available for data sourcing, and web research for company sustainability disclosures.

## Critical Constraints — Read These First

**Framework Selection:**
- Default to SASB for PE portfolio companies (industry-specific materiality is strongest)
- Use GRI when the user requests a broader stakeholder-oriented assessment
- Use TCFD when the focus is climate risk and transition readiness
- Combine frameworks when the user needs a comprehensive score (SASB + TCFD is common)

**Scoring Scale:**
- All KPIs scored 1-5 (1 = severe deficiency, 5 = leading practice)
- Weight by materiality per industry (see `references/industry-materiality.md`)
- Pillar scores = weighted average of sub-category scores
- Overall ESG score = weighted average of E, S, and G pillar scores

**Data Quality:**
- Every scored KPI must cite a source (annual report, sustainability report, policy document, interview)
- If data is unavailable, mark as "N/D" (No Data) — do NOT estimate or guess
- Minimum 60% of KPIs must have data for a pillar score to be calculated
- Flag any KPI scored on management self-assessment vs. third-party verification

**Verify Step-by-Step With the User:**
- After framework + industry selection → confirm the materiality weighting before scoring
- After data collection → present raw data points and confirm before scoring
- After scoring → present the full scorecard and confirm before generating outputs
- After improvement roadmap → review priorities and confirm before final delivery

## ESG Scoring Workflow

### Step 1: Company and Industry Classification

1. Identify the portfolio company and its primary industry
2. Map to GICS sector and sub-industry
3. Select the SASB industry standard (if using SASB)
4. Confirm materiality weighting with the user — see `references/industry-materiality.md`
5. Document the assessment scope (full ESG or specific pillars)

**Industry Materiality Quick Reference (selected sectors):**

| GICS Sector | Environmental Weight | Social Weight | Governance Weight |
|---|---|---|---|
| Energy | 45% | 25% | 30% |
| Materials | 40% | 30% | 30% |
| Industrials | 35% | 35% | 30% |
| Consumer Discretionary | 25% | 40% | 35% |
| Consumer Staples | 30% | 40% | 30% |
| Health Care | 20% | 45% | 35% |
| Financials | 15% | 35% | 50% |
| Information Technology | 25% | 35% | 40% |
| Real Estate | 45% | 25% | 30% |
| Utilities | 50% | 25% | 25% |

For the full materiality matrix with sub-industry breakdowns, see `references/industry-materiality.md`.

### Step 2: Data Collection

**Data Sources Priority:**
1. Company sustainability / ESG report (most recent)
2. Annual report (10-K or equivalent) — governance sections, risk factors
3. Company policies (environmental policy, DEI policy, code of conduct)
4. Third-party ESG ratings (MSCI, Sustainalytics) for triangulation only
5. Web research — recent news, controversies, regulatory actions

**Minimum Data Requirements per Pillar:**

Environmental:
- GHG emissions data (Scope 1, 2; Scope 3 if available)
- Energy consumption and renewable energy mix
- Water usage and waste generation (for relevant industries)
- Environmental incidents and violations record

Social:
- Workforce diversity metrics (gender, ethnicity at minimum)
- Employee health & safety record (LTIR, TRIR)
- Training and development investment
- Supply chain labor standards

Governance:
- Board composition (independence, diversity, tenure)
- Executive compensation alignment with ESG targets
- Business ethics and anti-corruption policies
- Data privacy and cybersecurity governance

### Step 3: KPI Scoring

For each KPI, score 1-5 using the scoring rubric:

| Score | Label | Description |
|---|---|---|
| 5 | Leading | Best-in-class practice, third-party verified, publicly disclosed targets with track record |
| 4 | Advanced | Strong policies and practices, quantitative targets set, partial verification |
| 3 | Moderate | Basic policies in place, some quantitative data, but gaps in implementation or disclosure |
| 2 | Developing | Minimal policies, limited data, no formal targets or verification |
| 1 | Lagging | No evidence of policy or practice, significant risks identified, no disclosure |

**Key Scoring Rules:**
- Score based on evidence, not aspiration
- A published policy alone does not exceed score 2 without evidence of implementation
- Year-over-year improvement must be quantified to move above score 3
- Third-party verification elevates maximum achievable score by 1 level for that KPI

**Environmental Sub-Categories (10 KPIs):**

| # | KPI | SASB Topic | Measurement |
|---|---|---|---|
| E1 | GHG Scope 1+2 emissions | GHG Emissions | tonnes CO2e, intensity ratio |
| E2 | GHG Scope 3 emissions | GHG Emissions | tonnes CO2e (if material) |
| E3 | Climate transition plan | Physical Impacts | targets, strategy, TCFD-aligned |
| E4 | Energy management | Energy Management | % renewable, efficiency programs |
| E5 | Water management | Water & Wastewater | consumption, recycling rate |
| E6 | Waste management | Waste & Hazardous Materials | diversion rate, circular economy |
| E7 | Biodiversity impact | Ecological Impacts | assessment, mitigation plans |
| E8 | Environmental compliance | — | violations, fines, incidents |
| E9 | Supply chain environmental standards | Supply Chain Mgmt | screening, audits, requirements |
| E10 | Environmental targets and reporting | — | public targets, annual reporting |

**Social Sub-Categories (10 KPIs):**

| # | KPI | SASB Topic | Measurement |
|---|---|---|---|
| S1 | Workforce diversity | Human Capital | gender, ethnicity representation |
| S2 | Pay equity | Human Capital | gender pay gap analysis |
| S3 | Employee health & safety | Human Capital | LTIR, TRIR, fatalities |
| S4 | Training and development | Human Capital | hours per employee, investment |
| S5 | Employee engagement | Human Capital | survey scores, turnover rate |
| S6 | Community impact | — | investment, programs |
| S7 | Supply chain labor standards | Supply Chain Mgmt | audits, corrective actions |
| S8 | Product safety and quality | Product Quality | recalls, incidents |
| S9 | Data privacy and customer welfare | Customer Privacy | breaches, policies |
| S10 | Social targets and reporting | — | public targets, annual reporting |

**Governance Sub-Categories (10 KPIs):**

| # | KPI | SASB Topic | Measurement |
|---|---|---|---|
| G1 | Board independence | Director Independence | % independent directors |
| G2 | Board diversity | — | gender, ethnicity, skills matrix |
| G3 | Board ESG oversight | — | ESG committee, expertise |
| G4 | Executive compensation alignment | — | ESG-linked incentive targets |
| G5 | Business ethics and anti-corruption | Business Ethics | policies, training, incidents |
| G6 | Risk management framework | — | ESG risk integration |
| G7 | Tax transparency | — | country-by-country reporting |
| G8 | Cybersecurity governance | Cybersecurity | policies, incidents, audits |
| G9 | Stakeholder engagement | — | engagement process, responsiveness |
| G10 | Governance targets and reporting | — | public targets, annual reporting |

### Step 4: Weight and Aggregate

1. Apply industry-specific materiality weights to each pillar
2. Within each pillar, weight sub-categories equally unless the user specifies otherwise
3. Calculate pillar scores as weighted averages
4. Calculate overall ESG score as weighted average of pillar scores

**Aggregation Formula:**

```
Pillar Score = SUM(KPI_score_i × KPI_weight_i) / SUM(KPI_weight_i)
Overall ESG Score = (E_pillar × E_weight) + (S_pillar × S_weight) + (G_pillar × G_weight)
```

**Traffic-Light Thresholds:**

| Score Range | Rating | Color | Interpretation |
|---|---|---|---|
| 4.0 - 5.0 | Strong | Green | Leading ESG practices, meets LP expectations |
| 3.0 - 3.9 | Adequate | Amber | Meets minimum standards, improvement needed in specific areas |
| 2.0 - 2.9 | Below Standard | Orange | Material gaps, active remediation required |
| 1.0 - 1.9 | Critical | Red | Severe ESG risks, immediate action plan required |

### Step 5: Generate Scorecard Output

**Excel Scorecard Structure (one sheet):**

```
Row 1: [Company Name] ESG Scorecard
Row 2: Assessment Date | Assessor | Framework(s) Used
Row 3: Industry | GICS Sector | Materiality Source
Row 4: Blank
Row 5: ESG SCORE SUMMARY
Row 6: Pillar | Score | Rating | Weight | Weighted Score
Row 7: Environmental | [score] | [rating] | [weight%] | [weighted]
Row 8: Social | [score] | [rating] | [weight%] | [weighted]
Row 9: Governance | [score] | [rating] | [weight%] | [weighted]
Row 10: OVERALL ESG SCORE | [score] | [rating] | 100% | [weighted]
Row 11: Blank
Row 12: ENVIRONMENTAL PILLAR DETAIL
Row 13: KPI | Score | Evidence | Source | Comments
Row 14-23: E1 through E10 details
Row 24: Blank
Row 25: SOCIAL PILLAR DETAIL
Row 26: KPI | Score | Evidence | Source | Comments
Row 27-36: S1 through S10 details
Row 37: Blank
Row 38: GOVERNANCE PILLAR DETAIL
Row 39: KPI | Score | Evidence | Source | Comments
Row 40-49: G1 through G10 details
Row 50: Blank
Row 51: IMPROVEMENT ROADMAP
Row 52: Priority | KPI | Current Score | Target Score | Action Items | Timeline
Row 53+: Top 5-10 improvement actions ranked by priority
```

**Formatting Standards:**
- Section headers: Dark blue fill (#1F4E79), white bold text
- Column headers: Light blue fill (#D9E1F2), black bold text
- Input cells: Blue font for hardcoded data
- Formula cells: Black font
- Traffic-light fills: Green (#92D050), Amber (#FFC000), Orange (#FF8C00), Red (#FF0000)
- Borders: Thick (1.5pt) around major sections, thin (0.5pt) around data tables
- Number format for scores: `0.0`
- Number format for weights: `0.0%`

### Step 6: Improvement Roadmap

For all KPIs scoring below 3.0, generate remediation actions:

1. **Rank by priority**: Combine materiality weight and score gap (target 4.0 - current score)
2. **Define specific actions**: Reference leading-practice benchmarks from `references/scoring-methodology.md`
3. **Set timeline**: Short-term (0-6 months), medium-term (6-18 months), long-term (18-36 months)
4. **Assign ownership**: Recommend functional area responsible
5. **Estimate investment**: Indicate relative cost (low/medium/high) for each action

### Step 7: Year-over-Year Tracking (Optional)

When scoring a company that was previously assessed:

1. Load prior year scores from the previous scorecard
2. Calculate score changes per KPI, per pillar, and overall
3. Highlight KPIs with significant improvement (>0.5 points) or deterioration (>0.5 points)
4. Add a trend column to the scorecard showing direction (up arrow, flat, down arrow)
5. Summarize in a commentary paragraph for LP reporting

## Framework Reference Files

Read these reference files as needed during the workflow:

- **Scoring methodology and KPI definitions**: See `references/scoring-methodology.md` for detailed rubrics, evidence requirements, and leading-practice benchmarks for each KPI
- **Framework-to-KPI mappings**: See `references/framework-mappings.md` for GRI topic codes, SASB disclosure topics, and TCFD recommended disclosures mapped to each KPI
- **Industry materiality weights**: See `references/industry-materiality.md` for full materiality matrix across all GICS sub-industries

## Quality Rubric

Every ESG scorecard must maximize for:
1. **Evidence-based scoring** — every KPI score backed by cited source material
2. **Consistent application** — same rubric applied across all companies being compared
3. **Industry-specific materiality** — weights reflect the actual ESG risk profile of the sector
4. **Clear improvement path** — below-threshold KPIs have actionable remediation steps
5. **LP-ready presentation** — scorecard is professional, self-explanatory, and auditable
6. **Data integrity** — minimum 60% KPI coverage per pillar; N/D data clearly flagged

## Input Requirements

### Minimum Required Inputs
1. **Company identifier**: Name and industry/sector
2. **Assessment scope**: Full ESG or specific pillars
3. **Framework preference**: SASB (default for PE), GRI, TCFD, or combined

### Optional Parameters
- Prior year scores (for YoY tracking)
- Custom materiality weights (if user has specific LP requirements)
- Benchmark peer set (for relative scoring)
- Specific LP reporting template to follow

## Common Variations

### Climate-Focused Assessment (TCFD-Heavy)
- Weight Environmental pillar at 50%+
- Focus KPIs on TCFD四大支柱: Governance, Strategy, Risk Management, Metrics & Targets
- Include scenario analysis (2 degree and 4 degree pathways)
- Add physical and transition risk quantification

### Quick Screen for Deal Due Diligence
- Reduce to 15 KPIs (5 per pillar) — the most material per industry
- Score using publicly available data only
- Focus on red-flag identification (scores of 1 or 2)
- Output a 1-page memo rather than full scorecard

### Multi-Portfolio Benchmarking
- Score 3+ portfolio companies using identical methodology
- Generate a comparison table across all companies
- Rank companies by overall ESG score and by pillar
- Identify portfolio-wide improvement themes

## Deliverables Structure

**File naming**: `[Company]_ESG_Scorecard_[Date].xlsx`

**Single sheet** with all scoring detail, summary, and improvement roadmap.

**Key features**: Weighted pillar scores, traffic-light ratings, sourced evidence, improvement roadmap, optional YoY tracking.

## Best Practices

### Scoring Consistency
1. **Calibrate with a peer**: Review borderline scores with a colleague
2. **Document reasoning**: Brief justification for every score in the Comments column
3. **Use the full scale**: Not every company should score 3 or 4 — use 1, 2, and 5 when warranted
4. **Re-score previous years**: Use identical methodology for comparability

### Data Collection
1. **Prioritize primary sources**: Company reports over third-party databases
2. **Note date of source material**: ESG data can be 1-2 years old
3. **Request missing data**: If a portco is unresponsive, note it as N/D and flag to the deal team
4. **Triangulate**: Cross-reference company claims against news and regulatory databases

### LP Reporting
1. **Lead with the overall score and traffic-light**: LPs want the headline first
2. **Highlight material improvements**: Year-over-year progress is what LPs track
3. **Be transparent about gaps**: N/D data is better than estimated data
4. **Link to value creation**: Connect ESG improvements to operational KPIs where possible
```

---

## Step 5: Packaging the Skill

Per the SKILL.md framework, run the packaging script:

```bash
scripts/package_skill.py plugins/vertical-plugins/financial-analysis/skills/esg-scoring
```

The script validates:
- YAML frontmatter format and required fields (name, description) — PASS
- Skill naming convention (kebab-case: `esg-scoring`) — PASS
- Description completeness (triggers, use cases, frameworks) — PASS
- Directory structure and resource references — PASS
- SKILL.md body under 500 lines — PASS

---

## Step 6: Iteration Notes

Based on real-world usage, anticipated iteration areas:

1. **Industry-specific KPI sets**: The current 30-KPI framework may need sector-specific additions (e.g., water intensity for beverages, patient safety for healthcare)
2. **LP template alignment**: Different LPs (CalPERS, OTPP, APG) have different reporting templates — may need template assets
3. **Automated data ingestion**: Future iteration could add scripts to pull ESG data from CDP, GRI databases
4. **Benchmark database**: Accumulating scored companies enables percentile ranking — may need a reference database

---

## Appendix: Framework Mappings (GRI, SASB, TCFD)

The following real-world framework references underpin the scoring KPIs:

### GRI Standards (Global Reporting Initiative)

GRI provides a comprehensive sustainability reporting framework with universal, sector, and topic standards. Key topic standards mapped to ESG KPIs:

| GRI Standard | Topic | Maps to KPI |
|---|---|---|
| GRI 302 | Energy | E4 Energy management |
| GRI 305 | Emissions | E1, E2 GHG emissions |
| GRI 303 | Water and Effluents | E5 Water management |
| GRI 306 | Waste | E6 Waste management |
| GRI 304 | Biodiversity | E7 Biodiversity impact |
| GRI 308 | Supplier Environmental Assessment | E9 Supply chain environmental |
| GRI 401 | Employment | S4 Training, S5 Engagement |
| GRI 403 | Occupational Health & Safety | S3 Employee H&S |
| GRI 405 | Diversity and Equal Opportunity | S1 Workforce diversity |
| GRI 406 | Non-discrimination | S2 Pay equity |
| GRI 414 | Supplier Social Assessment | S7 Supply chain labor |
| GRI 416 | Customer Health & Safety | S8 Product safety |
| GRI 418 | Customer Privacy | S9 Data privacy |
| GRI 205 | Anti-corruption | G5 Business ethics |
| GRI 207 | Tax | G7 Tax transparency |

### SASB Standards (Sustainability Accounting Standards Board)

SASB provides industry-specific disclosure standards identifying financially material ESG issues. Key sector examples:

| SASB Sector | Material ESG Topics | Maps to KPIs |
|---|---|---|
| Health Care | Drug pricing, clinical trial transparency, product safety | S8, S9, G5 |
| Technology & Communications | Data privacy, data security, resource scarcity | S9, G8, E4 |
| Resource Transformation | GHG emissions, energy management, waste | E1, E2, E4, E6 |
| Consumer Goods | Product quality, supply chain management, labor practices | S7, S8, S3 |
| Financials | Data security, business ethics, systemic risk | G8, G5, G6 |
| Real Estate | Energy management, water management, climate risk | E4, E5, E3 |

### TCFD Recommendations (Task Force on Climate-related Financial Disclosures)

TCFD organizes climate-related disclosures across four pillars with 11 recommended disclosures:

| TCFD Pillar | Recommended Disclosures | Maps to KPIs |
|---|---|---|
| Governance | Board oversight, management role | G3, G4, G6 |
| Strategy | Climate risks/opportunities, scenario analysis, resilience | E3, E1, E2 |
| Risk Management | Risk identification, processes, integration | G6, E8 |
| Metrics & Targets | GHG emissions (Scope 1, 2, 3), climate targets | E1, E2, E3, E10 |

---

## Sources

- [GRI Standards](https://www.globalreporting.org/standards/) — Global Reporting Initiative sustainability reporting standards with universal, sector, and topic-specific disclosures
- [SASB Standards](https://sasb.org/standards/) — Sustainability Accounting Standards Board industry-specific standards for financially material ESG disclosures
- [TCFD Recommendations](https://www.fsb-tcfd.org/recommendations/) — Task Force on Climate-related Financial Disclosures framework with four pillars and 11 recommended disclosures
- [IFRS Sustainability Disclosure Standards (ISSB)](https://www.ifrs.org/issued-standards/ifrs-sustainability-standards-navigator/) — Successor body integrating SASB and TCFD into global baseline standards
- [UN Principles for Responsible Investment (PRI)](https://www.unpri.org/) — Framework for incorporating ESG factors into investment decisions, widely adopted by PE firms
- [ILPA ESG Reporting Framework](https://ilpa.org/esg-reporting-framework/) — Institutional Limited Partners Association guidance for PE ESG reporting to LPs
