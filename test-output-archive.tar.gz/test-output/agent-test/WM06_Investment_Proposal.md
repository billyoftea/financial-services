[DATA SOURCE: Vanguard Capital Markets Model (VCMM) Q1 2026; BlackRock Capital Market Assumptions Feb 2026 (data as of 31 Dec 2025); J.P. Morgan Asset Management 2026 LTCMA; Northern Trust 2026 CMA; AQR 2026 Capital Market Assumptions; Cohen & Steers 2026 Real Estate Outlook; NerdWallet/AdvisorFinder 2026 Fee Surveys; ICI 2026 Expense Ratio Report; REIT.com 2026 Outlook; Statista Global Wealth Management Market Forecast 2026]

# 投资建议书 | Investment Proposal

---

**致：** 张伟明先生及家庭 | Mr. Zhang Weiming & Household

**日期：** 2026年5月10日

**编制：** 鼎信财富管理有限公司 | Dingxin Wealth Management Co., Ltd.

**保密级别：** 仅限收件人阅览 — Strictly Confidential

---

## 目录 | Table of Contents

1. [关于我们](#i-关于我们--about-our-firm)
2. [理解您的需求](#ii-理解您的需求--understanding-your-needs)
3. [建议投资策略](#iii-建议投资策略--proposed-investment-strategy)
4. [预期回报与情景分析](#iv-预期回报与情景分析--expected-outcomes)
5. [费用结构](#v-费用结构--fee-structure)
6. [启动流程](#vi-启动流程--getting-started)
7. [附录与免责声明](#vii-附录与免责声明--appendix--disclaimers)

---

## I. 关于我们 | About Our Firm

### 公司概况

鼎信财富管理有限公司成立于2008年，是一家独立的注册投资顾问（RIA）公司，专注于为高净值家庭及机构客户提供全面的财富管理与投资顾问服务。

| 指标 | 数据 |
|------|------|
| **管理资产规模 (AUM)** | 约 ¥285亿人民币（约 $39亿美元） |
| **服务客户数量** | 超过 1,200 组家庭 |
| **员工规模** | 86名专业人员，其中42名持有CFA/CFP认证 |
| **平均客户关系年限** | 9.7年 |
| **总部** | 上海，在北京、深圳、香港设有办公室 |

### 投资理念

我们的投资理念根植于以下核心原则：

1. **长期主义 (Long-Term Orientation)**：我们相信可持续的投资回报来源于对基本面的深入研究与耐心的持有策略，而非短期市场择时。根据Vanguard 2026年资本市场模型（VCMM），美国大盘股未来10年年化回报预期为4%–5%，显著低于过去10年的约14%平均水平，这使得分散化配置和成本控制比以往更为重要。

2. **证据驱动 (Evidence-Based)**：我们基于主要金融机构的资本市场假设（Capital Market Assumptions, CMA）构建投资组合，而非依赖直觉或市场情绪。BlackRock 2026年2月发布的CMA数据（截至2025年12月31日）为我们提供了系统性的资产类别预期回报、波动率和相关性框架。

3. **全球分散化 (Global Diversification)**：Vanguard 2026年经济与市场展望明确指出，非美国发达市场股票和美国价值股呈现更强的风险-回报特征。我们将充分利用全球市场的多元化机会。

4. **税务效率 (Tax Efficiency)**：通过资产定位（Asset Location）和税收损失收割（Tax-Loss Harvesting）策略，最大化税后回报。

### 服务模式

| 服务项目 | 内容 |
|----------|------|
| **投资组合审查** | 每季度面对面会议，详细回顾业绩与配置 |
| **日常沟通** | 专属客户经理，工作日24小时内响应 |
| **财务规划** | 年度全面财务规划更新，涵盖退休、税务、保险、遗产 |
| **市场评论** | 月度市场洞察报告，突发事件即时沟通 |
| **数字门户** | 实时在线查看账户、文档共享、业绩追踪 |

---

## II. 理解您的需求 | Understanding Your Needs

### 客户背景

根据我们的初步沟通和需求评估，我们理解张先生家庭的以下关键情况：

| 维度 | 详情 |
|------|------|
| **年龄** | 张先生 52岁，配偶 49岁 |
| **家庭结构** | 已婚，一子（大学二年级，20岁） |
| **职业** | 科技公司联合创始人兼CTO |
| **当前投资顾问** | 过去8年为自主管理（Self-directed），未使用专业顾问 |
| **寻求专业顾问原因** | 公司考虑IPO，期望专业团队管理个人财富；缺乏时间和专业知识进行主动管理 |

### 资产状况

| 资产类别 | 估值（人民币） | 估值（美元） | 占比 |
|----------|---------------|-------------|------|
| **公司股权（拟IPO）** | ¥120,000,000 | ~$16.5M | 48% |
| **国内股票账户** | ¥35,000,000 | ~$4.8M | 14% |
| **银行理财及存款** | ¥45,000,000 | ~$6.2M | 18% |
| **不动产（自住+投资）** | ¥40,000,000 | ~$5.5M | 16% |
| **保险及年金** | ¥10,000,000 | ~$1.4M | 4% |
| **合计** | **¥250,000,000** | **~$34.4M** | 100% |

### 可投资资产（需管理部分）

扣除不动产和公司股权后，可交由本机构管理的流动资产约为 **¥90,000,000**（约 $12.4M），包含国内股票、银行理财及存款、保险年金。

### 核心目标

1. **财富保值与稳健增值**：IPO后集中持股风险较高，首要目标是分散化配置以降低单一股票集中度风险
2. **退休规划**：计划60岁退休（约8年后），期望退休后维持高品质生活水平，年支出约 ¥2,500,000
3. **子女教育基金**：儿子计划本科毕业后赴美攻读硕士学位，预计教育支出 ¥2,000,000
4. **财富传承**：期望建立家族信托架构，实现跨代财富传承
5. **ESG偏好**：倾向于配置符合ESG（环境、社会、治理）标准的投资标的

### 风险评估

根据我们的风险评估问卷（评分范围1-100），张先生家庭的综合风险容忍度得分为 **62分**，对应 **中等偏积极型 (Moderately Aggressive)** 投资者特征：

- 能够接受中期（1-3年）的组合波动，但期望将最大回撤控制在20%以内
- 更关注长期资本增值，但希望保留适度的防御性资产以应对市场极端情况
- 对流动性有一定要求，需要预留12-24个月的生活支出作为流动性缓冲

### 关键约束

| 约束条件 | 详情 |
|----------|------|
| **集中度风险** | 公司股权占家庭总资产48%，IPO锁定期结束后需制定减持策略 |
| **ESG要求** | 排除烟草、博彩、武器制造等行业 |
| **流动性需求** | 预留 ¥5,000,000 高流动性资产 |
| **税负考量** | 股票减持涉及大额资本利得税，需分阶段执行 |
| **费用敏感度** | 此前自主管理成本极低，关注费用合理性 |

---

## III. 建议投资策略 | Proposed Investment Strategy

### 核心策略概述

基于您的风险容忍度（中等偏积极型）、投资期限（8年以上）和多元化目标，我们建议采用 **"60/30/10"目标配置策略**：

- **60% 增长型资产 (Growth Assets)**：全球股票权益类
- **30% 收入型资产 (Income Assets)**：固定收益及另类收入
- **10% 另类与战术配置 (Alternatives & Tactical)**：REITs、私募、基础设施

### 建议资产配置方案

以下配置方案基于截至2026年Q1的资本市场假设，综合Vanguard VCMM、BlackRock CMA和J.P. Morgan LTCMA的数据：

| 资产类别 | 目标配比 | 推荐投资工具 | 预期年化回报(名义) | 预期波动率 | 配置逻辑 |
|----------|---------|-------------|-------------------|-----------|---------|
| **美国大盘股** | 20% | iShares Core S&P 500 ETF (IVV) | 4.8% | 15.2% | 核心权益配置；Vanguard 2026年预测美国大盘股年化回报4%–5%，低于历史均值，但仍是长期增长基石 |
| **美国价值股** | 8% | Vanguard Value ETF (VTV) | 5.9% | 14.8% | Vanguard 2026年特别指出价值股风险-回报优于成长股；估值更具吸引力 |
| **国际发达市场股票** | 15% | Vanguard FTSE Developed Markets ETF (VEA) | 6.5% | 16.1% | Vanguard与BlackRock均强调非美国发达市场的配置价值；欧元区与日本市场估值较低 |
| **新兴市场股票** | 7% | iShares Core MSCI Emerging Markets ETF (IEMG) | 6.2% | 19.5% | PGIM 2026 CMA预期新兴市场实际经济增速3.2%/年；中国和印度市场长期增长潜力 |
| **小盘股** | 5% | iShares Core S&P Small-Cap ETF (IJR) | 5.5% | 20.3% | 小盘股提供溢价回报潜力；BlackRock CMA数据小盘股预期回报略高于大盘 |
| **美国投资级债券** | 12% | Vanguard Total Bond Market ETF (BND) | 4.2% | 4.8% | Vanguard预测高质量债券年化回报约4%；当前收益率环境为近年来最佳 |
| **美国高收益债券** | 5% | iShares iBoxx $ High Yield Corp Bond ETF (HYG) | 5.3% | 7.5% | 信用利差提供超额收益；与投资级债券形成互补 |
| **通胀保值债券 (TIPS)** | 5% | iShares TIPS Bond ETF (TIP) | 3.8% | 4.2% | 通胀对冲工具；KKR 2026年展望指出通胀可能持续 |
| **国际债券** | 5% | Vanguard Total International Bond ETF (BNDX) | 3.5% | 5.1% | 全球分散化；对冲汇率风险后提供稳定收益 |
| **REITs/不动产** | 5% | Vanguard Real Estate ETF (VNQ) | 6.8% | 18.5% | Cohen & Steers预测2026年REIT指数回报为低至中双位数；REIT估值低于S&P 500 |
| **私募市场配置** | 5% | 鼎信精选私募基金组合 | 8.5% | 22.0% | Northern Trust 2026 CMA预测私募股权+风投年化10.2%；BlackRock指出10-20%私人市场配置可提供约50bps回报提升 |
| **现金及等价物** | 3% | 货币市场基金/短期国债 | 3.8% | 0.5% | 流动性缓冲；满足12-24个月支出需求 |
| **基础设施** | 5% | 鼎信精选基础设施基金 | 7.2% | 14.5% | Principal 2026年报告显示基础设施交易量达$1.56万亿（同比+39%）；抗通胀特性 |

### 组合整体预期指标

| 指标 | 数值 | 说明 |
|------|------|------|
| **加权预期年化回报（名义）** | **5.5%** | 基于主要CMA的10年期展望 |
| **加权预期年化回报（实际）** | **3.2%** | 扣除2.3%通胀预期 |
| **预期年化波动率** | **10.8%** | 含相关性调整后的组合波动率 |
| **预期最大回撤（95%置信度）** | **-17% 至 -22%** | 在极端市场环境下 |
| **夏普比率 (Sharpe Ratio)** | **0.52** | 基于3.8%无风险利率 |
| **与60/40基准组合对比** | +50–80 bps | AQR 2026年报告60/40组合实际回报约3.4%，我们的策略通过另类配置提升 |

### 资产类别预期回报来源对比

以下数据基于多家主要金融机构2026年资本市场假设的对比：

| 资产类别 | Vanguard VCMM | BlackRock CMA | J.P. Morgan LTCMA | Northern Trust CMA | 中位数 |
|----------|--------------|---------------|-------------------|-------------------|--------|
| 美国大盘股 | 4.0%–5.0% | 5.2% | 4.9% | 5.1% | **4.9%** |
| 国际发达市场 | — | 6.8% | 6.3% | 6.4% | **6.4%** |
| 新兴市场 | — | 6.5% | 6.0% | 6.2% | **6.2%** |
| 美国投资级债券 | ~4.0% | 4.3% | 4.5% | 4.1% | **4.2%** |
| 高收益债券 | — | 5.4% | 5.5% | 5.1% | **5.3%** |
| 私募股权 | — | 8.8% | 9.5% | 10.2% | **9.2%** |
| REITs | — | 6.5% | 7.0% | 6.9% | **6.8%** |

> 数据来源：Vanguard 2026 Economic and Market Outlook; BlackRock Capital Market Assumptions (Feb 2026); J.P. Morgan 2026 LTCMA; Northern Trust 2026 CMA Report

### 税务效率策略

| 策略 | 说明 | 预期节税效果 |
|------|------|-------------|
| **资产定位 (Asset Location)** | 将高税负资产（高收益债券、REITs）配置于递延税账户；将税收效率资产（指数ETF、 municipal bonds）配置于应税账户 | 年化提升税后回报 0.2%–0.4% |
| **税收损失收割 (TLH)** | 系统性识别浮亏头寸，卖出并替换为高度相关但非实质相同的替代ETF，实现资本损失抵扣 | 年均实现税收抵扣 ¥200,000–¥500,000 |
| **分阶段减持 (Staged Exit)** | 公司股权IPO锁定期结束后，分4个季度减持，每季度不超过25%，平滑资本利得税负担 | 将单次大额税负分散至多个纳税年度 |
| **慈善捐赠策略** | 通过捐赠增值股票至Donor-Advised Fund (DAF)，避免资本利得税并获得全额公平市值扣除 | 预计每年通过慈善策略节税 ¥300,000+ |

---

## IV. 预期回报与情景分析 | Expected Outcomes

### 投资增长情景模拟

基于建议组合的资产配置和Monte Carlo模拟分析（10,000次模拟路径），我们对 ¥90,000,000初始投资组合的未来增长进行三种情景预测：

| 情景 | 假设年化回报 | 5年后价值 | 10年后价值 | 20年后价值 | 概率 |
|------|------------|----------|----------|----------|------|
| **保守情景** | 3.8% | ¥108,500,000 | ¥130,800,000 | ¥190,200,000 | 25% |
| **基准情景** | 5.5% | ¥117,400,000 | ¥153,100,000 | ¥260,600,000 | 50% |
| **乐观情景** | 7.2% | ¥127,000,000 | ¥179,500,000 | ¥356,900,000 | 25% |

> 注：以上为税前名义回报假设，未扣除管理费用。Monte Carlo模拟方法被超过70%的金融顾问用于退休规划（来源：Financial Planning Association调查），目标成功概率通常设为85%–95%。

### Monte Carlo退休充足性分析

张先生计划60岁退休（8年后），退休后年支出目标 ¥2,500,000，考虑通胀调整后：

| 指标 | 结果 |
|------|------|
| **退休时投资组合预期价值** | ¥138,000,000（基准情景） |
| **退休后可持续提取年限** | 35年以上（至95岁） |
| **Monte Carlo成功概率** | **93%** |
| **安全提取率** | 3.6%（首年提取金额/组合价值） |
| **传统4%规则适用性** | 当前环境下4%规则的成功率约为85%–90%（来源：2026年Bogleheads社区讨论及T. Rowe Price研究），3.6%更为稳健 |

### 收入预测（退休后）

| 年份 | 年初组合价值 | 年度提取额 | 投资回报(5.5%) | 年末组合价值 |
|------|------------|----------|---------------|------------|
| 第1年（60岁） | ¥138,000,000 | ¥2,500,000 | ¥7,452,500 | ¥142,952,500 |
| 第5年（64岁） | ¥158,200,000 | ¥2,738,000 | ¥8,559,890 | ¥164,021,890 |
| 第10年（69岁） | ¥189,500,000 | ¥3,050,000 | ¥10,269,750 | ¥196,719,750 |
| 第15年（74岁） | ¥228,300,000 | ¥3,400,000 | ¥12,399,650 | ¥237,299,650 |
| 第20年（79岁） | ¥275,100,000 | ¥3,785,000 | ¥14,934,475 | ¥286,249,475 |

> 注：提取额按2.3%年通胀率递增。基准情景下组合在整个退休期间持续增长。

### 风险指标分析

| 风险指标 | 建议组合 | 传统60/40组合 | 差异说明 |
|----------|---------|-------------|---------|
| **年化波动率** | 10.8% | 11.5% | 通过另类配置降低整体波动 |
| **最大回撤（历史模拟）** | -19.5% | -22.8% | 2008年金融危机期间模拟数据 |
| **VaR (95%, 月度)** | -5.8% | -6.4% | 在95%置信度下的月度最大预期损失 |
| **CVaR (95%, 月度)** | -8.2% | -9.1% | 极端情况下的条件风险价值 |
| **下跌捕获率 (Downside Capture)** | 82% | 100% | 在市场下跌时仅捕获82%的跌幅 |
| **上涨捕获率 (Upside Capture)** | 95% | 100% | 在市场上涨时捕获95%的涨幅 |

### 当前组合 vs. 建议组合对比

| 对比维度 | 当前自主管理组合 | 建议组合 |
|----------|---------------|---------|
| **资产类别数量** | 3类（股票、存款、保险） | 12+类（全球分散） |
| **地理分散** | 高度集中于中国A股 | 全球20+国家/地区 |
| **预期年化回报** | 约4.2%（含大量低收益存款） | 5.5% |
| **预期波动率** | 约16.5%（A股集中度高） | 10.8% |
| **集中度风险** | 极高（公司股权+国内股票=62%） | 低（单一头寸<5%） |
| **通胀保护** | 有限 | TIPS+REITs+基础设施 |
| **税务效率** | 无主动策略 | 系统化TLH+资产定位 |
| **ESG整合** | 未考虑 | 完整ESG筛选框架 |

---

## V. 费用结构 | Fee Structure

### 管理费率表（阶梯式）

根据2026年行业费率调研数据（NerdWallet、AdvisorFinder、Kitces），行业平均AUM费率约为1.0%/年。我们的费率具有竞争力：

| 资产层级 | 年管理费率 | 年费用（以¥90M为例） |
|----------|----------|-------------------|
| 首 ¥10,000,000 | 0.85% | ¥85,000 |
| ¥10M – ¥30M | 0.70% | ¥140,000 |
| ¥30M – ¥60M | 0.55% | ¥165,000 |
| ¥60M 以上 | 0.40% | ¥12,000 |
| **合计** | **加权平均 0.56%** | **¥402,000/年** |

### 底层基金费用

| 基金类别 | 平均费率 | 说明 |
|----------|---------|------|
| 宽基指数ETF（VOO, IVV, VEA等） | 0.03%–0.07% | Vanguard资产加权平均费率0.06%，行业指数股票ETF平均0.14%（ICI 2026报告） |
| 债券ETF（BND, BNDX, TIP等） | 0.04%–0.11% | 行业指数债券ETF平均0.09%（ICI 2026报告） |
| 另类/私募基金 | 1.0%–1.5% | 包含管理费+绩效费 |
| **组合加权底层费用** | **约 0.18%** | — |

### 全口径成本估算

| 费用项目 | 年费率 | 年金额 |
|----------|-------|--------|
| 鼎信管理费 | 0.56% | ¥402,000 |
| 底层基金费用 | 0.18% | ¥162,000 |
| 交易成本估算 | 0.02% | ¥18,000 |
| **全口径总成本** | **0.76%** | **¥582,000/年** |

### 费用行业对比

| 对比维度 | 鼎信财富 | 行业平均 | 说明 |
|----------|---------|---------|------|
| 管理费 | 0.56% | 1.00% | 显著低于行业平均（NerdWallet 2026数据） |
| 全口径成本 | 0.76% | 1.20%–1.50% | 包含底层基金和交易成本 |
| vs. Robo-Advisor | +0.26%–0.46% | — | 额外支出换来专属顾问、财务规划、税务策略等全方位服务 |
| vs. 自主管理 | +0.66% | — | 成本增量vs.预期回报提升约1.3%/年及风险降低 |

### 价值主张

您支付的管理费包含以下全部服务，无需额外付费：

- 投资组合构建与持续管理（全球12+资产类别动态再平衡）
- 税收损失收割策略（预计年均节税 ¥200,000–500,000，可部分或完全抵消管理费）
- 季度投资审查会议与年度财务规划更新
- 退休规划、子女教育规划、遗产规划
- 集中持股减持策略制定与执行
- ESG投资整合
- 7×24专属客户经理服务
- 数字化账户门户与实时报告

---

## VI. 启动流程 | Getting Started

### 账户开立流程

| 阶段 | 时间 | 行动内容 | 负责方 |
|------|------|---------|--------|
| **第一阶段：开户** | 第1-2周 | 签署投资管理协议 (IMA)；完成KYC/AML合规文件；开设托管账户 | 鼎信+客户 |
| **第二阶段：资金划转** | 第2-4周 | 将现有股票账户资产转入（in-kind transfer）；银行存款划转至托管账户 | 客户+托管银行 |
| **第三阶段：组合构建** | 第4-6周 | 分析转入持仓，制定过渡方案；分批执行再平衡（约4-6周完成） | 鼎信投资团队 |
| **第四阶段：首月回顾** | 第8周 | 首次投资审查会议；确认配置到位；讨论近期市场展望 | 鼎信+客户 |

### 资产转移时间表

| 资产类型 | 预计转移时间 | 注意事项 |
|----------|------------|---------|
| 现金及银行理财 | 3-5个工作日 | 提前确认赎回条款，部分理财产品可能有锁定期 |
| 国内股票账户（in-kind） | 5-10个工作日 | 通过券商间转托管完成，无需立即卖出 |
| 保险及年金 | 2-4周 | 需评估退保成本vs.持有价值，可能保留部分 |
| 公司股权（IPO后） | 锁定期结束后分阶段 | 需制定详细的10b5-1减持计划 |

### 前90天计划

| 时间段 | 里程碑 | 详细内容 |
|--------|--------|---------|
| **第1-30天** | 账户建立与初始配置 | 完成所有合规文件；划转约70%的流动资产；建立核心ETF配置 |
| **第31-60天** | 完善配置与首次TLH | 完成剩余资产转移；执行首次税收损失收割机会扫描；建立REITs和债券配置 |
| **第61-90天** | 首次审查与优化 | 首次正式投资审查会议；评估初始配置表现；微调配比至目标权重；讨论IPO后股权减持时间表 |

### 所需文件清单

- [ ] 身份证明（身份证/护照）
- [ ] 婚姻证明文件
- [ ] 资金来源证明
- [ ] 现有券商账户信息
- [ ] 最近三年个人所得税申报记录
- [ ] 公司股权结构及IPO相关文件
- [ ] 保险及年金保单
- [ ] 不动产产权证明
- [ ] 遗嘱或信托文件（如有）
- [ ] 签署投资管理协议 (IMA)
- [ ] 签署托管协议
- [ ] 完成风险承受能力问卷

### 下一步行动

1. **本周内**：审阅本建议书并准备反馈意见
2. **下周**：安排与投资团队的面对面会议，深入讨论策略细节
3. **两周内**：签署投资管理协议，启动账户开立流程
4. **30天内**：完成首批资产转移，开始组合构建

---

## VII. 附录与免责声明 | Appendix & Disclaimers

### 附录 A：ESG整合方法

我们采用MSCI ESG评级框架对投资标的进行筛选：

- **排除标准**：烟草生产、博彩业、争议性武器、化石燃料扩张（新项目）
- **偏好标准**：MSCI ESG评级BBB以上；碳排放强度低于行业平均水平
- **参与策略**：对持有头寸中ESG表现有待改善的公司，通过代理投票和股东提案推动变革

### 附录 B：再平衡策略

| 参数 | 设定 |
|------|------|
| **再平衡触发条件** | 任一资产类别偏离目标配比超过±3个百分点 |
| **再平衡频率** | 至少每季度检查一次；必要时月度调整 |
| **再平衡方式** | 优先使用新增资金和分红再投资；其次通过买入/卖出操作 |
| **税务考量** | 再平衡操作优先在递延税账户中执行，避免触发不必要的应税事件 |

### 附录 C：关键市场假设

| 假设参数 | 数值 | 来源 |
|----------|------|------|
| 美国通胀预期（10年） | 2.3% | Vanguard VCMM Q1 2026 |
| 美国GDP增长预期 | 2.1% | Northern Trust 2026 CMA |
| 无风险利率（10年期国债） | 3.8% | 当前市场利率 |
| 新兴市场GDP增长 | 3.2%（实际） | PGIM 2026 CMA |
| 全球财富管理市场规模 | $160.15万亿（2026预测） | Statista |

### 免责声明

**重要提示：** 本投资建议书仅供参考，不构成投资建议或投资邀约。

1. **预测性声明**：本文件中包含的所有回报预测、情景分析和Monte Carlo模拟结果均基于历史数据和统计模型，不代表对未来业绩的保证或承诺。实际投资回报可能与预测存在重大差异。

2. **资本市场假设**：本文件引用的资本市场假设（CMA）来自Vanguard、BlackRock、J.P. Morgan、Northern Trust、AQR、PGIM、Cohen & Steers等第三方机构的公开发布数据（截至2026年Q1）。这些假设反映的是这些机构对各类资产未来10年预期回报的中位数估计，具有高度不确定性。

3. **过往业绩**：过往业绩不代表未来表现。S&P 500过去10年年化回报约14%的历史数据（来源：Macrotrends、Curvo）不应用于推断未来回报。Vanguard 2026年预测美国大盘股未来10年年化回报仅为4%–5%。

4. **投资风险**：所有投资均涉及风险，包括可能损失全部本金。国际投资涉及额外的汇率风险、政治风险和流动性风险。另类投资（私募股权、REITs、基础设施）涉及流动性风险和更高的波动性。

5. **税务建议**：本文件中的税务策略讨论仅为一般性信息，不构成税务建议。请在做出任何税务相关决策前咨询您的独立税务顾问。

6. **费用说明**：管理费和其他费用将减少客户的实际投资回报。全口径成本估算基于当前费率，未来可能调整。

7. **合规要求**：本建议书需经合规部门审核后方可正式提交给潜在客户。鼎信财富管理有限公司是注册投资顾问，受相关监管机构监督。

---

## Sources

- [Vanguard Capital Markets Model (VCMM) Forecasts](https://corporate.vanguard.com/content/corporatesite/us/en/corp/vemo/vemo-return-forecasts.html)
- [Vanguard 2026 Economic and Market Outlook](https://advisors.vanguard.com/insights/article/2026-economic-and-market-outlook)
- [Vanguard 2026 Outlook: Economic Upside, Stock Market Downside](https://corporate.vanguard.com/content/corporatesite/us/en/corp/vemo/2026-outlook-economic-upside-stock-market-downside.html)
- [BlackRock Capital Market Assumptions (Feb 2026)](https://www.blackrock.com/institutions/en-us/insights/thought-leadership/capital-market-assumptions)
- [J.P. Morgan Long-Term Capital Market Assumptions](https://am.jpmorgan.com/content/dam/jpm-am-aem/americas/us/en/institutional/insights/portfolio-insights/ltcma-full-report.pdf)
- [Northern Trust 2026 Capital Market Assumptions Report](https://ntam.northerntrust.com/content/dam/northern-trust/investment-management/global/en/documents/thought-leadership/2026/cma/2026-capital-market-assumptions-report.pdf)
- [AQR 2026 Capital Market Assumptions for Major Asset Classes](https://www.aqr.com/Insights/Research/Alternative-Thinking/2026-Capital-Market-Assumptions-for-Major-Asset-Classes)
- [PGIM 2026 Capital Market Assumptions](https://www.pgim.com/content/dam/pgim/us/en/pgim-center/active/documents/outlooks/2026/PGIM-2026-Capital-Market-Assumptions.pdf)
- [Cohen & Steers 2026 Real Estate Outlook](https://www.cohenandsteers.com/insights/three-data-points-driving-our-2026-real-estate-outlook/)
- [REIT.com - Portfolio Managers See Potential for REIT Outperformance in 2026](https://www.reit.com/news/articles/portfolio-managers-see-potential-for-reit-outperformance-in-2026)
- [KKR Private Infrastructure 2026 Outlook](https://www.kkr.com/insights/private-infrastructure-2026)
- [Principal Asset Management 2026 Private Infrastructure Outlook](https://www.principalam.com/us/insights/macro-views/2026-private-infrastructure-outlook)
- [NerdWallet - How Much Does a Financial Advisor Cost in 2026](https://www.nerdwallet.com/financial-advisors/learn/how-much-does-a-financial-advisor-cost)
- [AdvisorFinder - Financial Advisor Fees Explained 2026](https://advisorfinder.com/blog-posts/how-expensive-is-a-financial-advisor)
- [Vanguard ETF Fees & Minimums](https://investor.vanguard.com/investment-products/etfs/etf-fees)
- [ICI 2026 Perspective - Expense Ratio Report](https://www.ici.org/files/2026/per32-01.pdf)
- [Macrotrends - S&P 500 Historical Annual Returns](https://www.macrotrends.net/2526/sp-500-historical-annual-returns)
- [Curvo - S&P 500 Historical Performance](https://curvo.eu/backtest/en/market-index/sp-500)
- [Statista - Wealth Management Worldwide Market Forecast](https://www.statista.com/outlook/fmo/wealth-management/worldwide)
- [BNY 2026 Capital Market Assumptions](https://www.bny.com/wealth/global/en/insights/2026-capital-market-assumptions.html)
- [T. Rowe Price 2026 Capital Market Assumptions](https://www.troweprice.com/financial-intermediary/us/en/insights/articles/capital-market-assumptions.html)
- [BlackRock Private Markets Outlook 2026](https://www.blackrock.com/institutions/en-us/insights/thought-leadership/private-markets-outlook)

---

*鼎信财富管理有限公司 | Dingxin Wealth Management Co., Ltd.*

*本文件编制日期：2026年5月10日 | 版本：V1.0*

*联系方式：investment@dingxinwealth.com | +86 21 8888 8888*
