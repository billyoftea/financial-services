[DATA SOURCE: WebSearch -- S&P 500 Q1 2026 returns (FactSet, Motley Fool, Novel Investor); US GDP Q1 2026 advance estimate (BEA, Advisor Perspectives, JEC); Federal Reserve fed funds rate May 2026 (FRED, Trading Economics, Forbes); Cybersecurity sector ETF performance (Yahoo Finance CIBR, Kavout, Cybersecurity Ventures); Software/SaaS valuation multiples 2026 (Aventis Advisors, SaaS Mag, Breakwater M&A, McKinsey Global PE Report); SaaS Rule of 40 & NRR benchmarks 2026 (Aventis Advisors, G2CFO, Software Equity Group, FE International, Optifai, SaaS Capital); Data infrastructure market outlook 2026 (Colliers, Morgan Stanley, ENR, IndexBox); 10-Year Treasury yield May 2026 (FRED, WSJ, Macrotrends)]

# Growth Equity Fund IV -- 季度投资组合监控报告

**报告期：2026年第一季度（截至2026年3月31日）**
**报告日期：2026年5月9日**
**基金规模：$1.85B（承诺资本）/ $1.42B（已投资本）**

---

## 一、执行摘要

Growth Equity Fund IV 的8家投资组合公司整体表现**略低于年初预算计划**，加权平均收入完成率为预算的**96.8%**，EBITDA完成率为**94.3%**。虽然宏观经济环境在Q1经历了较大波动（S&P 500下跌约4.6%），但网络安全和云基础设施领域的长期需求驱动因素保持不变。**2家公司亮红灯**（AIOps Inc和HealthSecure，均超出15%预算偏差阈值），**2家公司亮黄灯**（SecureNet和DevTools Pro），**4家公司保持绿灯**状态。基金层面的毛IRR预计为**18.4%**，净IRR为**14.2%**，略低于上季度的19.1%/14.8%。

**关键宏观背景：**
- S&P 500 Q1 2026回报：**-4.6%**（Vanguard Small Cap Index为+1.9%）
- 美国实际GDP Q1年化增长率：**2.0%**（较Q4 2025的0.5%显著反弹）
- 联邦基金利率：**3.50%-3.75%**（连续三次FOMC会议维持不变）
- 10年期国债收益率：**~4.40%**（较Q4上升约15bp）
- 网络安全ETF（CIBR）YTD回报：**+2.5%**，1年期+13.5%
- SaaS行业中位数NRR：**101-106%**，Rule of 40（FCF基准）中位数：**39.1%**
- PE收购进入倍数中位数：**11.8x EBITDA**（较2024年的11.3x上升）

---

## 二、投资组合公司KPI总览表

### 2.1 核心财务指标（单位：百万美元，除特别注明外）

| 指标 | CyberShield | DataStream | CloudPeak | SecureNet | AIOps Inc | DevTools Pro | FinGuard | HealthSecure |
|------|-------------|------------|-----------|-----------|-----------|--------------|----------|--------------|
| **行业** | 网络安全 | 数据基础设施 | 云平台 | 网络安全 | AI运维 | 开发者工具 | 金融科技安全 | 医疗数据安全 |
| **收入（实际）** | $48.2 | $72.5 | $39.1 | $28.4 | $22.3 | $15.7 | $31.6 | $18.9 |
| **收入（预算）** | $47.0 | $70.0 | $38.0 | $30.5 | $27.0 | $16.5 | $31.0 | $23.0 |
| **收入偏差(%)** | +2.6% | +3.6% | +2.9% | -6.9% | -17.4% | -4.8% | +1.9% | -17.8% |
| **YoY增长率** | +32% | +38% | +29% | +22% | +15% | +19% | +27% | +11% |
| **EBITDA（实际）** | $12.5 | $16.7 | $8.6 | $5.4 | $2.1 | $3.2 | $7.9 | $1.5 |
| **EBITDA（预算）** | $12.0 | $16.0 | $8.3 | $6.2 | $3.8 | $3.5 | $7.5 | $2.8 |
| **EBITDA利润率** | 26.0% | 23.0% | 22.0% | 19.0% | 9.4% | 20.4% | 25.0% | 7.9% |
| **现金余额** | $35.0 | $48.2 | $22.5 | $14.1 | $8.3 | $11.2 | $19.8 | $6.5 |
| **净负债** | $12.0 | $18.5 | $8.0 | $22.0 | $5.0 | $2.5 | $10.0 | $12.0 |
| **杠杆比率(ND/LTM EBITDA)** | 0.3x | 0.4x | 0.3x | 1.2x | 0.7x | 0.2x | 0.4x | 2.3x |
| **利息覆盖倍数** | 12.5x | 10.8x | 9.6x | 3.2x | 1.8x | 8.0x | 9.4x | 1.1x |
| **自由现金流** | $8.2 | $11.5 | $5.3 | $1.2 | -$1.8 | $2.4 | $5.1 | -$2.3 |
| **Capex** | $3.2 | $4.8 | $2.8 | $2.5 | $3.5 | $1.2 | $2.1 | $1.8 |

### 2.2 运营KPI

| 运营指标 | CyberShield | DataStream | CloudPeak | SecureNet | AIOps Inc | DevTools Pro | FinGuard | HealthSecure |
|----------|-------------|------------|-----------|-----------|-----------|--------------|----------|--------------|
| **ARR** | $193M | $290M | $156M | $114M | $89M | $63M | $126M | $76M |
| **NRR（净收入留存率）** | 125% | 132% | 118% | 108% | 96% | 112% | 121% | 88% |
| **客户数量** | 420 | 285 | 380 | 310 | 175 | 520 | 195 | 145 |
| **净新增客户（Q1）** | +28 | +15 | +22 | +8 | +3 | +18 | +12 | +2 |
| **收入/客户** | $115K | $254K | $103K | $92K | $127K | $30K | $162K | $130K |
| **员工人数** | 485 | 620 | 395 | 340 | 265 | 180 | 310 | 210 |
| **收入/员工** | $99.4K | $116.9K | $99.0K | $83.5K | $84.2K | $87.2K | $101.9K | $90.0K |
| **毛利率** | 82% | 78% | 76% | 74% | 68% | 85% | 80% | 71% |
| **Rule of 40** | 58% | 61% | 51% | 41% | 24% | 39% | 52% | 19% |
| **LTV/CAC** | 5.2x | 6.1x | 4.8x | 3.5x | 2.1x | 4.3x | 4.9x | 1.8x |

---

## 三、信号灯汇总

### 状态定义：
- **绿灯** -- 偏差在预算的+/-5%以内
- **黄灯** -- 偏差在预算的-5%至-15%之间，需关注讨论
- **红灯** -- 偏差超过-15%或存在债务契约违约风险，需立即行动

| 公司 | 收入偏差 | EBITDA偏差 | 信号灯 | 关键问题 |
|------|----------|------------|--------|----------|
| CyberShield | +2.6% | +4.2% | **绿灯** | 强劲增长，NRR 125%领先行业 |
| DataStream | +3.6% | +4.4% | **绿灯** | 数据基础设施需求旺盛，ARR增长最快 |
| CloudPeak | +2.9% | +3.6% | **绿灯** | 云迁移持续驱动增长，现金充足 |
| FinGuard | +1.9% | +5.3% | **绿灯** | 金融合规需求稳定，FCF强劲 |
| SecureNet | -6.9% | -12.9% | **黄灯** | 大客户续约延迟，杠杆偏高 |
| DevTools Pro | -4.8% | -8.6% | **黄灯** | ARR增长放缓，竞争压力加大 |
| AIOps Inc | -17.4% | -44.7% | **红灯** | 产品市场化受阻，烧钱加速，NRR跌破100% |
| HealthSecure | -17.8% | -46.4% | **红灯** | 医疗客户采购周期延长，杠杆2.3x接近违约 |

---

## 四、红灯公司详细分析

### 4.1 AIOps Inc -- 红灯

**执行摘要：** AIOps Inc Q1收入$22.3M，较预算$27.0M偏差-17.4%，EBITDA仅$2.1M（预算$3.8M），EBITDA利润率降至9.4%。核心问题是AI运维产品的市场接受度低于预期，NRR从上季度的105%降至96%，客户净新增仅3个。自由现金流为-$1.8M，按当前消耗速度现金跑道约4.6个月。

**关键问题：**
1. **产品-市场匹配问题：** AI运维模块的部署周期长达6-9个月，超出客户预期，导致POC转化率仅18%（行业基准30-40%）
2. **客户集中度：** 前5大客户占收入52%，其中1家大型云厂商客户Q1续约金额缩减40%
3. **人员成本失控：** 工程团队过去12个月扩张65%，但人均收入仅$84.2K，远低于绿灯公司的$100K+
4. **Rule of 40仅24%：** 远低于SaaS行业中位数39.1%（FCF基准），处于底部四分位

**管理团队行动项：**
- [ ] 30天内完成产品路线图重新评估，缩短部署周期至3个月
- [ ] 冻结非关键岗位招聘，将员工增长控制在10%以内
- [ ] 启动战略备选方案评估（包括潜在出售给战略买家）
- [ ] 与现有投资者讨论过桥融资可能性，确保12个月运营资金

**估值更新：** 基于当前绩效，建议将EV/Revenue倍数从5.5x下调至3.5-4.0x ARR区间（参照2026年私募SaaS中位数4.5x，但低于预算执行率的公司折价20-30%）。隐含估值从$490M降至$312-356M，基金层面可能需计提**$30-35M**的未实现减值。

---

### 4.2 HealthSecure -- 红灯

**执行摘要：** HealthSecure Q1收入$18.9M，较预算$23.0M偏差-17.8%，为全组合表现最差。EBITDA仅$1.5M（预算$2.8M），杠杆比率2.3x，利息覆盖倍数仅1.1x，**接近债务契约阈值**（ covenant要求利息覆盖>1.0x，杠杆<3.0x）。自由现金流-$2.3M，现金余额$6.5M。

**关键问题：**
1. **医疗行业采购冻结：** 多家大型医疗系统因2026年预算重新审核推迟了安全平台采购决策，Q1 pipeline转化率仅12%
2. **HIPAA合规升级成本：** 产品架构升级以满足2026年新HIPAA安全规则要求，产生一次性工程费用$3.5M
3. **关键人员流失：** CTO和VP Sales在过去90天内相继离职，影响产品交付和销售执行力
4. **杠杆风险：** 净负债$12.0M / LTM EBITDA $5.2M = 2.3x，距离3.0x契约上限仅0.7x缓冲

**债务契约合规状态：**

| 契约条款 | 要求 | Q1实际 | 缓冲空间 | 状态 |
|----------|------|--------|----------|------|
| 最大杠杆（Net Debt/EBITDA） | <3.0x | 2.3x | 0.7x | 合规但趋紧 |
| 最低利息覆盖（EBITDA/利息） | >1.0x | 1.1x | 0.1x | **危险接近违约** |
| 最低EBITDA（滚动12月） | $4.0M | $5.2M | $1.2M | 合规 |
| 最低现金余额 | $5.0M | $6.5M | $1.5M | 合规 |

**管理团队行动项：**
- [ ] 立即与贷款银行沟通，讨论契约豁免或修订（提前主动沟通）
- [ ] 60天内完成CTO和VP Sales的替代人选招聘
- [ ] 削减非核心研发支出$2M，重点保障HIPAA合规项目
- [ ] 评估非核心资产剥离或战略合作以改善现金流

**估值更新：** Rule of 40仅19%，LTV/CAC 1.8x（低于3.0x健康阈值），建议倍数从4.0x下调至2.5-3.0x ARR。隐含估值从$304M降至$190-228M，基金层面可能需计提**$25-30M**未实现减值。若触发债务违约，情景分析下行风险可达$120-140M。

---

## 五、黄灯公司详细分析

### 5.1 SecureNet -- 黄灯

**执行摘要：** 收入$28.4M（预算$30.5M，偏差-6.9%），EBITDA $5.4M（预算$6.2M，偏差-12.9%）。主要受2笔大型企业续约延迟至Q2影响（合计$3.2M ARR），并非基本面恶化。NRR 108%处于行业低端但仍在健康范围。杠杆1.2x需关注但尚可控。

**管理团队讨论要点：**
- 续约延迟是暂时性还是结构性问题？客户是否在评估替代方案？
- 竞争格局变化：是否有新的低价竞争者侵蚀市场份额？
- 杠杆1.2x的债务偿还计划：是否需提前偿还以降低利息成本？

### 5.2 DevTools Pro -- 黄灯

**执行摘要：** 收入$15.7M（预算$16.5M，偏差-4.8%），EBITDA $3.2M（预算$3.5M，偏差-8.6%）。开发者工具市场竞争加剧，GitHub Copilot等AI辅助工具的普及对传统DevOps工具链形成替代压力。NRR 112%健康但呈下行趋势（上季度116%）。毛利率85%为全组合最高，体现轻资产优势。

**管理团队讨论要点：**
- AI集成路线图进展如何？能否在Q2推出AI辅助功能以保持竞争力？
- 免费用户到付费用户的转化率趋势如何？
- 是否考虑通过收购补充AI能力？

---

## 六、绿灯公司亮点

### 6.1 CyberShield -- 表现最佳
- NRR 125%超过最佳-in-class公共SaaS基准（120-125%），客户粘性极强
- Rule of 40达58%，在全组合中仅次于DataStream
- Q1签署3笔>$1M ARR的大型企业合同，pipeline创历史新高
- 估值支撑：参照2026年网络安全SaaS估值溢价（NRR 120%+的公司享受约63%估值溢价，来源：Software Equity Group），维持6.0x ARR倍数，隐含估值$1.16B

### 6.2 DataStream -- 增长最快
- ARR增长率38%为全组合最高，受益于数据基础设施投资热潮（全球数据中心市场2025年达$384B，2026-2033年CAGR 11.3%）
- NRR 132%为全组合最高，体现数据基础设施的高切换成本
- 估值参照：数据基础设施SaaS在2026年享受溢价倍数，维持5.5x ARR，隐含估值$1.60B
- AI驱动需求：UBS估计2026年全球AI基础设施投资达$500B+，直接利好DataStream的产品定位

### 6.3 CloudPeak -- 稳健增长
- 云迁移持续为收入增长提供结构性支撑
- Morgan Stanley将"数据中心及其电力需求"列为2026年基础设施领域最重要的两大趋势
- FCF $5.3M，现金余额$22.5M，财务状况健康

### 6.4 FinGuard -- 合规驱动
- 金融行业监管趋严持续推动需求增长
- EBITDA利润率25%为全组合最高之一（不含问题公司）
- Rule of 40达52%，远超行业中位数39.1%

---

## 七、基金层面估值更新

### 7.1 投资组合估值汇总（百万美元）

| 公司 | 投入成本 | 上期估值 | 当期估值 | MoM | IRR（毛） | EV/ARR倍数 |
|------|----------|----------|----------|-----|-----------|-----------|
| CyberShield | $180 | $980 | $1,158 | 6.4x | 42% | 6.0x |
| DataStream | $250 | $1,250 | $1,595 | 6.4x | 44% | 5.5x |
| CloudPeak | $150 | $620 | $780 | 5.2x | 38% | 5.0x |
| SecureNet | $120 | $420 | $399 | 3.3x | 25% | 3.5x |
| AIOps Inc | $100 | $490 | $334 | 3.3x | 22% | 3.8x |
| DevTools Pro | $65 | $275 | $284 | 4.4x | 32% | 4.5x |
| FinGuard | $110 | $520 | $630 | 5.7x | 40% | 5.0x |
| HealthSecure | $85 | $304 | $209 | 2.5x | 18% | 2.8x |
| **合计** | **$1,060** | **$4,855** | **$5,389** | **5.1x** | **36%** | -- |

### 7.2 估值方法与基准

估值倍数基于以下实际市场基准：
- **PE收购进入倍数中位数（2025）：** 11.8x EBITDA（McKinsey Global PE Report 2026）
- **公共SaaS EV/Revenue中位数：** ~6.1x（Aventis Advisors 2026）
- **私募SaaS EV/Revenue中位数：** ~4.7x（Aventis Advisors 2026）
- **高增长SaaS EBITDA倍数范围：** 10-25x（Praxis Rock 2026）
- **中低端市场SaaS收入倍数：** 3-6x（Windsor Drake 2026）

本基金各公司的倍数根据Rule of 40得分、NRR水平、增长率和执行质量在2.8x-6.0x ARR区间内确定，与上述行业基准一致。

### 7.3 DPI / TVPI 更新

| 指标 | 数值 |
|------|------|
| 已投入资本（Paid-in） | $1,060M |
| 已实现回报（Distributions） | $280M |
| 未实现价值（NAV） | $5,389M |
| **DPI** | **0.26x** |
| **TVPI** | **5.35x** |
| **RVPI** | **5.08x** |

---

## 八、趋势分析

### 8.1 季度收入趋势（过去4个季度，百万美元）

| 公司 | Q2 2025 | Q3 2025 | Q4 2025 | Q1 2026 | 趋势 |
|------|---------|---------|---------|---------|------|
| CyberShield | $38.5 | $41.2 | $44.8 | $48.2 | 加速增长 |
| DataStream | $55.0 | $60.5 | $66.0 | $72.5 | 加速增长 |
| CloudPeak | $30.5 | $33.0 | $35.8 | $39.1 | 稳定增长 |
| SecureNet | $24.0 | $25.5 | $27.0 | $28.4 | 减速增长 |
| AIOps Inc | $19.5 | $20.0 | $21.5 | $22.3 | 明显减速 |
| DevTools Pro | $13.0 | $14.0 | $15.0 | $15.7 | 轻微减速 |
| FinGuard | $24.5 | $26.5 | $29.0 | $31.6 | 加速增长 |
| HealthSecure | $16.0 | $16.5 | $17.5 | $18.9 | 减速增长 |

### 8.2 趋势观察

- **加速增长（3家）：** CyberShield、DataStream、FinGuard -- 受益于网络安全合规需求和AI/数据基础设施投资热潮
- **稳定增长（2家）：** CloudPeak、DevTools Pro -- 增长轨道可预测
- **减速增长（3家）：** SecureNet（续约延迟）、AIOps Inc（产品市场匹配问题）、HealthSecure（行业采购周期延长）

---

## 九、关键风险与关注事项

### 9.1 宏观风险
| 风险因素 | 影响评估 | 概率 |
|----------|----------|------|
| 利率维持高位（10Y @ 4.40%） | 压制退出估值倍数，增加融资成本 | 高 |
| 美国经济放缓风险 | 企业IT预算削减，影响所有组合公司 | 中 |
| 地缘政治风险 | 供应链和安全需求可能同时受益和受损 | 中 |

### 9.2 组合层面风险
| 风险 | 涉及公司 | 行动建议 |
|------|----------|----------|
| 债务契约违约 | HealthSecure | 立即与银行沟通修订条款 |
| 现金消耗过快 | AIOps Inc, HealthSecure | 启动过桥融资或成本削减 |
| 关键人员流失 | HealthSecure（CTO、VP Sales已离职）| 加速替代招聘 |
| 竞争格局恶化 | DevTools Pro, SecureNet | 强化AI功能路线图 |

---

## 十、待管理层讨论问题

### 全组合层面：
1. 基金层面的$30-35M（AIOps）+ $25-30M（HealthSecure）潜在减值是否需要在Q1报告中确认？
2. 是否需要启动AIOps Inc的战略备选方案（出售/合并）评估？
3. 基金剩余$430M未投资承诺资本的部署节奏和时间表？

### 各公司专项：
4. **AIOps Inc：** 产品路线图调整方案何时能完成？POC转化率18%是否结构性偏低？
5. **HealthSecure：** 银行对契约修订的初步反馈如何？是否需要考虑注资减债？
6. **SecureNet：** Q2延迟续约的$3.2M ARR确认概率有多大？
7. **DevTools Pro：** AI功能集成路线图能否在Q2 GA？竞争定位如何维护？
8. **CyberShield/DataStream：** 作为明星资产，是否已开始规划退出路径？IPO市场窗口评估？

---

## 十一、下季度展望

基于当前宏观环境和各公司pipeline，Q2 2026关键预期：

| 公司 | Q2收入预期 | 关键驱动因素 | 信心度 |
|------|-----------|-------------|--------|
| CyberShield | $52-54M | 3笔大合同开始确认收入 | 高 |
| DataStream | $78-82M | 新产品线贡献，AI需求持续 | 高 |
| CloudPeak | $41-43M | 云迁移季节性旺季 | 高 |
| SecureNet | $30-32M | 续约回补（若延迟合同确认） | 中 |
| AIOps Inc | $22-24M | 需产品突破才能扭转 | 低 |
| DevTools Pro | $16-17M | AI功能发布或提供增量 | 中 |
| FinGuard | $34-36M | 合规季节性旺季 | 高 |
| HealthSecure | $19-21M | 新CTO到岗或改善执行 | 低 |

---

## 附录：行业基准对照

| 基准指标 | SaaS行业中位数2026 | 本基金中位数 | 评估 |
|----------|-------------------|-------------|------|
| NRR（净收入留存率） | 101-106% | 115% | **优于基准** |
| Rule of 40（FCF） | 39.1% | 43% | **优于基准** |
| 毛利率 | 75-80% | 77% | **持平** |
| 收入增长率（YoY） | 20-25% | 24% | **持平** |
| EBITDA利润率 | 15-20% | 17.8% | **持平** |
| EV/Revenue（私募） | 4.7x | 4.5x | **略低于基准**（受红灯公司拖累） |

**注：** 以上SaaS行业基准来源于Aventis Advisors 2026 SaaS估值报告、G2CFO 2026 SaaS基准和Software Equity Group 2026年度SaaS报告。

---

*本报告基于各投资组合公司提交的Q1 2026财务数据包编制，结合公开市场数据和行业基准。所有估值均为管理层估计的公允价值，最终估值需经基金审计师和估值委员会确认。*

---

## Sources

- [FactSet -- S&P 500 Earnings Season Update May 1, 2026](https://insight.factset.com/sp-500-earnings-season-update-may-1-2026)
- [Motley Fool -- S&P 500 Q1 2026 Negative Territory](https://www.fool.com/investing/2026/03/25/the-sp-500-is-on-track-to-finish-q1-in-negative-te/)
- [Novel Investor -- 2026 Q1 Returns](https://novelinvestor.com/2026-q1-returns/)
- [BEA -- Gross Domestic Product](https://www.bea.gov/data/gdp/gross-domestic-product)
- [Advisor Perspectives -- Q1 2026 GDP Advance Estimate](https://www.advisorperspectives.com/dshort/updates/2026/04/30/gdp-gross-domestic-product-q1-2026-advance-estimate)
- [JEC Senate -- GDP Update](https://www.jec.senate.gov/public/index.cfm/republicans/gdp-update)
- [FRED -- Federal Funds Effective Rate](https://fred.stlouisfed.org/series/FEDFUNDS)
- [Trading Economics -- US Interest Rate](https://tradingeconomics.com/united-states/interest-rate)
- [Forbes -- Federal Funds Rate History](https://www.forbes.com/advisor/investing/fed-funds-rate-history/)
- [FRED -- 10-Year Treasury Yield](https://fred.stlouisfed.org/series/DGS10)
- [Macrotrends -- 10 Year Treasury Yield](https://www.macrotrends.net/2016/10-year-treasury-bond-rate-yield-chart)
- [WSJ -- Treasury Bond Yields](https://www.wsj.com/market-data/quotes/bond/BX/TMUBMUSD10Y)
- [Yahoo Finance -- CIBR Performance](https://finance.yahoo.com/quote/CIBR/performance/)
- [Kavout -- Cybersecurity Sector Growth 2026](https://www.kavout.com/market-lens/is-the-cybersecurity-sector-poised-for-explosive-growth-in-2026)
- [Cybersecurity Ventures -- Global Security Spending](https://cybersecurityventures.com/the-nasdaq-cybersecurity-etf-looks-like-one-of-2026s-best-investments/)
- [McKinsey -- Global Private Equity Report 2026](https://www.mckinsey.com/industries/private-capital/our-insights/global-private-markets-report/private-equity)
- [Aventis Advisors -- SaaS Valuation Multiples](https://aventis-advisors.com/saas-valuation-multiples/)
- [Aventis Advisors -- Rule of 40 in SaaS 2026](https://aventis-advisors.com/rule-of-40-in-saas-2026/)
- [SaaS Mag -- SaaS Consolidation Wave 2026](https://www.saasmag.com/saas-consolidation-ma-wave-2026/)
- [Breakwater M&A -- Software Company Valuation Multiples 2026](https://www.breakwaterma.com/blog/software-company-valuation-multiples-2026)
- [Windsor Drake -- SaaS Valuation Multiples 2026](https://windsordrake.com/saas-valuation-multiples/)
- [Software Equity Group -- SEG 2026 Annual SaaS Report](https://softwareequity.com/research/annual-saas-report)
- [Software Equity Group -- Net Retention and Valuation](https://softwareequity.com/blog/net-retention-public-saas-companies)
- [G2CFO -- SaaS Benchmarks 2026](https://www.gsquaredcfo.com/blog/saas-benchmarks-2026)
- [FE International -- NRR SaaS Valuation Guide](https://www.feinternational.com/blog/net-revenue-retention-saas-valuation)
- [Optifai -- B2B SaaS NRR Benchmarks](https://optif.ai/learn/questions/b2b-saas-net-revenue-retention-benchmark/)
- [SaaS Capital -- Bootstrapped SaaS Benchmarks 2026](https://www.saas-capital.com/blog-posts/benchmarking-metrics-for-bootstrapped-saas-companies/)
- [Colliers -- 2026 Data Center Marketplace Report](https://www.colliers.com/en/research/nrep-usdc-data-center-marketplace-2026)
- [Morgan Stanley -- Infrastructure 2026 Outlook](https://www.morganstanley.com/im/en-us/institutional-investor/insights/outlooks/infrastructure-2026-outlook.html)
- [IndexBox -- Data Infrastructure Stocks Q1 2026](https://www.indexbox.io/blog/data-infrastructure-stocks-post-mixed-q1-2026-results/)
- [NYU Stern Damodaran -- EV/EBITDA by Sector](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/vebitda.html)
- [Praxis Rock -- EBITDA Multiples by Industry 2026](https://praxisrock.com/insights/ebitda-multiples-by-industry)
