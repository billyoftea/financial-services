[DATA SOURCE: Gartner Information Security Forecast 2023-2029 (3Q25 Update); IDC Worldwide Public Cloud Services Forecast 2025-2026; Momentum Cyber Almanac 2025 Year-End Report; Company IR filings (PANW, CRWD, FTNT, ZS, OKTA, S); Fortune Business Insights Cybersecurity Market Report 2025; WEF Global Cybersecurity Outlook 2026; Capstone Partners Cybersecurity M&A Update; Solganick Cybersecurity M&A Q4 2025; Mordor Intelligence Zero Trust Market Report 2025; Coherent Market Insights SASE Market Forecast 2026-2033; Finro Cybersecurity Valuation Multiples 2025; NYU Stern / Prof. Damodaran EV Multiples by Sector (Jan 2026)]

# B2B SaaS / 网络安全行业概览报告

**报告日期：2026年5月10日 | 研究类型：行业全景分析**
**覆盖范围：全球网络安全及B2B安全SaaS市场**

---

## 一、市场概述与规模

### 1.1 全球网络安全市场规模

全球信息安全终端用户支出预计在2025年达到**2,130亿美元**，2026年进一步增长至**2,440亿美元**，同比增长约**11.6%**（恒定汇率计算）。根据Gartner预测，该市场将以**10.9%的复合年增长率（CAGR）**增长，至2029年达到**3,230亿美元**。

| 年份 | 市场规模（十亿美元） | 同比增速 | 来源 |
|------|---------------------|---------|------|
| 2023 | ~172 | ~12% | Gartner |
| 2024 | ~193 | ~12.2% | Gartner |
| 2025E | 213 | ~10.4% | Gartner (3Q25 Update) |
| 2026E | 244 | ~11.6% | Gartner (3Q25 Update) |
| 2029E | 323 | 10.9% CAGR | Gartner |

**交叉验证数据源：**

| 来源 | 2025E | 远期预测 | CAGR |
|------|-------|---------|------|
| MarketsandMarkets | $227.6B | $352B (2030) | 9.1% |
| Fortune Business Insights | ~$200B+ | $699B (2034) | 13.8% |
| Cybersecurity Ventures | — | $300B+ (2028) | ~10% |

### 1.2 B2B SaaS市场关联规模

根据IDC预测，全球SaaS应用收入在2025年预计增长至约**3,020亿美元**，SaaS约占公有云支出的60%。全球公有云服务支出预计在2026年突破**1万亿美元**，同比增长超过21%（IDC, 2025）。整体IT支出预计在2026年达到**6.15万亿美元**（Gartner, 2026年2月）。

### 1.3 市场细分

网络安全市场可按以下维度细分：

**按产品类别（2025年估算）：**
- 网络安全设备与软件：~$85B（40%）
- 云安全：~$35B（16%）——增速最快
- 身份与访问管理（IAM）：~$25B（12%）
- 终端安全（EDR/XDR）：~$20B（9%）
- 安全运营（SIEM/SOAR）：~$18B（8%）
- 数据安全与隐私：~$15B（7%）
- 其他（咨询、合规等）：~$15B（8%）

**按地理区域：**
- 北美：~42%
- 欧洲：~26%
- 亚太：~22%
- 其他地区：~10%

**按客户类型：**
- 大型企业（10,000+员工）：~55%
- 中型企业：~30%
- 小型企业和SMB：~15%

---

## 二、行业结构与竞争格局

### 2.1 行业集中度

网络安全市场呈现"大而散"的结构——头部厂商收入占比持续提升，但整体市场仍由数百家中型企业参与。Top 5纯网络安全厂商的合计市场份额约为**15-18%**，若计入Microsoft、Cisco等综合科技巨头则提高到约**25-30%**。

### 2.2 价值链分析

```
上游（芯片/硬件）→ 中游（平台/SaaS）→ 下游（MSSP/咨询/集成）
     │                    │                      │
  Intel, Broadcom    PANW, CRWD, ZS        Accenture, Deloitte
  NVIDIA, AMD        FTNT, OKTA, S         Wipro, IBM Consulting
  低附加值              高附加值/利润池           中等附加值
```

价值主要向**平台化SaaS**环节集中——订阅收入占比高、毛利率高（75-85%）、客户生命周期价值大。纯硬件和低端服务的利润率持续被压缩。

### 2.3 主要商业模式

| 模式 | 代表公司 | 毛利率 | 特点 |
|------|---------|-------|------|
| 订阅SaaS | CrowdStrike, Zscaler | 75-82% | ARR驱动，高NRR |
| 混合（硬件+订阅） | Palo Alto Networks, Fortinet | 70-78% | 正在向平台化转型 |
| 身份SaaS | Okta | 78-80% | 高粘性，用户数量驱动 |
| AI原生SaaS | SentinelOne | 72-76% | 高增长，利润率爬坡中 |
| 云平台服务 | Cloudflare, Microsoft | 60-80% | 生态捆绑优势 |

### 2.4 进入壁垒

- **技术壁垒**：威胁情报积累、AI/ML模型训练需要海量数据和时间
- **客户转换成本**：安全产品一旦部署，替换成本极高（6-18个月迁移周期）
- **合规与认证**：FedRAMP、SOC 2、ISO 27001等认证需要多年获取
- **网络效应**：数据网络效应——更多客户=更多威胁数据=更好的检测能力
- **品牌与信任**：安全是"零容忍"领域，品牌声誉至关重要

---

## 三、核心公司分析

### 3.1 竞争格局总览

| 公司 | 股票代码 | 最新年度收入 | 收入增速 | Non-GAAP营业利润率 | 主要领域 |
|------|---------|------------|---------|-------------------|---------|
| Palo Alto Networks | PANW | $9.2B (FY2025) | ~15% | ~28% | 网络安全+云安全+SOC |
| Fortinet | FTNT | $6.8B (CY2025) | ~14% | ~30%+ | 统一威胁管理/防火墙 |
| CrowdStrike | CRWD | ~$3.9B (FY2025) | ~20%+ | ~25% | 终端安全/XDR/云安全 |
| Zscaler | ZS | $2.67B (FY2025) | ~23% | ~20% | 零信任/SASE |
| Okta | OKTA | ~$2.56B (FY2025) | ~13-15% | ~27% | 身份与访问管理 |
| SentinelOne | S | ~$820M (FY2025) | ~29% | 亏损收窄中 | AI原生终端安全 |
| Cloudflare | NET | ~$1.6B+ | ~25%+ | 亏损收窄中 | Web安全/CDN/边缘 |
| Microsoft Security | MSFT | ~$20B+（估） | ~30%+ | 捆绑在云业务中 | 全栈安全 |
| Cisco Security | CSCO | ~$5B+ | — | 捆绑在网络业务中 | 网络+安全（含Splunk） |

### 3.2 核心公司详细画像

#### Palo Alto Networks (PANW)

- **业务描述**：全球最大的纯网络安全公司，提供从下一代防火墙到云安全（Prisma Cloud）再到AI驱动SOC（Cortex XSIAM）的全栈平台。FY2025收入92.2亿美元，同比增长15%。
- **战略护城河**：三大产品线（Strata/Prisma/Cortex）覆盖网络、云和运营三大领域，正在推进"平台化"战略（Platformization），引导客户从单点产品转向统一平台。
- **最新动态**：FY2025自由现金流41.3亿美元，FCF Margin约37.6%，为行业最高。FY2020至FY2025收入CAGR达22%。订阅和支持服务收入达74.2亿美元，占总收入的80%+。
- **估值参考**：EV/Revenue ~12-14x fwd, EV/EBITDA ~40-50x fwd

#### CrowdStrike (CRWD)

- **业务描述**：云原生终端安全领导者，Falcon平台覆盖EDR、身份保护、云安全和工作负载保护。FY2025收入约39亿美元，增速超20%。
- **战略护城河**：单一代理架构（single-agent）降低部署复杂度；庞大的威胁图谱（Threat Graph）利用AI实时分析数万亿事件/周；高净留存率（NRR >115%）。
- **最新动态**：Non-GAAP营业利润率从21.2%扩张至25%；GAAP仍亏损（SBC和摊销影响大）；FY2026 Q4订阅收入12.4亿美元，同比增长23%。
- **估值参考**：EV/Revenue ~15-18x fwd, EV/EBITDA ~80-100x fwd（高增长溢价）

#### Fortinet (FTNT)

- **业务描述**：以自研ASIC芯片和FortiOS操作系统为基础的垂直整合安全厂商，FortiGate防火墙市占率全球领先。2025年收入68亿美元，同比增长14%。
- **战略护城河**：自研芯片带来成本优势（毛利率行业前列）；统一操作系统降低TCO；庞大的渠道网络覆盖SMB和中型企业。
- **最新动态**：产品收入22.2亿美元（同比+16%）；积极扩展SASE和OT安全；GAAP营业利润率在纯安全厂商中最高之一。
- **估值参考**：EV/Revenue ~7-9x fwd, EV/EBITDA ~25-35x fwd（价值型定价）

#### Zscaler (ZS)

- **业务描述**：云原生零信任安全平台领导者，通过安全服务边缘（SSE）架构保护用户到应用的连接。FY2025收入26.7亿美元，同比增长23%。
- **战略护城河**：全球最大安全云之一，每日处理超过5,000亿个安全事务；零信任架构先发优势；高NDR（净美元留存率）。
- **最新动态**：ARR达30.2亿美元，同比增长22%；Non-GAAP EPS $3.28（同比大幅增长）；GAAP净亏损收窄至4,150万美元。
- **估值参考**：EV/Revenue ~14-16x fwd, EV/EBITDA ~60-70x fwd

#### Okta (OKTA)

- **业务描述**：领先的身份与访问管理（IAM）SaaS平台，提供单点登录（SSO）、多因素认证（MFA）和生命周期管理。FY2025收入约25.6亿美元，同比增长13-15%。
- **战略护城河**：身份是安全的"控制平面"——所有访问都必须经过身份验证；与数千个SaaS应用的预集成形成生态壁垒；客户量大且分散。
- **最新动态**：FY2025 Non-GAAP营业利润约7亿美元，FCF在Q4达2.84亿美元（42% FCF Margin），盈利能力显著改善。
- **估值参考**：EV/Revenue ~6-8x fwd, EV/EBITDA ~30-40x fwd

#### SentinelOne (S)

- **业务描述**：AI原生终端安全公司，Singularity平台从第一天就以数据科学和AI为核心设计。FY2025收入约8.2亿美元，同比增长29%。
- **战略护城河**：完全自主的AI检测引擎（无需人工定义规则）；Purple AI将自然语言查询转化为威胁狩猎；高增长率的独立EDR替代选项。
- **最新动态**：FY2026全年指引约10亿美元，即将突破关键的十亿收入门槛；亏损持续收窄但仍未实现GAAP盈利。
- **估值参考**：EV/Revenue ~7-9x fwd（增长放缓后估值回落）

---

## 四、增长驱动因素与行业趋势

### 4.1 五大长期增长动力（Secular Tailwinds）

**1. AI驱动的攻防升级（94%的受访领导者认为AI是网络安全领域最大的变革驱动力——WEF 2026）**

AI正在双向重塑网络安全：攻击者利用生成式AI生成更复杂的钓鱼邮件、自动化漏洞利用和深度伪造攻击；防御方则利用AI/ML实现威胁检测自动化、安全运营智能化（XDR/SOAR）和安全 Copilot。这场"AI军备竞赛"将持续推高安全支出。

**2. 零信任架构的加速普及**

零信任安全市场从2025年的约423亿美元增长至2026年的约494亿美元，保持双位数增长（Mordor Intelligence）。美国政府（OMB Memo M-22-09）要求联邦机构在2027年前全面实施零信任架构，这一合规要求正在向私营部门外溢。

**3. 云安全与SASE（Secure Access Service Edge）的融合**

云原生SASE市场预计从2026年的98亿美元增长至2033年的367亿美元，CAGR达20.8%（Coherent Market Insights）。企业向混合办公和多云架构的迁移推动SASE成为刚需，Zscaler、Palo Alto（Prisma SASE）和Fortinet（FortiSASE）是主要受益者。

**4. 监管与合规压力持续强化**

全球范围内的数据保护法规日趋严格——欧盟NIS2指令（2024年10月生效）、美国SEC网络安全披露规则（2023年通过）、中国《数据安全法》和《个人信息保护法》等——迫使企业增加合规相关安全投入。

**5. 平台整合（Platformization）趋势**

客户已出现"工具疲劳"——平均企业部署75+种安全工具。买方偏好正从最佳单点产品（best-of-breed）转向统一平台（platform），以降低复杂度、提升可见性和降低TCO。这一趋势利好Palo Alto Networks、CrowdStrike和Microsoft等平台型厂商。

### 4.2 关键风险与逆风因素

| 风险因素 | 影响程度 | 说明 |
|---------|---------|------|
| 宏观经济放缓 | 中 | 预算审查趋严，但安全支出相对刚性 |
| 估值泡沫 | 中高 | 部分高增长公司估值已透支多年增长预期 |
| Microsoft捆绑策略 | 高 | 将安全功能捆绑至Microsoft 365/Azure，挤压独立厂商 |
| 人才短缺 | 中 | 全球网络安全人才缺口约340万人（ISC2报告） |
| 地缘政治风险 | 中 | 供应链安全、数据主权和跨境合规增加复杂性 |

### 4.3 技术颠覆向量

- **AI-Native安全**：AI原生安全产品（如SentinelOne Purple AI、CrowdStrike Charlotte AI）正在重新定义安全运营
- **量子计算威胁**：后量子密码学（PQC）标准化的紧迫性上升，NIST已于2024年发布首批PQC标准
- **供应链安全**：软件物料清单（SBOM）和第三方风险管理成为强制要求
- **物联网/OT安全**：随着IT/OT融合加速，工控系统安全需求爆发

---

## 五、M&A与行业整合趋势

### 5.1 M&A市场概况

2025年网络安全领域M&A活动强劲反弹，全年交易总值约**1,020亿美元**，共发生**734轮融资**，其中**48笔交易金额超过1亿美元**（高于2024年的40笔）。2025年Q4单季完成105笔交易（Solganick）。

| M&A指标 | 2024 | 2025 | 变化 |
|---------|------|------|------|
| 总交易价值 | ~$76B | ~$102B | +34% |
| $100M+交易数 | 40 | 48 | +20% |
| 月均交易量 | ~30-35 | ~35-45 | +15-25% |

### 5.2 重大交易回顾

- **Cisco收购Splunk（$28B，2024年完成）**：标志性交易，将安全数据分析能力整合进Cisco生态
- **Palo Alto Networks持续收购**：多笔补强型收购（如Platformization战略下的目标公司）
- **私募股权活跃**：Thoma Bravo、Vista Equity Partners等PE持续大手笔收购网络安全资产

### 5.3 估值倍数参考

- M&A平均收入倍数：约**3.3x**（Capstone Partners, 2020-2023均值）
- 高增长目标（30%+增速）：4-6x EV/Revenue
- 成熟目标（10-15%增速）：2-4x EV/Revenue
- 公开市场EV/2025F收入倍数：头部厂商约10-16x，底部中位数约2.9x（ICON Corporate Finance）

---

## 六、估值分析

### 6.1 公开市场交易倍数

| 公司 | EV/Revenue (NTM) | EV/EBITDA (NTM) | P/E (NTM) | FCF Yield |
|------|-----------------|-----------------|-----------|-----------|
| PANW | ~12-14x | ~40-50x | ~50-60x | ~2.5-3.0% |
| CRWD | ~15-18x | ~80-100x | ~90-120x | ~1.0-1.5% |
| FTNT | ~7-9x | ~25-35x | ~35-45x | ~3.0-4.0% |
| ZS | ~14-16x | ~60-70x | N/M (亏损) | ~1.5-2.0% |
| OKTA | ~6-8x | ~30-40x | ~40-50x | ~2.5-3.5% |
| S | ~7-9x | N/M (亏损) | N/M | ~0% |
| **行业中位数** | **~8-10x** | **~45-55x** | **~50-60x** | **~2.0-2.5%** |

*注：估值数据基于2026年5月初市场数据，可能因股价波动而变化。*

### 6.2 相对估值分析

- **增长溢价**：收入增速每增加10个百分点，EV/Revenue倍数平均提升约3-4x
- **利润率溢价**：FCF Margin超过30%的厂商享受约20-30%的估值溢价
- **平台溢价**：平台型公司（PANW、CRWD）比单点产品公司估值高30-50%
- **网络安全 vs. B2B SaaS整体**：网络安全厂商交易倍数通常比一般SaaS高20-30%，反映更强的增长可见性和较低的经济敏感性

### 6.3 历史估值区间

网络安全行业EV/Revenue (NTM)的历史区间：
- 2021年高点：15-25x（低利率+高增长预期）
- 2022-2023年低点：5-10x（利率飙升+增长放缓）
- 2024-2025年复苏：8-16x（AI叙事+盈利改善）
- 当前水平（2026年5月）处于历史中位数偏上

---

## 七、投资启示

### 7.1 最佳风险回报机会

**高质量首选（Conviction Picks）：**
1. **Palo Alto Networks**：行业龙头，FCF Margin最高（37.6%），平台化战略正在加速份额集中。估值虽不便宜但相对合理。
2. **CrowdStrike**：终端安全领域无可争议的领导者，高NRR（>115%）确保收入可见性，利润率持续扩张。

**价值机会（Value Plays）：**
3. **Fortinet**：估值最便宜（EV/Revenue ~7-9x），GAAP利润率最高，渠道优势显著，适合风险偏好较低的投资者。
4. **Okta**：FCF改善显著（42% FCF Margin），身份安全是长期刚需，估值回落至合理区间。

**高增长概念（Growth Bets）：**
5. **SentinelOne**：AI原生差异化明显，即将突破$1B收入门槛，若能加速盈利路径则有重估空间。

### 7.2 核心辩论

| 主题 | 多方论点 | 空方论点 |
|------|---------|---------|
| **平台化 vs. 单点产品** | 平台降低TCO，提升效率，长期份额集中 | 客户仍选best-of-breed，转换慢于预期 |
| **AI的净影响** | AI驱动检测效率提升，新收入来源 | AI降低攻击门槛，推高防御成本，侵蚀利润 |
| **Microsoft威胁** | 独立厂商创新更快，专业化优势 | 捆绑策略对中小企业极具吸引力 |
| **估值可持续性** | 增长可见性高，利润率扩张路径清晰 | 高倍数依赖低利率环境，经济衰退将压缩估值 |

### 7.3 关键催化剂

- **上行催化剂**：重大网络攻击事件（提升安全预算紧迫性）、AI安全产品商业化加速、超预期盈利增长、利率下行
- **下行催化剂**：宏观经济衰退导致IT预算削减、Microsoft捆绑策略侵蚀份额、主要厂商安全事件（如CrowdStrike 2024年全球宕机事件重演）、估值压缩

### 7.4 主题性投资表达

- **零信任/SASE** → Zscaler, Palo Alto Networks (Prisma SASE)
- **AI安全** → CrowdStrike (Charlotte AI), SentinelOne (Purple AI)
- **身份安全** → Okta, CyberArk
- **安全运营自动化** → Palo Alto (Cortex XSIAM), CrowdStrike
- **OT/物联网安全** → Fortinet, Claroty (私有)

---

## 八、关键图表建议

1. **市场规模瀑布图**：从2024年$193B到2029年$323B的增长分解（按细分市场贡献）
2. **竞争定位矩阵**：X轴=产品广度，Y轴=增长速度，气泡大小=收入规模
3. **估值散点图**：X轴=收入增速，Y轴=EV/Revenue NTM
4. **自由现金流利润率趋势**：PANW/CRWD/FTNT/OKTA的FCF Margin 5年趋势
5. **市场份额变化**：Top 5厂商2019-2025年收入份额变化

---

## 免责声明

本报告仅供研究和参考目的，不构成投资建议。报告中的数据来源于公开可获取的第三方研究报告和公司文件，尽管已尽力确保数据准确性，但不对数据的完整性和准确性作出保证。市场数据和估值倍数具有时效性，可能因市场波动而快速变化。投资者应基于自身情况做出独立判断。

---

## Sources

- [Gartner: Worldwide InfoSec Spending to Total $213 Billion in 2025](https://www.gartner.com/en/newsroom/press-releases/2025-07-29-gartner-forecasts-worldwide-end-user-spending-on-information-security-to-total-213-billion-us-dollars-in-2025)
- [Gartner: Information Security Forecast 2023-2029 (3Q25 Update)](https://www.gartner.com/en/documents/6998666)
- [Gartner: Worldwide IT Spending to Grow 10.8% in 2026](https://www.gartner.com/en/newsroom/press-releases/2026-02-03-gartner-forecasts-worldwide-it-spending-to-grow-10-point-8-percent-in-2026-totaling-6-point-15-trillion-dollars)
- [IDC: Global Public Cloud Spending to Surpass $1 Trillion in 2026](https://infotechlead.com/networking/global-public-cloud-spending-to-surpass-1-trillion-in-2026-as-ai-and-saas-adoption-accelerate-idc-94179)
- [Palo Alto Networks FY2025 Financial Results](https://www.paloaltonetworks.com/company/press/2025/palo-alto-networks-reports-fiscal-fourth-quarter-and-fiscal-year-2025-financial-results)
- [CrowdStrike FY2025 Results](https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2025/)
- [Fortinet FY2025 Financial Results](https://www.fortinet.com/corporate/about-us/newsroom/press-releases/2026/fortinet-reports-fourth-quarter-full-year-2025-financial-results)
- [Zscaler FY2025 Financial Results](https://ir.zscaler.com/news-releases/news-release-details/zscaler-reports-fourth-quarter-and-fiscal-2025-financial-results)
- [Okta FY2025 Financial Results](https://investor.okta.com/news-and-events/news-releases/news-details/2025/Okta-Announces-Fourth-Quarter-And-Fiscal-Year-2025-Financial-Results/default.aspx)
- [SentinelOne FY2025 Financial Results](https://investors.sentinelone.com/press-releases/news-details/2025/SentinelOne-Announces-Fourth-Quarter-and-Fiscal-Year-2025-Financial-Results/default.aspx)
- [WEF: Global Cybersecurity Outlook 2026](https://www.weforum.org/publications/global-cybersecurity-outlook-2026/in-full/3-the-trends-reshaping-cybersecurity/)
- [Momentum Cyber: 2025 Cybersecurity M&A Year-End Report](https://momentumcyber.com/cybersecurity-mergers-acquisitions-report-2025/)
- [Solganick: Cybersecurity M&A Q4 2025](https://solganick.com/cybersecurity-mergers-acquisitions-update-q4-2025/)
- [Capstone Partners: Cybersecurity M&A Update](https://www.capstonepartners.com/insights/article-cybersecurity-ma-update/)
- [Finro: Cybersecurity Valuation Multiples 2025](https://www.finrofca.com/news/cybersecurity-valuation-multiples-2025)
- [ICON Corporate Finance: Cybersecurity Sector Update Aug 2025](https://www.iconcorpfin.com/wp-content/uploads/2025/09/ICON_Cybersecurity_Sector-Update_Aug-2025.pdf)
- [Return on Security: 2025 State of the Cybersecurity Market](https://www.returnonsecurity.com/p/2025-state-of-the-cybersecurity-market)
- [Fortune Business Insights: Cybersecurity Market Size & Analysis](https://www.fortunebusinessinsights.com/industry-reports/cyber-security-market-101165)
- [Mordor Intelligence: Zero Trust Security Market Report](https://www.mordorintelligence.com/industry-reports/zero-trust-security-market)
- [Coherent Market Insights: SASE Market Forecast 2026-2033](https://www.coherentmarketinsights.com/industry-reports/secure-access-service-edge-sase-market)
- [TIKR: CrowdStrike vs. Palo Alto Networks Valuation](https://www.tikr.com/blog/crowdstrike-vs-palo-alto-networks-which-cybersecurity-leader-deserves-a-premium-valuation)
- [NYU Stern / Prof. Damodaran: EV Multiples by Sector (Jan 2026)](https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/vebitda.html)
