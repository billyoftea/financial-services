[DATA SOURCE: Yahoo Finance, MarketWatch, CNBC, Investing.com, Reuters, Wall Street Journal, S&P Global, Bloomberg, Seeking Alpha, Zacks, Tom's Hardware, The Motley Fool, BLS, FRED/St. Louis Fed, MarketBeat, Tikr, Shacknews, Stock Titan, IBD, Kitco, CBOE, CME Group, SSGA Sector Tracker, ETFreplay, Charles Schwab, Yahoo Finance Earnings Calendar, Nasdaq Earnings Calendar, TradingEconomics]

---

**2026年5月9日 晨会纪要 (Morning Note) — Equity Research Desk**
**覆盖板块：Technology / Semiconductors / AI & Data Center**

> 撰写时间：2026年5月9日 06:30 ET（盘前数据截至发稿时，开盘前可能变动）

---

## Top Call: Micron 财报后跳涨 15.5%，AI 内存超级周期确认 — 继续超配内存与半导体板块

Micron Technology (MU) 盘后发布 Q2 FY2026（截至3月）财报，结果大幅超越市场预期。调整后 EPS $12.20（共识 $9.21，超预期 32.7%），营收 $23.86B（共识 ~$20.0B，超预期约 19.5%），毛利率 75%（环比提升18个百分点）。公司给出的 Q3 FY2026 指引更为激进：营收指引 $33.5B（远超华尔街预期），毛利率指引约 81%。这意味着 Micron 单季 Q3 营收将超过公司 FY2024 全年营收。盘后股价飙升 15.5%。

**我们的看法**：这份财报确认了 AI 驱动的内存超级周期正在加速，DRAM 营收同比增长 207%，NAND 价格和出货量均环比增长。HBM（高带宽内存）需求持续旺盛，数据中心资本开支周期远未见顶。我们维持 Micron "买入" 评级，上调目标价至 $175（前 $140）。更重要的是，这对整个半导体供应链（NVIDIA、AMD、Broadcom、SK Hynix）都是利好信号。

---

## 一、隔夜及盘前市场概览

### 美国主要指数（5月8日收盘）

| 指数 | 收盘 | 当日涨跌 | 周涨跌 |
|------|------|---------|--------|
| S&P 500 | ~7,365 | +1.46% | +0.9%（连续第五周上涨） |
| NASDAQ Composite | 创历史新高 | 收涨 | 连续第五周上涨 |
| Dow Jones Industrial | — | 小幅收涨 | 正向 |
| Russell 2000 | — | — | — |

**52周区间**：S&P 500 52周高触及 7,401.50，当前距历史高点仅一步之遥。

**盘前期货（5月9日 06:00 ET）**：
- E-mini S&P 500 期货指向小幅高开，受 Micron 财报及 AI 板块情绪提振
- NASDAQ 100 期货表现优于大盘，科技股盘前活跃
- 注意：5月9日为周六，本次晨会纪要覆盖周五（5月8日）收盘及盘后动态

### 关键宏观资产

| 资产 | 价格/水平 | 变动 |
|------|----------|------|
| 10年期美债收益率 | ~4.36%–4.39% | 小幅下行（-0.64% 周变动） |
| VIX 恐慌指数 | 低区间（估算 ~15-17） | 波动率持续压缩 |
| WTI 原油 | ~$88–$96/bbl 区间 | 近期大幅波动（美伊停火消息驱动） |
| 现货黄金 | ~$4,600–$5,100/oz | 2026年初以来持续创历史新高 |

**宏观背景**：
- 美伊停火协议于4月初签署，后续多次延长，地缘风险溢价大幅回落。原油从 $113/bbl 高点回落至 $90 以下区间
- 但停火前景仍不确定，Strait of Hormuz 风险仍需关注
- S&P 500 自3月30日低点以来增加约 $6万亿市值，资金大规模回流股票市场
- 国债收益率小幅回落，为成长股估值提供支撑

---

## 二、板块表现

### S&P 500 11大板块本周表现（截至5月8日）

| 板块 | ETF | 近期趋势 | 52周权重 | 备注 |
|------|-----|---------|---------|------|
| Communication Services | XLC | 领涨 | ~8.5% | 本周 S&P 500 上涨主力 |
| Technology | XLK | 强势 | ~30%+ | AI 叙事持续，十年最佳表现板块 |
| Energy | XLE | +25.4%（3个月） | 4.0% | 原油波动中表现亮眼 |
| Industrials | XLI | +11.4% | 9.0% | 基建与国防支出驱动 |
| Financials | XLF | -2.0%（近期） | 12.6% | 相对承压 |
| Healthcare | XLV | -1.2%（近期） | 9.5% | 防御性板块偏弱 |
| Semiconductors | SOXX/SMH | 强势 | — | 半导体指数 MSCI ACWI IMI 半导体年初至今 +73% |

**板块轮动观察**：
- 资金从防御板块（Healthcare、Consumer Staples）向成长/周期板块轮动明显
- Communication Services 板块领涨本周，受 Meta、Alphabet 等AI货币化预期推动
- iShares AI Innovation Tech ETF 近期 +4.1%，中长期 +41.1%，AI 主题ETF持续吸金

---

## 三、重点个股动态

### 财报与业绩

#### Micron Technology (MU) — Q2 FY2026 财报（盘后发布）

| 指标 | 华尔街共识 | 实际 | 超预期 |
|------|-----------|------|--------|
| 营收 | ~$20.0B | $23.86B | +19.5% |
| Non-GAAP EPS | $9.21 | $12.20 | +32.7% |
| 毛利率 | ~57% | 75% | +18pp |
| DRAM 营收 YoY | — | +207% | 大幅超预期 |
| Q3 FY2026 营收指引 | ~$26B | $33.5B | 远超预期 |
| Q3 FY2026 毛利率指引 | — | ~81% | 历史性水平 |

**我们的看法**：这是 Micron 有史以来最具统治力的一份财报。单季 Q3 营收指引 $33.5B 超过公司 FY2024 全年营收。DRAM 营收同比增长 207% 反映了 AI 数据中心对 HBM 的爆炸性需求。毛利率从 57% 跃升至 75% 并指引进一步扩张至 81%，显示定价权极强。NAND 出货量和价格同步增长，避免了"只靠DRAM"的风险。

**行动**：上调评级至"强烈买入"，12个月目标价 $175（前 $140）。Micron 是本轮 AI 内存超级周期的最大受益者之一。

#### AMD (AMD) — Q1 2026 财报（本周早些时候发布）

| 指标 | 华尔街共识 | 实际 | 超预期 |
|------|-----------|------|--------|
| 营收 | $9.84–$9.89B | $10.25–$10.3B | +3.6–4.7% |
| YoY 营收增速 | — | +38% | — |
| 数据中心营收 | — | $5.78B (+57% YoY) | 创纪录 |
| Q2 营收指引 | — | ~$11.2B | 超预期 |

**我们的看法**：AMD 交付了一份重磅财报，数据中心营收 $5.78B（同比增长 57%）是核心亮点。EPYC 服务器 CPU 和 Instinct GPU 的 AI 工作负载需求是主要驱动力。Q2 指引 $11.2B 显示增长势头持续加速。但消费和游戏业务预计 Q2 下滑（内存及组件成本上升），需要关注。

**行动**：维持"买入"，目标价不变。AMD 股价财报后跳涨 18%，短期可能整固，但数据中心加速增长的逻辑不变。

#### NVIDIA (NVDA) — 盘中动态

| 日期 | 价格区间 |
|------|---------|
| 5月4日 | $198.48 |
| 5月5日 | $196.50 |
| 5月6日 | $207.83 |
| 5月7日 | $211.50 |
| 5月9日（盘中高低） | $212.89 – $217.80 |

**我们的看法**：NVIDIA 已成为全球首家市值突破 $4万亿的公司，超越 Apple 和 Microsoft。5月8日 Yahoo Finance 报道指出 NVDA、AAPL、MSFT 可能正处于"多年来最佳估值"区间，是逢低买入的机会。AMD 财报中数据中心 GPU 需求的数据进一步验证了 NVIDIA 的增长逻辑。Micron HBM 供给紧张意味着 NVIDIA 的定价权和需求可见度依然强劲。

**行动**：维持"买入"评级，目标价 $250。短期催化剂包括下一季度财报和 GB200 出货量更新。

### 其他个股动态

- **StarkNet (STRK)**：盘后暴涨 ~24–30%，受 strkBTC 发布及隐私功能升级催化。与我们的科技股覆盖关联度不高，但加密/AI 交叉叙事值得关注
- **Apple (AAPL)**：本周盘前一度走弱，但整体处于"买入估值"区间。Apple Intelligence 能否驱动硬件换机潮是后续关键。全球市值排名第二
- **Microsoft (MSFT)**：Azure 营收同比增长 40%，资本开支估算 ~$190B。近期季度调整后 EPS $4.27，营收 $82.89B。全球市值排名第四（被 NVIDIA 和 Alphabet 超越）
- **Alphabet (GOOGL)**：5月7日盘前逆势上涨，AI 搜索广告货币化预期。全球市值排名第三
- **Broadcom (AVGO)**：受 AI 定制芯片（ASIC）需求提振，与 Google TPU、Meta MTIA 合作深化

---

## 四、关键宏观与经济事件

### 本周已发布

| 日期 | 事件 | 结果 |
|------|------|------|
| 5月5日（周一） | AMD Q1 财报 | 大超预期，营收 +38% YoY |
| 5月8日（周五） | S&P 500 / NASDAQ 收盘 | 双双创历史新高，连续第五周上涨 |
| 4月22日以来 | 美伊停火延续 | 原油从 $113 回落至 ~$88–$96 区间 |

### 下周关注

| 日期 | 事件 | 预期 |
|------|------|------|
| 5月12日（周一） | 无重大经济数据 | 关注周末地缘政治动态 |
| 5月13日 | CPI 通胀数据（如BLS排期） | 市场预期核心 CPI 环比 +0.2–0.3% |
| 5月15日 | 零售销售数据 | 消费者支出韧性是关键 |
| 5月中旬 | PCE 物价指数 | 美联储降息路径的核心指标 |

### 美联储与利率

- 10年期美债收益率小幅回落至 ~4.36–4.39%，为成长股估值提供支撑
- 市场对美联储降息预期：关注下周 CPI 数据，若通胀继续缓和将加强下半年降息预期
- VIX 处于低区间，市场波动率持续压缩，风险偏好处于高位

---

## 五、Trade Ideas

### Trade Idea #1：做多 Micron Technology (MU)

- **方向**：LONG
- **逻辑**：Q2 FY2026 财报全面碾压预期，Q3 指引（营收 $33.5B、毛利率 81%）远超华尔街共识。DRAM 营收 YoY +207% 确认 AI 内存超级周期。HBM 产能约束意味着定价权将持续强劲。技术面突破，盘后 +15.5% 后短期可能整固，但基本面支撑中期继续上行
- **目标价**：$175（12个月）
- **催化剂**：Q3 FY2026 财报（6月底）、HBM 出货量更新、数据中心资本开支上修
- **风险**：内存价格周期性见顶、客户库存调整、AI 资本开支放缓

### Trade Idea #2：做多半导体板块（SOXX/SMH）

- **方向**：LONG（板块层面）
- **逻辑**：AMD +18%、Micron +15.5% 的财报后涨幅显示 AI 硬件需求持续加速。MSCI 全球半导体指数年初至今 +73%，但估值在盈利暴增的背景下仍具吸引力。Q1 2026 S&P 500 盈利增长 27.1%（FactSet），为有记录以来最高，半导体是核心贡献板块
- **催化剂**：NVIDIA 下一季度财报、Broadcom AI 定制芯片出货更新、数据中心 build-out 数据
- **风险**：AI 资本开支放缓信号、美中科技限制升级、板块拥挤交易风险

### Trade Idea #3：做空 WTI 原油（谨慎）

- **方向**：SHORT（小仓位对冲）
- **逻辑**：美伊停火协议持续延长，地缘风险溢价已从原油价格中大幅移除。WTI 从 $113 高点回落至 ~$88–$96 区间。若停火稳定延续且 OPEC+ 不大幅减产，油价可能进一步向 $80 回归
- **风险**：停火破裂、Strait of Hormuz 中断、OPEC+ 意外减产、夏季需求旺季

---

## 六、风险提示与关注事项

1. **美伊停火不确定性**：停火协议已多次延长但前景仍不明朗。Strait of Hormuz 承载全球约 20% 石油运输，任何中断将导致油价飙升、通胀预期回升
2. **AI 资本开支周期见顶风险**：当前 AI 硬件需求呈爆炸式增长，但市场对"何时见顶"存在分歧。Microsoft 资本开支 ~$190B 的规模引发部分投资者对 ROI 的质疑
3. **估值拉伸**：S&P 500 连续五周上涨，52周高点 7,401.50。部分成长股估值处于历史高位，任何盈利不及预期可能引发剧烈回调
4. **通胀数据**：下周 CPI/PCE 数据将是美联储政策路径的关键。若通胀超预期，降息预期推迟将压制成长股估值
5. **黄金与避险资产**：现货黄金 2026 年初已突破 $5,100/oz 创历史新高，全球央行连续三年购买 1,000+ 吨。尽管风险资产表现强劲，避险需求同样旺盛，暗示市场底层存在结构性担忧
6. **半导体板块拥挤度**：NVDA、AMD、MU 等个股持仓高度集中，任何负面催化可能引发板块级去风险

---

## 七、Q1 2026 盈利季总结（FactSet 数据）

- S&P 500 Q1 2026 盈利增长：**+27.1% YoY**（有记录以来最高）
- 营收增长超预期板块：Technology (+35%)、Communication Services (+22%)、Healthcare (+15%)
- 超预期比例：约 78% 的 S&P 500 公司 EPS 超预期
- 核心驱动：AI 数据中心 build-out、云计算需求、企业数字化加速

---

## 八、本日/本周关键结论

1. **Micron 财报是本周最重要事件**：Q2 FY2026 全线超预期 + Q3 指引远超华尔街，确认 AI 内存超级周期
2. **S&P 500 和 NASDAQ 双双创历史新高**：连续第五周上涨，为 2024 年底以来最长连胜
3. **AMD 数据中心营收 $5.78B（+57% YoY）** 进一步验证 AI 硬件需求加速
4. **NVIDIA 成为全球首家 $4万亿市值公司**，AI 叙事从 GPU 扩展至内存（HBM）、网络、定制芯片全链条
5. **美伊停火**推动地缘风险溢价下降，$6万亿资金回流股市
6. **关注下周 CPI 数据**：通胀路径将决定美联储下半年政策走向

---

> **免责声明**：本晨会纪要仅供参考，不构成投资建议。所有观点基于公开信息和分析师判断，可能随时调整。投资有风险，入市需谨慎。

> **数据截止**：2026年5月9日 06:30 ET。盘前数据为截至发稿时的最新可用数据，实际开盘可能有所变动。

---

Sources:
- [Yahoo Finance - S&P 500 Historical Data](https://finance.yahoo.com/quote/%255EGSPC/history/)
- [MarketWatch - S&P 500, Nasdaq end at records (May 8, 2026)](https://www.marketwatch.com/investing/index/spx)
- [Investing.com - S&P 500 Historical Data (52-week range)](https://www.investing.com/indices/us-spx-500-historical-data)
- [WSJ - S&P 500 Extends Longest Weekly Winning Streak](https://www.wsj.com/finance/stocks/s-p-500-extends-longest-weekly-winning-streak-since-late-2024-7cefd3ad)
- [S&P Global - S&P 500 Index (Current Price: 7,365.12)](https://www.spglobal.com/spdji/en/indices/equity/sp-500/)
- [MarketWatch - JPMorgan S&P 500 target](https://www.marketwatch.com/story/the-blue-sky-scenario-that-could-take-the-s-p-500-to-8-000-by-years-end-according-to-jpmorgan-10138b80)
- [Yahoo Finance - NVIDIA $4 Trillion Market Cap](https://ca.finance.yahoo.com/news/nvidia-apple-microsoft-may-trading-182235268.html)
- [Investing.com - Apple, Nvidia Premarket](https://www.investing.com/news/stock-market-news/apple-nvidia-and-xpeng-fall-premarket-alphabet-rises-4361915)
- [Yahoo Finance - AMD Q1 2026 Earnings: Revenue up 38%](https://finance.yahoo.com/markets/stocks/articles/amd-q1-2026-earnings-revenue-203331768.html)
- [Tom's Hardware - AMD Record Q1 Results](https://www.tomshardware.com/pc-components/cpus/amd-posts-record-first-quarter-results-driven-by-skyrocketing-data-center-cpu-demand)
- [Shacknews - AMD Q1 2026 Earnings](http://www.shacknews.com/article/149011/amd-q1-2026-earnings-results)
- [IBD - AMD Stock Jumps on AI Data Center Sales](https://www.investors.com/news/technology/amd-stock-q1-2026-earnings-advanced-micro-devices/)
- [Tikr - Micron Stock Up 70% in 2026](https://www.tikr.com/blog/micron-stock-is-up-70-in-2026-heres-why-analysts-still-see-more-upside-ahead)
- [Seeking Alpha - Micron $33.5B Q3 Revenue Target](https://seekingalpha.com/news/4566187-micron-signals-33_5b-q3-revenue-target-and-81-percent-gross-margin-guidance-driven-by-ai)
- [Zacks - Micron Q2 Earnings Crush Estimates](https://www.zacks.com/stock/news/2886465/micron-q2-earnings-crush-estimates-q3-guidance-above-street-view)
- [MarketBeat - How Much Higher Can Micron Go](https://www.marketbeat.com/originals/after-blowout-earnings-how-much-higher-can-micron-go/)
- [CNBC - Oil Price WTI Brent Iran Ceasefire](https://www.cnbc.com/2026/04/22/oil-price-wti-brent-iran-ceasefire-extension-clouds-outlook.html)
- [CNBC - Oil Prices Plunge After Iran Ceasefire](https://www.cnbc.com/2026/04/07/oil-prices-iran-war-trump-deadline-strait-hormuz.html)
- [Reuters - Record Start to 2026, $5,000 Gold](https://www.reuters.com/world/india/record-start-2026-brings-prospect-5000-gold-into-view-2026-01-13/)
- [The Guardian - Gold Jumps Above $5,000](https://www.theguardian.com/business/2026/jan/26/gold-prices-record-5000-ounce-trump-turmoil)
- [Bullion Trading LLC - Gold Price Record High 2026](https://bulliontradingllc.com/blog/gold-price-5000-record-high-2026-drivers/)
- [JP Morgan - Gold Price Predictions 2026-2027](https://www.jpmorgan.com/insights/global-research/commodities/gold-prices)
- [SSGA - Sector Tracker](https://www.ssga.com/us/en/intermediary/resources/sector-tracker)
- [ETFreplay - ETF Return Summary US Sectors](https://www.etfreplay.com/summary/130)
- [Charles Schwab - Sector Views](https://www.schwab.com/learn/story/stock-sector-outlook)
- [FactSet via Interactive Investor - S&P 500 Earnings +27.1%](https://www.ii.co.uk/investing-with-ii/international-investing/us-earnings-season)
- [Yahoo Finance Earnings Calendar](https://finance.yahoo.com/calendar/earnings?from=2026-05-08&to=2026-05-14&day=2026-05-09)
- [BLS - CPI Release Schedule](https://www.bls.gov/schedule/news_release/cpi.htm)
- [FRED - Economic Calendar (May 3-9, 2026)](https://fred.stlouisfed.org/releases/calendar)
- [YouTube - Post-Market Recap May 9, 2026 (StarkNet +30%, Micron +15.5%)](https://www.youtube.com/watch?v=jQbNBGN5pQU)
- [Moomoo - S&P 500 Fifth Weekly Gain](https://www.moomoo.com/news/post/69305971/s-p-500-marks-fifth-weekly-gain-reaches-new-records)
