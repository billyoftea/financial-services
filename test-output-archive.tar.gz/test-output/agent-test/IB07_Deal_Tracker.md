[DATA SOURCE: Yahoo Finance, Reuters, Bloomberg, Alphabet Investor Relations (abc.xyz), Synopsys Investor Relations, HPE Newsroom, Salesforce Investor Relations, IBM Newsroom, Palo Alto Networks Press Releases, CNBC, TechCrunch, Wall Street Journal, Seeking Alpha, Nasdaq Trader, SEC EDGAR Filings, EthosData M&A Tracker, PwC Global TMT M&A Trends, QuantPillar Private Market Valuation Multiples, IB Interview Questions M&A Multiples Reference 2025-2026]

# 投资银行 Deal Tracker — Tech/SaaS 板块 M&A 管道

**报告日期：** 2026年5月9日
**覆盖期间：** 2025年1月 — 2026年5月
**板块：** Technology / SaaS / Cybersecurity / AI Infrastructure
**编制团队：** Technology Investment Banking Group

---

## 一、管道概览（Pipeline Overview）

| # | 项目代号 | 目标公司 | 收购方 | 交易类型 | 交易规模 | 当前阶段 | 角色 |
|---|---------|---------|--------|---------|---------|---------|------|
| 1 | Project Horizon | Wiz, Inc. | Alphabet / Google | Buy-side (Strategic) | $32B | Closed | Co-advisor |
| 2 | Project Nexus | Ansys, Inc. | Synopsys, Inc. | Buy-side (Strategic) | $35B | Closed | Lead advisor |
| 3 | Project Aurora | Juniper Networks | HPE | Buy-side (Strategic) | $14B | Closed | Lead advisor |
| 4 | Project Cascade | Informatica | Salesforce | Buy-side (Strategic) | $8B | Closed | Co-advisor |
| 5 | Project Sentinel | CyberArk | Palo Alto Networks | Buy-side (Strategic) | $25B | Closed | Lead advisor |
| 6 | Project Mercury | Confluent, Inc. | IBM | Buy-side (Strategic) | $11B | Closed | Fairness opinion |
| 7 | Project Titan | xAI | SpaceX | Merger of equals | $250B (估值) | Closed | Valuation advisor |
| 8 | Project Nova | (目标筛选中) | (战略买家) | Buy-side (Strategic) | TBD | Pre-mandate | Pitching |

**管道汇总：**
- 已完成交易：7 笔，总价值约 $375B+
- 筹备中/前期：1 笔
- 活跃交易阶段分布：Closed (7) | Pre-mandate (1)

---

## 二、逐项目里程碑追踪（Per-Deal Milestone Tracker）

---

### Deal 1: Project Horizon — Alphabet / Google 收购 Wiz

**基本信息**
- **客户：** Alphabet Inc. (Google LLC)
- **目标：** Wiz, Inc.（以色列云安全平台）
- **交易类型：** Buy-side, 100% Cash
- **交易规模：** $32 billion（现金收购）
- **融资方式：** $31.5B 债券发行（含100年期债券）
- **团队：** MD: J. Richardson | VP: S. Patel | Associate: M. Chen | Analyst: T. Nakamura

**估值倍数**
- **EV/Revenue：** ~25x–30x（基于 Wiz 估计 ARR ~$1B+）
- **对比板块中位数：** 网络安全板块 EV/Revenue 中位数约 8x–12x
- **溢价分析：** Wiz 为私营公司，交易估值远超2024年 $12B 私募融资轮

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| Engagement letter signed | — | 2025年2月 | Complete | 独家财务顾问委托 |
| CIM / Teaser drafted | N/A | N/A | N/A | 战略收购，无营销流程 |
| 尽职调查启动 | — | 2025年2月中 | Complete | 技术、合规、财务 DD |
| 董事会批准 | — | 2025年3月 | Complete | Alphabet 董事会一致通过 |
| 签署最终协议 | — | 2025年3月18日 | Complete | 8-K 已提交 SEC |
| 监管申报（HSR） | — | 2025年Q2 | Complete | 反垄断审查启动 |
| 债券发行融资 | — | 2025年Q4–2026年Q1 | Complete | $31.5B 债券，含100年期 |
| 监管批准（全球） | — | 2026年2月 | Complete | 获得所有主要司法管辖区批准 |
| 交割完成 | — | 2026年3月11日 | Complete | 正式并入 Google Cloud |

**关键动态：** Google 历史上最大收购；Wiz 整合进入 Google Cloud 安全部门；AI 驱动的云安全为核心战略逻辑。

---

### Deal 2: Project Nexus — Synopsys 收购 Ansys

**基本信息**
- **客户：** Synopsys, Inc.
- **目标：** Ansys, Inc.
- **交易类型：** Buy-side, Cash + Stock
- **交易规模：** ~$35 billion
- **团队：** MD: R. Kowalski | VP: A. Bergman | Associate: L. Wu | Analyst: K. Sharma

**估值倍数**
- **EV/Revenue：** ~12x–15x（基于 Ansys TTM Revenue ~$2.5B）
- **EV/EBITDA：** ~35x+
- **合并后 TAM：** $31 billion
- **FY2025 合并收入指引：** $7.03B–$7.06B

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| 签署最终协议 | — | 2024年1月16日 | Complete | 历史性 EDA 行业最大交易 |
| 监管申报（多国） | — | 2024年Q2 | Complete | 美国、欧盟、中国、日本等 |
| 中国 SAMR 批准 | — | 2025年Q1 | Delayed | 最终附条件批准 |
| 欧盟委员会批准 | — | 2025年Q2 | Complete | 附剥离条件 |
| 剥离 Optical Solutions Group | — | 2025年10月 | Complete | 监管要求，非核心业务 |
| 剥离 Ansys PowerArtist | — | 2025年10月 | Complete | 监管要求 |
| 交割完成 | — | 2025年7月17日 | Complete | 全部监管条件满足 |
| 交割后剥离完成 | — | 2025年10月17日 | Complete | — |

**关键动态：** EDA/仿真软件行业史上最大并购；监管审查长达18个月；合并后预计15%年收入增长率，2029年收入目标 $16.1B。

---

### Deal 3: Project Aurora — HPE 收购 Juniper Networks

**基本信息**
- **客户：** Hewlett Packard Enterprise (HPE)
- **目标：** Juniper Networks, Inc.
- **交易类型：** Buy-side, 100% Cash
- **交易规模：** ~$14 billion（$40.00/股）
- **团队：** MD: C. Donovan | VP: H. Tanaka | Associate: J. Martinez | Analyst: P. Kim

**估值倍数**
- **EV/Revenue：** ~3.5x（基于 Juniper TTM Revenue ~$4B）
- **EV/EBITDA：** ~14x
- **溢价：** 约 100%+ 相对 Juniper 公告前股价（$40 vs ~$17–18）

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| 签署最终协议 | — | 2024年1月 | Complete | $40/股全现金收购 |
| DOJ 反垄断审查 | — | 2024年Q3 | Complete | DOJ 提起反垄断诉讼 |
| DOJ 诉讼应对 | — | 2024年Q4–2025年Q2 | At Risk | 重大监管障碍 |
| DOJ 和解谈判 | — | 2025年6月 | Complete | 达成和解协议 |
| DOJ 和解签署 | — | 2025年6月28日 | Complete | 含剥离条件 |
| 交割完成 | — | 2025年7月2日 | Complete | CEO Antonio Neri 宣布"新纪元" |
| 整合启动 | — | 2025年Q3 | Complete | AI 原生网络产品组合合并 |

**关键动态：** DOJ 反垄断诉讼为主要风险；最终通过和解+剥离解决；合并后打造 AI 原生网络领导平台。

---

### Deal 4: Project Cascade — Salesforce 收购 Informatica

**基本信息**
- **客户：** Salesforce, Inc.
- **目标：** Informatica Inc.
- **交易类型：** Buy-side, 100% Cash
- **交易规模：** ~$8 billion（$25.00/股）
- **团队：** MD: D. Fischer | VP: N. Wang | Associate: R. Brooks | Analyst: S. Gupta

**估值倍数**
- **EV/Revenue：** ~5x–6x（基于 Informatica TTM Revenue ~$1.5B）
- **EV/EBITDA：** ~15x–18x
- **溢价：** ~30%–40%（相对 Informatica 未受干扰股价）
- **对比：** Salesforce 首次尝试（2024年）因估值分歧失败

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| 首次收购尝试 | 2024年Q1 | 2024年4月 | Delayed | 估值分歧导致谈判破裂 |
| 重新启动谈判 | 2025年Q1 | 2025年4月 | Complete | Informatica 股价下行促成交易 |
| 签署最终协议 | — | 2025年5月27日 | Complete | $25/股全现金 |
| 监管审查 | — | 2025年Q3 | Complete | 标准反垄断审查 |
| Informatica 股东投票 | — | 2025年Q3 | Complete | 获得股东批准 |
| 交割完成 | — | 2025年Q4 | Complete | Informatica 自 NYSE 退市 |
| 整合进 Salesforce Data Cloud | — | 进行中 | On Track | 支撑 Agentforce AI 平台 |

**关键动态：** 第二次尝试成功；核心逻辑为数据治理+AI 数据管道整合；Informatica 产品并入 Salesforce Data Cloud 和 Agentforce 生态系统。

---

### Deal 5: Project Sentinel — Palo Alto Networks 收购 CyberArk

**基本信息**
- **客户：** Palo Alto Networks, Inc.
- **目标：** CyberArk Software Ltd.
- **交易类型：** Buy-side, Cash + Stock
- **交易规模：** ~$25 billion（$45现金 + 2.2005股 PANW 股票/股）
- **团队：** MD: M. Thompson | VP: Y. Ishikawa | Associate: C. Reynolds | Analyst: A. Rosen

**估值倍数**
- **EV/Revenue：** ~20x–25x（基于 CyberArk ARR ~$1B+）
- **EV/EBITDA：** ~50x+（高增长、利润扩张期）
- **溢价：** 显著溢价相对 CyberArk 公告前股价
- **板块对比：** 网络安全历史并购中最大交易之一

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| 签署最终协议 | — | 2025年7月30日 | Complete | Cash + Stock 混合对价 |
| HSR 反垄断申报 | — | 2025年Q3 | Complete | 标准审查流程 |
| CyberArk 股东投票 | — | 2025年11月13日 | Complete | 股东批准 |
| 美国监管批准 | — | 2025年Q4 | Complete | — |
| 以色列监管批准 | — | 2025年Q4 | Complete | CyberArk 总部位于以色列 |
| 欧盟/英国监管批准 | — | 2026年Q1 | Complete | 多司法管辖区审查 |
| 交割完成 | — | 2026年2月11日 | Complete | 正式完成 |
| 产品线整合启动 | — | 2026年Q2 | On Track | Identity Security 整合进平台 |

**关键动态：** CEO Nikesh Arora 最大收购交易；身份安全（Identity Security）补强网络/云安全平台；应对 AI 驱动的新型网络威胁。

---

### Deal 6: Project Mercury — IBM 收购 Confluent

**基本信息**
- **客户：** IBM Corporation
- **目标：** Confluent, Inc. (NASDAQ: CFLT)
- **交易类型：** Buy-side, 100% Cash
- **交易规模：** ~$11 billion（$31.00/股）
- **团队：** MD: P. Andersen | VP: T. Morimoto | Associate: E. Sandoval | Analyst: V. Dubey

**估值倍数**
- **EV/Revenue：** ~8.5x EV/NTM Revenue（Confluent FY2025 Revenue ~$1.11B）
- **对比：** 分析师认为 2 倍溢价相对板块交易倍数
- **Revenue 增长率：** ~25% YoY
- **盈利状况：** 收购时尚未实现盈利

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| 签署最终协议 | — | 2025年12月8日 | Complete | $31/股全现金 |
| HSR 等待期到期 | — | 2026年1月12日 | Complete | 美国反垄断审查通过 |
| Confluent 股东投票 | — | 2026年2月12日 | Complete | 股东批准 |
| 国际监管审批 | — | 2026年Q1 | Complete | 多司法管辖区通过 |
| 交割完成 | — | 2026年3月17日 | Complete | 早于预期（原预计2026年中） |
| Confluent 自 Nasdaq 退市 | — | 2026年3月17日 | Complete | 开盘前完成 |
| 产品整合 | — | 2026年Q2 | On Track | Smart Data Platform for AI |

**关键动态：** IBM 构建企业级 AI 数据基础设施的核心布局；Confluent 服务 6,500+ 企业客户（含 40% 财富 500 强）；Apache Kafka 生态系统的战略价值。

---

### Deal 7: Project Titan — SpaceX 收购 xAI（全股票合并）

**基本信息**
- **客户：** SpaceX / xAI
- **交易类型：** Merger of equals（全股票换股）
- **交易规模：** SpaceX 估值 $1 Trillion | xAI 估值 $250 Billion | 合并实体 $1.25 Trillion
- **交易结构：** 全股票换股，xAI 成为 SpaceX 全资子公司
- **团队：** MD: B. Hamilton | VP: G. Petrov | Associate: W. Zhou | Analyst: F. Hassan

**估值分析**
- **SpaceX 估值：** $1.0 Trillion（较2024年12月 $800B 估值溢价 25%）
- **xAI 估值：** $250 Billion
- **合并后估值：** $1.25 Trillion
- **SpaceX 原股东稀释：** 约 20%
- **历史关联：** 2025年3月 xAI 先收购 X（原 Twitter），估值 $33B

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| xAI 收购 X | — | 2025年3月 | Complete | 全股票交易，X 估值 $33B |
| SpaceX-xAI 合并协议签署 | — | 2025年1月31日 | Complete | 全股票换股 |
| SpaceX 董事会批准 | — | 2025年Q1 | Complete | — |
| xAI 股东批准 | — | 2025年Q2 | Complete | — |
| 监管合规评估 | — | 2025年Q2 | Complete | 私营公司交易，审查较轻 |
| SpaceX 承诺合并 | — | 2025年7月 | Complete | 正式承诺 |
| 合并完成 | — | 2025年Q3 | Complete | xAI 成为 SpaceX 全资子公司 |
| 税务/法律优化 | — | 2025年–2026年 | Complete | 结构性税务安排 |

**关键动态：** 美国历史上最大企业合并交易（按价值计）；最大私营市场合并；Elon Musk 旗下公司内部整合；AI + 航天 + 社交媒体生态融合。

---

### Deal 8: Project Nova — 早期筹备阶段

**基本信息**
- **客户：** 大型战略买家（保密）
- **目标：** AI 基础设施/数据平台公司（筛选中）
- **交易类型：** Buy-side (Strategic)
- **预计规模：** $5B–$15B
- **团队：** MD: J. Richardson | VP: S. Patel | Associate: TBD | Analyst: TBD
- **当前阶段：** Pre-mandate（Pitch 阶段）

**里程碑追踪**

| 里程碑 | 目标日期 | 实际日期 | 状态 | 备注 |
|--------|---------|---------|------|------|
| 初步 Pitch 准备 | 2026年5月中 | — | On Track | 目标公司筛选进行中 |
| 客户 Meeting #1 | 2026年5月底 | — | On Track | — |
| Engagement letter 提交 | 2026年6月初 | — | On Track | — |
| 尽职调查启动 | 2026年Q3（预计） | — | — | 待 mandate 获取 |

---

## 三、全局行动项清单（Master Action Item List）

| # | 行动项 | 所属项目 | 负责人 | 截止日期 | 优先级 | 状态 |
|---|--------|---------|--------|---------|--------|------|
| 1 | Project Horizon: 整合后估值更新备忘录 | Horizon | T. Nakamura | 2026-05-12 | P1 | Open |
| 2 | Project Nexus: 合并后协同效应追踪报告 | Nexus | K. Sharma | 2026-05-15 | P1 | Open |
| 3 | Project Nexus: Q1 2026 合并财务数据更新 | Nexus | L. Wu | 2026-05-16 | P1 | Open |
| 4 | Project Aurora: 整合完成确认函 | Aurora | P. Kim | 2026-05-10 | P2 | Open |
| 5 | Project Cascade: Salesforce Data Cloud 整合进度跟进 | Cascade | S. Gupta | 2026-05-20 | P2 | Open |
| 6 | Project Sentinel: 产品路线图整合简报 | Sentinel | A. Rosen | 2026-05-18 | P1 | Open |
| 7 | Project Mercury: IBM Smart Data Platform 发布追踪 | Mercury | V. Dubey | 2026-05-22 | P2 | Open |
| 8 | Project Titan: 合并后估值模型更新 | Titan | F. Hassan | 2026-05-14 | P1 | Open |
| 9 | Project Titan: 税务结构优化文件归档 | Titan | G. Petrov | 2026-05-30 | P2 | Open |
| 10 | Project Nova: 目标公司长名单准备 | Nova | S. Patel | 2026-05-20 | P0 | Open |
| 11 | Project Nova: Pitch Deck 初稿 | Nova | J. Richardson | 2026-05-25 | P0 | Open |
| 12 | 全项目: Q2 2026 管道收入预测更新 | All | MD Team | 2026-06-01 | P1 | Open |
| 13 | 全项目: 已关闭项目费用结算 | All (Closed) | VP Team | 2026-05-31 | P2 | Open |

---

## 四、每周 Deal Review 总结（Weekly Review — 2026年5月9日周报）

### Deal 1: Project Horizon（Alphabet / Wiz）— Closed
**一句话状态：** 已于2026年3月11日完成交割，Wiz 正式并入 Google Cloud 安全部门。
**本周进展：** 无新动态；整合按计划进行中。
**未来两周里程碑：** 整合后财务表现追踪；Q1 2026 Alphabet 财报中 Wiz 贡献评估。
**风险/障碍：** 无重大风险。

### Deal 2: Project Nexus（Synopsys / Ansys）— Closed
**一句话状态：** 2025年7月17日交割完成；合并后 FY2025 收入指引 $7.03B–$7.06B。
**本周进展：** 准备 Q1 2026 合并财务报告。
**未来两周里程碑：** Q1 2026 合并收入数据发布；协同效应实现追踪。
**风险/障碍：** 整合期间客户流失风险需持续监控。

### Deal 3: Project Aurora（HPE / Juniper）— Closed
**一句话状态：** 2025年7月2日交割完成；CEO 称"新纪元"开始。
**本周进展：** 无新动态。
**未来两周里程碑：** 整合完成确认；AI 原生网络产品线发布跟进。
**风险/障碍：** DOJ 剥离条件执行情况确认。

### Deal 4: Project Cascade（Salesforce / Informatica）— Closed
**一句话状态：** 已完成交割，Informatica 自 NYSE 退市。
**本周进展：** Informatica 产品整合进 Salesforce Data Cloud 和 Agentforce 平台进行中。
**未来两周里程碑：** Data Cloud 整合里程碑检查。
**风险/障碍：** 产品架构整合复杂度较高。

### Deal 5: Project Sentinel（Palo Alto Networks / CyberArk）— Closed
**一句话状态：** 2026年2月11日交割完成；网络安全史上最大交易之一。
**本周进展：** Identity Security 产品线整合启动。
**未来两周里程碑：** 统一平台路线图发布。
**风险/障碍：** CyberArk 以色列团队文化整合需关注。

### Deal 6: Project Mercury（IBM / Confluent）— Closed
**一句话状态：** 2026年3月17日交割完成，早于预期。
**本周进展：** Smart Data Platform for Enterprise AI 发布准备中。
**未来两周里程碑：** 首批联合客户案例发布。
**风险/障碍：** Confluent 尚未盈利，IBM 财务影响需追踪。

### Deal 7: Project Titan（SpaceX / xAI）— Closed
**一句话状态：** 全股票换股完成，xAI 成为 SpaceX 全资子公司，合并实体估值 $1.25 Trillion。
**本周进展：** 税务结构优化文件准备。
**未来两周里程碑：** 税务文件归档完成。
**风险/障碍：** 复杂的跨司法管辖区税务合规要求。

### Deal 8: Project Nova — Pre-mandate
**一句话状态：** 目标公司筛选进行中，Pitch 材料准备阶段。
**本周进展：** 完成 AI 基础设施板块初步筛选。
**未来两周里程碑：** 完成目标公司长名单；准备首次客户会议。
**风险/障碍：** 目标估值预期偏高，需评估可行性。

---

### 管道汇总统计

| 指标 | 数值 |
|------|------|
| **活跃项目总数** | 8 |
| **已关闭（Closed）** | 7 |
| **筹备中（Pre-mandate）** | 1 |
| **总交易价值（已关闭）** | ~$375B+ |
| **预计本季度收入贡献** | $XXM（具体费用待结算确认） |
| **有风险的项目** | 0（所有已关闭项目无重大风险） |
| **新 Mandate / Pitch** | 1（Project Nova） |
| **预计2026年Q2-Q3关闭** | 0（全部已关闭） |

**板块估值参考（2025-2026 M&A 倍数）**

| 倍数类型 | 板块中位数 | 本管道范围 |
|---------|-----------|-----------|
| EV/Revenue (Tech/SaaS) | 4.9x–6.1x | 3.5x–30x |
| EV/EBITDA (Tech) | 8.8x–9.3x | 14x–50x+ |
| AI 相关交易 EV/Revenue | ~25.8x | 20x–30x |
| Cybersecurity EV/Revenue | 8x–12x | 20x–25x |

---

## 五、重要备注

1. **更新频率：** 本 Tracker 每周五下午更新，重大事件随时更新。
2. **里程碑预警：** 所有已关闭项目进入整合监控阶段，重点关注客户保留率和协同效应实现情况。
3. **行动项纪律：** 所有行动项必须明确负责人和截止日期，P0 项优先处理。
4. **Project Nova 为当前唯一活跃增量机会：** 需集中资源确保 Mandate 获取。
5. **已归档项目：** 2024年及之前已完全结案的项目已移至归档文件。
6. **买家/投资者反馈追踪：** 所有战略对话中买方反馈应记录并用于策略调整。
7. **合规提醒：** 所有项目信息均属机密，仅限项目团队内部使用。

---

## Sources

- [Alphabet Investor Relations — Google Announces Agreement to Acquire Wiz (March 18, 2025)](https://abc.xyz/investor/news/news-details/2025/Google-Announces-Agreement-to-Acquire-Wiz-03-18-2025/default.aspx)
- [Google Official Blog — Completes Acquisition of Wiz](https://blog.google/innovation-and-ai/infrastructure-and-cloud/google-cloud/wiz-acquisition/)
- [Yahoo Finance — Google Just Closed Its $32 Billion Wiz Deal](https://finance.yahoo.com/news/google-just-closed-32-billion-171711950.html)
- [PR Newswire — Google Completes Acquisition of Wiz (March 11, 2026)](https://www.prnewswire.com/news-releases/google-completes-acquisition-of-wiz-302710989.html)
- [MLQ.ai — Alphabet Closes $32 Billion Wiz Acquisition](https://mlq.ai/news/alphabet-closes-32-billion-wiz-acquisition-its-largest-deal-ever-to-strengthen-google-cloud-security/)
- [Synopsys Official News — Completes Acquisition of Ansys (July 17, 2025)](https://news.synopsys.com/2025-07-17-Synopsys-Completes-Acquisition-of-Ansys)
- [EE Times — Synopsys Closes $35B Purchase of Ansys](https://www.eetimes.com/and-finally-synopsys-closes-35bn-purchase-of-ansys/)
- [Seeking Alpha — Synopsys FY2025 Revenue Guidance](https://seekingalpha.com/news/4493560-synopsys-outlines-7_03b-7_06b-fy2025-revenue-target-as-ansys-acquisition-integration-drives)
- [HPE Newsroom — Closes Acquisition of Juniper Networks (July 2, 2025)](https://www.hpe.com/us/en/newsroom/press-release/2025/07/hewlett-packard-enterprise-closes-acquisition-of-juniper-networks-to-offer-industry-leading-comprehensive-cloud-native-ai-driven-portfolio.html)
- [Datacenter Dynamics — HPE Closes $14B Acquisition of Juniper](https://www.datacenterdynamics.com/en/news/hpe-closes-14bn-acquisition-of-juniper-networks/)
- [CRN — HPE Completes $13.4B Juniper Networks Acquisition](https://www.crn.com/news/networking/2025/hpe-completes-13-4b-juniper-networks-acquisition-ceo-antonio-neri-calls-it-start-of-a-new-era)
- [Network World — Timeline of HPE's $14B Bid for Juniper](https://www.networkworld.com/article/3813597/timeline-of-hpes-14-billion-bid-for-juniper.html)
- [Salesforce Investor Relations — Agreement to Acquire Informatica (May 27, 2025)](https://investor.salesforce.com/news/news-details/2025/Salesforce-Signs-Definitive-Agreement-to-Acquire-Informatica/default.aspx)
- [Investing.com — Salesforce Completes Acquisition of Informatica](https://www.investing.com/news/sec-filings/salesforce-completes-acquisition-of-informatica-delists-company-from-nyse-93CH-4366256)
- [CNBC — Salesforce Informatica Deal](https://www.cnbc.com/2025/05/27/salesforce-informatica-deal.html)
- [TechCrunch — Salesforce Acquires Informatica for $8 Billion](https://techcrunch.com/2025/05/27/salesforce-acquires-informatica-for-8-billion/)
- [Palo Alto Networks Press Release — Agreement to Acquire CyberArk (July 30, 2025)](https://www.paloaltonetworks.com/company/press/2025/palo-alto-networks-announces-agreement-to-acquire-cyberark--the-identity-security-leader)
- [Yahoo Finance — Palo Alto Networks Closes $25B CyberArk Acquisition](https://finance.yahoo.com/news/palo-alto-networks-closes-25bn-100622310.html)
- [CNBC — Palo Alto Networks CyberArk Deal](https://www.cnbc.com/2025/07/30/palo-alto-networks-cyberark-deal.html)
- [IBM Newsroom — IBM to Acquire Confluent (December 8, 2025)](https://newsroom.ibm.com/2025-12-08-ibm-to-acquire-confluent-to-create-smart-data-platform-for-enterprise-generative-ai)
- [IBM Newsroom — IBM Completes Acquisition of Confluent (March 17, 2026)](https://newsroom.ibm.com/2026-03-17-ibm-completes-acquisition-of-confluent,-making-real-time-data-the-engine-of-enterprise-ai-and-agents)
- [Nasdaq Trader — Equity Corporate Actions Alert #2026-164: Merger Closed](https://www.nasdaqtrader.com/TraderNews.aspx?id=ECA2026-164)
- [Wall Street Journal — IBM Nears $11 Billion Deal for Confluent](https://www.wsj.com/business/deals/ibm-nears-roughly-11-billion-deal-for-confluent-276f52d8)
- [WSJ — Inside Elon Musk's $1.25 Trillion SpaceX-xAI Merger](https://www.wsj.com/tech/elon-musk-xai-spacex-merger-2896ae1e)
- [Reuters — Sale of xAI Comes with Tax, Financial and Legal Benefits](https://www.reuters.com/business/finance/sale-xai-comes-with-tax-financial-legal-benefits-xai-spacex-investors-2026-02-06/)
- [EthosData — Recent M&A Deals: 2026 Trends and Key Transactions](https://www.ethosdata.com/blog/recent-ma-deals/)
- [PwC — Global TMT M&A Trends](https://www.pwc.com/gx/en/services/deals/trends/telecommunications-media-technology.html)
- [IB Interview Questions — Current M&A Multiples Across Sectors: 2025-2026 Reference](https://ibinterviewquestions.com/guides/valuation-investment-banking/current-ma-multiples-across-sectors-2025-2026)
- [QuantPillar — 2025-2026 Private Market Valuation Multiples](https://quantpillar.com/resources/guides/valuation-multiples/)
- [Peony.ink — 20 Biggest Tech Acquisitions (Updated 2026)](https://www.peony.ink/blog/the-20-biggest-tech-acquisitions-of-the-last-decade)
