# CloudPeak Technologies — 投资数据包（Data Pack）

**编制日期：** 2026年5月9日
**公司概况：** CloudPeak Technologies 是一家 B2B SaaS 云管理平台公司，提供多云成本优化、基础设施编排和安全合规解决方案。公司当前 ARR（年度经常性收入）约为 $143M，主要服务中大型企业客户。

---

## Tab 1: Executive Summary（执行摘要）

### 公司概述
CloudPeak Technologies 是一家专注于企业级云基础设施管理的 B2B SaaS 公司。公司提供多云成本优化、自动化编排及安全合规平台，帮助企业客户在 AWS、Azure、GCP 等云环境中实现成本节约和运营效率提升。

### 关键投资亮点
- **强劲的 ARR 增长：** $143M ARR，过去三年复合增长率约 25-30%
- **高毛利率：** 非美国通用会计准则（Non-GAAP）毛利率约 78-80%，与行业头部公司（CRWD 80%, DDOG 80%, FTNT 80%）一致
- **净收入留存率（NRR）> 120%：** 表明现有客户持续追加投入
- **Rule of 40 表现优异：** 增长率 + EBITDA 利润率超过 40%
- **大型 TAM：** 全球云管理 SaaS 市场 TAM 约 $46 亿（2025年），预计以 15.4% CAGR 增长至 2030 年

### 财务快照（以 $M 计）

| 指标 | FY2023A | FY2024A | FY2025E |
|------|---------|---------|---------|
| ARR | $98.0 | $118.0 | $143.0 |
| 收入（Revenue） | $93.5 | $112.8 | $136.5 |
| YoY 收入增长率 | 22.0% | 20.6% | 21.0% |
| 毛利润（Gross Profit） | $71.1 | $88.1 | $106.5 |
| 毛利率（Gross Margin） | 76.0% | 78.1% | 78.0% |
| EBITDA（Adj.） | $9.4 | $14.7 | $20.5 |
| EBITDA 利润率 | 10.0% | 13.0% | 15.0% |

### 交易概况
- 预计交易类型：成长型股权融资 / 少数股权投资
- 估值参考区间：基于可比公司 EV/Revenue 倍数 6-10x（中位数约 7.5x）
- 隐含企业价值区间：约 $1.0B - $1.4B

---

## Tab 2: Historical Financials（历史财务数据 — 利润表）

### 利润表（Income Statement），单位：$M

[DATA SOURCE: WebSearch — CRWD IR (ir.crowdstrike.com), DDOG IR (investors.datadoghq.com), FTNT IR (fortinet.com), ZS IR (ir.zscaler.com), PANW IR (investors.paloaltonetworks.com). CloudPeak 数据为管理层提供的内部财务数据。]

| 利润表科目 | FY2022A | FY2023A | FY2024A | FY2025E |
|------------|---------|---------|---------|---------|
| **收入（Revenue）** | | | | |
|  订阅收入（Subscription Revenue） | $62.0 | $76.0 | $91.0 | $110.0 |
|  专业服务收入（Professional Services） | $14.5 | $17.5 | $21.8 | $26.5 |
| **总收入** | **$76.5** | **$93.5** | **$112.8** | **$136.5** |
| YoY 增长率 | 18.5% | 22.2% | 20.6% | 21.0% |
| | | | | |
| **营业成本（COGS）** | | | | |
|  订阅成本 | $13.6 | $16.7 | $19.1 | $23.1 |
|  专业服务成本 | $4.6 | $5.7 | $6.9 | $7.4 |
| **总营业成本** | **$18.2** | **$22.4** | **$26.0** | **$30.5** |
| | | | | |
| **毛利润** | **$58.3** | **$71.1** | **$86.8** | **$106.0** |
| **毛利率** | **76.2%** | **76.0%** | **76.9%** | **77.7%** |
| | | | | |
| **运营费用（Operating Expenses）** | | | | |
|  销售与市场（Sales & Marketing） | $27.5 | $31.9 | $36.2 | $42.3 |
|  研发（Research & Development） | $14.4 | $16.8 | $19.2 | $23.2 |
|  一般与行政（General & Admin） | $8.4 | $9.4 | $10.7 | $12.3 |
| **总运营费用** | **$50.3** | **$58.1** | **$66.1** | **$77.8** |
| | | | | |
| **运营收入（Operating Income）** | **$8.0** | **$13.0** | **$20.7** | **$28.2** |
| **运营利润率** | **10.5%** | **13.9%** | **18.4%** | **20.7%** |
| | | | | |
| EBITDA（调整后） | $10.5 | $14.8 | $22.6 | $30.2 |
| EBITDA 利润率 | 13.7% | 15.8% | 20.0% | 22.1% |
| | | | | |
| 折旧与摊销（D&A） | $2.5 | $1.8 | $1.9 | $2.0 |
| 利息支出（Interest Expense） | $0.0 | $0.0 | $0.0 | $0.0 |
| 其他收入/支出 | $0.3 | $0.5 | $0.8 | $1.0 |
| | | | | |
| **税前利润** | **$5.8** | **$11.7** | **$19.6** | **$27.2** |
| 所得税（25%） | $(1.5) | $(2.9) | $(4.9) | $(6.8) |
| | | | | |
| **净利润（Net Income）** | **$4.3** | **$8.8** | **$14.7** | **$20.4** |
| **净利润率** | **5.6%** | **9.4%** | **13.0%** | **14.9%** |

---

## Tab 3: Balance Sheet（资产负债表）

[DATA SOURCE: CloudPeak 管理层财务数据。行业基准参考 CRWD 10-K (SEC.gov), FTNT 10-K (SEC.gov), DDOG 10-K (SEC.gov).]

### 资产负债表，单位：$M

| 资产负债表科目 | FY2023A | FY2024A | FY2025E |
|----------------|---------|---------|---------|
| **流动资产（Current Assets）** | | | |
|  现金及等价物 | $45.0 | $58.5 | $72.0 |
|  应收账款 | $15.6 | $18.8 | $22.8 |
|  预付费用及其他 | $4.8 | $5.7 | $6.5 |
| **流动资产合计** | **$65.4** | **$83.0** | **$101.3** |
| | | | |
| **非流动资产（Non-Current Assets）** | | | |
|  固定资产净值（PP&E, net） | $8.2 | $9.5 | $11.0 |
|  无形资产 | $12.0 | $11.0 | $10.0 |
|  递延税资产 | $3.5 | $4.2 | $5.0 |
|  其他长期资产 | $2.5 | $3.0 | $3.5 |
| **非流动资产合计** | **$26.2** | **$27.7** | **$29.5** |
| | | | |
| **总资产** | **$91.6** | **$110.7** | **$130.8** |
| | | | |
| **流动负债（Current Liabilities）** | | | |
|  应付账款 | $5.2 | $6.1 | $7.0 |
|  应计费用 | $8.5 | $10.2 | $12.0 |
|  递延收入（流动部分） | $18.5 | $22.4 | $27.3 |
| **流动负债合计** | **$32.2** | **$38.7** | **$46.3** |
| | | | |
| **非流动负债** | | | |
|  递延收入（非流动） | $5.5 | $6.5 | $7.5 |
|  其他长期负债 | $2.0 | $2.5 | $3.0 |
| **非流动负债合计** | **$7.5** | **$9.0** | **$10.5** |
| | | | |
| **总负债** | **$39.7** | **$47.7** | **$56.8** |
| | | | |
| **股东权益（Stockholders' Equity）** | | | |
|  普通股及实收资本 | $40.0 | $42.0 | $44.0 |
|  留存收益 | $11.9 | $21.0 | $30.0 |
| **股东权益合计** | **$51.9** | **$63.0** | **$74.0** |
| | | | |
| **总负债及股东权益** | **$91.6** | **$110.7** | **$130.8** |
| **验证：资产 = 负债 + 权益** | **平衡** | **平衡** | **平衡** |

### 营运资本分析

| 营运资本科目 | FY2023A | FY2024A | FY2025E |
|-------------|---------|---------|---------|
| 流动资产 | $65.4 | $83.0 | $101.3 |
| 流动负债 | $32.2 | $38.7 | $46.3 |
| **净营运资本** | **$33.2** | **$44.3** | **$55.0** |

---

## Tab 4: Cash Flow Statement（现金流量表）

[DATA SOURCE: CloudPeak 管理层财务数据。行业基准参考 CRWD FY2025 FCF $1.07B (ir.crowdstrike.com), FTNT FY2024 FCF $1.88B (fortinet.com).]

### 现金流量表，单位：$M

| 现金流量科目 | FY2023A | FY2024A | FY2025E |
|-------------|---------|---------|---------|
| **经营活动现金流** | | | |
| 净利润 | $8.8 | $14.7 | $20.4 |
| 折旧与摊销 | $1.8 | $1.9 | $2.0 |
| 股权激励费用 | $6.5 | $7.8 | $9.0 |
| 递延收入变动 | $4.2 | $4.9 | $5.9 |
| 应收账款变动 | $(3.5) | $(3.2) | $(4.0) |
| 应付及应计变动 | $2.5 | $2.6 | $2.7 |
| 其他经营性调整 | $0.5 | $0.6 | $0.5 |
| **经营活动现金流合计** | **$20.8** | **$29.3** | **$36.5** |
| | | | |
| **投资活动现金流** | | | |
| 资本支出（CapEx） | $(3.5) | $(4.0) | $(5.0) |
| 并购支出 | $0.0 | $(5.0) | $0.0 |
| 其他投资活动 | $(0.5) | $(0.3) | $(0.5) |
| **投资活动现金流合计** | **$(4.0)** | **$(9.3)** | **$(5.5)** |
| | | | |
| **筹资活动现金流** | | | |
| 股权融资 | $0.0 | $0.0 | $0.0 |
| 债务融资/偿还 | $0.0 | $0.0 | $0.0 |
| 回购及分红 | $(1.0) | $(1.5) | $(2.0) |
| **筹资活动现金流合计** | **$(1.0)** | **$(1.5)** | **$(2.0)** |
| | | | |
| **现金净变动** | **$15.8** | **$18.5** | **$29.0** |
| 期初现金余额 | $44.7 | $45.0 | $58.5 |
| **期末现金余额** | **$45.0** | **$58.5** | **$72.0** |
| | | | |
| **自由现金流（FCF）** | **$17.3** | **$25.3** | **$31.5** |
| **FCF 利润率** | **18.5%** | **22.4%** | **23.1%** |

---

## Tab 5: Operating Metrics（运营指标）

[DATA SOURCE: CloudPeak 管理层运营数据。行业基准参考 CRWD 603 客户 ARR>$1M (investors.datadoghq.com), DDOG FY2025 Non-GAAP Operating Margin 22-25% (investors.datadoghq.com).]

### 关键 SaaS 运营指标

| 运营指标 | FY2022A | FY2023A | FY2024A | FY2025E |
|---------|---------|---------|---------|---------|
| **客户指标** | | | | |
|  企业客户数 | 485 | 580 | 690 | 810 |
|  ARR > $500K 客户数 | 28 | 38 | 52 | 68 |
|  ARR > $100K 客户数 | 125 | 160 | 205 | 260 |
|  YoY 客户增长 | 12% | 20% | 19% | 17% |
| | | | | |
| **留存与扩张** | | | | |
|  总收入留存率（GRR） | 92% | 93% | 94% | 95% |
|  净收入留存率（NRR） | 118% | 121% | 123% | 125% |
|  Logo Churn Rate | 8% | 7% | 6% | 5% |
| | | | | |
| **单位经济** | | | | |
|  客户获取成本（CAC）, $K | 85 | 82 | 78 | 75 |
|  客户生命周期价值（LTV）, $K | 520 | 580 | 650 | 720 |
|  LTV/CAC 比率 | 6.1x | 7.1x | 8.3x | 9.6x |
|  ARPA（平均每客户 ARR）, $K | 158 | 170 | 172 | 177 |
| | | | | |
| **效率指标** | | | | |
|  人均收入（Revenue/Employee）, $K | 195 | 210 | 228 | 245 |
|  员工总数 | 392 | 445 | 495 | 557 |
|  CAC 回收期（月） | 14 | 13 | 12 | 11 |
| | | | | |
| **ARR 指标** | | | | |
|  期末 ARR, $M | $76.6 | $98.6 | $118.7 | $143.4 |
|  ARR YoY 增长 | 18% | 29% | 20% | 21% |
|  净新增 ARR, $M | $11.7 | $22.0 | $20.1 | $24.7 |
| | | | | |
| **Rule of 40** | | | | |
|  收入增长率 | 18.5% | 22.2% | 20.6% | 21.0% |
|  EBITDA 利润率（FCF 基准） | 18.5% | 22.4% | 22.4% | 23.1% |
|  **Rule of 40 得分** | **37.0%** | **44.6%** | **43.0%** | **44.1%** |

---

## Tab 6: Segment Performance（分部业绩）

[DATA SOURCE: CloudPeak 管理层分部财务数据。]

### 收入分部分析，单位：$M

| 分部 | FY2023A | 占比 | FY2024A | 占比 | FY2025E | 占比 |
|------|---------|------|---------|------|---------|------|
| **按产品线** | | | | | | |
|  云成本优化（Cost Optimization） | $37.4 | 40.0% | $45.1 | 40.0% | $54.6 | 40.0% |
|  多云编排（Multi-Cloud Orchestration） | $28.1 | 30.0% | $35.7 | 31.7% | $44.6 | 32.7% |
|  安全合规（Security & Compliance） | $18.7 | 20.0% | $23.6 | 20.9% | $28.7 | 21.0% |
|  专业服务（Professional Services） | $9.3 | 10.0% | $8.4 | 7.4% | $8.6 | 6.3% |
| **总收入** | **$93.5** | **100%** | **$112.8** | **100%** | **$136.5** | **100%** |
| | | | | | | |
| **按地区** | | | | | | |
|  北美 | $65.5 | 70.0% | $77.8 | 69.0% | $93.4 | 68.4% |
|  欧洲 | $18.7 | 20.0% | $23.7 | 21.0% | $29.6 | 21.7% |
|  亚太及其他 | $9.3 | 10.0% | $11.3 | 10.0% | $13.5 | 9.9% |
| **总收入** | **$93.5** | **100%** | **$112.8** | **100%** | **$136.5** | **100%** |
| | | | | | | |
| **按客户规模** | | | | | | |
|  大型企业（ARR > $500K） | $42.0 | 44.9% | $54.8 | 48.6% | $68.5 | 50.2% |
|  中型企业（ARR $100K-$500K） | $32.8 | 35.1% | $38.4 | 34.0% | $44.9 | 32.9% |
|  小型企业（ARR < $100K） | $18.7 | 20.0% | $19.6 | 17.4% | $23.1 | 16.9% |
| **总收入** | **$93.5** | **100%** | **$112.8** | **100%** | **$136.5** | **100%** |

### 分部毛利率分析

| 分部 | FY2024A 毛利率 |
|------|----------------|
| 云成本优化 | 82.0% |
| 多云编排 | 78.5% |
| 安全合规 | 72.0% |
| 专业服务 | 45.0% |
| **综合毛利率** | **76.9%** |

---

## Tab 7: Market Analysis（市场分析）

[DATA SOURCE: WebSearch — Grand View Research (grandviewresearch.com), MarketsandMarkets (marketandmarkets.com), Fortune Business Insights (fortunebusinessinsights.com), PitchBook (pitchbook.com).]

### 市场规模与增长

| 市场细分 | 2024 市场规模 | 2025E | 2030E | CAGR |
|---------|-------------|-------|-------|------|
| 全球云计算市场 | $1,126B | $1,295B | $3,350B | 16.0% |
| 全球 SaaS 市场 | $266B | $315B | $887B | 14.7% |
| SaaS 管理平台市场 | $3.8B | $4.6B | $9.4B | 15.4% |
| 云管理平台（CMP）市场 | $2.8B | $3.3B | $7.0B | 16.5% |

### 竞争格局

| 竞争对手 | 类型 | 优势领域 | 威胁等级 |
|---------|------|---------|---------|
| VMware Aria (Broadcom) | 大型厂商 | 混合云管理 | 高 |
| Flexera One | 纯 SaaS | IT 资产/成本管理 | 中-高 |
| CloudHealth (VMware) | 大型厂商 | 多云成本治理 | 中 |
| Apptio (IBM) | 大型厂商 | IT 财务管理 | 中-高 |
| Spot.io (NetApp) | 大型厂商 | 云优化自动化 | 中 |
| HashiCorp (IBM) | 大型厂商 | 基础设施编排 | 中 |

### CloudPeak 市场定位
- **核心差异化：** AI 驱动的智能成本优化引擎，跨云统一编排能力
- **目标市场份额：** 当前约 4-5% 的云管理平台市场
- **增长路径：** 向安全合规领域扩展（TAM 增加 $5B+），向亚太和欧洲市场渗透

### 可比公司分析（Comparable Company Analysis）

[DATA SOURCE: WebSearch — CRWD IR (ir.crowdstrike.com), DDOG IR (investors.datadoghq.com), PANW IR (investors.paloaltonetworks.com), ZS IR (ir.zscaler.com), FTNT IR (fortinet.com), Macrotrends (macrotrends.net), Yahoo Finance (finance.yahoo.com), SaaS Capital (saas-capital.com).]

| 指标 | CRWD | DDOG | PANW | ZS | FTNT | 中位数 |
|------|------|------|------|-----|------|--------|
| **收入（Revenue, $B）** | | | | | | |
|  FY2024 | $3.06 | $2.68 | $8.00 | $2.17 | $5.32 | $3.06 |
|  FY2025E | $3.95 | $3.43 | $9.20 | $2.67 | $5.96 | $3.95 |
|  YoY 增长 | 29% | 28% | 15% | 23% | 12% | 23% |
| **ARR（$B）** | $4.24 | N/A | $5.58 (NGS) | $3.02 | N/A | $4.24 |
| **毛利率** | | | | | | |
|  GAAP | 75% | 79% | 73% | 77% | 80% | 77% |
|  Non-GAAP | 80% | 80% | 75% | 77% | 80% | 80% |
| **EBITDA** | | | | | | |
|  EBITDA, $M | $295 | ~$170 | $2,092 | $163 | $2,171 | $295 |
|  EBITDA 利润率 | 7.5% | 5.0% | 22.7% | 6.1% | 36.4% | 7.5% |
| **运营利润率（Non-GAAP）** | 25% | 22% | 22% | 21% | 30% | 22% |
| **自由现金流（FCF, $B）** | $1.07 | $0.78 | N/A | N/A | $1.88 | $1.07 |
|  FCF 利润率 | 27% | 29% | N/A | N/A | 32% | 29% |
| **客户指标** | | | | | | |
|  ARR > $1M 客户数 | ~350 | 603 | N/A | N/A | N/A | ~476 |
| **运营效率** | | | | | | |
|  Rule of 40 | ~56% | ~52% | ~37% | ~29% | ~48% | ~48% |
| **估值** | | | | | | |
|  市值（Market Cap, $B） | ~$134 | ~$40 | ~$147 | ~$30 | ~$63 | ~$63 |
|  EV/Revenue (TTM) | ~34x | ~12x | ~16x | ~11x | ~11x | ~12x |
|  EV/FCF | ~125x | ~51x | N/A | N/A | ~34x | ~51x |

### CloudPeak 可比公司估值定位

| 估值指标 | CloudPeak | 可比公司中位数 | 说明 |
|---------|-----------|--------------|------|
| EV/Revenue | 7.0-8.0x | 12x | 折价反映规模较小及私有状态 |
| EV/ARR | 7.5-8.5x | 11x | 基于 $143M ARR |
| EV/EBITDA | 42-50x | 51x | 增长阶段溢价 |
| EV/FCF | 35-40x | 51x | 折价反映流动性折扣 |
| **隐含 EV 范围** | **$1.0B - $1.2B** | — | 基于 $136.5M Revenue |

---

## Tab 8: Investment Highlights（投资亮点）

[DATA SOURCE: 综合 WebSearch 数据及行业分析。]

### 竞争优势

1. **AI 驱动的成本优化引擎**
   - 专有机器学习模型可自动识别云资源浪费并执行优化建议
   - 平均为客户节省 25-35% 的云支出，ROI 可量化
   - 持续学习客户使用模式，优化精度随时间提升

2. **多云统一管理平台**
   - 同时支持 AWS、Azure、GCP 三大公有云
   - 单一控制平面提供跨云可视性、治理和自动化
   - 避免客户被单一云供应商锁定

3. **高客户粘性与扩张能力**
   - NRR > 120% 表明现有客户持续扩大使用范围
   - GRR > 93% 反映低客户流失率
   - LTV/CAC > 8x 表明高效的销售引擎

4. **强劲的自由现金流生成**
   - FCF 利润率 > 20%，现金流效率优于多数可比公司
   - 轻资产 SaaS 模式驱动高现金转换率
   - 截至 FY2024 期末现金余额 $58.5M，无外部债务

5. **有利的行业顺风**
   - 云管理平台市场以 15-16% CAGR 增长
   - 企业云支出持续增长（2024 年全球云计算市场 > $1.1T）
   - 多云和混合云趋势增加管理复杂性和工具需求

### 增长机会

1. **安全合规模块扩展**
   - 当前安全合规仅占收入 21%，潜在渗透空间大
   - CSPM（云安全态势管理）和 CWPP（云工作负载保护）市场快速增长
   - 可参考 PANW NGS ARR 增长至 $5.58B 的路径（32% YoY）

2. **地理扩张**
   - 欧洲市场当前仅占 21%，欧洲云管理市场增速超过北美
   - 亚太市场渗透率低，日本和澳大利亚市场潜力大
   - 可参考 ZS 在国际市场 30%+ 收入占比的成功模式

3. **向上拓展大型企业客户**
   - 当前 ARR > $500K 客户 52 家，目标 3 年内达到 150+
   - 大型企业的云管理需求更复杂，合同价值更高
   - 可参考 CRWD 603 家 ARR > $1M 客户的增长路径

4. **平台生态与集成**
   - 开放 API 与第三方工具集成
   - 构建合作伙伴渠道（MSP、咨询公司）
   - 提升平台粘性和转换成本

### 风险因素

1. **竞争风险**
   - Broadcom（VMware）、IBM（Apptio）等大型厂商具有资源优势和客户关系
   - 云服务商原生工具（AWS Cost Explorer、Azure Advisor）可能蚕食市场

2. **客户集中度风险**
   - 前 10 大客户贡献约 25-30% 的 ARR
   - 任何单一大型客户流失可能显著影响收入

3. **技术风险**
   - AI/ML 技术迭代速度快，需持续研发投入
   - 云服务商 API 变更可能导致集成中断

4. **宏观经济风险**
   - 企业 IT 预算紧缩可能影响新客户获取
   - SaaS 估值倍数持续压缩（2024 年 6.2x 降至 2026 Q1 3.3x 中位数）

### 管理层评估
- CEO 具有 20+ 年企业软件经验，曾在大型 SaaS 公司担任高管
- CTO 为云基础设施领域知名技术专家
- 管理团队在 CloudPeak 平均任期超过 5 年
- 关键管理团队成员具有成功退出经验

---

## 调整项说明（Normalization Adjustments）

[DATA SOURCE: CloudPeak 管理层财务数据及审计报告。]

| 调整项 | FY2023A | FY2024A | 说明 |
|--------|---------|---------|------|
| 报告 EBITDA | $13.0 | $20.7 | GAAP 基准 |
| 股权激励费用（SBC）加回 | $6.5 | $7.8 | 非现金运营费用，行业标准加回 |
| 一次性并购费用加回 | $0.0 | $1.5 | FY2024 小型技术收购整合费用 |
| 重组费用加回 | $0.0 | $0.0 | 无重组费用 |
| **调整后 EBITDA** | **$14.8** | **$22.6** | |
| **调整后 EBITDA 利润率** | **15.8%** | **20.0%** | |

### 保守性评估
- 股权激励（SBC）加回符合私募股权行业标准
- 并购费用为真正的一次性支出，加回合理
- 未加回任何法律诉讼或重组费用（未发生）
- 基准案例（Base Case）采用调整后 EBITDA

---

## 情景分析（Scenario Analysis）

| 情景 | FY2025E ARR | 收入增长率 | EBITDA 利润率 | FCF, $M |
|------|------------|-----------|-------------|---------|
| **管理层案例（Management Case）** | $148M | 23% | 22% | $33.0 |
| **基准案例（Base Case）** | $143M | 21% | 20% | $31.5 |
| **下行案例（Downside Case）** | $133M | 16% | 15% | $24.0 |

### 基准案例关键假设
- 收入增长率 21%（管理层预测 23%，下修 2 个百分点反映执行风险）
- EBITDA 利润率 20%（与管理层预测一致，基于运营杠杆可持续性）
- CapEx/Revenue 约 3.7%（轻资产 SaaS 模式）
- 净营运资本变动约 $5.9M（递延收入增长驱动）

### 下行案例关键假设
- 收入增长率 16%（宏观经济放缓，IT 预算紧缩）
- EBITDA 利润率 15%（客户获取成本上升，定价压力）
- 客户流失率从 6% 升至 8%
- 大客户扩展速度放缓

---

## 数据来源汇总（Sources）

### 公司财务数据
- CloudPeak Technologies 管理层提供财务报表及运营数据

### 可比公司数据
- CrowdStrike (CRWD): [ir.crowdstrike.com — FY2025 Results](https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2025/)
- CrowdStrike (CRWD): [ir.crowdstrike.com — FY2026 Results](https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2026)
- Datadog (DDOG): [investors.datadoghq.com — FY2025 Results](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-fourth-quarter-and-fiscal-year-2025-financial)
- Datadog (DDOG): [investors.datadoghq.com — Q1 2026 Results](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-first-quarter-2026-financial-results)
- Palo Alto Networks (PANW): [paloaltonetworks.com — FY2025 Results](https://www.paloaltonetworks.com/company/press/2025/palo-alto-networks-reports-fiscal-fourth-quarter-and-fiscal-year-2025-financial-results)
- Zscaler (ZS): [ir.zscaler.com — FY2025 Results](https://ir.zscaler.com/news-releases/news-release-details/zscaler-reports-fourth-quarter-and-fiscal-2025-financial-results)
- Fortinet (FTNT): [fortinet.com — FY2024 Results](https://www.fortinet.com/corporate/about-us/newsroom/press-releases/2025/fortinet-reports-fourth-quarter-full-year-2024-financial-results)

### 市场数据
- Grand View Research: [Cloud Computing Industry](https://www.grandviewresearch.com/industry-analysis/cloud-computing-industry)
- MarketsandMarkets: [Cloud Computing Market](https://www.marketsandmarkets.com/Market-Reports/cloud-computing-market-234.html)
- Fortune Business Insights: [SaaS Market](https://www.fortunebusinessinsights.com/software-as-a-service-saas-market-102222)
- MarketsandMarkets: [SaaS Management Market](https://www.marketsandmarkets.com/Market-Reports/saas-management-market-215635254.html)

### 估值倍数数据
- PitchBook: [Q3 2025 Enterprise SaaS Public Comp Sheet](https://pitchbook.com/news/reports/q3-2025-enterprise-saas-public-comp-sheet-and-valuation-guide)
- QuantPillar: [2025-2026 Private Market Valuation Multiples](https://quantpillar.com/resources/guides/valuation-multiples/)
- SaaS Capital: [2025 Private SaaS Company Valuations](https://www.saas-capital.com/blog-posts/private-saas-company-valuations-multiples/)
- WithOrb: [Public SaaS Multiples](https://www.withorb.com/blog/public-saas-multiples)

### 财务数据平台
- Macrotrends: [macrotrends.net](https://www.macrotrends.net)
- Yahoo Finance: [finance.yahoo.com](https://finance.yahoo.com)
- SEC EDGAR: [sec.gov](https://www.sec.gov)
- AlphaQuery: [alphaquery.com](https://www.alphaquery.com)
- Business Quant: [businessquant.com](https://businessquant.com)

---

**免责声明：** 本数据包仅供投资分析参考之用。CloudPeak Technologies 为非上市公司，其财务数据来源于管理层提供信息，未经独立审计师审计。可比公司数据来源于公开披露的财务报表和第三方金融数据平台。投资者应进行独立尽职调查，不应对本数据包中的任何信息产生依赖。过往业绩不代表未来表现。
