[DATA SOURCE: Gartner Worldwide Public Cloud Spending Forecast (2025-2026); Fortune Business Insights Cloud FinOps Market Report; MarketsandMarkets Cloud FinOps Market Analysis; Flexera 2025 State of the Cloud Report; QuantPillar SaaS Valuation Multiples (2025-2026); Aventis Advisors SaaS Valuation Multiples; Finerva B2B SaaS 2026 Valuation Multiples; Software Equity Group (SEG) Annual SaaS Report 2025; SaaS Capital Private SaaS Retention Benchmarks 2025; Benchmarkit 2025 SaaS Performance Metrics; ChartMogul SaaS Retention Report; Optifai NRR Benchmarks; BCG Rule of 40 Analysis 2025; BVP Cloud 100 Benchmarks Report; Grand View Research Cloud Computing Market; TechSci Research Cloud Management Platform Market; Fortune Business Insights Multi-Cloud Management Market; Precedence Research Multi-Cloud Management Market; State of FinOps 2026 Report; First Page Sage B2B SaaS CAC 2025 Report; Data-Mania B2B SaaS Benchmarks 2026]

---

# CONFIDENTIAL INFORMATION MEMORANDUM

## CloudPeak Technologies, Inc.

**Prepared for Selected Prospective Buyers**

---

**STRICTLY CONFIDENTIAL**

This Confidential Information Memorandum (the "CIM") has been prepared by CloudPeak Technologies, Inc. (the "Company" or "CloudPeak") and its financial advisor to provide certain information to prospective buyers in connection with a potential transaction. This document is confidential and proprietary. Recipients agree not to reproduce, distribute, or disclose any information contained herein without the prior written consent of the Company.

**Date:** May 2026

---

## TABLE OF CONTENTS

- I. Executive Summary
- II. Company Overview
- III. Industry Overview
- IV. Growth Opportunities
- V. Customers & Sales
- VI. Operations
- VII. Financial Overview
- VIII. Appendix

---

# I. EXECUTIVE SUMMARY

## Company Overview

CloudPeak Technologies is a leading B2B SaaS cloud management platform that enables enterprises to optimize, govern, and automate their multi-cloud infrastructure across AWS, Microsoft Azure, and Google Cloud Platform. Founded in 2016 and headquartered in Denver, Colorado, CloudPeak has grown to **$143 million in Annual Recurring Revenue (ARR)** as of Q1 2026, serving over 1,200 enterprise customers across 28 countries.

The Company's unified platform integrates cloud cost optimization (FinOps), infrastructure automation, security compliance, and performance monitoring into a single pane of glass -- addressing the full lifecycle of cloud management for enterprises navigating increasingly complex multi-cloud environments.

## Investment Highlights

**1. Scaled and Growing ARR Platform ($143M ARR, 24% YoY Growth)**
CloudPeak has achieved significant scale with $143M in ARR, growing at 24% year-over-year as of Q1 2026. This growth rate meaningfully exceeds the median growth rate for private SaaS companies at this scale (estimated at 15-25% per SaaS Capital and Bessemer benchmarks), demonstrating durable product-market fit and continued momentum.

**2. Best-in-Class Net Revenue Retention (118% NRR)**
CloudPeak achieves 118% Net Revenue Retention, significantly above the 2025 median NRR of ~101% for all SaaS companies (Benchmarkit 2025) and in line with the enterprise SaaS median of 118% (Optifai). This reflects strong land-and-expand dynamics, with expansion revenue from upsells, cross-sells, and platform modules outpacing churn by a wide margin.

**3. Attractive Unit Economics (4.2x LTV:CAC Ratio)**
The Company maintains a healthy LTV:CAC ratio of approximately 4.2x, above the 3:1 benchmark considered healthy for B2B SaaS (per industry standards from Stripe, Data-Mania, and First Page Sage). CAC payback period stands at approximately 14 months for enterprise customers, with strong payback efficiency given the high-ACV nature of the business.

**4. Positioned in a Large and Rapidly Growing Market**
The global cloud management platform market is projected to grow from ~$21 billion in 2024 to ~$54.8 billion by 2030 at a CAGR of 17.3% (Yahoo Finance / industry research). The broader Cloud FinOps market is projected to grow from $15.1 billion in 2025 to $26.9 billion by 2030 at a 12.6% CAGR (MarketsandMarkets). CloudPeak is positioned at the intersection of these two high-growth segments.

**5. High Gross Margins and Clear Path to Profitability**
CloudPeak maintains an 81% gross margin, consistent with best-in-class enterprise SaaS benchmarks of 70-85% (BCG, SaaS Capital). The Company is approaching Rule of 40 compliance with a combined growth rate + EBITDA margin score of approximately 36 (24% growth + 12% EBITDA margin), with a clear line of sight to exceeding 40% through operating leverage.

**6. Deep Enterprise Relationships and Low Volatility**
The Company serves 42 Fortune 500 companies with a median contract duration of 3 years. Weighted average contract life is 2.8 years, and annual dollar churn is below 5%. Top-20 customer concentration is manageable at approximately 38% of ARR.

**7. Experienced Management Team with Domain Expertise**
The founding and executive team has a combined 120+ years of experience in cloud infrastructure, enterprise software, and SaaS operations. The leadership team has scaled the business through multiple market cycles and technology shifts.

## Financial Summary

| Metric | FY2023A | FY2024A | FY2025A | Q1 2026 |
|---|---|---|---|---|
| Annual Recurring Revenue (ARR) | $98M | $115M | $143M | $155M (exit) |
| ARR Growth Rate | 32% | 17% | 24% | 24% YoY |
| Revenue | $89M | $108M | $134M | $36M |
| Gross Profit | $71M | $87M | $109M | $29M |
| Gross Margin | 80% | 81% | 81% | 81% |
| EBITDA | $3M | $9M | $16M | $5M |
| EBITDA Margin | 3% | 8% | 12% | 14% |
| Free Cash Flow | ($5M) | $2M | $8M | $3M |
| Net Revenue Retention | 115% | 116% | 118% | 118% |

## Transaction Overview

CloudPeak Technologies has retained [Financial Advisor] to explore strategic alternatives, including a potential sale of the Company. The transaction is expected to include:

- **100% of the equity** of CloudPeak Technologies, Inc.
- **Indicative timeline:** Management presentations in Q2 2026, indicative offers by Q3 2026, definitive agreement by Q4 2026
- **Transaction structure:** Preferred all-cash, but open to strategic equity rollover structures
- **Estimated valuation range:** Based on current SaaS M&A benchmarks of 4.7-6.1x EV/Revenue for private SaaS (Aventis Advisors, QuantPillar), the implied enterprise value range is approximately **$670M to $870M** (4.7x to 6.1x trailing ARR of $143M)

---

# II. COMPANY OVERVIEW

## History and Founding

CloudPeak Technologies was founded in 2016 in Denver, Colorado by a team of former AWS and Google Cloud engineers who identified a critical gap in enterprise cloud management. The founders observed that as enterprises migrated workloads to multiple cloud providers, they faced fragmented tooling, runaway costs, governance challenges, and operational complexity.

Key milestones:

| Year | Milestone |
|---|---|
| 2016 | Company founded; seed funding of $4M |
| 2017 | Launched MVP cloud cost optimization module |
| 2018 | Series A ($18M); reached 50 customers |
| 2019 | Series B ($42M); launched multi-cloud automation engine |
| 2020 | Reached $30M ARR; expanded to Europe |
| 2021 | Series C ($75M); launched security compliance module |
| 2022 | Reached $75M ARR; 500+ customers |
| 2023 | Completed strategic acquisition of CloudGovern AI |
| 2024 | Reached $115M ARR; launched FinOps Pro suite |
| 2025 | Reached $143M ARR; expanded to APAC region |
| 2026 Q1 | ARR reached $155M run-rate; 1,200+ customers |

## Mission and Value Proposition

**Mission:** To be the definitive platform for enterprise cloud intelligence -- enabling organizations to run their multi-cloud infrastructure with complete visibility, optimal efficiency, and automated governance.

**Value Proposition:** CloudPeak delivers a unified platform that replaces 3-5 point solutions typically used by enterprises for cloud cost management, infrastructure automation, compliance monitoring, and performance optimization. This consolidation reduces total cost of ownership by 30-40% while improving operational outcomes.

## Products and Services

### CloudPeak Platform (100% SaaS)

**Module 1: FinOps Pro (Cloud Cost Optimization)**
- Real-time cloud spend visibility across AWS, Azure, and GCP
- AI-driven rightsizing recommendations and automated savings execution
- Reserved Instance and Savings Plan optimization
- Showback/chargeback with business-unit tagging
- Unit economics dashboards (cost per transaction, per customer, per feature)

**Module 2: CloudAutomate (Infrastructure Automation)**
- Infrastructure-as-Code (IaC) orchestration (Terraform, Pulumi, CloudFormation)
- Auto-scaling policies and workload scheduling
- Multi-cloud provisioning with policy guardrails
- Disaster recovery automation and failover

**Module 3: CloudGovern (Security & Compliance)**
- Continuous compliance monitoring (SOC 2, HIPAA, PCI-DSS, GDPR, FedRAMP)
- Policy-as-code enforcement across cloud environments
- Drift detection and automated remediation
- Audit-ready reporting and evidence collection

**Module 4: CloudPerform (Performance Monitoring)**
- Multi-cloud infrastructure performance analytics
- Application-level observability integration
- SLA monitoring and alerting
- Capacity planning and forecasting

### Professional Services (8% of Revenue)
- Implementation and onboarding
- Cloud maturity assessment
- Custom integration development
- Training and certification programs

## Business Model and Revenue Streams

| Revenue Stream | % of Total Revenue | Description |
|---|---|---|
| Platform Subscriptions | 87% | Annual/multi-year SaaS contracts based on cloud spend under management |
| Professional Services | 8% | Implementation, training, and advisory |
| Premium Support | 5% | Enhanced SLA, dedicated CSM, priority support |

**Pricing Model:** Platform subscriptions are priced on a tiered basis tied to the customer's aggregate annual cloud spend under management, ranging from $50K to $2M+ annually for the largest enterprises.

## Key Differentiators and Competitive Advantages

**1. Unified Platform vs. Point Solutions**
CloudPeak uniquely combines FinOps, automation, governance, and performance in a single platform. Most competitors specialize in one or two of these domains (e.g., Flexera in cost management, Datadog in observability, VMware Aria in infrastructure).

**2. Multi-Cloud Depth**
The platform provides parity across AWS, Azure, and GCP -- with 350+ integrations and API connectors. Over 92% of large enterprises now operate in multi-cloud environments (Gartner, 2024), and CloudPeak is purpose-built for this reality.

**3. AI-Native Architecture**
CloudPeak's AI engine processes over 2.8 billion data points daily across customer environments, generating automated optimization recommendations that have delivered $1.2 billion in cumulative documented savings for customers.

**4. Enterprise-Grade Security and Compliance**
CloudGovern provides continuous compliance across 12 frameworks with automated evidence collection, reducing audit preparation time by an average of 70%.

**5. Strong Developer Ecosystem**
The platform offers 200+ pre-built integrations, a robust API, and a growing marketplace of community-built extensions with 15,000+ active developers.

---

# III. INDUSTRY OVERVIEW

## Market Size and Growth Dynamics

### Total Addressable Market (TAM)

The global cloud computing market generated approximately **$752 billion in revenue in 2024** and is expected to reach **$2.39 trillion by 2030** (Grand View Research). Within this, Gartner forecasts worldwide public cloud end-user spending to reach **$723 billion in 2025**, growing at approximately 21.3% (Gartner, 2025).

### Serviceable Addressable Market (SAM)

The Cloud Management Platform (CMP) market, encompassing tools for cloud operations, cost management, automation, and governance, is projected to grow from approximately **$21 billion in 2024 to $54.8 billion by 2030** at a CAGR of 17.3% (industry research). The Cloud FinOps segment specifically is valued at **$15.1 billion in 2025**, projected to reach **$26.9 billion by 2030** at a 12.6% CAGR (MarketsandMarkets).

The Multi-Cloud Management market was valued at **$13.4 billion in 2025** and is projected to reach **$85.9 billion by 2034** (Fortune Business Insights), reflecting the accelerating need for cross-platform management tools.

### Serviceable Obtainable Market (SOM)

CloudPeak's current market penetration represents approximately 0.7% of the SAM, indicating substantial runway for growth. The Company targets enterprises with annual cloud spend exceeding $2 million, representing an estimated SOM of $8-10 billion.

## Key Industry Trends and Tailwinds

### 1. Accelerating Multi-Cloud Adoption
- **Over 92% of large enterprises** now operate in multi-cloud environments (Gartner, 2024)
- **50% of organizations** run workloads in a multi-cloud setup (Parallels, 2025)
- **39% of businesses** use hybrid cloud setups (industry statistics, 2025)
- This trend directly drives demand for unified management platforms like CloudPeak

### 2. Cloud Cost Optimization Becoming Board-Level Priority
- Wasted cloud spend has climbed to **29%** of total cloud budgets (Flexera 2026 State of the Cloud Report)
- **90% of FinOps practitioners** now manage SaaS costs alongside IaaS (State of FinOps 2026 Report)
- FinOps is expanding beyond public cloud to encompass SaaS, licensing, private cloud, and data centers

### 3. AI-Driven Cloud Management
- AI and machine learning are becoming essential for real-time optimization at scale
- Gartner forecasts **sovereign cloud spend will increase 35.6% to $80 billion in 2026**
- The integration of AI into cloud operations is driving the next wave of platform evolution

### 4. Regulatory and Compliance Complexity
- Increasing data sovereignty requirements (GDPR, emerging AI regulations)
- Growing audit burden for enterprises operating across jurisdictions
- Continuous compliance automation is becoming a necessity, not a luxury

### 5. Enterprise Cloud Maturity Deepening
- Global cloud computing market projected to grow from **$912 billion in 2025 to $5.15 trillion by 2034**
- Organizations are moving from cloud migration to cloud optimization and governance
- The buyer persona is shifting from engineering teams to FinOps and finance leadership

## Competitive Landscape

| Competitor | Primary Focus | Gartner Rating | Est. Revenue | Strengths | Vulnerabilities |
|---|---|---|---|---|---|
| **VMware Aria (Broadcom)** | Infrastructure & Virtualization | 4.3/5 (182 reviews) | $5B+ (cloud mgmt) | Enterprise virtualization dominance | Customer churn post-Broadcom acquisition; licensing changes |
| **Flexera** | FinOps & ITAM | 4.3/5 (142 reviews); 2025 MQ Leader | ~$500M | Only leader in FinOps + ITAM + SaaS mgmt | Narrower scope vs. full-stack platforms |
| **ServiceNow** | ITSM & Cloud Ops | MQ Leader | $11B+ (total) | Deep enterprise IT workflows | Observability still maturing |
| **Datadog** | Observability & Monitoring | MQ Leader | $2.5B+ | Unified observability, DevOps-centric | Narrower moat; not a governance/FinOps platform |
| **HashiCorp (IBM)** | IaC & Multi-Cloud Orchestration | MQ Challenger | ~$600M | Terraform ecosystem dominance | Being absorbed into IBM; integration risk |
| **Spot by NetApp** | Cloud Cost Optimization | Challenger | ~$200M | Strong spot instance optimization | Limited to cost optimization; no governance |

**CloudPeak's Positioning:** CloudPeak occupies a differentiated position as a unified, multi-cloud management platform that spans cost optimization (FinOps), infrastructure automation, compliance governance, and performance monitoring -- a combination no single competitor fully replicates.

## Barriers to Entry

1. **Data Network Effects:** CloudPeak's AI models improve with each additional customer environment, creating a compounding advantage in optimization recommendations
2. **Enterprise Integration Depth:** 350+ integrations and API connectors represent years of development investment
3. **Switching Costs:** Once embedded in enterprise cloud operations, CloudPeak becomes mission-critical infrastructure with high switching costs (average 3-year contract, 14-month CAC payback)
4. **Compliance Certifications:** SOC 2 Type II, FedRAMP authorization, and 12 framework certifications require significant investment and time to replicate
5. **Developer Ecosystem:** 15,000+ active developers and a marketplace create community-driven lock-in

---

# IV. GROWTH OPPORTUNITIES

## Organic Growth Levers

### 1. Expansion into Adjacent Cloud Categories
The FinOps market is expanding beyond IaaS to encompass SaaS cost management, licensing optimization, and private cloud governance. The State of FinOps 2026 Report shows that **90% of respondents** now manage or plan to manage SaaS costs (up from 65% in 2025). CloudPeak is developing SaaS Cost Intelligence and Licensing Optimization modules to capture this expansion, representing an estimated incremental TAM of $3-5 billion.

### 2. AI-Powered Autonomous Cloud Operations (AIOps)
CloudPeak is investing in next-generation AI capabilities that move from recommendations to fully autonomous cloud optimization. With AI infrastructure spending projected to drive **21.3% public cloud growth in 2026** (Gartner), the Company is developing self-healing infrastructure, predictive scaling, and anomaly detection capabilities. Targeted launch: Q4 2026.

### 3. International Expansion
CloudPeak currently derives approximately 78% of revenue from North America. The European and APAC markets represent significant untapped potential, particularly as:
- Global sovereign cloud spend is increasing **35.6% to $80 billion in 2026** (Gartner)
- European enterprises face mounting GDPR and AI Act compliance requirements
- The Company has opened offices in London and Singapore with plans for Frankfurt and Tokyo

### 4. Upsell and Cross-Sell within Existing Base
With 118% NRR and an average of 2.4 modules per customer, CloudPeak has significant room to expand platform adoption:
- Current average: 2.4 of 4 modules adopted
- Target: 3.5 modules per customer by 2027
- Each additional module increases average contract value by 35-50%

### 5. Mid-Market Downmarket Expansion
CloudPeak currently serves primarily large enterprises (1,000+ employees). The mid-market segment (200-1,000 employees) represents a significant greenfield opportunity. The Company is developing a self-serve, lower-ACV product tier to access this market without diluting enterprise sales efficiency.

## Inorganic Growth (M&A Opportunities)

CloudPeak has identified several potential acquisition targets that would accelerate its roadmap:

- **Cloud security startups** with CNAPP or CSPM capabilities ($20-50M ARR targets)
- **Specialized FinOps tools** focused on Kubernetes/container cost allocation
- **Regional cloud consultancies** to accelerate international go-to-market
- **Compliance automation platforms** to deepen CloudGovern capabilities

The Company completed one strategic acquisition in 2023 (CloudGovern AI for $28M), which contributed $12M in ARR within 18 months of integration.

## Operational Improvement Opportunities

1. **Sales Efficiency:** Increase quota-carrying rep productivity from $650K to $850K ARR per rep through improved enablement and AI-assisted selling tools
2. **Product-Led Growth:** Launch self-serve trial and freemium tier for mid-market to reduce CAC and increase top-of-funnel pipeline
3. **Gross Margin Expansion:** Migrate remaining on-premises components to fully cloud-native architecture, targeting 83-85% gross margins by 2027
4. **Customer Success Automation:** Implement AI-driven health scoring and proactive retention workflows to maintain NRR above 115%

---

# V. CUSTOMERS & SALES

## Customer Overview

| Metric | Value |
|---|---|
| Total Enterprise Customers | 1,200+ |
| Fortune 500 Customers | 42 |
| Average Annual Contract Value (ACV) | $119K |
| Median Contract Duration | 3 years |
| Customers by Geography | North America: 78%, EMEA: 15%, APAC: 7% |
| Industries Served | Technology, Financial Services, Healthcare, Retail, Manufacturing, Government |

## Customer Segmentation

| Segment | Customers | % of ARR | Avg ACV | NRR |
|---|---|---|---|---|
| Strategic (> $500K ACV) | 45 | 28% | $890K | 125% |
| Enterprise ($100K-$500K ACV) | 280 | 42% | $215K | 119% |
| Mid-Market ($50K-$100K ACV) | 420 | 22% | $75K | 112% |
| SMB (< $50K ACV) | 455 | 8% | $25K | 98% |

## Top Customer Analysis (Anonymized)

| Customer | Industry | ACV | Modules | Contract Term | Relationship Length |
|---|---|---|---|---|---|
| Customer A | Financial Services | $1.8M | 4 of 4 | 3 years | 5 years |
| Customer B | Technology | $1.4M | 4 of 4 | 3 years | 4 years |
| Customer C | Healthcare | $1.2M | 3 of 4 | 3 years | 3 years |
| Customer D | Retail | $1.1M | 3 of 4 | 2 years | 4 years |
| Customer E | Manufacturing | $0.9M | 4 of 4 | 3 years | 3 years |

**Customer Concentration:** The top 10 customers represent approximately 22% of ARR; the top 20 represent 38%. No single customer exceeds 5% of total ARR. This concentration profile is manageable and consistent with diversified enterprise SaaS businesses at this scale.

## Retention Metrics

| Metric | FY2023 | FY2024 | FY2025 |
|---|---|---|---|
| Gross Revenue Retention (GRR) | 93% | 94% | 95% |
| Net Revenue Retention (NRR) | 115% | 116% | 118% |
| Logo Retention | 96% | 97% | 97% |
| Annual Dollar Churn | 7% | 6% | 5% |

CloudPeak's 118% NRR significantly exceeds the 2025 SaaS industry median of 101% (Benchmarkit) and is in line with enterprise SaaS segment benchmarks of 118% (Optifai). The improving trend reflects deepening platform adoption and increasing stickiness.

## Sales Process and Go-to-Market Strategy

### Sales Model
- **Direct Enterprise Sales:** 65% of new ARR; dedicated account executives with 14-month average sales cycle for Strategic/Enterprise segments
- **Channel Partners:** 20% of new ARR; partnerships with 8 major cloud consultancies and 3 global systems integrators
- **Product-Led Growth:** 15% of new ARR; free trials and freemium entry points for mid-market customers

### Sales Efficiency
| Metric | FY2024 | FY2025 |
|---|---|---|
| Quota-Carrying Reps | 62 | 78 |
| New ARR per Rep | $410K | $490K |
| CAC Payback Period | 16 months | 14 months |
| Sales & Marketing as % of Revenue | 42% | 36% |

### Pipeline
As of Q1 2026, the Company's qualified pipeline stands at $185M, representing 1.3x of the trailing twelve-month ARR. Pipeline conversion rate is approximately 25%, yielding an expected new ARR contribution of approximately $46M from current pipeline over the next 12 months.

---

# VI. OPERATIONS

## Organizational Structure

CloudPeak employs approximately 680 full-time employees across the following functions:

| Function | Headcount | % of Total |
|---|---|---|
| Engineering & Product | 245 | 36% |
| Sales & Marketing | 185 | 27% |
| Customer Success & Support | 105 | 15% |
| General & Administrative | 65 | 10% |
| Professional Services | 80 | 12% |

## Key Personnel

| Name | Title | Background |
|---|---|---|
| [Founder/CEO] | Chief Executive Officer | Former AWS Principal Engineer; 18 years in cloud infrastructure; MBA from Stanford |
| [CTO] | Chief Technology Officer | Former Google Cloud Senior Staff Engineer; 15 years in distributed systems |
| [CRO] | Chief Revenue Officer | Former VP Sales at Datadog; 20 years enterprise SaaS sales leadership |
| [CFO] | Chief Financial Officer | Former CFO at two public SaaS companies; CPA, 25 years finance experience |
| [VP Engineering] | VP of Engineering | Former Engineering Director at ServiceNow; 12 years building cloud platforms |
| [VP Customer Success] | VP of Customer Success | Former VP CS at Flexera; 15 years in enterprise customer success |

## Facilities and Geographic Footprint

| Location | Function | Headcount |
|---|---|---|
| Denver, CO (HQ) | All functions | 340 |
| San Francisco, CA | Engineering & Sales | 120 |
| Austin, TX | Engineering | 65 |
| London, UK | Sales & CS | 55 |
| Toronto, Canada | Engineering | 45 |
| Singapore | Sales & CS | 30 |
| Remote (Global) | Various | 25 |

Total facility footprint: approximately 85,000 square feet across owned and leased offices. All leases are standard commercial terms with remaining durations of 2-5 years.

## Technology and Systems

- **Platform Architecture:** Cloud-native, microservices-based architecture deployed on AWS, Azure, and GCP
- **Data Processing:** Processes 2.8 billion+ data points daily across customer environments
- **Security:** SOC 2 Type II certified, FedRAMP authorized, ISO 27001, HIPAA compliant
- **Development:** CI/CD pipeline with 99.99% platform uptime SLA; 2-week release cadence
- **AI/ML Stack:** Proprietary ML models trained on aggregated (anonymized) cloud telemetry data
- **Integrations:** 350+ pre-built integrations and API connectors

## Vendor Relationships

Key vendor dependencies include AWS, Azure, and GCP for infrastructure hosting (combined approximately $8M annually). The Company maintains favorable enterprise agreements with all three hyperscalers and is a certified partner in each cloud marketplace.

---

# VII. FINANCIAL OVERVIEW

## Historical Income Statement

| ($ in Millions) | FY2021 | FY2022 | FY2023 | FY2024 | FY2025 |
|---|---|---|---|---|---|
| **Revenue** | | | | | |
| Subscription Revenue | $44.0 | $61.5 | $79.2 | $97.2 | $119.3 |
| Professional Services | $4.5 | $5.5 | $6.3 | $7.6 | $10.7 |
| Premium Support | $1.5 | $2.0 | $3.5 | $3.2 | $4.0 |
| **Total Revenue** | **$50.0** | **$69.0** | **$89.0** | **$108.0** | **$134.0** |
| | | | | | |
| **Cost of Revenue** | | | | | |
| Subscription COGS | ($7.5) | ($10.8) | ($14.3) | ($17.5) | ($21.5) |
| Services & Support COGS | ($3.5) | ($4.2) | ($3.7) | ($3.5) | ($3.5) |
| **Total COGS** | **($11.0)** | **($15.0)** | **($18.0)** | **($21.0)** | **($25.0)** |
| | | | | | |
| **Gross Profit** | **$39.0** | **$54.0** | **$71.0** | **$87.0** | **$109.0** |
| **Gross Margin** | **78%** | **78%** | **80%** | **81%** | **81%** |
| | | | | | |
| **Operating Expenses** | | | | | |
| Sales & Marketing | ($20.0) | ($26.5) | ($33.2) | ($39.4) | ($48.2) |
| Research & Development | ($12.5) | ($16.0) | ($21.4) | ($24.8) | ($29.5) |
| General & Administrative | ($6.5) | ($8.0) | ($10.0) | ($11.0) | ($12.3) |
| **Total Operating Expenses** | **($39.0)** | **($50.5)** | **($64.6)** | **($75.2)** | **($90.0)** |
| | | | | | |
| **EBITDA** | **$0.0** | **$3.5** | **$6.4** | **$11.8** | **$19.0** |
| **EBITDA Margin** | **0%** | **5%** | **7%** | **11%** | **14%** |
| | | | | | |
| Depreciation & Amortization | ($1.0) | ($1.5) | ($2.4) | ($3.0) | ($3.5) |
| Interest Expense | ($0.5) | ($0.8) | ($1.0) | ($0.8) | ($0.5) |
| **Pre-Tax Income** | **($1.5)** | **$1.2** | **$3.0** | **$8.0** | **$15.0** |
| Tax Provision | $0.0 | ($0.2) | ($0.7) | ($1.8) | ($3.5) |
| **Net Income** | **($1.5)** | **$1.0** | **$2.3** | **$6.2** | **$11.5** |

## Revenue Analysis

### Revenue by Product Module

| Module | FY2024 | FY2025 | % of FY2025 Revenue |
|---|---|---|---|
| FinOps Pro (Cost Optimization) | $48.6 | $60.3 | 45% |
| CloudAutomate (Infrastructure) | $28.1 | $36.2 | 27% |
| CloudGovern (Compliance) | $18.4 | $24.1 | 18% |
| CloudPerform (Performance) | $9.7 | $13.4 | 10% |
| **Total Platform** | **$104.8** | **$134.0** | **100%** |

Fastest-growing modules: CloudGovern (+31% YoY) and CloudPerform (+38% YoY), driven by increasing regulatory complexity and performance management needs.

### Revenue by Geography

| Region | FY2024 | FY2025 | Growth |
|---|---|---|---|
| North America | $86.4 | $104.5 | 21% |
| EMEA | $14.0 | $18.8 | 34% |
| APAC | $7.6 | $10.7 | 41% |
| **Total** | **$108.0** | **$134.0** | **24%** |

International revenue mix increased from 20% to 22% of total revenue, reflecting early-stage international expansion success.

### Revenue by Customer Size

| Segment | FY2024 % of ARR | FY2025 % of ARR |
|---|---|---|
| Strategic (> $500K ACV) | 25% | 28% |
| Enterprise ($100K-$500K) | 40% | 42% |
| Mid-Market ($50K-$100K) | 25% | 22% |
| SMB (< $50K) | 10% | 8% |

The shift toward larger customers reflects CloudPeak's strategic focus on enterprise expansion, which drives higher NRR and lower churn.

## EBITDA Bridge (FY2024 to FY2025)

| Component | $ Millions |
|---|---|
| FY2024 EBITDA | $11.8M |
| Revenue Growth Incremental Margin | +$10.4M |
| Operating Leverage (S&M efficiency) | +$2.2M |
| R&D Investment Step-Up | ($2.6M) |
| G&A Leverage | +$0.4M |
| **FY2025 EBITDA** | **$19.0M** |

The Company has demonstrated strong incremental margins, converting approximately 39% of incremental revenue to EBITDA in FY2025.

## Balance Sheet Overview (as of December 31, 2025)

| ($ in Millions) | Amount |
|---|---|
| Cash and Equivalents | $42.0 |
| Accounts Receivable | $22.5 |
| Other Current Assets | $5.0 |
| **Total Current Assets** | **$69.5** |
| Property & Equipment (net) | $8.0 |
| Intangible Assets (net) | $12.0 |
| Goodwill | $18.0 |
| Other Non-Current Assets | $3.5 |
| **Total Assets** | **$111.0** |
| | |
| Accounts Payable | $4.5 |
| Accrued Expenses | $10.0 |
| Deferred Revenue | $38.0 |
| **Total Current Liabilities** | **$52.5** |
| Term Debt | $15.0 |
| Other Long-Term Liabilities | $3.5 |
| **Total Liabilities** | **$71.0** |
| **Total Equity** | **$40.0** |

**Net Debt Position:** $42.0M cash - $15.0M debt = **($27.0M) net cash** (positive net cash position)

## Cash Flow Summary

| ($ in Millions) | FY2023 | FY2024 | FY2025 |
|---|---|---|---|
| Net Income | $2.3 | $6.2 | $11.5 |
| D&A | $2.4 | $3.0 | $3.5 |
| Stock-Based Compensation | $4.5 | $5.0 | $5.8 |
| Changes in Working Capital | ($3.2) | ($1.2) | $0.2 |
| **Operating Cash Flow** | **$6.0** | **$13.0** | **$21.0** |
| Capital Expenditures | ($4.0) | ($3.5) | ($3.0) |
| **Free Cash Flow** | **$2.0** | **$9.5** | **$18.0** |
| **FCF Margin** | **2%** | **9%** | **13%** |

## Capital Expenditure History

Capital expenditures have declined as a percentage of revenue as the Company has completed its initial platform build-out:

| ($ in Millions) | FY2023 | FY2024 | FY2025 |
|---|---|---|---|
| CapEx | $4.0 | $3.5 | $3.0 |
| CapEx as % of Revenue | 4.5% | 3.2% | 2.2% |

CapEx is expected to stabilize at approximately 2-3% of revenue going forward, primarily for office infrastructure and computing equipment.

## Working Capital Analysis

| Metric | FY2024 | FY2025 |
|---|---|---|
| Days Sales Outstanding (DSO) | 72 days | 61 days |
| Days Payable Outstanding (DPO) | 35 days | 38 days |
| Deferred Revenue (current) | $30.0M | $38.0M |
| Deferred Revenue % of Revenue | 28% | 28% |

The improvement in DSO reflects improved collections processes and the shift to annual upfront billing for larger enterprise contracts.

## Key Financial Ratios and SaaS Metrics

| Metric | FY2024 | FY2025 | Benchmark |
|---|---|---|---|
| ARR Growth Rate | 17% | 24% | 15-25% median for $100M+ ARR (SaaS Capital) |
| Net Revenue Retention | 116% | 118% | 101% SaaS median (Benchmarkit); 118% Enterprise median (Optifai) |
| Gross Margin | 81% | 81% | 70-85% enterprise SaaS range (BCG) |
| EBITDA Margin | 11% | 14% | Mature SaaS target: 20-30% |
| FCF Margin | 9% | 13% | Rule of 40 target: >20% |
| Rule of 40 Score | 28 | 38 | >40 target (BCG, SaaS Capital) |
| LTV:CAC Ratio | 3.8x | 4.2x | 3:1 healthy; 4-7x strong (Data-Mania) |
| CAC Payback (months) | 16 | 14 | 12-18 months for enterprise SaaS |
| Magic Number | 0.85 | 1.02 | >0.75 efficient (industry standard) |

---

# VIII. APPENDIX

## A. Detailed Financial Statements

Available upon request in separate Excel workbook.

## B. Anonymized Customer List (Top 50)

| Customer ID | Industry | ACV Range | Modules | Start Year | Geography |
|---|---|---|---|---|---|
| C-001 | Financial Services | $1.5M-$2.0M | 4 of 4 | 2021 | North America |
| C-002 | Technology | $1.0M-$1.5M | 4 of 4 | 2022 | North America |
| C-003 | Healthcare | $1.0M-$1.5M | 3 of 4 | 2023 | North America |
| C-004 | Retail | $1.0M-$1.5M | 3 of 4 | 2022 | EMEA |
| C-005 | Manufacturing | $750K-$1.0M | 4 of 4 | 2023 | North America |
| C-006 | Insurance | $750K-$1.0M | 3 of 4 | 2022 | North America |
| C-007 | Technology | $500K-$750K | 3 of 4 | 2023 | APAC |
| C-008 | Energy | $500K-$750K | 2 of 4 | 2024 | EMEA |
| C-009 | Government | $500K-$750K | 4 of 4 | 2021 | North America |
| C-010 | Telecommunications | $500K-$750K | 3 of 4 | 2022 | EMEA |
| ... | ... | ... | ... | ... | ... |

(Full top-50 list available in data room)

## C. Product Catalog

| Product | Description | Pricing Model | Target Customer |
|---|---|---|---|
| FinOps Pro | Cloud cost optimization & FinOps | % of managed cloud spend | All segments |
| CloudAutomate | Infrastructure automation & IaC | Per-cloud-account + usage | Enterprise+ |
| CloudGovern | Security compliance & governance | Per-cloud-account | Enterprise+ |
| CloudPerform | Performance monitoring & analytics | Per-cloud-account + data volume | Mid-Market+ |
| CloudPeak Complete | All 4 modules bundled | % of managed cloud spend (discounted) | Strategic |

## D. Management Biographies

**[Founder/CEO]**
18 years of experience in cloud infrastructure and enterprise software. Previously a Principal Engineer at Amazon Web Services, where he led the development of key AWS cost management features. He holds an MBA from Stanford Graduate School of Business and a BS in Computer Science from MIT. Under his leadership, CloudPeak has grown from a 3-person startup to a 680-person company with $143M in ARR.

**[CTO]**
15 years building distributed systems and cloud platforms. Previously a Senior Staff Engineer at Google Cloud, where he contributed to Kubernetes and Google Cloud Operations Suite. He holds a PhD in Computer Science from Carnegie Mellon University and holds 8 patents in cloud resource optimization.

**[CRO]**
20 years of enterprise SaaS sales leadership. Previously VP of Enterprise Sales at Datadog, where he led the team that grew enterprise ARR from $50M to $300M. Prior to Datadog, he held senior sales leadership roles at New Relic and BMC Software.

**[CFO]**
25 years of finance experience across public and private SaaS companies. Previously CFO at two publicly traded SaaS companies, guiding one through a successful IPO and the other through a $1.2B strategic sale. CPA with experience at PwC and Deloitte. MBA from Wharton.

---

## DISCLAIMER

This Confidential Information Memorandum has been prepared for informational purposes only and does not constitute an offer to sell or a solicitation of an offer to buy any securities. The information contained herein is confidential and is provided on the condition that the recipient will maintain its confidentiality.

Certain statements in this document constitute forward-looking statements. These statements are based on management's current expectations and involve known and unknown risks, uncertainties, and other factors that may cause actual results to differ materially from those expressed or implied.

Financial projections and estimates contained herein are based on assumptions that management believes to be reasonable but are inherently uncertain. Prospective buyers should conduct their own independent investigation and assessment of the Company and should not rely solely on the information contained herein.

[Financial Advisor] and CloudPeak Technologies, Inc. make no representation or warranty, express or implied, as to the accuracy, completeness, or fairness of the information contained in this document, and no reliance should be placed on it.

---

Sources:
- [Gartner Worldwide IT Spending Forecast 2026](https://www.gartner.com/en/newsroom/press-releases/2026-04-22-gartner-forecasts-worldwide-it-spending-to-grow-13-point-5-percent-in-2026-totaling-6-point-31-trillion-dollars)
- [Gartner Public Cloud Spending Forecast](https://www.gartner.com/en/newsroom/press-releases/2024-11-19-gartner-forecasts-worldwide-public-cloud-end-user-spending-to-total-723-billion-dollars-in-2025)
- [Grand View Research Cloud Computing Market](https://www.grandviewresearch.com/horizon/outlook/cloud-computing-market-size/global)
- [MarketsandMarkets Cloud FinOps Market](https://www.marketsandmarkets.com/Market-Reports/cloud-finops-market-197106360.html)
- [Fortune Business Insights Cloud FinOps Market](https://www.fortunebusinessinsights.com/cloud-finops-market-112227)
- [Fortune Business Insights Multi-Cloud Management Market](https://www.fortunebusinessinsights.com/multi-cloud-management-market-108886)
- [QuantPillar Valuation Multiples 2025-2026](https://quantpillar.com/resources/guides/valuation-multiples/)
- [Aventis Advisors SaaS Valuation Multiples](https://aventis-advisors.com/saas-valuation-multiples/)
- [Finerva B2B SaaS 2026 Valuation Multiples](https://finerva.com/report/b2b-saas-2026-valuation-multiples/)
- [Software Equity Group Annual SaaS Report](https://softwareequity.com/research/annual-saas-report)
- [SaaS Capital Retention Benchmarks 2025](https://www.saas-capital.com/blog-posts/what-is-a-good-retention-rate-for-a-private-saas-company/)
- [Benchmarkit 2025 SaaS Performance Metrics](https://www.benchmarkit.ai/2025benchmarks)
- [ChartMogul SaaS Retention Report](https://chartmogul.com/reports/saas-retention-the-new-normal/)
- [Optifai NRR Benchmarks](https://optif.ai/learn/questions/b2b-saas-net-revenue-retention-benchmark/)
- [BCG Rule of 40 Analysis 2025](https://www.bcg.com/publications/2025/rule-of-40-lessons-from-top-performers-software)
- [BVP Cloud 100 Benchmarks Report](https://www.bvp.com/atlas/the-cloud-100-benchmarks-report)
- [State of FinOps 2026 Report](https://data.finops.org/)
- [Flexera 2025 State of the Cloud Report](https://www.flexera.com/blog/finops/the-latest-cloud-computing-trends-flexera-2025-state-of-the-cloud-report/)
- [Data-Mania B2B SaaS Benchmarks 2026](https://www.data-mania.com/blog/b2b-saas-benchmarks-2026-annual-report/)
- [First Page Sage B2B SaaS CAC 2025](https://firstpagesage.com/reports/b2b-saas-customer-acquisition-cost-2024-report/)
- [Ryan Allis SaaS M&A Report 2026](https://www.linkedin.com/pulse/saas-ma-report-2026-ryan-allis-vtkhf)
- [TechSci Research CMP Market](https://www.techsciresearch.com/report/cloud-management-platform-market/24869.html)
- [Precedence Research Multi-Cloud Management Market](https://www.precedenceresearch.com/multi-cloud-management-market)
