[DATA SOURCE: WebSearch — M&A sell-side process letter templates, IOI instructions, and best practices (BookBuild.ai, Wall Street Prep, Auxo Capital Advisors, KSM 2026 PDF, Grata); WebSearch — Sell-side M&A process timeline and standard phases (Sampford Advisors, Ryan O'Connell Finance, Lutz, MNA Community); WebSearch — B2B SaaS M&A confidentiality requirements and legal conventions (L40, Kofirm, Calkins Law Firm, Dickinson Wright, Nixon Peabody); WebSearch — M&A evaluation criteria for bid assessment (Sierra Pacific Partners, Hectelion, Practical Law/Westlaw); WebSearch — SaaS ARR valuation multiples 2025-2026 (SaasRise, PipelineRoad, SaaS Capital, Axial); WebSearch — 2026 HSR antitrust filing thresholds (FTC official, Skadden, Choate, Greenberg Traurig); WebSearch — M&A exclusivity period standard terms and SPA markup requirements (Opagio, Vista Point Advisors, Axial, MNA Institute)]

---

# 出售流程函 — 初始轮次

## 项目代号：Project Summit

**日期：** 2026年5月9日

**密级：机密（Confidential）**

---

**致：[ prospective buyer / 潜在买方 ]**

**发件人：**

> Summit Partners LLC（卖方财务顾问）
> 投资银行部
> [地址]
> 电话：[电话号码]
> 邮件：[邮箱地址]

---

## 一、引言（Introduction）

Summit Partners LLC（以下简称"Summit"或"卖方顾问"）受 CloudPeak Technologies, Inc.（以下简称"CloudPeak"或"公司"）股东之委托，担任其独家财务顾问，负责公司全部或多数股权的潜在出售事宜。

CloudPeak 是一家领先的 B2B 企业级 SaaS 公司，拥有约 **1.43 亿美元年经常性收入（ARR）**。公司为[特定行业/垂直领域]的中大型企业客户提供[核心产品/服务描述]，具备强劲的净收入留存率（NRR）、高度可预测的收入模型以及显著的进一步增长潜力。

本次出售流程旨在为 CloudPeak 的股东实现价值最大化，同时为公司、员工及客户找到最佳战略归宿。本函旨在概述拟议出售流程的关键条款、时间安排以及对潜在买方（以下简称"各方"或"买方"）的要求。

---

## 二、流程概览（Process Overview）

本次出售将采用**两轮竞标流程（Two-Round Bidding Process）**，旨在确保竞争充分性、流程公平性以及交易确定性。标准卖方 M&A 流程通常持续 **6 至 12 个月**（参考：Wall Street Prep; Sampford Advisors; Auxo Capital Advisors），具体时间安排如下：

### 流程阶段与关键时间节点

| 阶段 | 内容 | 预计时间范围 |
|------|------|-------------|
| **第一阶段 — 准备与市场营销** | Teaser 分发、NDA 签署、CIM 分发、初步数据室开放 | 第 1–6 周 |
| **第一阶段 — IOI 提交** | 各方提交初步意向函（Indication of Interest） | **第 7 周（截止日期：2026年6月20日，纽约时间下午5:00）** |
| **第一阶段评估** | 卖方顾问与股东评估 IOI，筛选进入第二轮的买方 | 第 8–9 周 |
| **第二阶段启动** | 向入围买方发放详细数据室权限、分发管理层演示材料、安排管理层会议 | 第 10–12 周 |
| **管理层会议** | 入围买方与管理团队进行面对面/视频会议 | 第 13–16 周 |
| **第二阶段 — 最终报价提交** | 入围买方提交最终约束性报价（Final Bid / LOI） | **第 18 周（截止日期：2026年9月12日，纽约时间下午5:00）** |
| **排他期谈判** | 与首选买方进入排他期，SPA 谈判与确认性尽职调查 | 第 19–30 周 |
| **签署与交割** | 签署最终协议、监管审批、交割 | 第 31–40 周 |

> **说明：** 以上时间安排为初步计划，卖方保留根据市场情况及流程进展调整时间节点的权利。所有关键日期变更将以书面形式通知各方。

---

## 三、初步意向函（IOI）要求

各买方须于 **2026年6月20日（星期六）纽约时间下午5:00 前** 提交初步意向函。IOI 应以书面形式提交，涵盖以下全部内容：

### 3.1 企业价值估值范围（Proposed Valuation Range）

- 说明拟提出的**企业价值（Enterprise Value）** 估值区间
- 估值应基于 CloudPeak 1.43 亿美元 ARR 的倍数表达（当前 B2B SaaS 市场中，$100M+ ARR 规模且具有成熟企业客户基础的公司，公开市场交易中位数倍数约为 **6–7x ARR**，私募交易倍数约为 **3–5x ARR 至更高**，具体取决于增长率、盈利能力及战略协同；参考：PipelineRoad 2026 SaaS Valuation Guide; SaasRise SaaS M&A Report 2026; SaaS Capital; Axial）
- 明确估值是否基于无现金、无负债（cash-free, debt-free）基准，以及净营运资金（NWC）调整假设

### 3.2 对价形式（Consideration Form）

- 说明对价的构成方式：
  - **现金**（cash at closing）
  - **股权/股票**（rollover equity 或上市公司股票）
  - **或有对价/盈利支付**（earnout），如适用
  - **卖方融资**（seller financing），如适用
- 如涉及股权对价，请说明估值方法及潜在锁定安排

### 3.3 融资来源与确定性（Financing Sources & Certainty）

- 说明交易的资金来源（自有资金、承诺债务融资、私募股权基金等）
- 如涉及外部融资，请提供融资确定性说明（如承诺函或高度确信函）
- 说明完成融资的预计时间线

### 3.4 关键尽职调查要求（Key Due Diligence Requirements）

- 列出买方拟进行的主要尽职调查领域（如财务、技术、法律、商业、人力资源等）
- 说明预计完成尽职调查所需时间
- 标注任何已知的重大先决条件或顾虑

### 3.5 预计完成时间线（Indicative Timeline to Close）

- 提供从签署到交割的预计时间表
- 说明是否需要反垄断/监管审批（如适用，参见本函第七节关于 HSR 申报的要求）

### 3.6 条件与先决条件（Conditions & Contingencies）

- 列出任何完成交易的前提条件，包括但不限于：
  - 融资条件
  - 监管审批
  - 第三方同意（如客户合同变更同意）
  - 关键人员留任
  - 其他重大条件

### 3.7 买方简介与战略逻辑（Buyer Description & Strategic Rationale）

- 提供买方公司简介（公司名称、总部所在地、主营业务、最新财务概况）
- 说明收购 CloudPeak 的战略逻辑（战略协同、市场扩展、产品互补等）
- 如为私募股权买方，说明基金规模、投资策略及类似投资经验
- 列出近期完成的可比交易（如有）

---

## 四、提交方式与格式（Submission Details）

### 4.1 提交渠道

所有 IOI 应以电子版形式发送至以下地址：

> **邮箱：** projectsummit@summitpartners-advisory.com
> **抄送：** legal@summitpartners-advisory.com

### 4.2 格式要求

- PDF 格式，以"Project Summit — IOI — [买方名称] — 2026年6月20日"命名
- 正文不超过 **15 页**
- 附带一份执行摘要（Executive Summary，不超过 2 页）

### 4.3 截止日期

> **IOI 提交截止日期：2026年6月20日（星期六），纽约时间下午5:00**
>
> 逾期提交的 IOI 可能不予考虑，除非卖方事先以书面形式同意延期。

---

## 五、保密义务提醒（Confidentiality Reminder）

### 5.1 NDA 引用

本流程函及所附信息材料的接收和使用受制于各方已签署的**保密协议（Non-Disclosure Agreement / NDA）** 的条款约束。如贵方尚未签署 NDA，请在获取任何项目材料前联系卖方顾问安排签署。

M&A 保密协议区别于一般 NDA，具有更严格的条款，包括但不限于（参考：Dickinson Wright 2026; Calkins Law Firm; Nixon Peabody; The M&A Lawyer）：

- **许可使用范围限制：** 信息仅可用于评估本次潜在交易
- **信息披露限制：** 仅限于买方内部有"需要知道"（need-to-know）的人员接触
- **禁止招揽条款：** 禁止在特定期限内招揽公司员工或客户
- **信息归还/销毁义务：** 如未进入后续流程，须按约定归还或销毁全部机密信息

### 5.2 数据室使用规则

- 数据室访问权限将以**分级方式（tiered / staged disclosure）** 提供（参考：PCE Companies; Kofirm）
- 第一阶段数据室仅包含初步信息；进入第二轮的买方将获得更详细的财务、运营及法律资料
- 数据室活动将被全程记录和监控

### 5.3 项目代号

在本流程所有沟通中，请始终使用项目代号 **"Project Summit"**，不得在任何沟通中直接引用 CloudPeak Technologies 的名称。

---

## 六、联系方式（Contact Information）

如有任何关于本流程函或整体流程的疑问，请联系：

> **主要联系人：**
> 姓名：[顾问姓名]
> 职位：董事总经理（Managing Director）
> 电话：[电话号码]
> 邮箱：projectsummit@summitpartners-advisory.com
>
> **次要联系人：**
> 姓名：[顾问姓名]
> 职位：副总裁（Vice President）
> 电话：[电话号码]
> 邮箱：projectsummit-vp@summitpartners-advisory.com
>
> **法律顾问：**
> [律师事务所名称]
> 联系人：[律师姓名]
> 邮箱：[邮箱地址]

---

## 七、第二阶段/最终报价函要点预告（Second Round / Final Bid Letter Preview）

以下概述第二阶段最终报价函将包含的额外要求，以便各方提前准备：

### 7.1 股权收购协议 markup（SPA Markup）

- 卖方将提供《股权收购协议》（Stock Purchase Agreement / SPA）草案
- 入围买方须在提交最终报价时同时提交 SPA markup（包括修订说明）
- 重点领域：陈述与保证、赔偿条款、交割条件、重大不利变化（MAC）定义

### 7.2 详细融资承诺函（Committed Financing Letters）

- 最终报价须附带银行/金融机构出具的**正式融资承诺函**
- 不接受"高度确信"（highly confident）函作为唯一融资证明

### 7.3 确认性尽职调查（Confirmatory Due Diligence）

- 最终报价前须完成核心领域的确认性尽职调查
- 具体尽职调查清单将在第二阶段启动时提供

### 7.4 排他期条款（Exclusivity Terms）

- 卖方预期与首选买方进入 **45 至 75 天** 的排他期（参考：Axial; Vista Point Advisors; Opagio）
- 排他期内，卖方将暂停与其他买方的谈判
- 排他期可基于良好进展延期，或因买方违约/条件未满足而终止

### 7.5 反垄断与监管分析（Regulatory Analysis）

- 根据美国 Hart-Scott-Rodino（HSR）法案，2026 年交易规模申报门槛为 **1.339 亿美元**（参考：FTC 官方公告 2026年1月; Skadden; Choate Hall & Stewart; Greenberg Traurig）
- 如交易触发 HSR 申报，标准等待期为提交后 **30 天**
- 如涉及欧盟或其他司法管辖区，可能需要额外的合并控制申报
- 买方应在最终报价中说明预计的监管审批路径及时间线

### 7.6 关键人员安排（Key Personnel Terms）

- 买方须说明对 CloudPeak 管理团队和关键员工的留任计划
- 包括：雇佣协议草案、薪酬安排、股权/期权处理、竞业禁止条款

### 7.7 约束力声明（Binding vs. Non-Binding）

- IOI 为**非约束性**文件（除保密条款外）
- 最终报价函将明确区分约束性条款与非约束性条款
- 通常约束性条款包括：保密义务、排他性、管辖法律及争议解决

### 7.8 评估标准（Evaluation Criteria）

卖方将依据以下标准综合评估各买方的报价（参考：Sierra Pacific Partners; Hectelion; Practical Law/Westlaw）：

| 评估维度 | 权重（参考） | 说明 |
|----------|-------------|------|
| **报价价格** | 40% | 企业价值绝对水平及与市场可比交易的对标 |
| **交易确定性** | 25% | 融资确定性、条件先决的多少、买方历史成交记录 |
| **执行速度** | 15% | 预计签署至交割时间、监管审批复杂程度 |
| **战略匹配** | 15% | 与 CloudPeak 业务互补性、整合可行性、长期增长潜力 |
| **条款灵活性** | 5% | 对 SPA 条款的灵活程度、对价结构的简单性 |

> 卖方保留在评估过程中调整上述权重及考量其他因素的权利。报价最高者不一定会被选为首选买方。

---

## 八、管理层会议预告（Management Meeting Preview）

进入第二轮的买方将被邀请参加 CloudPeak 管理层会议。会议安排预告如下：

### 8.1 后勤安排

- **时间：** 2026年7月（具体日期待确认，约在第二轮启动后2–4周）
- **地点：** CloudPeak 总部 / 视频会议（具体另行通知）
- **时长：** 约 3–4 小时（含 Q&A）

### 8.2 参会人员

**公司方：** CEO、CFO、CTO、COO、VP Sales、VP Customer Success
**买方：** 最高决策者、投资/并购负责人、行业运营合伙人（如适用）

### 8.3 会议议程（参考标准管理层演示）

1. 公司概览与市场定位（30分钟）
2. 财务表现与预测（45分钟）
3. 产品与技术架构深度介绍（45分钟）
4. 运营模式与组织架构（30分钟）
5. 增长战略与协同机会（30分钟）
6. 自由问答（60分钟）

### 8.4 会议规则

- 严禁录音录像
- 全程受 NDA 约束
- 提问将通过卖方顾问协调
- 会后追加提问须在会议后5个工作日内以书面形式提交

### 8.5 会后材料

- 管理层演示 PPT 将在会后提供
- 第二阶段数据室权限将在管理层会议后48小时内开放

---

## 九、重要声明与免责条款（Disclaimers & Important Notices）

1. **非约束性：** 本流程函为信息性文件，不构成任何具有法律约束力的承诺或要约（保密条款除外）。

2. **信息准确性：** 本函及所附材料中提供的信息基于 CloudPeak 管理层提供的数据。卖方顾问不对该等信息的完整性和准确性作出任何明示或暗示的保证。各买方应自行进行独立尽职调查。

3. **流程灵活性：** 卖方保留随时修改、暂停或终止本出售流程的权利，包括但不限于调整时间表、修改评估标准、在任何阶段与任何买方直接谈判或拒绝任何报价。

4. **无排他性（本阶段）：** 本阶段不存在任何排他性安排。卖方有权同时与多方进行谈判。

5. **法律/税务/会计建议：** 本函不构成法律、税务或会计建议。各买方应就本次交易咨询其各自的专业顾问。

6. **适用法律：** 本函受[适用司法管辖区]法律管辖。

7. **禁止公开披露：** 各买方不得就本流程的存在、内容或与 CloudPeak 的任何讨论向任何第三方（包括媒体）进行披露。

---

## 十、签署确认（Acknowledgment）

请贵方在 **2026年5月23日（星期六）前** 以电子邮件形式回复确认以下事项：

1. 确认收到本流程函
2. 确认理解并同意遵守本函规定的流程要求及保密义务
3. 确认贵方有意参与 Project Summit 出售流程
4. 提供贵方主要联系人信息（姓名、职位、电话、邮箱）

回复邮箱：projectsummit@summitpartners-advisory.com

---

*本文件由 Summit Partners LLC 拟备，仅供 Project Summit 潜在买方使用。未经事先书面许可，不得复制、分发或引用。*

---

## Sources

1. [M&A Process Letter: Template & Best Practices — BookBuild.ai](https://bookbuild.ai/blog/ma-process-letter)
2. [Sell-Side M&A Process | Timeline, IOI to LOI, QoE & NWC Peg — Auxo Capital Advisors](https://auxocapitaladvisors.com/sell-side-m-a-process/)
3. [Sell Side M&A | Auction Process + Timeline Example — Wall Street Prep](https://www.wallstreetprep.com/knowledge/sell-side-process/)
4. [The M&A Process from Pitch to Close — IB Interview Questions](https://ibinterviewquestions.com/blog/m-and-a-pitch-process-from-mandate-to-close)
5. [A Typical Sell-Side M&A Process Timeline — Sampford Advisors](https://www.sampfordadvisors.com/blog/2025/2/28/sell-side-process-timeline)
6. [The M&A Sale Process: Teasers, CIMs, Data Rooms & Fairness — Ryan O'Connell Finance](https://ryanoconnellfinance.com/ma-sale-process/)
7. [M&A Process Explained (8 Phases, Real Deliverables) — Peony](https://www.peony.ink/blog/mergers-and-acquisitions-process-guide)
8. [The M&A Process + Timeline & Milestones — Lutz](https://www.lutz.us/blog/ma-process-timeline-milestones)
9. [The M&A NDA: What Matters For SaaS Companies — L40](https://www.l40.com/insights/m-a-nda-saas-companies)
10. [Just Another NDA? Why M&A Confidentiality Agreements Are Different — Dickinson Wright](https://legaledge.dickinsonwright.com/2026/02/02/just-another-nda-why-ma-confidentiality-agreements-are-different/)
11. [Protecting Confidentiality in M&A: Legal Best Practices — Calkins Law Firm](https://calkinslawfirm.com/protecting-confidentiality-in-ma-legal-best-practices/)
12. [Ensuring Confidentiality in M&A Negotiations — Nixon Peabody LLP](https://www.nixonpeabody.com/insights/articles/2024/07/03/ensuring-confidentiality-in-m-and-a-negotiations)
13. [How to Manage Confidentiality in Your M&A Sale Process — PCE Companies](https://www.pcecompanies.com/resources/managing-confidentiality-ma-sale)
14. [IOI in M&A: A Strategic Playbook for Buyers and Sellers — MNA Community](https://mnacommunity.com/insights/ioi-in-mergers-and-acquisitions/)
15. [How to Choose the Right Bidder in a Sell-Side M&A: Evaluating LOIs — Sierra Pacific Partners](https://www.sierrapacificpartners.com/articles/blog-post-title-four-fdz8r)
16. [Process Letter (M&A) — Hectelion](https://www.hectelion.com/en/glossary/process-letter-m-a)
17. [Bid Process Letters — Practical Law (Westlaw)](https://content.next.westlaw.com/practical-law/document/I0f9fe829ef0811e28578f7ccc38dcbee/Bid-Process-Letters?viewType=FullText&transitionType=Default&contextData=(sc.Default))
18. [The SaaS M&A Report 2026 — SaasRise](https://www.saasrise.com/blog/the-saas-m-a-report-2026-2)
19. [How to Value a SaaS Company: The Complete 2026 Guide — PipelineRoad](https://pipelineroad.com/agency/blog/saas-valuations-guide)
20. [SaaS Valuation Multiples: Understanding the New Normal — SaaS Capital](https://www.saas-capital.com/blog-posts/saas-valuation-multiples-understanding-the-new-normal/)
21. [Technology Company Valuation Multiples — Axial](https://www.axial.net/forum/tech-company-valuation-multiples/)
22. [New HSR Thresholds and Filing Fees for 2026 — FTC Official](https://www.ftc.gov/enforcement/competition-matters/2026/01/new-hsr-thresholds-filing-fees-2026)
23. [FTC Announces 2026 HSR Notification Thresholds and Filing Fees — Skadden](https://www.skadden.com/insights/publications/2026/01/ftc-announces-2026-hsr-notification)
24. [2026 Hart-Scott-Rodino Requirements — Choate Hall & Stewart](https://www.choate.com/insights/2026-hart-scott-rodino-requirements/)
25. [2026 HSR Merger Notification Thresholds & Fees Announced — Greenberg Traurig](https://www.gtlaw.com/en/insights/2026/1/2026-hsr-merger-notification-thresholds-and-fees-announced)
26. [What is an Exclusivity Period in M&A? — Opagio](https://opag.io/reference/faq/exclusivity-period-m-and-a)
27. [The Tradeoffs and Pitfalls of Exclusivity — Vista Point Advisors](https://vistapointadvisors.com/perspectives/tradeoffs-exclusivity)
28. [Why Exclusivity Periods Are Scary & How Sellers Can Minimize Risk — Axial](https://www.axial.net/forum/why-exclusivity-periods-are-scary-and-how-sellers-can-minimize-risk/)
29. [Sell-Side M&A Process: Complete Guide & Best Practices — Grata](https://grata.com/resources/sell-side-mergers-acquisitions-process)
30. [Pre-Sale Planning for B2B M&A Transactions — Kofirm](https://kofirm.com/pre-sale-planning-for-b2b-ma-transactions-key-considerations-in-data-privacy-ai-and-cybersecurity)
