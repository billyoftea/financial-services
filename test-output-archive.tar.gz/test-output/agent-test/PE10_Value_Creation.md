[DATA SOURCE: Bain & Company 2026 Global Private Equity Report ("12 is the new 5"); McKinsey Global Private Markets Report 2026; McKinsey SaaS and the Rule of 40; BCG Rule of 40 Lessons from Top Performers in Software; S&P Global PE Dry Powder Data (Q1 2025); PitchBook Global Private Market Funds Dry Powder Dashboard; SaaS Capital 2025 Private SaaS Company Valuations; PitchBook Q3 2025 Enterprise SaaS Public Comp Sheet; QuantPillar 2025-2026 Private Market Valuation Multiples; KPMG Corporate Governance for PE-Backed Companies (2025); Deloitte Portfolio Company Board Governance; NACD PE Portfolio Company Governance; Blue Ridge Partners PE Value Creation Research; E78 Partners PE Value Creation 2025; PE Insights Bain Coverage; Moonfare PE Value Creation Strategies]

# CloudPeak Technologies — 价值创造计划 (Value Creation Plan)

**投资标的:** CloudPeak Technologies
**投资类型:** 成长型少数股权投资 (Growth Minority)
**当前 ARR:** $143M | **企业价值 (EV):** $429M | **EV/ARR:** 3.0x
**投资金额:** $150M（获得35%股权，隐含投后估值 $429M）
**持有期目标:** 4-5年
**目标 MOIC:** 2.5-3.0x | **目标 IRR:** 20-25%

---

## 一、执行摘要 (Executive Summary)

CloudPeak Technologies 是一家年经常性收入 $143M 的云软件公司，以 EV/ARR 3.0x 的估值完成投资。根据 Bain & Company 2026年全球私募股权报告的核心论断——**"12 is the new 5"**（即当今PE交易需要12%的年化EBITDA增长才能实现目标回报，而十年前仅需5%），我们制定了一套全面的三支柱价值创造计划。

当前 CloudPeak 的 Rule of 40 得分约为 **32%**（假设20%收入增长率 + 12% EBITDA利润率），低于行业健康水平。通过本计划，我们的目标是将 Rule of 40 得分提升至 **45%+**，实现显著的价值倍数扩张。

本计划围绕三大价值创造支柱展开：
1. **收入增长 (Revenue Growth):** ARR从$143M增长至$280-320M
2. **利润率改善 (Margin Improvement):** EBITDA利润率从12%提升至25-28%
3. **估值倍数扩张 (Multiple Expansion):** EV/ARR从3.0x提升至4.5-5.0x

---

## 二、基准评估 (Baseline Assessment)

### 2.1 当前财务概况

| 指标 | 当前值 | 行业中位数 | 差距 |
|------|--------|-----------|------|
| ARR | $143M | — | — |
| ARR增长率 | ~20% | 15-25% (中位) | 持平 |
| EBITDA利润率 | ~12% | 18-22% (成熟SaaS) | 落后6-10pp |
| 净收入留存率 (NRR) | ~108% | 110-120% (一流) | 落后2-12pp |
| Rule of 40 得分 | ~32% | ≥40% | 落后8pp |
| EV/ARR倍数 | 3.0x | 3.9x (公开SaaS中位, Q3 2025) | 低于中位 |
| 客户流失率 (Gross Churn) | ~12% | 5-8% (一流) | 落后4-7pp |
| LTV/CAC 比率 | ~3.2x | ≥4.0x | 落后 |

### 2.2 组织能力评估

- **管理层优势:** 技术团队强、产品研发能力领先、核心客户关系稳固
- **管理层差距:** 商业化/销售运营不够成熟、财务规划与分析 (FP&A) 能力薄弱、缺少专业CRO
- **快速赢取机会 (Quick Wins):** 价格优化（定价偏低约10-15%）、客户成功团队重组、冗余供应商整合

### 2.3 市场背景

根据 S&P Global 数据，全球PE dry powder 截至2025年Q1为 **$2.184万亿**，虽然从历史高点略有回落，但仍然庞大。PitchBook 数据显示，2025年Q2全球私募市场基金dry powder达 **$4.63万亿**。这意味着大量资金仍在等待部署，优质云软件标的将面临激烈的收购竞争，同时也意味着退出市场对高质量资产有强劲需求。

---

## 三、价值创造杠杆 (Value Creation Levers)

### 支柱一：收入增长 (Revenue Growth)

#### 3.1 有机增长 (Organic Growth)

| 杠杆 | 当前状态 → 目标状态 | ARR影响 | 时间线 | 投资需求 | 置信度 |
|------|---------------------|---------|--------|---------|--------|
| 价格优化 | 定价低于市场10-15% → 市场化定价 | +$8-12M | 6-12个月 | $0.5M (定价顾问) | 高 |
| 销售团队扩张 | 25名AE → 50名AE | +$18-25M | 12-24个月 | $8M (招聘+培训) | 中-高 |
| 销售效率提升 | 转化率12% → 18% | +$10-15M | 12-18个月 | $2M (销售赋能工具) | 中 |
| 上销/交叉销售 | 扩展率15% → 25% | +$12-18M | 12-24个月 | $3M (客户成功团队) | 中-高 |

**定价优化说明：** McKinsey 研究表明，执行良好的定价计划通常可为PE投资组合公司带来 **3-7%的利润率提升**。CloudPeak当前定价明显偏低，这是最直接的快速赢取机会。

#### 3.2 新市场进入 (New Market Entry)

| 杠杆 | 当前状态 → 目标状态 | ARR影响 | 时间线 | 投资需求 | 置信度 |
|------|---------------------|---------|--------|---------|--------|
| 垂直行业扩展 | 3个行业 → 6个行业 | +$15-22M | 18-36个月 | $6M | 中 |
| 国际市场扩张 | 北美为主 → 进入欧洲+亚太 | +$12-20M | 24-48个月 | $10M | 中 |
| 中端市场渗透 | 企业级为主 → 向中端下沉 | +$8-14M | 12-24个月 | $4M | 中-高 |
| 渠道合作建设 | 直销为主 → VAR+渠道30% | +$6-10M | 18-36个月 | $3M | 中 |

#### 3.3 补充收购 (Add-on M&A)

| 杠杆 | 当前状态 → 目标状态 | ARR影响 | 时间线 | 投资需求 | 置信度 |
|------|---------------------|---------|--------|---------|--------|
| 技术互补收购 | 无 → 2-3个bolt-on | +$25-40M | 12-36个月 | $30-50M | 中 |
| 团队收购(Aqui-hire) | 无 → 1-2个 | +$3-5M | 6-18个月 | $5-8M | 中-高 |
| 客户群收购 | 无 → 1个 | +$5-10M | 18-30个月 | $10-15M | 低-中 |

**M&A说明：** 根据SKILL.md的关键指导——"补充收购通常是最大的价值创造杠杆，应从第一天开始建立收购管道。" 我们将预留$30-50M用于bolt-on收购。

### 支柱二：利润率改善 (Margin Expansion)

| 杠杆 | 当前状态 → 目标状态 | EBITDA影响 | 时间线 | 投资需求 | 置信度 |
|------|---------------------|-----------|--------|---------|--------|
| 定价优化 | 提价10-15% | +$14-21M | 6-12个月 | $0.5M | 高 |
| 产品组合优化 | 低毛利产品占比高 → 高毛利为主 | +$5-8M | 12-24个月 | $1M | 中-高 |
| 云基础设施优化 | 未充分优化 → FinOps最佳实践 | +$3-5M | 6-12个月 | $0.5M | 高 |
| 供应商整合 | 分散采购 → 集中谈判 | +$2-4M | 3-6个月 | $0.2M | 高 |
| G&A精简 | 冗余管理层 → 共享服务中心 | +$4-6M | 12-18个月 | $1.5M | 中 |
| 研发效率提升 | 瀑布式开发 → 敏捷+自动化 | +$3-5M | 12-24个月 | $2M | 中 |
| 规模杠杆 | 固定成本分摊 | +$5-8M | 随收入增长 | — | 高 |
| **合计** | | **+$36-57M** | | | |

**利润率改善路径：**

| 阶段 | 时间 | EBITDA利润率目标 | 主要驱动因素 |
|------|------|------------------|-------------|
| 基准 | Year 0 | 12% | — |
| 快速赢取 | Year 1 | 16-18% | 定价优化、供应商整合、云成本优化 |
| 运营提升 | Year 2 | 20-22% | 规模杠杆、G&A精简、产品组合 |
| 全面优化 | Year 3-4 | 25-28% | 研发效率、全面运营成熟 |

### 支柱三：战略与估值倍数扩张 (Multiple Expansion)

| 杠杆 | 当前状态 → 目标状态 | 倍数影响 | 时间线 | 置信度 |
|------|---------------------|---------|--------|--------|
| 经常性收入质量提升 | 收入占比75% → 90%+ | +0.5-1.0x EV/ARR | 12-24个月 | 高 |
| 增长率加速 | 20% → 28-30% | +0.3-0.5x EV/ARR | 12-24个月 | 中-高 |
| NRR提升 | 108% → 118%+ | +0.5-0.8x EV/ARR | 12-36个月 | 中-高 |
| 管理层专业化 | 创始人团队 → 专业C-Suite | +0.2-0.3x EV/ARR | 6-18个月 | 高 |
| 平台叙事构建 | 单一产品 → 平台公司 | +0.5-1.0x EV/ARR | 24-48个月 | 中 |
| ESG与治理成熟 | 基础治理 → 全面ESG框架 | +0.1-0.2x EV/ARR | 12-24个月 | 高 |

**倍数扩张逻辑：**
- 入场倍数: 3.0x EV/ARR
- 目标出场倍数: 4.5-5.0x EV/ARR
- 依据: SaaS Capital数据显示2025年初私人SaaS中位估值为 **7.0x ARR**；PitchBook Q3 2025企业SaaS公开中位数为 **3.9x**。CloudPeak若能将增长率提升至25%+、EBITDA利润率提升至25%+，可比肩中高端公开市场SaaS估值水平。
- 根据BCG关于Rule of 40的研究，达到45%+得分的软件公司在估值倍数上显著领先同行。

---

## 四、EBITDA价值桥 (EBITDA Value Bridge)

| 杠杆 | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|------|--------|--------|--------|--------|--------|
| **基准ARR ($M)** | $165 | $195 | $235 | $275 | $310 |
| 基准EBITDA ($M) | $19.8 | $23.4 | $28.2 | $33.0 | $37.2 |
| **有机收入增长** | $4.0 | $8.5 | $14.0 | $18.0 | $20.0 |
| **定价优化** | $6.0 | $8.0 | $9.0 | $9.5 | $10.0 |
| **补充M&A** | $2.0 | $6.0 | $12.0 | $18.0 | $22.0 |
| **COGS节省** | $3.0 | $5.0 | $6.0 | $6.5 | $7.0 |
| **OpEx优化** | $2.5 | $5.5 | $8.0 | $10.0 | $11.0 |
| **技术/自动化投资** | ($1.5) | ($1.0) | $1.0 | $2.5 | $4.0 |
| **Pro Forma EBITDA ($M)** | $35.8 | $55.4 | $78.2 | $97.5 | $111.2 |
| **EBITDA利润率** | 21.7% | 28.4% | 33.3% | 35.5% | 35.9% |
| **Rule of 40 得分** | 34.7% | 42.4% | 46.3% | 45.5% | 43.9% |

**注：** Year 5 EBITDA利润率较高包含了M&A贡献。有机业务利润率目标为25-28%。

---

## 五、100天计划 (100-Day Plan)

### 第1-30天：稳定与评估 (Stabilize & Assess)

| 优先级 | 行动项 | 责任人 | 交付物 |
|--------|--------|--------|--------|
| P0 | 管理层对齐——签署就业协议、设定薪酬激励 | PE交易牵头人 | 已签署的雇佣协议 |
| P0 | 董事会组建——1名PE代表 + 1名管理层 + 1名独立董事 | PE治理委员会 | 董事会章程 |
| P0 | 建立KPI仪表板与周报机制 | CFO | 实时仪表板 |
| P1 | 客户沟通计划——通知top 20客户投资事宜 | CEO | 客户沟通材料 |
| P1 | 价格审计——全面评估定价差距 | CFO + 外部顾问 | 定价差距报告 |
| P2 | 详细运营评估——各职能深度审查 | 各VP | 职能评估报告 |
| P2 | 供应商全面审查 | CFO | 供应商优化方案 |

**治理说明：** 根据KPMG (2025) 和 Deloitte 的研究，PE投资组合公司的治理成熟度与价值创造直接相关。我们将采用典型的PE董事会结构：1-2名PE代表、1-2名管理层成员、1-2名独立行业专家。

### 第31-60天：计划与启动 (Plan & Initiate)

| 优先级 | 行动项 | 责任人 | 交付物 |
|--------|--------|--------|--------|
| P0 | 完成战略计划并向全员沟通 | CEO + PE运营合伙人 | 战略计划文档 |
| P0 | 启动前3-5项价值创造举措 | 各举措负责人 | 项目章程 |
| P1 | 启动补充收购管道开发 | BD团队 + PE团队 | 收购目标清单(15-20个) |
| P1 | 招聘关键岗位（CRO、VP客户成功） | CHRO | 已录用通知 |
| P1 | 实施价格优化（Phase 1：新客户新价格） | CRO + CFO | 定价变更执行 |
| P2 | 启动FinOps云成本优化 | CTO | 云成本基线报告 |
| P2 | 建立周度Flash、月度Review、季度董事会节奏 | CFO | 会议日历 |

### 第61-100天：执行与衡量 (Execute & Measure)

| 优先级 | 行动项 | 责任人 | 交付物 |
|--------|--------|--------|--------|
| P0 | 第一次董事会——运营指标汇报 | CEO + CFO | 董事会材料包 |
| P0 | 快速赢取举措首期成果评估 | 各举措负责人 | 成果报告 |
| P1 | 价值创造杠杆进展评估与计划调整 | PE运营合伙人 | 调整后计划 |
| P1 | 补充收购——完成第一个LOI | BD团队 | 已签署LOI |
| P2 | 客户成功团队重组完成 | VP客户成功 | 新组织架构 |
| P2 | 供应商重新谈判完成（Phase 1） | CFO | 已签署的新合同 |

---

## 六、KPI仪表板 (KPI Dashboard)

### 6.1 核心财务KPI

| KPI | 当前 | Year 1目标 | Year 2目标 | Year 3目标 | 负责人 | 报告频率 |
|-----|------|-----------|-----------|-----------|--------|---------|
| ARR ($M) | $143 | $165 | $195 | $235 | CEO | 月度 |
| ARR增长率 | 20% | 15% | 18% | 21% | CEO | 月度 |
| EBITDA ($M) | $17.2 | $35.8 | $55.4 | $78.2 | CFO | 月度 |
| EBITDA利润率 | 12% | 22% | 28% | 33% | CFO | 月度 |
| Rule of 40得分 | 32% | 37% | 46% | 54% | CEO/CFO | 月度 |
| 自由现金流 ($M) | ($5) | $8 | $18 | $30 | CFO | 月度 |
| 收入成本占比 | 55% | 50% | 45% | 42% | CTO | 月度 |

### 6.2 客户与销售KPI

| KPI | 当前 | Year 1目标 | Year 2目标 | Year 3目标 | 负责人 | 报告频率 |
|-----|------|-----------|-----------|-----------|--------|---------|
| 净收入留存率 (NRR) | 108% | 112% | 116% | 120% | CRO | 月度 |
| 新客户获取数 | 120 | 160 | 200 | 250 | CRO | 周度 |
| 客户流失率 | 12% | 9% | 7% | 5% | VP客户成功 | 月度 |
| 销售周期 (天) | 120 | 100 | 85 | 75 | CRO | 月度 |
| CAC回收期 (月) | 18 | 15 | 12 | 10 | CRO/CFO | 月度 |
| LTV/CAC | 3.2x | 3.8x | 4.5x | 5.0x | CRO/CFO | 月度 |
| ACV ($K) | $85 | $95 | $110 | $125 | CRO | 月度 |

### 6.3 组织与运营KPI

| KPI | 当前 | Year 1目标 | Year 2目标 | Year 3目标 | 负责人 | 报告频率 |
|-----|------|-----------|-----------|-----------|--------|---------|
| 员工人数 | 520 | 600 | 680 | 750 | CHRO | 月度 |
| 人均收入 ($K) | $275 | $275 | $287 | $313 | CEO | 月度 |
| 关键人才流失率 | 15% | 10% | 8% | 7% | CHRO | 月度 |
| 员工净推荐值 (eNPS) | 35 | 45 | 50 | 55 | CHRO | 季度 |
| 产品可用性 (SLA) | 99.5% | 99.9% | 99.95% | 99.99% | CTO | 月度 |
| 功能发布周期 (周) | 6 | 4 | 3 | 2 | CTO | 月度 |

---

## 七、治理框架 (Governance Framework)

### 7.1 董事会构成

根据NACD、Deloitte和KPMG的PE治理最佳实践：

| 席位 | 角色 | 说明 |
|------|------|------|
| 1 | PE基金代表 (交易牵头人) | 投资委员会联络、战略监督 |
| 1 | PE运营合伙人 | 运营改善、行业资源对接 |
| 1 | CEO | 管理层代表、战略执行 |
| 1 | CFO (列席) | 财务报告、预算管理 |
| 1-2 | 独立董事 | 行业专家（SaaS/Cloud领域资深高管） |

### 7.2 汇报节奏

| 会议类型 | 频率 | 参会者 | 主要内容 |
|----------|------|--------|---------|
| 周度Flash | 每周 | CEO + C-Suite | 关键运营指标快报 |
| 月度经营Review | 每月 | 全C-Suite + PE运营合伙人 | 详细财务与运营分析 |
| 季度董事会 | 每季 | 董事会全体 | 战略回顾、价值创造进展、关键决策 |
| 年度战略规划 | 每年 | 董事会 + 管理层全员 | 下一年度计划、3年展望更新 |
| 价值创造专项 | 每双月 | PE运营合伙人 + 举措负责人 | 各举措深度Review |

### 7.3 激励对齐

- **管理层持股计划:** 管理团队将持有5-10%股权（与管理层co-invest匹配）
- **绩效奖金:** 与EBITDA目标和ARR增长挂钩的年度现金奖金
- **长期激励:** 基于MOIC/IRR里程碑的股权vesting计划
- ** clawback条款:** 关键人才离职时的股权回购机制

---

## 八、价值桥总览 (Value Bridge Summary)

### 8.1 入场到出场的价值创造

| 价值驱动因素 | Year 0 (入场) | Year 4 (目标出场) | 价值创造 ($M) | 占比 |
|-------------|---------------|-------------------|--------------|------|
| ARR ($M) | $143 | $275 | — | — |
| EV/ARR倍数 | 3.0x | 4.5x | — | — |
| **企业价值 (EV)** | **$429** | **$1,238** | **$809** | **100%** |
| 其中：EBITDA增长驱动 | — | — | $456 | 56% |
| 其中：倍数扩张驱动 | — | — | $275 | 34% |
| 其中：杠杆/现金流驱动 | — | — | $78 | 10% |

### 8.2 回报分析

| 指标 | 数值 |
|------|------|
| 入场EV | $429M |
| 目标出场EV (Year 4) | $1,238M |
| 股权价值增长 (35%持股) | $283M |
| 投资成本 | $150M |
| **目标MOIC** | **2.5x** |
| **目标IRR (4年持有)** | **~26%** |
| **目标IRR (5年持有)** | **~20%** |

### 8.3 "12 is the new 5" 对标

根据Bain 2026全球PE报告，当前PE交易需要 **12%年化EBITDA增长** 才能实现目标回报。CloudPeak的价值创造计划远超此基准：

| 指标 | Bain基准要求 | CloudPeak计划 |
|------|-------------|--------------|
| EBITDA年化增长率 | 12% | **~55% (Year 0-4 CAGR)** |
| 主要回报驱动 | 运营改善 | 运营改善 + 倍数扩张 |
| 有机增长贡献 | — | ~45% |
| M&A贡献 | — | ~25% |
| 倍数扩张贡献 | — | ~30% |

---

## 九、风险因素 (Risk Factors)

### 9.1 执行风险

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 关键管理层流失 | 中 | 高 | 保留激励、竞争禁止条款、继任计划 |
| 收购整合困难 | 中 | 中 | 严格尽调、专门整合团队、阶段性整合 |
| 定价调整导致客户流失 | 低-中 | 中 | 渐进式调价、高端客户优先、增强客户成功 |
| 销售扩张ROI不达预期 | 中 | 中 | 阶段性招聘、严格销售指标跟踪、早期纠偏 |

### 9.2 市场风险

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| SaaS估值倍数进一步压缩 | 中 | 高 | 加速盈利改善、降低对倍数扩张的依赖 |
| 宏观经济衰退影响IT预算 | 低-中 | 中 | 多元化垂直行业、强调ROI销售叙事 |
| 竞争对手激进定价 | 中 | 中 | 强化产品差异化、锁定长期合同 |
| AI技术颠覆云软件市场 | 低-中 | 高 | 投资AI功能、战略收购AI能力 |

### 9.3 财务风险

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 收入增长不达预期 | 中 | 高 | 保守规划、多情景分析、快速调整机制 |
| M&A过度支付 | 低-中 | 中 | 严格估值纪律、 earnout结构、卖方融资 |
| 流动性不足 | 低 | 高 | 维持最低现金余额、备用信贷额度 |

---

## 十、情景分析 (Scenario Analysis)

| 情景 | ARR (Year 4) | EBITDA利润率 | EV/ARR倍数 | EV ($M) | MOIC | IRR |
|------|-------------|-------------|-----------|---------|------|-----|
| **上行 (Bull)** | $320M | 32% | 5.0x | $1,600 | 3.7x | ~38% |
| **基准 (Base)** | $275M | 28% | 4.5x | $1,238 | 2.9x | ~30% |
| **下行 (Bear)** | $230M | 22% | 3.5x | $805 | 1.9x | ~17% |
| **压力 (Stress)** | $200M | 18% | 3.0x | $600 | 1.4x | ~9% |

---

## 十一、问责矩阵 (Accountability Matrix)

| 价值创造举措 | 执行负责人 | PE监督人 | 董事会汇报 | 关键里程碑 |
|-------------|-----------|---------|-----------|-----------|
| 定价优化 | CRO | PE运营合伙人 | 季度 | Day 60: 新客户新价格; Day 120: 全面上线 |
| 销售团队扩张 | CRO + CHRO | PE运营合伙人 | 季度 | Month 6: 35名AE; Month 12: 50名AE |
| 客户成功/NRR提升 | VP客户成功 | PE运营合伙人 | 月度 | Month 6: NRR>110%; Month 18: NRR>116% |
| 补充收购 | BD VP + CEO | PE交易团队 | 月度 | Day 100: 首个LOI; Month 12: 首个close |
| 云成本优化 | CTO | PE运营合伙人 | 月度 | Month 3: FinOps基线; Month 6: 15%节省 |
| G&A精简 | CFO | PE运营合伙人 | 季度 | Month 6: 组织重组; Month 12: 全面实施 |
| 国际扩张 | CEO + CRO | PE交易团队 | 季度 | Month 12: 欧洲首个office; Month 24: 亚太启动 |
| 管理层升级 | CEO + CHRO | PE治理委员会 | 季度 | Month 3: CRO到位; Month 6: VP客户成功到位 |
| ESG/治理建设 | CFO + 法务 | PE治理委员会 | 半年 | Month 6: ESG基线报告; Month 12: 全面ESG框架 |

---

## 十二、退出策略概述 (Exit Strategy Overview)

| 退出路径 | 适用条件 | 预期倍数 | 预计时间 |
|----------|---------|---------|---------|
| **战略收购** | CloudPeak成为有吸引力的平台标的；大型软件公司战略收购 | 5.0-6.0x ARR | Year 3-4 |
| **二次收购 (Secondary Buyout)** | 继续独立运营、财务表现强劲；另一家PE以更高倍数接盘 | 4.5-5.5x ARR | Year 4-5 |
| **IPO** | ARR>$250M、增长率>25%、盈利、治理成熟 | 5.0-7.0x ARR | Year 4-5 |
| **股息资本化 (Dividend Recap)** | 现金流强劲但退出时机不佳；通过杠杆实现部分回报 | N/A | Year 3-4 |

**首选路径：** 战略收购或二次收购，在Year 4实现退出。

---

## 附录：关键假设与数据来源

### 财务假设
- ARR基准: $143M (投资时点)
- 初始EBITDA利润率: ~12% (基于行业同类公司推算)
- 有机ARR增长率: Year 1 15% → Year 4 15%（M&A叠加后总增长20%+）
- 目标EBITDA利润率: 25-28%（有机）/ 33%+（含M&A）
- 入场EV/ARR: 3.0x → 目标出场EV/ARR: 4.5-5.0x

### 行业基准数据来源
- Rule of 40 参考BCG (2025) 和McKinsey研究
- SaaS估值倍数参考SaaS Capital、PitchBook、QuantPillar
- PE市场数据参考Bain 2026全球PE报告、McKinsey全球私募市场报告、S&P Global
- 治理框架参考KPMG (2025)、Deloitte、NACD

---

## Sources

- [Bain & Company — 2026 Global Private Equity Report](https://www.bain.com/insights/topics/global-private-equity-report/)
- [Bain Press Release: Private Equity Resurgence Gathers Steam](https://www.bain.com/about/media-center/press-releases/2026/private-equity-resurgence-gathers-steam-as-new-era-challenges-firms-to-enhance-value-creationbain--company-global-pe-report/)
- [PE Insights: Bain Global Buyout Deal Value Surges to $904bn](https://pe-insights.com/bain-global-buyout-deal-value-surges-to-904bn-as-12-is-the-new-5-reshapes-returns/)
- [McKinsey — Global Private Markets Report 2026](https://www.mckinsey.com/industries/private-capital/our-insights/global-private-markets-report)
- [McKinsey — SaaS and the Rule of 40](https://www.mckinsey.com/industries/technology-media-and-telecommunications/our-insights/saas-and-the-rule-of-40-keys-to-the-critical-value-creation-metric)
- [BCG — Rule of 40 Lessons from Top Performers in Software](https://www.bcg.com/publications/2025/rule-of-40-lessons-from-top-performers-software)
- [S&P Global — PE Dry Powder Recedes from All-Time Highs](https://www.spglobal.com/market-intelligence/en/news-insights/articles/2025/12/private-equity-dry-powder-recedes-from-all-time-highs-amid-slow-fundraising-96015525)
- [PitchBook — Global Private Market Funds Dry Powder Dashboard](https://pitchbook.com/news/articles/global-private-market-funds-dry-powder-dashboard-2026)
- [SaaS Capital — 2025 Private SaaS Company Valuations](https://www.saas-capital.com/blog-posts/private-saas-company-valuations-multiples/)
- [PitchBook — Q3 2025 Enterprise SaaS Public Comp Sheet](https://pitchbook.com/news/reports/q3-2025-enterprise-saas-public-comp-sheet-and-valuation-guide)
- [QuantPillar — 2025-2026 Private Market Valuation Multiples](https://quantpillar.com/resources/guides/valuation-multiples/)
- [KPMG — Corporate Governance for PE-Backed Companies (2025)](https://assets.kpmg.com/content/dam/kpmgsites/in/pdf/2025/10/corporate-governance-for-private-equity-backed-companies.pdf)
- [Deloitte — Driving Value: Portfolio Company Board Governance](https://www.deloitte.com/us/en/programs/center-for-board-effectiveness/articles/private-equity-portfolio-company-board-governance.html)
- [NACD — How Board Governance Drives Value in PE Portfolio Companies](https://www.nacdonline.org/all-governance/governance-resources/governance-research/outlook-and-challenges/2026-governance-outlook/unlock-value-through-governance-in-private-equity-portfolio-companies/)
- [Blue Ridge Partners — Revenue Growth Is the #1 Driver of PE Value Creation](https://www.blueridgepartners.com/insights/private-equity-value-creation-revenue-growth/)
- [E78 Partners — Private Equity in 2025: Growth, Efficiency, and Margin](https://e78partners.com/blog/private-equity-in-2025-growth-efficiency-and-margin-a-deeper-look-at-value-creation/)
- [Moonfare — Private Equity Value Creation: Strategies & Examples](https://www.moonfare.com/blog/5-examples-pe-value-creation)
- [Wall Street Prep — The Rule of 40](https://www.wallstreetprep.com/knowledge/rule-of-40/)
