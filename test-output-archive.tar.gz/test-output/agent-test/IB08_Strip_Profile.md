[DATA SOURCE: Datadog Investor Relations (investors.datadoghq.com) — FY2024 & FY2025 earnings releases, 10-K annual report; Yahoo Finance — DDOG stock price, key statistics, historical prices; Macrotrends — DDOG revenue, EBITDA, free cash flow, market cap history; GuruFocus — DDOG EV/Revenue, EV/EBITDA valuation multiples; SEC EDGAR — 10-K/10-Q filings; BrandColorCode.com — Datadog brand hex colors; SimplyWall.st — CEO compensation & management; Fintel — Institutional ownership; MarketBeat / StockAnalysis — Analyst consensus & price targets; TIKR — Q1 2026 earnings & FY2026 guidance; Zacks — Q1 earnings estimates; BusinessQuant — Enterprise value history]

---

# Datadog, Inc. (DDOG) — Strip Profile

> **Prepared:** May 9, 2026
> **Exchange:** NASDAQ | **Ticker:** DDOG
> **Industry:** Application / Cloud Observability & Security Software
> **Sector:** Information Technology — Systems Software

---

## Page 1: Company Snapshot (4-Quadrant Layout)

### Brand Colors
- Primary Purple: **#632CA6**
- Secondary Purple: **#774AA4**
- Accent: White (#FFFFFF) on purple backgrounds

---

### Quadrant 1: Company Overview

| Attribute | Detail |
|-----------|--------|
| **Company** | Datadog, Inc. |
| **Ticker** | DDOG (NASDAQ) |
| **Headquarters** | New York, New York, USA |
| **Founded** | 2010 |
| **CEO** | Olivier Pomel (Co-Founder; tenure since June 2010, ~16 years) |
| **CFO** | David Obstler |
| **Employees** | ~6,500 (FY2024; ~3,100 in R&D) |
| **Market Cap** | ~$50.0 billion (as of Dec 2025) |
| **Enterprise Value** | ~$46.8 billion |
| **52-Week Range** | $81.63 — $201.69 |
| **Recent Price** | ~$117.88 (May 30, 2025) |

**Key Stats:**
- Co-founded by Olivier Pomel and others in 2010; IPO'd September 2019 at $27/share
- CEO total compensation: ~$27.1M (FY2024; ~98% equity-based)
- Cash & marketable securities: $4.2 billion (FY2024 year-end)
- Zero debt on balance sheet — net cash position of ~$4.2B
- Customer retention rate: ~97% (consistently high NDR)

---

### Quadrant 2: Business & Positioning

**Business Model:**
- Cloud-scale observability and security platform for developers, IT ops teams, and business users
- Single integrated SaaS platform spanning infrastructure monitoring, APM, log management, cloud security, and more
- Subscription-based with usage-driven pricing (consumption model)
- Reports as a single operating segment: "Observability and Security Platform"

**Revenue Drivers & Product Suite:**
- **Infrastructure Monitoring** — Flagship product; largest revenue contributor
- **APM (Application Performance Monitoring)** — Second pillar; distributed tracing
- **Log Management** — Core third product; unified log analytics
- **Synthetics** — Crossed $100M+ ARR in 2024 (4th product milestone)
- **RUM (Real User Monitoring)** — Crossed $100M+ ARR in 2024 (5th product milestone)
- **Cloud Security & SIEM** — Next-gen SIEM, cloud security, identity protection; combined ~$1.3B ARR
- **Database Monitoring, CI Visibility, Error Tracking** — Expanding product portfolio

**Competitive Position:**
- Primary competitors: Dynatrace (DT), Splunk/Cisco (SPLK/CSCO), New Relic (acquired by PE), Elastic (ESTC), and cloud-native offerings from AWS CloudWatch, Azure Monitor, GCP Operations
- Competitive moats: Unified platform (vs. point solutions), multi-cloud support, consumption pricing, developer-first UX
- ~30,500+ customers globally; 603 customers at $1M+ ARR (FY2025)
- Geographic mix: ~71% North America, ~29% International (FY2024)

**Growth Drivers:**
- Multi-product expansion (customers adopting 2, 3, 4+ products)
- AI/ML observability (emerging GenAI workload monitoring)
- Enterprise penetration (large deal growth)
- International expansion

---

### Quadrant 3: Key Financials & Valuation

#### Revenue Trend ($B)

| Year | Revenue | YoY Growth | Gross Margin | FCF | FCF Margin |
|------|---------|------------|-------------|-----|------------|
| FY2021 | $1.02B | +70% | ~80% | $337M | ~33% |
| FY2022 | $1.68B | +63% | ~80% | $354M | ~21% |
| FY2023 | $2.13B | +27% | ~80% | $598M | ~28% |
| FY2024 | $2.68B | +26% | ~80% | $775M | ~29% |
| FY2025 | $3.43B | +28% | ~80% | ~$950M* | ~28%* |

(*FY2025 FCF estimated based on run-rate extrapolation from $871M FY2024 operating cash flow and 29% FCF margin trend)

#### Profitability (FY2024)

| Metric | GAAP | Non-GAAP |
|--------|------|----------|
| Operating Income | $54M | ~$670M |
| Operating Margin | 2% | ~25% |
| Net Income | $184M | ~$540M |
| EPS (Diluted) | $0.53 | ~$1.55 |

Note: Large GAAP-to-non-GAAP gap driven by ~$615M+ in stock-based compensation (SBC)

#### Valuation Multiples

| Metric | Current | Notes |
|--------|---------|-------|
| EV / Revenue (TTM) | ~13.7x | Down from 25.7x historical average |
| EV / EBITDA | ~55x — 227x | High due to low GAAP EBITDA |
| P/E (GAAP, TTM) | ~398x | Reflects nascent GAAP profitability |
| P/E (Non-GAAP, Forward) | ~85x | More reflective of cash earnings |
| EV / FCF | ~58x | Based on ~$775M FY2024 FCF |
| Price / Sales | ~14.6x | |

#### Operating Cash Flow Trend

| Year | Operating Cash Flow | FCF | FCF Margin |
|------|--------------------—|-----|------------|
| FY2022 | ~$380M | $354M | 21% |
| FY2023 | $660M | $598M | 28% |
| FY2024 | $871M | $775M | 29% |
| FY2025 | ~$1.1B (est.) | ~$950M (est.) | ~28% |

---

### Quadrant 4: Stock Performance, Ownership & Recent Developments

#### Top Institutional Shareholders

| Rank | Holder | Shares | % Ownership |
|------|--------|--------|-------------|
| 1 | Vanguard Group Inc | 41.9M | 12.7% |
| 2 | BlackRock Inc | 28.3M | 8.6% |
| 3 | FMR LLC (Fidelity) | Notable | — |
| 4 | Price T Rowe Associates | Notable | — |
| 5 | Jennison Associates LLC | 7.6M | 2.1% |

- **Total institutional ownership:** ~90.8%
- **Insider ownership:** ~0.8%
- **Short interest:** ~3.9% of float
- CEO Olivier Pomel holds ~8.6M shares

#### Analyst Consensus

| Metric | Value |
|--------|-------|
| Consensus Rating | Buy (33-44 analysts) |
| Average Price Target | $177 — $212 |
| Highest Target | $305 (MarketBeat) |
| Lowest Target | $122 |
| Implied Upside | ~20% — 45% from ~$117 level |

#### Recent Developments (2024-2025)

- **Q1 2026 (May 2026):** Revenue crossed $1B for the first time ($1.01B, +32% YoY); stock surged ~31%; raised FY2026 guidance to $4.30-$4.34B
- **FY2025 (Full Year):** Revenue $3.43B (+28% YoY); 603 customers at $1M+ ARR; GAAP operating loss of $(44)M
- **Q1 2025 (May 2025):** Revenue $762M (+25% YoY); non-GAAP EPS $0.57 (+35.7% beat); raised FY2025 outlook
- **Acquisitions (2025):**
  - **Metaplane** (Apr 2025) — AI-powered data observability startup
  - **Eppo** (May 2025) — Experimentation and feature flag platform for AI/product analytics
  - **Propolis** (2025) — Autonomous GenAI QA testing platform
- Total 15 acquisitions to date; 2025 represents an AI-focused acquisition spree

#### Key Catalysts (Forward-Looking)

1. **GenAI Observability Tailwind** — AI workload monitoring becoming mission-critical
2. **$1B+ Quarterly Revenue Milestone** — Achieved Q1 2026; signals scale maturity
3. **FY2026 Guidance** — $4.30-$4.34B revenue guidance implies 25-27% growth
4. **Security Expansion** — Cloud security + SIEM reaching ~$1.3B ARR
5. **Enterprise Upsell** — Multi-product adoption driving NDR expansion
6. **International Growth** — 29% international revenue with room to expand

---

## Page 2: Financial Deep Dive

### Revenue by Quarter ($M)

| Quarter | Revenue | YoY Growth |
|---------|---------|------------|
| Q1 2024 | $611M | +27% |
| Q2 2024 | $645M | +27% |
| Q3 2024 | $690M | +26% |
| Q4 2024 | $738M | +25% |
| **FY2024 Total** | **$2,684M** | **+26%** |
| Q1 2025 | $762M | +25% |
| Q2 2025 | ~$815M (est.) | ~+26% |
| Q3 2025 | ~$870M (est.) | ~+26% |
| Q4 2025 | $953M | +29% |
| **FY2025 Total** | **$3,427M** | **+28%** |
| Q1 2026 | $1,006M | +32% |

### Customer Metrics Trend

| Metric | FY2022 | FY2023 | FY2024 | FY2025 |
|--------|--------|--------|--------|--------|
| Total Customers | ~22,000 | ~26,000 | ~30,500 | ~32,000+ |
| $100K+ ARR Customers | ~2,250 | ~2,780 | ~3,620 | ~4,100 |
| $1M+ ARR Customers | ~290 | 396 | 462 | 603 |
| Customer Retention Rate | ~97% | ~97% | ~97% | ~97% |

### Geographic Revenue Mix (FY2024)

| Region | % of Revenue | Est. Revenue |
|--------|-------------|-------------|
| **United States / North America** | ~71% | ~$1.90B |
| **International** | ~29% | ~$0.78B |

All revenue denominated in USD; no significant FX risk per 10-K disclosure.

### Profitability Bridge (FY2024, Non-GAAP)

| Line Item | $ Amount | Margin |
|-----------|----------|--------|
| Revenue | $2,684M | 100% |
| Cost of Revenue | (~$537M) | (~20%) |
| **Gross Profit** | **$2,147M** | **80%** |
| Operating Expenses | (~$1,477M) | (~55%) |
| **Non-GAAP Operating Income** | **~$670M** | **~25%** |
| Stock-Based Compensation | ~$615M | ~23% |
| **GAAP Operating Income** | **$54M** | **2%** |

### Balance Sheet Highlights (FY2024 Year-End)

| Item | Amount |
|------|--------|
| Cash & Cash Equivalents | ~$1.5B |
| Short-Term Investments | ~$1.2B |
| Long-Term Investments | ~$1.5B |
| **Total Cash & Marketable Securities** | **~$4.2B** |
| Total Debt | $0 |
| **Net Cash Position** | **~$4.2B** |
| Shares Outstanding | ~331M (diluted) |

---

## Page 3: Competitive Landscape & Market Position

### Peer Comparison (Latest Available Data)

| Metric | Datadog (DDOG) | Dynatrace (DT) | Elastic (ESTC) |
|--------|---------------|----------------|----------------|
| **Revenue (LTM)** | ~$3.4B | ~$1.6B | ~$1.3B |
| **Revenue Growth** | +28% | +18% | +16% |
| **Gross Margin** | ~80% | ~82% | ~73% |
| **Non-GAAP Op. Margin** | ~25% | ~30% | ~20% |
| **FCF Margin** | ~29% | ~30% | ~22% |
| **EV/Revenue** | ~13.7x | ~12x | ~5x |
| **Market Cap** | ~$50B | ~$16B | ~$10B |
| **Customers ($1M+ ARR)** | 603 | ~250 | ~150 |

### Datadog Competitive Advantages

1. **Unified Platform** — Single pane of glass for observability, security, and business analytics; reduces tool sprawl
2. **Consumption Pricing** — Usage-based model aligns with cloud-native workflows; drives expansion revenue
3. **Multi-Cloud Support** — Agnostic across AWS, Azure, GCP; 850+ built-in integrations
4. **Developer-First UX** — Low-friction onboarding; self-serve model; strong developer community
5. **Product Breadth** — 20+ products spanning infrastructure, APM, logs, security, CI/CD, RUM, database monitoring
6. **AI/ML Capabilities** — Anomaly detection, watchdog, change tracking; GenAI observability emerging

### Market Opportunity

- Total addressable market (TAM) for observability and security: ~$53B by 2026 (management estimate)
- Cloud infrastructure spending growing 20%+ annually; observability attach rate increasing
- AI/ML workloads creating new monitoring requirements (GenAI observability)

---

## Page 4: Forward Outlook & Investment Considerations

### FY2026 Guidance (Raised, Post Q1 2026)

| Metric | Guidance |
|--------|----------|
| **Revenue** | $4.30B — $4.34B (+25% — 27% YoY) |
| **Non-GAAP Operating Income** | ~$950M — $1.0B |
| **Non-GAAP Net Income / Share** | ~$1.75 — $1.85 |

### Bear / Base / Bull Scenario Analysis

| Scenario | FY2026 Revenue | YoY Growth | EV/Revenue | Implied EV |
|----------|---------------|------------|------------|------------|
| **Bear** | $4.10B | +20% | 10x | $41B |
| **Base** | $4.32B | +26% | 14x | $60B |
| **Bull** | $4.60B | +34% | 18x | $83B |

**Bear Case Drivers:** Macro slowdown, cloud spend optimization, competitive pressure from hyperscaler-native tools
**Bull Case Drivers:** GenAI tailwind accelerates, multi-product expansion beats expectations, security becomes $2B+ ARR

### Key Risk Factors

1. **Valuation Premium** — Trading at ~14x revenue vs. software sector median of ~6x; de-rating risk
2. **Consumption Model Volatility** — Usage-based revenue can fluctuate with customer cost optimization
3. **Hyperscaler Competition** — AWS CloudWatch, Azure Monitor improving rapidly
4. **Stock-Based Compensation** — ~23% of revenue; significant dilution risk (~3-4% annual dilution)
5. **Customer Concentration** — Large enterprise customers driving disproportionate growth
6. **GAAP Profitability** — Still marginally GAAP-profitable; SBC masks true cost structure

### Key Investment Themes

- **Cloud Observability Category Leader** — #1 or #2 market position across key product categories
- **AI Tailwind** — GenAI workload monitoring is a greenfield opportunity; 3 AI-focused acquisitions in 2025
- **Margin Expansion Path** — Non-GAAP operating margins expanding from ~19% (FY2022) to ~25%+ (FY2025)
- **Cash Flow Machine** — Generating $775M+ FCF annually with ~29% FCF margin; no debt
- **Platform Consolidation** — Multi-product adoption trend drives NDR above 120%

---

## Sources

1. [Datadog Investor Relations — FY2025 Earnings Release](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-fourth-quarter-and-fiscal-year-2025-financial)
2. [Datadog Investor Relations — FY2024 Earnings Release](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-fourth-quarter-and-fiscal-year-2024-financial)
3. [Datadog Investor Relations — FY2023 Earnings Release](https://investors.datadoghq.com/news-releases/news-release-details/datadog-announces-fourth-quarter-and-fiscal-year-2023-financial)
4. [Datadog 2024 Annual Report (10-K)](https://investors.datadoghq.com/static-files/bf7296e6-b2cd-4464-973a-5f36abefa033)
5. [Yahoo Finance — DDOG Key Statistics](https://finance.yahoo.com/quote/DDOG/key-statistics/)
6. [Yahoo Finance — DDOG Historical Prices](https://finance.yahoo.com/quote/DDOG/history/)
7. [Macrotrends — DDOG Revenue](https://www.macrotrends.net/stocks/charts/DDOG/datadog/revenue)
8. [Macrotrends — DDOG Free Cash Flow](https://www.macrotrends.net/stocks/charts/DDOG/datadog/free-cash-flow)
9. [Macrotrends — DDOG EBITDA Margin](https://www.macrotrends.net/stocks/charts/DDOG/datadog/ebitda-margin)
10. [Macrotrends — DDOG Market Cap](https://www.macrotrends.net/stocks/charts/DDOG/datadog/market-cap)
11. [GuruFocus — DDOG EV/Revenue](https://www.gurufocus.com/term/enterprise-value-to-revenue/DDOG)
12. [GuruFocus — DDOG EV/EBITDA](https://www.gurufocus.com/term/enterprise-value-to-ebitda/DDOG)
13. [Fintel — DDOG Institutional Ownership](https://fintel.io/so/us/ddog)
14. [SimplyWall.st — DDOG Management](https://simplywall.st/stocks/us/software/nasdaq-ddog/datadog/management)
15. [MarketBeat — DDOG Analyst Forecast](https://www.marketbeat.com/stocks/NASDAQ/DDOG/forecast/)
16. [StockAnalysis — DDOG Forecast](https://stockanalysis.com/stocks/ddog/forecast/)
17. [TIKR — Datadog Q1 2026 Earnings](https://www.tikr.com/blog/datadog-stock-jumps-31-after-q1-revenue-crosses-1-billion-for-the-first-time)
18. [Zacks — Datadog Q1 Earnings](https://www.zacks.com/stock/news/2917967/datadog-ddog-q1-earnings-taking-a-look-at-key-metrics-versus-estimates)
19. [Yahoo Finance — DDOG Q1 Earnings](https://finance.yahoo.com/news/datadog-q1-earnings-revenues-surpass-162900073.html)
20. [Datadog — Eppo Acquisition Press Release](https://www.datadoghq.com/about/latest-news/press-releases/datadog-acquires-eppo-to-expand-its-ai/)
21. [Datadog — Propolis Acquisition Blog](https://www.datadoghq.com/blog/datadog-acquires-propolis/)
22. [BrandColorCode — Datadog Brand Colors](https://www.brandcolorcode.com/datadog)
23. [SEC EDGAR — Datadog Filings](https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=DDOG)
24. [BusinessQuant — DDOG Enterprise Value](https://businessquant.com/metrics/ddog/enterprise-value)

---

*This strip profile is prepared for investment banking advisory purposes. All financial data sourced from public filings, earnings releases, and third-party financial data providers. Estimates and forward-looking statements are based on management guidance and consensus analyst estimates as of May 2026.*
