[DATA SOURCE: WebSearch — Deloitte DD Framework (deloitte.com); PwC PE DD Best Practices; McKinsey SaaS DD Playbook; Bain PE DD Methodology; Neotas PE DD Checklist 2026 (neotas.com); NMS Consulting PE DD Checklist (nmsconsulting.com); Affinity PE DD Guide (affinity.co); SaaS Capital 2026 Benchmarks (saas-capital.com); Benchmarkit 2025 SaaS Performance Metrics (benchmarkit.ai); Aventis Advisors SaaS Valuation Multiples 2015-2026 (aventis-advisors.com); SaaS Valuation Multiple Q1 2026 (saasvaluationmultiple.com); Livmo SaaS Valuation Multiples 2026 (livmo.com); Research and Markets CMP Market Report (researchandmarkets.com); SecurePrivacy SaaS Compliance Guide 2025 (secureprivacy.ai); Pathlock SOX Compliance Guide 2025 (pathlock.com); ComplyDog GDPR Checklist B2B SaaS (complydog.com); Zylo SaaS Compliance Checklist 2026 (zylo.com); PI Partners SOC 2 PE Briefing (pipartners.com); Cloud Security Alliance SaaS Compliance Guide (cloudsecurityalliance.org); FE International NRR Benchmarks (feinternational.com); Data-Mania B2B SaaS Benchmarks 2026 (data-mania.com); Sutton Place Strategies PE Deal Timelines; Cherry Bekaert PE Report 2025; Growth Unhinged 2025 SaaS Benchmarks Report (growthunhinged.com); Burkland Associates / High Alpha 9th Annual SaaS Benchmarks (burklandassociates.com); SaaS Mag M&A Trends 2026 (saasmag.com)]

# 尽职调查追踪清单 — CloudPeak Technologies

> **目标公司**: CloudPeak Technologies — B2B SaaS 云管理平台
> **交易类型**: Platform Acquisition（平台收购）
> **交易规模**: $143M ARR，预估 EV 约 $572M-$1,001M（基于 4x-7x ARR 估值区间，参考 2026 年私有 SaaS 公司中位数 3.1x-4.5x ARR；高增长优质标的可溢价至 7x+）
> **行业**: B2B SaaS / 云管理平台（CMP）
> **关键指标**: $143M ARR | 82% 毛利率 | 25% YoY 增长率
> **尽职调查启动日期**: 2026年5月9日
> **LOI 目标日期**: 2026年6月中旬（约 4-6 周）
> **预计交割时间线**: LOI 后 90 天（2026年9月中旬）；注意行业中位数已延长至约 230 天（Sutton Place Strategies Q3 2024 数据）
> **主要关注领域**: 客户集中度、ARR 质量、技术可扩展性、数据隐私合规

---

## 一、交易概览与市场背景

### 1.1 Cloud Management Platform（CMP）市场

| 指标 | 数据 | 来源 |
|------|------|------|
| CMP 市场规模（2025E） | $21.25B | Research and Markets |
| CMP 市场规模（2026E） | $25.66B | Research and Markets |
| CMP 市场 CAGR | ~20.8% | Research and Markets |
| 广义云计算市场规模（2025E） | ~$1,130B | Markets and Markets / Fortune Business Insights |
| SaaS 管理平台市场（2026E） | $16.85B | Business Research Insights |

### 1.2 SaaS 估值参考基准

| 指标 | 数值 | 来源 |
|------|------|------|
| 私有 SaaS 中位数 EV/ARR（2026 Q1） | ~4.5x | SaaS Valuation Multiple |
| 私有 SaaS 中位数 EV/Revenue（2025） | 3.8x | Aventis Advisors |
| 私有 SaaS 范围（2026） | 3x-7x ARR | Livmo |
| 公有 SaaS 中位数 EV/Revenue（2026 Q1） | 6.4x | SaaS Valuation Multiple |
| 订阅毛利率中位数 | 81% | Benchmarkit 2025 |

### 1.3 CloudPeak 关键指标 vs 行业基准

| 指标 | CloudPeak | 行业基准 | 评估 |
|------|-----------|----------|------|
| ARR | $143M | $50M-$100M ARR 段位 | 大型私有 SaaS |
| 毛利率 | 82% | 81%（订阅收入中位数） | 达标 |
| YoY 增长率 | 25% | 26%（2026 中位数） | 接近中位数 |
| NRR | 待验证 | 100-106%（行业中位数） | **P0 待确认** |

---

## 二、尽职调查工作流清单

### 工作流 A: 财务尽职调查 (Financial DD)

| # | 调查事项 | 优先级 | 状态 | 负责人 | 备注 |
|---|---------|--------|------|--------|------|
| F-01 | **收益质量报告（QoE）** — 收入与 EBITDA 调整项分析 | P0 | 未启动 | 财务 DD 团队 | 核心 gating item；需验证 ARR $143M 的真实性及可持续性 |
| F-02 | **ARR 质量分解** — Contracted ARR vs. 认缴 ARR vs. 实际账单；区分新业务、续约、扩展收入 | P0 | 未启动 | 财务 DD 团队 | 参考 The SaaS CFO 的 CARR 分析框架；需提供 cohort 分析 |
| F-03 | **收入确认政策** — ASC 606 合规性检查，合同资产/负债分析 | P0 | 未启动 | 审计师 | SaaS 收入确认复杂度高；关注 upfront fees vs. 递延收入 |
| F-04 | **营运资金分析** — 标准化 vs. 实际营运资金；NWC peg 计算 | P0 | 未启动 | 财务 DD 团队 | 关键交易条款输入；影响购买价格调整 |
| F-05 | **债务及类债务项目** — 银行贷款、可转债、未付奖金、递延收入处理 | P1 | 未启动 | 财务 DD 团队 | 识别所有类债务项目以计算 EV 调整 |
| F-06 | **资本支出分析** — 维护性 CapEx vs. 增长性 CapEx 区分 | P1 | 未启动 | 财务 DD 团队 | SaaS 模型下 CapEx 通常较低；关注托管基础设施投入 |
| F-07 | **税务结构与风险** — 联邦/州/国际税务合规，转移定价，NOLs | P1 | 未启动 | 税务 DD 顾问 | 评估税务资产利用潜力及潜在税务风险 |
| F-08 | **审计历史与会计政策** — 过去 3 年审计报告，重大会计政策变更 | P1 | 未启动 | 审计师 | 关注审计意见类型、关键审计事项（KAM） |
| F-09 | **预估调整项（Pro forma）** — Run-rate 调整、协同效应量化 | P2 | 未启动 | 财务建模团队 | 需在财务模型中单独列示 |
| F-10 | **月度/季度财务趋势** — 过去 36 个月 P&L，季节性分析 | P1 | 未启动 | 财务 DD 团队 | 验证增长率的可持续性及季度波动 |
| F-11 | **客户单位经济** — LTV、CAC、LTV/CAC 比率、回收期 | P0 | 未启动 | 商业 DD 团队 | Benchmarkit 2025 数据：ARR per FTE 约 $200K |
| F-12 | **现金流量分析** — 经营/投资/筹资现金流；FCF 转换率 | P0 | 未启动 | 财务 DD 团队 | 验证 "cash burn vs. growth" 平衡 |

### 工作流 B: 商业尽职调查 (Commercial DD)

| # | 调查事项 | 优先级 | 状态 | 负责人 | 备注 |
|---|---------|--------|------|--------|------|
| C-01 | **市场规模与增长（TAM/SAM/SOM）** — CMP 市场 TAM $21.25B（2025），CAGR 20.8% | P0 | 未启动 | 商业 DD 顾问 | 参考 Research and Markets CMP 报告；验证 CloudPeak 的市场定位 |
| C-02 | **竞争格局分析** — 主要竞争对手、市场份额、差异化优势 | P0 | 未启动 | 商业 DD 顾问 | 主要竞品：VMware Aria、Flexera、ServiceNow ITOM、Datadog |
| C-03 | **客户集中度分析** — Top 10/20/50 客户收入占比；客户行业分布 | P0 | 未启动 | 商业 DD 团队 | **关键关注点** — SaaS 客户集中度 >30% 为红旗 |
| C-04 | **客户留存与 NRR** — Gross Revenue Retention (GRR)、Net Revenue Retention (NRR)；行业基准：中位数 100-106%，top quartile >120% | P0 | 未启动 | 商业 DD 团队 | 参考 SaaS Capital / Data-Mania 2026 基准 |
| C-05 | **Cohort 分析** — 按年份/季度的客户群组留存分析 | P0 | 未启动 | 商业 DD 团队 | 验证新客户群组是否维持或改善留存 |
| C-06 | **定价策略与合同结构** — 定价模型（per-seat / per-resource / tiered）、合同期限、涨价历史 | P1 | 未启动 | 商业 DD 团队 | 评估 pricing power 及提价空间 |
| C-07 | **销售管线与 backlog** — 当前 pipeline、weighted pipeline、转化率 | P1 | 未启动 | 商业 DD 团队 | 验证未来 12-18 个月收入可见性 |
| C-08 | **GTM 效果评估** — 销售渠道效率、渠道合作伙伴、直销 vs. 渠道收入占比 | P1 | 未启动 | 商业 DD 团队 | 分析 CAC 趋势；2026 基准显示 CAC 上涨 14%（G2 CFO） |
| C-09 | **客户 NPS 与满意度** — NPS 评分、客户推荐率、客户案例 | P2 | 未启动 | 商业 DD 团队 | 安排 8-12 个客户 reference calls |
| C-10 | **行业趋势与 AI 影响** — AI 对 CMP 市场的影响、AI-native SaaS 产品威胁 | P1 | 未启动 | 商业 DD 团队 | AI SaaS CAGR 38.28%（BetterCloud）；评估 AI 转型风险 |

### 工作流 C: 法律尽职调查 (Legal DD)

| # | 调查事项 | 优先级 | 状态 | 负责人 | 备注 |
|---|---------|--------|------|--------|------|
| L-01 | **公司结构与组织架构** — 实体架构图、股权结构、子公司清单 | P0 | 未启动 | 法律顾问 | 识别所有关联方及复杂结构 |
| L-02 | **重大合同审查** — 客户合同（Top 20）、供应商合同、合作伙伴协议 | P0 | 未启动 | 法律顾问 | 关注 MFN 条款、排他条款、变更控制条款 |
| L-03 | **诉讼历史与未决案件** — 过去 5 年诉讼、仲裁、监管行动 | P0 | 未启动 | 法律顾问 | 包括 IP 侵权诉讼、劳动争议 |
| L-04 | **知识产权组合** — 专利、商标、版权、商业秘密、开源组件审计 | P0 | 未启动 | IP 律师 | SaaS 企业的核心价值资产；需全面 IP 审计 |
| L-05 | **监管合规** — 行业特定许可、数据跨境传输合规 | P1 | 未启动 | 法律顾问 | 参考 Deloitte 多维度 DD 框架 |
| L-06 | **雇佣协议与竞业限制** — 关键员工合同、竞业禁止、发明人协议 | P1 | 未启动 | 法律顾问 | 关注创始人/核心技术人员约束力 |
| L-07 | **数据隐私合规 — GDPR** | P0 | 未启动 | 隐私合规顾问 | EU 数据保护：数据清单、合法处理依据、DPO 指定、Cookie 政策（参考 ComplyDog B2B SaaS GDPR Checklist） |
| L-08 | **数据隐私合规 — CCPA/CPRA** | P0 | 未启动 | 隐私合规顾问 | 加州消费者隐私法：删除权、选择退出权、数据访问请求（参考 SecurePrivacy SaaS Compliance Guide） |
| L-09 | **SOX 合规评估** | P1 | 未启动 | 审计师 | 虽非上市公司，但若买方为公众公司或准备 IPO exit，需评估内控成熟度（参考 Pathlock SOX Compliance Guide） |
| L-10 | **保险政策审查** — D&O、E&O、网络安全保险、一般责任险 | P2 | 未启动 | 法律顾问 | 评估保险覆盖是否充分 |

### 工作流 D: 运营尽职调查 (Operational DD)

| # | 调查事项 | 优先级 | 状态 | 负责人 | 备注 |
|---|---------|--------|------|--------|------|
| O-01 | **管理团队评估** — CEO/CFO/CTO 及核心高管背景、能力、留任意愿 | P0 | 未启动 | 运营 DD 团队 | 评估 post-close 管理连续性 |
| O-02 | **组织架构与关键人员风险** — 关键人物依赖度分析 | P0 | 未启动 | 运营 DD 团队 | 识别 bus factor |
| O-03 | **IT 系统与基础设施** — 核心系统架构、第三方依赖、托管方案 | P1 | 未启动 | 技术 DD 团队 | 参考 Deloitte Switzerland IT DD 框架：验证 IT 投资在估值模型中的准确性 |
| O-04 | **供应链与供应商依赖** — 云基础设施提供商（AWS/Azure/GCP）集中度、合同条款 | P1 | 未启动 | 运营 DD 团队 | 云托管成本通常是 SaaS 企业最大的 COGS 组成部分 |
| O-05 | **办公场所与不动产** — 租约、远程/混合办公政策 | P2 | 未启动 | 运营 DD 团队 | SaaS 企业通常不动产需求有限 |
| O-06 | **业务连续性与灾难恢复** — BCP/DR 计划、RTO/RPO 指标 | P1 | 未启动 | 技术 DD 团队 | CMP 客户对可用性要求极高 |
| O-07 | **运营 KPI 仪表盘** — 内部管理报告体系、数据驱动决策成熟度 | P2 | 未启动 | 运营 DD 团队 | 评估管理团队运营成熟度 |

### 工作流 E: 人力资源 / 人才尽职调查 (HR / People DD)

| # | 调查事项 | 优先级 | 状态 | 负责人 | 备注 |
|---|---------|--------|------|--------|------|
| H-01 | **组织架构图与人员趋势** — 过去 3 年 headcount 变化、部门分布 | P1 | 未启动 | HR DD 团队 | Benchmarkit 2025：ARR per FTE 约 $200K；CloudPeak 约 715 FTEs（$143M/$200K） |
| H-02 | **薪酬基准对标** — 现金薪酬、股权激励、与市场水平对比 | P1 | 未启动 | HR DD 团队 | 评估 post-close 薪酬调整成本 |
| H-03 | **福利与养老金义务** — 401(k) 匹配、健康保险、其他福利 | P2 | 未启动 | HR DD 团队 | 识别隐藏负债 |
| H-04 | **关键员工保留风险** — Top 20 关键员工识别与保留策略 | P0 | 未启动 | HR DD 团队 | 制定留任奖金计划（retention bonus pool） |
| H-05 | **企业文化评估** — 员工满意度调查、Glassdoor 评分、离职面谈数据 | P2 | 未启动 | HR DD 团队 | 评估文化契合度 |
| H-06 | **劳动合同与工会** — 劳动协议、竞业限制执行情况、国际员工合规 | P1 | 未启动 | HR DD 团队 | 如有国际员工需评估当地劳动法合规 |

### 工作流 F: IT / 技术尽职调查 (IT / Technology DD)

| # | 调查事项 | 优先级 | 状态 | 负责人 | 备注 |
|---|---------|--------|------|--------|------|
| T-01 | **技术栈与架构评估** — 核心技术栈、微服务 vs. 单体架构、API 设计 | P0 | 未启动 | 技术 DD 顾问 | 评估技术债务水平和现代化程度 |
| T-02 | **技术债务评估** — 代码质量、测试覆盖率、重构需求 | P0 | 未启动 | 技术 DD 顾问 | 参考 Ideas2IT：技术债务是 PE 收购中最大的隐藏执行风险之一 |
| T-03 | **网络安全态势** — 渗透测试报告、漏洞管理、安全事件历史 | P0 | 未启动 | 安全 DD 顾问 | 参考 PI Partners：SOC 2 不等于完整的网络安全方案 |
| T-04 | **SOC 2 Type II 合规** — 当前 SOC 2 报告、控制点测试结果、 remediation 计划 | P0 | 未启动 | 安全 DD 顾问 | SOC 2+ 或 SOC for Cybersecurity 报告提供更深保证（参考 Grant Thornton / CBIZ） |
| T-05 | **数据隐私合规 — 技术层面** — 数据加密（at rest / in transit）、数据分类、DLP | P0 | 未启动 | 安全 DD 顾问 | GDPR/CCPA 技术控制验证（参考 Cloud Security Alliance 指南） |
| T-06 | **产品路线图与 R&D 投入** — 未来 12-24 个月产品规划、R&D 支出分析 | P1 | 未启动 | 技术 DD 顾问 | 私有 SaaS R&D 支出中位数约 34% of revenue（Benchmarkit 2025） |
| T-07 | **可扩展性评估** — 负载测试结果、架构弹性、多租户支持 | P1 | 未启动 | 技术 DD 顾问 | CMP 平台需支持企业级规模 |
| T-08 | **第三方组件与开源审计** — 开源许可证合规（GPL、AGPL 风险）、SBOM | P1 | 未启动 | 技术 DD 顾问 | 开源合规风险可能导致 IP 传染 |
| T-09 | **DevOps 与 CI/CD 成熟度** — 部署频率、变更失败率、MTTR | P2 | 未启动 | 技术 DD 顾问 | 评估工程运营成熟度 |
| T-10 | **AI/ML 能力评估** — 现有 AI 功能、AI 产品路线图、训练数据合规 | P1 | 未启动 | 技术 DD 顾问 | AI-native SaaS 威胁加剧；评估 AI 整合战略 |

### 工作流 G: ESG 与环境尽职调查 (Environmental / ESG DD)

| # | 调查事项 | 优先级 | 状态 | 负责人 | 备注 |
|---|---------|--------|------|--------|------|
| E-01 | **ESG 政策与报告** — ESG 策略、可持续发展报告、碳足迹 | P2 | 未启动 | ESG 顾问 | SaaS 企业 ESG 重点通常在数据中心能耗与治理 |
| E-02 | **环境合规历史** — 环境监管记录、违规历史 | P2 | 未启动 | ESG 顾问 | 主要关注数据中心环境影响 |
| E-03 | **供应链 ESG 风险** — 云服务商 ESG 政策、供应链劳工标准 | P2 | 未启动 | ESG 顾问 | AWS/Azure/GCP ESG 政策审查 |
| E-04 | **治理结构评估** — 董事会组成、独立性、治理最佳实践 | P1 | 未启动 | 法律顾问 | 评估公司治理成熟度 |

---

## 三、汇总仪表板

### 3.1 各工作流完成进度

| 工作流 | 总项目数 | P0 项目 | 已完成 | 进行中 | 已请求 | 未启动 | 完成率 |
|--------|---------|---------|--------|--------|--------|--------|--------|
| A: 财务 DD | 12 | 5 | 0 | 0 | 0 | 12 | 0% |
| B: 商业 DD | 10 | 5 | 0 | 0 | 0 | 10 | 0% |
| C: 法律 DD | 10 | 5 | 0 | 0 | 0 | 10 | 0% |
| D: 运营 DD | 7 | 2 | 0 | 0 | 0 | 7 | 0% |
| E: HR DD | 6 | 1 | 0 | 0 | 0 | 6 | 0% |
| F: 技术 DD | 10 | 5 | 0 | 0 | 0 | 10 | 0% |
| G: ESG DD | 4 | 0 | 0 | 0 | 0 | 4 | 0% |
| **合计** | **59** | **23** | **0** | **0** | **0** | **59** | **0%** |

### 3.2 P0 关键路径事项（Gating Items）

以下 P0 事项为 LOI 和交割的 gating items，必须在 LOI 前完成或获得初步结论：

| 优先序 | 事项编号 | 描述 | 目标完成日期 | 当前状态 |
|--------|---------|------|-------------|---------|
| 1 | F-01 | QoE 报告 — ARR 真实性验证 | LOI 前 | 未启动 |
| 2 | F-02 | ARR 质量分解 — cohort 分析 | LOI 前 | 未启动 |
| 3 | C-03 | 客户集中度分析 | LOI 前 | 未启动 |
| 4 | C-04 | 客户留存与 NRR | LOI 前 | 未启动 |
| 5 | T-01 | 技术栈与架构评估 | LOI 前 | 未启动 |
| 6 | T-03 | 网络安全态势 | LOI 前 | 未启动 |
| 7 | T-04 | SOC 2 Type II 合规 | LOI 前 | 未启动 |
| 8 | L-07/L-08 | GDPR/CCPA 合规 | LOI 前 | 未启动 |

---

## 四、红旗预警追踪

| # | 发现日期 | 红旗描述 | 工作流 | 严重程度 | 缓解措施 | 对估值/交易条款的影响 |
|---|---------|---------|--------|---------|---------|---------------------|
| RF-01 | 待发现 | **[关注点] 客户集中度风险** — 需验证 Top 10 客户收入占比是否超过 30% | 商业 DD | 待评估 | 待制定 | 可能影响 EV 或要求 earnout 条款 |
| RF-02 | 待发现 | **[关注点] NRR 水平** — 25% YoY 增长率下 NRR 是否健康？若 NRR <100%，则增长依赖新客获取，可持续性存疑 | 商业 DD | 待评估 | 待制定 | 直接影响估值倍数 |
| RF-03 | 待发现 | **[关注点] 技术债务与可扩展性** — $143M ARR 规模的系统是否已积累显著技术债务？ | 技术 DD | 待评估 | 待制定 | 可能需要 post-close CAPEX 投入 |
| RF-04 | 待发现 | **[关注点] 数据隐私合规缺口** — GDPR/CCPA 合规状态不明；违规罚款可达全球营收 4%（GDPR）或 $7,500/故意违规（CCPA） | 法律 DD | 待评估 | 待制定 | 可能需要 indemnification 条款 |
| RF-05 | 待发现 | **[关注点] 网络安全成熟度** — SOC 2 Type II 仅为控制审计，不代表完整安全态势 | 技术 DD | 待评估 | 待制定 | 可能需要 represent & warranty 保险 |

---

## 五、Data Room 请求清单

### 5.1 财务类文件

- [ ] 过去 36 个月月度 P&L（按产品线/区域/客户段位）
- [ ] 过去 3 年经审计财务报表
- [ ] ARR waterfall / cohort 分析表（按月度/季度）
- [ ] 客户合同清单（含 ARR、合同期限、续约日期）
- [ ] 营运资金计算表（过去 12 个月月度）
- [ ] CapEx 明细（维护性 vs. 增长性）
- [ ] 税务申报表（联邦/州/国际，过去 3 年）
- [ ] 现金流量表（月度，过去 36 个月）
- [ ] 银行贷款协议及债务清单
- [ ] 管理层预算与实际对比（过去 3 年）

### 5.2 商业类文件

- [ ] 客户名单（含 ARR、行业、地区、合同期限）
- [ ] 竞争分析报告（如有）
- [ ] 市场研究/第三方行业报告
- [ ] 销售管线报告（当前 quarter）
- [ ] 定价策略文件与历史定价变更
- [ ] NPS 调查结果
- [ ] Churn 分析报告（含 churn 原因分类）
- [ ] Partner/channel 程序文档

### 5.3 法律类文件

- [ ] 公司注册文件及修订案
- [ ] 股权结构表（cap table）
- [ ] Top 20 客户合同（完整版）
- [ ] Top 10 供应商合同
- [ ] IP 登记证书（专利、商标）
- [ ] 未决/历史诉讼清单
- [ ] 隐私政策与服务条款（当前版本及历史版本）
- [ ] SOC 2 Type II 报告
- [ ] 雇佣合同模板及关键员工合同
- [ ] 保险证书

### 5.4 技术/运营类文件

- [ ] 技术架构文档
- [ ] 代码审计/质量报告（如有）
- [ ] 渗透测试报告（最近一次）
- [ ] 安全事件日志（过去 24 个月）
- [ ] 产品路线图（未来 12-24 个月）
- [ ] SLA 承诺与实际 uptime 数据
- [ ] DevOps 工具链文档
- [ ] 开源组件清单（SBOM）
- [ ] 组织架构图与员工花名册

---

## 六、每周状态更新模板

```
=====================================================================
CloudPeak Technologies — 尽职调查周报
报告周期: YYYY-MM-DD 至 YYYY-MM-DD
=====================================================================

【整体进度】
- 总完成率: XX/59 (XX%)
- P0 完成率: XX/23 (XX%)
- 红旗数量: X 个（X 个 deal-breaker / X 个 significant / X 个 manageable）

【本周关键进展】
1. ...
2. ...

【待解决问题】
1. 卖方尚未提供: [具体文件]
2. 待安排: [客户 reference calls / 管理层访谈]

【下周计划】
1. 完成 [具体事项]
2. 启动 [具体事项]

【风险提示】
- [新发现的红旗或延迟事项]

=====================================================================
```

---

## 七、SaaS 行业特定补充事项

### 7.1 ARR 质量深入分析要求

根据 SaaS Capital、Benchmarkit 及 Growth Unhinged 2025 报告的行业最佳实践：

| 分析维度 | 具体要求 |
|---------|---------|
| ARR 构成分解 | 新业务 ARR / 扩展 ARR / 续约 ARR / 降级 ARR / 流失 ARR |
| Cohort 分析 | 按获客季度追踪 12/24/36 个月留存曲线 |
| ARR per FTE | 对标 $200K（$50M-$100M ARR 段位） |
| 收入可见性 | ARR 中已签约但未确认部分的比例 |
| 收入质量 | 按月度 vs. 年度合同；预付 vs. 后付占比 |
| 扩展收入驱动 | upsell vs. cross-sell vs. 座位扩张 |

### 7.2 关键 SaaS 基准对标

| 指标 | CloudPeak（待验证） | 行业基准 | 数据来源 |
|------|---------------------|---------|---------|
| 毛利率 | 82% | 81%（订阅收入中位数） | Benchmarkit 2025 |
| YoY 增长率 | 25% | 26%（中位数） | G2 CFO 2026 |
| NRR | 待验证 | 100-106%（中位数）/ >120%（top quartile） | Data-Mania / SaaS Capital |
| GRR | 待验证 | 91%（bootstrapped 中位数） | SaaS Capital 2026 |
| ARR per FTE | 待计算 | ~$200K | Benchmarkit 2025 |
| R&D 占收入比 | 待验证 | 34%（私有 SaaS 中位数） | Benchmarkit 2025 |
| Rule of 40 | 待计算 | >40% 为优秀 | Burkland / High Alpha |

### 7.3 监管合规检查清单

| 合规领域 | 核心要求 | 适用性 | 优先级 |
|---------|---------|--------|--------|
| **GDPR** | EU 个人数据处理合规、数据清单、合法处理依据、DPO 指定、72 小时违规通知、数据跨境传输机制（SCCs/BCRs） | 如有 EU 客户/员工 | P0 |
| **CCPA/CPRA** | 加州消费者隐私权：知情权、删除权、选择退出权、非歧视权；年度隐私报告 | 如有加州客户 | P0 |
| **SOX** | 内部控制有效性评估、财务报告内控、审计委员会要求 | 如考虑未来 IPO | P1 |
| **SOC 2 Type II** | 安全、可用性、处理完整性、保密性、隐私五项 Trust Services Criteria | SaaS 标配 | P0 |
| **ISO 27001** | 信息安全管理体系认证 | 增强可信度 | P2 |
| **HIPAA** | 健康信息保护（如有医疗行业客户） | 条件性 | P1 |
| **PCI DSS** | 支付卡数据安全（如处理支付信息） | 条件性 | P1 |
| **SEC cybersecurity disclosure** | 网络安全事件披露要求（针对公众公司收购目标） | 条件性 | P2 |

---

## 八、方法论与参考框架

本尽职调查清单基于以下行业框架和最佳实践构建：

1. **Deloitte 尽职调查框架** — 多维度 DD 整合方法（财务、税务、商业、运营、HR、技术、法律）
2. **PwC 私募股权 DD 方法论** — 价值驱动型尽职调查
3. **McKinsey SaaS DD 指南** — 软件行业特定 DD 方法论
4. **Bain PE DD 框架** — 商业尽职调查核心方法论
5. **Neotas PE DD Checklist 2026** — 涵盖财务、商业、运营、法律、税务、IT、HR、ESG 八大领域
6. **NMS Consulting PE DD Checklist** — 包含 100 天计划的综合清单
7. **Affinity PE DD Guide** — 九大关键领域覆盖

---

## 九、时间线与里程碑

```
2026年5月                    2026年6月                    2026年7-8月                2026年9月
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│ DD 启动与规划    │    │ P0 调查执行      │    │ P1/P2 调查完成   │    │ 交割             │
│ - Data Room 开放 │ →  │ - QoE 分析       │ →  │ - 深度技术审计   │ →  │ - SPA 签署       │
│ - 初步管理层会议 │    │ - ARR 质量分析   │    │ - 客户 interviews│    │ - 资金交割       │
│ - P0 文件请求    │    │ - 法律/IP 审查   │    │ - ESG 评估       │    │ - 交割后整合启动 │
│                  │    │ - 网络安全评估   │    │ - 红旗解决       │    │                  │
│                  │    │ - LOI 签署(目标) │    │ - SPA 谈判       │    │                  │
└──────────────────┘    └──────────────────┘    └──────────────────┘    └──────────────────┘
         WEEK 1-2                WEEK 3-8                WEEK 9-14              WEEK 15-17
```

---

*本文件为尽职调查的活文档（living document），将随着调查进展持续更新。所有状态变更和红旗发现应在本文件中实时记录。*

*最后更新: 2026-05-09 | 版本: v1.0 | 编制: PE DD 团队*

---

## Sources

- [Deloitte Netherlands — Due Diligence Framework](https://www.deloitte.com/nl/en/Industries/tmt/perspectives/due-diligence.html)
- [Deloitte US — Private Equity Finance and Operations](https://www.deloitte.com/us/en/services/audit-assurance/articles/starting-a-private-equity-firm.html)
- [Deloitte Switzerland — 4 Key IT DD Opportunities in PE](https://www.deloitte.com/ch/en/services/consulting/perspectives/4-key-it-due-diligence-opportunities-to-add-value-in-pe-buy-side-investments.html)
- [Neotas — Private Equity Due Diligence Checklist 2026](https://neotas.com/private-equity-due-diligence-checklist/)
- [NMS Consulting — PE DD Checklist](https://nmsconsulting.com/private-equity-due-diligence-checklist/)
- [Affinity — Complete PE DD Checklist](https://www.affinity.co/guides/due-diligence-checklist-for-private-equity-firms)
- [Alexander Group — PE DD Guide](https://alexandergroup.com/insights/private-equity-a-guide-to-conducting-private-equity-due-diligence/)
- [SaaS Capital — Four Early 2026 SaaS Trends](https://www.saas-capital.com/blog-posts/four-early-2026-saas-trends/)
- [SaaS Capital — 2026 Benchmarking Metrics for Bootstrapped SaaS](https://www.saas-capital.com/blog-posts/benchmarking-metrics-for-bootstrapped-saas-companies/)
- [SaaS Capital — SaaS Valuation Multiples: Understanding the New Normal](https://www.saas-capital.com/blog-posts/saas-valuation-multiples-understanding-the-new-normal/)
- [Benchmarkit — 2025 SaaS Performance Metrics](https://www.benchmarkit.ai/2025benchmarks)
- [Aventis Advisors — SaaS Valuation Multiples 2015-2026](https://aventis-advisors.com/saas-valuation-multiples/)
- [SaaS Valuation Multiple — Q1 2026 Data](https://saasvaluationmultiple.com/)
- [Livmo — SaaS Valuation Multiples 2026](https://livmo.com/blog/saas-valuation-multiples-2026/)
- [Clearly Acquired — EBITDA Multiples for SaaS 2025-2026](https://www.clearlyacquired.com/blog/ebitda-multiples-for-saas-and-software-companies-2025-2026)
- [Research and Markets — Cloud Management Platform Market Report](https://www.researchandmarkets.com/reports/5767586/cloud-management-platform-market-report)
- [Business Research Insights — SaaS Management Platform Market](https://www.businessresearchinsights.com/market-reports/saas-management-platform-market-121476)
- [FE International — Net Revenue Retention (NRR) Explained](https://www.feinternational.com/blog/net-revenue-retention-saas-valuation)
- [Data-Mania — B2B SaaS Benchmarks 2026](https://www.data-mania.com/blog/b2b-saas-benchmarks-2026-annual-report/)
- [G2 CFO — SaaS Benchmarks 2026](https://www.gsquaredcfo.com/blog/saas-benchmarks-2026)
- [Growth Unhinged — 2025 SaaS Benchmarks Report](https://www.growthunhinged.com/p/2025-saas-benchmarks-report)
- [Burkland Associates — 2025 SaaS Benchmarks: What Great Looks Like](https://burklandassociates.com/2025/11/18/2025-saas-benchmarks-what-great-looks-like-and-how-to-reach-it/)
- [SaaS Mag — SaaS Consolidation Wave: 2026 M&A Trends](https://www.saasmag.com/saas-consolidation-ma-wave-2026/)
- [SaaS Mag — NRR: The Defining SaaS Metric of 2026](https://www.saasmag.com/net-revenue-retention-defining-saas-metric/)
- [SecurePrivacy — SaaS Privacy Compliance Requirements 2025](https://secureprivacy.ai/blog/saas-privacy-compliance-requirements-2025-guide)
- [ComplyDog — GDPR Compliance Checklist for B2B SaaS](https://complydog.com/blog/gdpr-compliance-checklist-complete-guide-b2b-saas-companies)
- [Zylo — Essential SaaS Compliance Checklist 2026](https://zylo.com/blog/saas-compliance-checklist/)
- [Pathlock — SOX Compliance Guide 2025](https://pathlock.com/blog/sox-compliance/)
- [Cloud Security Alliance — SaaS Compliance Guide](https://cloudsecurityalliance.org/blog/2025/01/21/your-guide-to-saas-compliance-key-areas-and-best-practices)
- [PI Partners — SOC 2: A Private Equity Briefing](https://www.pipartners.com/soc-2-a-private-equity-briefing/)
- [CBIZ — What Is a SOC 2+ Report](https://www.cbiz.com/insights/article/what-is-a-soc-2-report-and-why-it-matters)
- [Grant Thornton — SOC for Cybersecurity](https://www.grantthornton.com/services/audit-and-assurance-services/strategic-assurance-and-soc)
- [Ideas2IT — Technology DD for PE: Hidden Execution Risks](https://www.ideas2it.com/blogs/technology-due-diligence-private-equity)
- [Sourcepass — How IT DD Protects PE Investments](https://blog.sourcepass.com/sourcepass-blog/how-it-due-diligence-protects-pe-investments-before-the-deal-closes)
- [Plante Moran — Six Critical PE DD Considerations](https://www.plantemoran.com/explore-our-thinking/insight/2016/whitepapers/2016-peg-due-diligence-guidebook)
- [Magistral Consulting — DD for PE: A Data-Driven Framework](https://magistralconsulting.com/due-diligence-for-private-equity/)
- [Apex Leaders — PE DD Best Practices](https://apexleaders.com/blog/clients/everything-you-need-to-know-about-due-diligence-best-practices-and-more/)
- [FE Training — Private Equity Transaction Timeline](https://www.fe.training/free-resources/private-equity/private-equity-transaction-timeline/)
