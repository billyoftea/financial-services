[DATA SOURCE: WebSearch — Microsoft FY2025 Annual Report, Salesforce FY2025 Investor Relations, Oracle FY2025 Q4 Earnings, IBM Newsroom (HashiCorp acquisition), Cisco 2025 Annual Report, Google/Alphabet Wiz acquisition press releases, ServiceNow Investor Relations (Armis/Veza acquisitions), CrowdStrike FY2025 Earnings Release, Palo Alto Networks FY2025 Q2/Q4 Earnings, Thoma Bravo Official Press Release ($34.4B fundraise), Vista Equity Partners Official Site ($107B+ AUM), Permira 2025 Year in Review, Insight Partners $12.5B Fund Close, EQT Group Portfolio, ClassV Partners "Top Strategic Buyers in SaaS 2025", Software Equity Group "Top Strategic Buyers", CRN "10 Big Cybersecurity Acquisitions 2025", PrivSource Cloud & SaaS Buyout Acquisitions 2025, SaaSrise SaaS M&A Report 2025, Capstone Partners Cybersecurity Market Update May 2026, InfoSecurity Magazine "Biggest Cybersecurity M&A 2025"]

---

# 买方清单 (Buyer Universe)

**项目:** CloudPeak Technologies — 出售方 M&A 顾问委托
**日期:** 2026年5月9日
**分析师:** Investment Banking Advisory Team

---

## 一、目标公司概况 (Step 1: Target Profile)

| 项目 | 详情 |
|------|------|
| **公司名称** | CloudPeak Technologies |
| **业务描述** | B2B SaaS 云管理平台，提供多云环境下的成本优化、治理合规、安全监控及基础设施自动化管理解决方案 |
| **所属行业** | 企业软件 / 云管理平台 / FinOps / Cybersecurity |
| **商业模式** | 纯 SaaS 订阅模式 (年度经常性收入 ARR) |
| **ARR** | $143M |
| **增长率** | 预估 25-35% YoY (基于行业基准) |
| **核心资产** | 多云管理平台、企业级客户关系、云成本优化 AI 算法、合规治理引擎 |
| **地理覆盖** | 以北美为主，兼顾欧洲和亚太 |
| **预估估值区间** | $1.4B - $2.5B (基于 10-18x ARR 乘数，参考 2024-2025 SaaS 并购交易倍数) |
| **出售方偏好** | 开放讨论：战略买家和财务投资者均可考虑；希望保持管理团队连续性 |

---

## 二、战略买方 (Step 2: Strategic Buyers)

### 2.1 平台构建者 (Platform Builders)

| 序号 | 买方 | 行业 | 收入 | 战略契合度 | 财务能力 | M&A 历史记录 | 可能性 | 优先级 |
|------|------|------|------|-----------|---------|-------------|--------|--------|
| S1 | **Microsoft** | 云计算/企业软件 | $281.7B (FY2025) | 高 | 极强 ($94.6B 现金) | 极其活跃 | 中-高 | A |
| S2 | **Google (Alphabet)** | 云计算/网络安全 | Google Cloud $58.7B (2025) | 高 | 极强 ($32B Wiz 收购已关闭) | 活跃 | 中 | A |
| S3 | **Oracle** | 云基础设施/企业软件 | $57.4B (FY2025) | 高 | 强 | 温和 | 中 | B |

### 2.2 直接竞争者 / 相邻领域玩家 (Adjacent Players)

| 序号 | 买方 | 行业 | 收入 | 战略契合度 | 财务能力 | M&A 历史记录 | 可能性 | 优先级 |
|------|------|------|------|-----------|---------|-------------|--------|--------|
| S4 | **ServiceNow** | 企业工作流/云安全 | ~$13.3B (TTM) | 高 | 强 (2025年收购支出 ~$12B) | 极其活跃 | 高 | A |
| S5 | **Cisco** | 网络/安全/可观测性 | $56.7B (FY2025) | 中-高 | 强 | 活跃 ($28B Splunk 收购) | 中-高 | A |
| S6 | **IBM** | 混合云/企业软件 | ~$58B (年化) | 高 | 强 | 活跃 ($6.4B HashiCorp) | 中-高 | A |
| S7 | **Palo Alto Networks** | 网络安全 | ~$9.2B (FY2025) | 中-高 | 强 | 极其活跃 (25+ 收购) | 中 | B |
| S8 | **CrowdStrike** | 网络安全/XDR | $3.95B (FY2025) | 中 | 中-强 | 活跃 | 中 | B |

### 2.3 垂直整合者 / 相邻市场进入者 (Vertical Integrators)

| 序号 | 买方 | 行业 | 收入 | 战略契合度 | 财务能力 | M&A 历史记录 | 可能性 | 优先级 |
|------|------|------|------|-----------|---------|-------------|--------|--------|
| S9 | **Salesforce** | CRM/企业云 | ~$37.9B (FY2025), 指引 $40.5-40.9B (FY2026) | 中 | 强 ($8B Informatica 收购) | 活跃 | 中 | B |
| S10 | **Datadog** | 可观测性/监控 | ~$2.7B (2025 估算) | 中 | 中 | 温和 | 中 | C |

---

### 战略买方详细分析

#### S1 — Microsoft (Tier 1, 优先级 A)
- **收入:** $281.7B (FY2025), +15% YoY
- **市值:** ~$3.8T
- **现金储备:** $94.6B
- **Azure 收入:** 超过 $75B，首次突破该里程碑
- **战略契合度:** Azure 生态系统需要增强多云管理能力。CloudPeak 的云成本优化和治理平台可补强 Azure 的混合云和多云管理短板
- **M&A 轨迹:** Microsoft 持续主导 SaaS 收购，利用 Azure 云计算生态整合新能力。被 ClassV Partners 评为 2025 年顶级 SaaS 战略买方
- **可能性评估:** 中-高。Microsoft 可能更倾向于收购 AI 原生公司，但 CloudPeak 的云管理能力与其 Azure 战略高度互补
- **关键考量:** 需关注反垄断审查风险；Microsoft 收购通常溢价较高，有利于卖方

#### S2 — Google / Alphabet (Tier 1, 优先级 A)
- **Google Cloud 收入:** ~$58.7B (+35.8% YoY)
- **近期重大交易:** 2025年3月宣布以 $32B 全现金收购 Wiz (云安全)，2026年3月关闭 — 网络安全史上最大收购
- **战略契合度:** 收购 Wiz 后，Google Cloud 在云安全方面已大幅增强。CloudPeak 的云成本优化和治理能力可进一步补强 Google Cloud 的多云管理产品线
- **可能性评估:** 中。Google 刚完成 Wiz 整合，短期内可能消化期有限。但若 CloudPeak 定位为 Wiz 的互补资产，仍有机会
- **关键考量:** 交易审批时间可能较长 (Wiz 用了一年才完成交割)

#### S3 — Oracle (Tier 2, 优先级 B)
- **收入:** $57.4B (FY2025), +8% YoY
- **云基础设施增长:** +84% YoY
- **市值表现:** 2025年股价上涨约 87%
- **资本支出计划:** FY2026 超过 $25B
- **战略契合度:** Oracle 正在激进扩展云基础设施，但多云管理能力有限。CloudPeak 可帮助 Oracle 补强跨云管理和 FinOps 能力
- **可能性评估:** 中。Oracle 更专注于自建 IaaS 能力而非多云管理平台，但 $553B 的收入积压为其提供了充足弹药
- **关键考量:** Oracle 收购文化以整合深度著称，管理团队连续性需谨慎评估

#### S4 — ServiceNow (Tier 1, 优先级 A)
- **收入:** ~$13.3B (TTM)
- **FY2025 Q4 订阅收入:** $3.47B
- **安全业务 ACV:** 已超过 $1B (Q3 2025 里程碑)
- **近期收购:** Armis ($7.75B, 2025.12), Veza (~$1.25B, 2025)
- **2025年收购总支出:** ~$12B
- **战略契合度:** 极高。ServiceNow 正从 IT 服务管理向全栈安全和云运营扩展。CloudPeak 的云管理平台完美契合其 "workflow gravity" 战略 — 通过工作流自动化整合安全、IT 运营和云管理
- **可能性评估:** 高。ServiceNow 已证明其愿意进行大规模收购，且正在积极构建云安全和云运营能力。CEO Bill McDermott 的收购驱动增长战略明确
- **关键考量:** 投资者对 ServiceNow 高额收购支出已有所担忧，但公司股价依然强劲。需关注估值预期是否匹配

#### S5 — Cisco (Tier 1, 优先级 A)
- **收入:** $56.7B (FY2025), +5% YoY
- **Splunk 贡献:** $3.9B 收入 (首个完整财年)
- **安全业务:** 19.5% 的 FY2025 收入占比，同比增长 59.5%
- **近期重大交易:** Splunk ($28B, 2024.3)
- **AI 订单:** 单季度 $1.3B，FY2026 目标 $4B
- **战略契合度:** 高。Cisco 通过 Splunk 收购大幅增强了可观测性和安全分析能力。CloudPeak 的云管理和 FinOps 平台可与 Splunk 的数据平台形成协同效应
- **可能性评估:** 中-高。Cisco 正在消化 Splunk 整合，但对云管理和网络安全领域仍有收购胃口
- **关键考量:** Splunk 整合进展良好，但 Cisco 可能需要时间评估下一个大规模收购目标

#### S6 — IBM (Tier 1, 优先级 A)
- **HashiCorp 收购:** $6.4B ($35/股现金), 2025年2月完成
- **战略定位:** 通过 HashiCorp (Terraform, Vault) 构建端到端混合云平台
- **云市场规模:** $1.1T (2023), 预计高 teens CAGR 增长至 2027
- **战略契合度:** 高。IBM 已通过 HashiCorp 获得多云基础设施自动化能力。CloudPeak 的云成本优化和治理平台可完美补强 IBM 的混合云管理产品线，形成从基础设施自动化到成本治理的完整闭环
- **可能性评估:** 中-高。IBM 刚完成 HashiCorp 整合初期，正在寻找能进一步扩展其云管理能力的机会
- **关键考量:** HashiCorp 整合后保持相对独立运营，IBM 对被收购公司的管理团队较为友好

#### S7 — Palo Alto Networks (Tier 2, 优先级 B)
- **收入:** ~$9.2B (FY2025), +14% YoY
- **下一代安全 ARR:** $5.9B+ (+29% 增长)
- **RPO:** $15.5-15.8B (+24% 增长)
- **收购记录:** 25+ 收购，平均交易规模 ~$1.76B
- **近期交易:** $3.35B 收购 (云安全领域)
- **战略契合度:** 中-高。Palo Alto Networks 正在构建平台化网络安全解决方案，云安全和云管理是其战略重点。CloudPeak 的云治理和合规能力可增强其 Prisma Cloud 产品线
- **可能性评估:** 中。PANW 更专注于纯安全能力，对云成本管理/FinOps 的战略优先级可能较低
- **关键考量:** FY2026 收入目标 $11.3B，近期收购对 EPS 有轻微稀释影响

#### S8 — CrowdStrike (Tier 2, 优先级 B)
- **收入:** $3.95B (FY2025), +29% YoY
- **Q4 FY2025 收入:** $1.31B (超预期)
- **近期收购:** SGNL ($740M, 2026.1), 专注身份安全
- **战略契合度:** 中。CrowdStrike 的核心优势在端点安全和 XDR 平台。云管理平台与其核心业务的直接协同有限，但云安全和身份管理的交叉领域有价值
- **可能性评估:** 中偏低。CrowdStrike 收购偏好更接近其核心安全能力的产品
- **关键考量:** FY2025 新增 ARR $265M (+73% YoY 增长)，公司更倾向于内生增长配合小型收购

#### S9 — Salesforce (Tier 2, 优先级 B)
- **收入:** ~$37.9B (FY2025), FY2026 指引 $40.5-40.9B
- **近期重大交易:** Informatica (~$8B, 2025.5) — 数据治理和云数据管理
- **剩余履约义务:** ~$29.4B (+11% YoY)
- **战略契合度:** 中。Salesforce 通过 Informatica 收购进入了数据治理领域。CloudPeak 的云成本管理和 FinOps 能力与 Salesforce 的数据/分析战略有一定协同，但核心契合度不如纯云基础设施玩家
- **可能性评估:** 中。Salesforce 可能更关注 AI 和数据领域而非云基础设施管理
- **关键考量:** CRM FY2025 净现金流下降 74%，收购预算可能更谨慎

---

## 三、财务投资者 (Step 3: Financial Sponsors)

### 3.1 平台投资者 (Platform Investors)

| 序号 | 基金 | 基金规模 | 行业侧重 | 投资组合重叠 | 近期活动 | 优先级 |
|------|------|---------|---------|-------------|---------|--------|
| F1 | **Thoma Bravo** | $34.4B (2025年新募资，含旗舰基金 XVI $24.3B) | 企业软件/SaaS | 高 — 专注 SaaS 收购 | 2025年完成 4 个 SaaS 平台收购 (含多个 take-private) | A |
| F2 | **Vista Equity Partners** | $107B+ AUM, 90+ 投资组合公司 | 企业软件/SaaS | 高 — 纯 SaaS 投资者 | 2025年 $3B 收购 Nexthink (从 Permira); $5.6B 续存基金 | A |
| F3 | **Permira** | 2025年投资 €7.5B | 科技/消费者/医疗 | 中-高 — 科技团队活跃 | Clearwater Analytics $8.4B (联合收购); 退出 Nexthink $3B | A |
| F4 | **EQT** | ~€270B AUM, 300+ 投资组合公司 | 科技/多行业 | 中 — 云 SaaS 投资组合不断扩大 | Acumatica (云 ERP), PropertyMe (云 PropTech), PageUp (SaaS) | B |

### 3.2 增长型股权投资者 (Growth Equity)

| 序号 | 基金 | 基金规模 | 行业侧重 | 投资组合重叠 | 近期活动 | 优先级 |
|------|------|---------|---------|-------------|---------|--------|
| F5 | **Insight Partners** | $12.5B (最新基金), $90B+ 公司整体 | 全球软件/SaaS | 高 — 全球最大软件投资者之一 | 被评为 2025 年顶级增长型股权基金；专注 B2B SaaS | A |
| F6 | **PSG** | 专注 B2B 软件/网络安全/办公效率 | 中-高 — 擅长中间市场 SaaS | 在网络安全和 SaaS 领域活跃投资 | B |

---

### 财务投资者详细分析

#### F1 — Thoma Bravo (Tier 1, 优先级 A)
- **基金规模:** $34.4B (2025年新募资)
  - 旗舰基金 XVI: $24.3B (科技史上最大 Buyout 基金)
  - Discover Fund V: $8.1B (中型市场/成长期)
  - 欧洲基金: ~€1.8B
- **行业侧重:** 100% 专注企业软件和技术
- **M&A 轨迹:** 2025年完成 4 个 SaaS 平台收购 (其中 3 个为上市公司私有化)；标志性交易包括 Anaplan ($10.7B)
- **战略契合度:** 极高。Thoma Bravo 开创了软件领域的 "buy-and-build" 策略。CloudPeak ($143M ARR) 完全处于其核心投资区间 ($500M-$5B 交易规模)
- **关键考量:** Orlando Bravo 公开表示当前是软件收购的最佳时机。基金 XVI 刚完成募资，部署压力较大。CloudPeak 可作为平台公司或对现有投资组合的 bolt-on 收购

#### F2 — Vista Equity Partners (Tier 1, 优先级 A)
- **AUM:** $107B+
- **投资组合:** 90+ 企业软件公司，服务 4.5 亿+用户
- **近期交易:** Nexthink ($3B, 2025年从 Permira 收购); Cloud Software Group 续存基金 ($5.6B)
- **AI 战略:** 与 Google Cloud 合作，在所有 90+ 投资组合公司中部署 Agentic AI
- **战略契合度:** 极高。Vista 是全球最大的纯企业软件 PE。CloudPeak 的 SaaS 商业模式和云管理能力与 Vista 的投资策略完美匹配
- **关键考量:** Vista 的运营改进方法论 (Vista Standard Operating Procedures) 在业界独树一帜，可能要求较高的运营变革

#### F3 — Permira (Tier 1, 优先级 A)
- **2025年投资总额:** €7.5B
- **投资组合表现:** 收入增长 11%, EBITDA 增长 16%
- **科技团队:** 40 年软件投资经验
- **近期交易:** Clearwater Analytics ($8.4B, 联合收购); 成功退出 Nexthink 至 Vista ($3B)
- **战略契合度:** 高。Permira 在 SaaS 和云软件领域有深厚的投资经验和成功的退出记录。CloudPeak 可作为 Permira 新的平台投资
- **关键考量:** Permira 的 Growth Opportunities (PGO) 基金也适合少数股权/共同控制结构，交易灵活性较高

#### F4 — EQT (Tier 2, 优先级 B)
- **AUM:** ~€270B
- **投资组合:** 300+ 公司
- **SaaS/云投资组合:** Acumatica (云 ERP), PropertyMe (云 PropTech), thinkproject (云建筑), PageUp (SaaS HR), AMCS (垂直 SaaS)
- **战略契合度:** 中-高。EQT 在 SaaS 领域持续扩大投资版图，CloudPeak 符合其偏好 — 高增长云原生平台
- **关键考量:** EQT 偏好欧洲背景的公司，但也在积极扩展北美市场。投资决策流程可能较长

#### F5 — Insight Partners (Tier 1, 优先级 A)
- **最新基金:** $12.5B (近12个月最大基金)
- **公司整体规模:** $90B+
- **投资风格:** 全球软件投资者，覆盖从早期到成熟期各阶段
- **2025年定位:** 被 GrowthCap 评为顶级增长型股权基金；投资重点从广泛的互联网/消费转向更聚焦的 B2B SaaS
- **战略契合度:** 极高。Insight Partners 是全球最活跃的软件投资者之一。CloudPeak 的 B2B SaaS 模式和 $143M ARR 规模完全符合其投资标准
- **关键考量:** Insight 可以提供少数股权投资 (增长型) 或多数股权 (buyout)，交易结构灵活。其 "Onsite" 运营支持团队可为 CloudPeak 提供增值服务

---

## 四、优先级分层 (Step 4: Prioritization)

### Tier 1 — 第一梯队 (5-10 名，最高优先级，优先接触)

| 编号 | 买方 | 类型 | 核心理由 |
|------|------|------|---------|
| S4 | **ServiceNow** | 战略 | 正在积极构建云安全和云运营能力，2025年已支出 ~$12B 收购，CEO 明确执行收购驱动增长战略 |
| S6 | **IBM** | 战略 | 刚完成 HashiCorp 整合，需要扩展云管理能力以形成完整混合云产品线 |
| S5 | **Cisco** | 战略 | Splunk 整合进展顺利，云管理和 FinOps 是其安全/可观测性平台的自然延伸 |
| F1 | **Thoma Bravo** | 财务 | 刚完成史上最大科技 Buyout 基金募资 ($24.3B)，部署压力巨大，CloudPeak 规模完美匹配 |
| F2 | **Vista Equity Partners** | 财务 | 全球最大纯软件 PE ($107B+ AUM)，90+ 软件投资组合，CloudPeak 可作为平台或 bolt-on |
| F5 | **Insight Partners** | 财务 | 全球顶级软件投资者，$12.5B 新基金，B2B SaaS 是核心投资方向 |
| F3 | **Permira** | 财务 | 活跃的科技投资者，2025年投资 €7.5B，Nexthink 退出后可再投资 |

### Tier 2 — 第二梯队 (后续接触)

| 编号 | 买方 | 类型 | 核心理由 |
|------|------|------|---------|
| S1 | **Microsoft** | 战略 | 财务能力无可匹敌 ($94.6B 现金)，但收购决策流程可能较长，且可能更偏好 AI 原生标的 |
| S2 | **Google** | 战略 | 刚完成 Wiz 整合，需消化期；但若定位为 Wiz 互补资产仍有吸引力 |
| S7 | **Palo Alto Networks** | 战略 | 积极的收购者 (25+ 收购)，但更专注于纯安全能力 |
| S8 | **CrowdStrike** | 战略 | 高增长网络安全公司，但云管理非核心战略方向 |
| S9 | **Salesforce** | 战略 | Informatica 收购后进入数据治理领域，但云基础设施管理非核心 |
| F4 | **EQT** | 财务 | 规模庞大但偏好可能不同，SaaS 投资组合持续扩大 |

### Tier 3 — 第三梯队 (扩大接触范围时考虑)

| 编号 | 买方 | 类型 | 核心理由 |
|------|------|------|---------|
| S3 | **Oracle** | 战略 | 云基础设施增长迅速 (+84% YoY)，但收购战略更偏向 IaaS/数据库 |
| S10 | **Datadog** | 战略 | 可观测性领域领导者，但收入规模较小 (~$2.7B)，收购能力有限 |
| F6 | **PSG** | 财务 | 专注 B2B 软件/网络安全，中间市场规模适合，但品牌知名度低于 Tier 1 |

---

## 五、Tier 1 接触图谱 (Step 5: Contact Mapping)

### S4 — ServiceNow

| 项目 | 详情 |
|------|------|
| **关键决策人** | Bill McDermott (CEO) — 以收购驱动增长著称; Chirantan "CJ" Desai (COO) — 负责产品战略和收购整合 |
| **关系状态** | 需要通过投行渠道进行冷接触 (cold outreach) |
| **已知偏好** | 偏好大规模收购 ($1B+)，注重产品互补性和市场扩展潜力；追求 AI 驱动的安全和工作流自动化 |
| **最佳接触渠道** | 通过顶级投行 (Goldman Sachs / Morgan Stanley) 的科技组引入; ServiceNow Corp Dev 团队对主动推介持开放态度 |
| **时间窗口** | 2026年 Q1-Q2 (Armis 整合初步完成后可能启动新一轮收购) |

### S6 — IBM

| 项目 | 详情 |
|------|------|
| **关键决策人** | Arvind Krishna (CEO); Rob Thomas (SVP, Software and Chief Commercial Officer) |
| **关系状态** | 可通过 IBM 长期合作的投行中介引入 |
| **已知偏好** | 注重混合云和 AI 战略契合度；偏好有强大技术团队的企业软件公司；收购后允许一定独立性运营 |
| **最佳接触渠道** | IBM Corporate Development 团队 (Armonk, NY); 通过 Lazard / Goldman Sachs 引入 |
| **时间窗口** | 2026年 H1 (HashiCorp 整合进入第二阶段) |

### S5 — Cisco

| 项目 | 详情 |
|------|------|
| **关键决策人** | Chuck Robbins (CEO); Jeetu Patel (EVP and Chief Product Officer) — 负责 Splunk 整合和产品战略 |
| **关系状态** | 需要通过投行渠道建立联系 |
| **已知偏好** | 偏好能增强安全和可观测性平台的收购；重视数据分析和 AI 驱动能力；交易规模 $1-10B |
| **最佳接触渠道** | Cisco Corporate Development; 通过 Barclays / Morgan Stanley 引入 |
| **时间窗口** | 2026年 H2 (Splunk 整合成熟后可能寻找云管理领域补充) |

### F1 — Thoma Bravo

| 项目 | 详情 |
|------|------|
| **关键决策人** | Orlando Bravo (Managing Partner); Holden Spaht (Managing Partner) |
| **关系状态** | 通过投行并购团队直接联系 (Thoma Bravo 对主动推介非常开放) |
| **已知偏好** | 高质量的 SaaS 订阅收入、强劲的毛利率 (>70%)、可预测的现金流、明确的市场领导地位 |
| **最佳接触渠道** | 直接联系 Thoma Bravo 旧金山或芝加哥办公室; 通过 Kirkland & Ellis (常年法律顾问) 引入 |
| **时间窗口** | 即时 — 基金 XVI ($24.3B) 刚完成募资，正在积极部署 |

### F2 — Vista Equity Partners

| 项目 | 详情 |
|------|------|
| **关键决策人** | Robert F. Smith (Founder, Chairman and CEO); David Flannery (President) |
| **关系状态** | 通过投行并购团队直接联系 |
| **已知偏好** | 企业软件公司、SaaS 订阅模型、高毛利率、明确的运营改进空间；偏好控股型投资 |
| **最佳接触渠道** | 直接联系 Vista 奥斯汀总部; 通过 Simpson Thacher & Bartlett (常年法律顾问) 引入 |
| **时间窗口** | 即时 — Vista 持续寻求优质 SaaS 平台投资 |

### F5 — Insight Partners

| 项目 | 详情 |
|------|------|
| **关键决策人** | Jeff Horing (Co-Founder and Managing Director); Deven Parekh (Managing Director) |
| **关系状态** | 通过投行或现有被投企业网络引入 |
| **已知偏好** | 全球高增长软件/SaaS 公司、强大的产品差异化、清晰的规模化路径；投资阶段灵活 (少数或控股均可) |
| **最佳接触渠道** | Insight Partners 纽约总部; 通过其 Onsite 团队进行初步接触 |
| **时间窗口** | 即时 — $12.5B 新基金正在部署 |

### F3 — Permira

| 项目 | 详情 |
|------|------|
| **关键决策人** | Kurt Bjorklund (Managing Partner); Tom Lister (Managing Partner) |
| **关系状态** | 通过投行并购团队直接联系 |
| **已知偏好** | 高质量的市场领导者、科技行业专注、强管理团队、可执行的增值策略 |
| **最佳接触渠道** | Permira 伦敦/纽约办公室; 通过 Cleary Gottlieb Steen & Hamilton 引入 |
| **时间窗口** | 即时 — 2025年已投资 €7.5B，持续寻求优质科技标的 |

---

## 六、总结统计

| 指标 | 数量 |
|------|------|
| **战略买方总数** | 10 |
| **财务投资者总数** | 6 |
| **Tier 1 买方** | 7 (战略 3, 财务 4) |
| **Tier 2 买方** | 6 (战略 5, 财务 1) |
| **Tier 3 买方** | 3 (战略 2, 财务 1) |
| **买方总数** | 16 |

### 按类型分布

| 类型 | Tier 1 | Tier 2 | Tier 3 | 总计 |
|------|--------|--------|--------|------|
| 大型科技平台 | 3 (ServiceNow, IBM, Cisco) | 3 (Microsoft, Google, Salesforce) | 1 (Oracle) | 7 |
| 网络安全 | 0 | 2 (PANW, CrowdStrike) | 0 | 2 |
| 可观测性 | 0 | 0 | 1 (Datadog) | 1 |
| PE (Buyout) | 3 (Thoma Bravo, Vista, Permira) | 1 (EQT) | 0 | 4 |
| PE (Growth) | 1 (Insight Partners) | 0 | 1 (PSG) | 2 |

---

## 七、关键注意事项

1. **质量优于数量:** 本清单聚焦于 16 个经过深入研究的买方，而非 200 个泛泛的名字。每个买方都有明确的战略/财务逻辑和可执行的行动方案。

2. **近期 M&A 活动参考:**
   - 2024-2025 是 SaaS M&A 历史上第二活跃的年份
   - Q1 2025 企业 SaaS M&A 交易达 210 宗 (PitchBook)
   - 2025年网络安全 M&A 创纪录 $75-76B
   - Salesforce → Informatica (~$8B), Google → Wiz (~$32B), IBM → HashiCorp (~$6.4B), ServiceNow → Armis (~$7.75B)

3. **反垄断风险标记:**
   - Microsoft / Google / Oracle 作为直接竞争对手可能面临监管审查
   - 建议在正式接触前进行初步反垄断评估
   - PE 买方的反垄断风险相对较低

4. **财务投资者部署压力:**
   - Thoma Bravo: 基金 XVI ($24.3B) 刚完成募资，处于投资期初期，部署动力最强
   - Vista: $107B+ AUM，持续寻找优质标的
   - Insight Partners: $12.5B 新基金，专注 B2B SaaS
   - Permira: 2025年已投资 €7.5B，投资节奏活跃

5. **估值参考:**
   - 2024-2025 SaaS 收购倍数范围: 8-22x ARR
   - 大型战略买方通常支付溢价 (如 Google Wiz ~30x ARR)
   - PE 买方估值更注重 EBITDA/现金流，倍数通常低于战略买方
   - CloudPeak ($143M ARR) 的预估估值区间: $1.4B-$2.5B

6. **建议的接触时序:**
   - 第一周: 同时接触 F1 (Thoma Bravo) 和 F2 (Vista) — PE 买家决策较快
   - 第二周: 接触 S4 (ServiceNow) 和 S6 (IBM) — 最有诚意的战略买家
   - 第三周: 接触 F5 (Insight) 和 F3 (Permira)
   - 第四周: 接触 S5 (Cisco)
   - 后续: 根据第一波反馈调整 Tier 2 接触计划

---

## Sources

- [Microsoft Annual Report FY2025](https://www.microsoft.com/investor/reports/ar25/index.html)
- [Microsoft FY25 Q2 Balance Sheets](https://www.microsoft.com/en-us/investor/earnings/fy-2025-q2/balance-sheets)
- [Salesforce FY2025 Q4 Results](https://investor.salesforce.com/news/news-details/2025/Salesforce-Announces-Fourth-Quarter-and-Fiscal-Year-2025-Results/default.aspx)
- [Oracle FY2025 Q4 and Full Year Results](https://investor.oracle.com/investor-news/news-details/2025/Oracle-Announces-Fiscal-2025-Fourth-Quarter-and-Fiscal-Full-Year-Financial-Results/default.aspx)
- [IBM Completes HashiCorp Acquisition](https://newsroom.ibm.com/2025-02-27-ibm-completes-acquisition-of-hashicorp,-creates-comprehensive,-end-to-end-hybrid-cloud-platform)
- [Cisco 2025 Annual Report](https://www.cisco.com/c/dam/en_us/about/annual-report/2025-cisco-full-annual-report.pdf)
- [Cisco Completes Splunk Acquisition](https://www.cisco.com/site/us/en/about/corporate-development/acquisitions/splunk/index.html)
- [Alphabet Closes $32B Wiz Acquisition](https://finance.yahoo.com/news/google-wraps-32b-acquisition-cloud-125654180.html)
- [ServiceNow to Acquire Armis](https://investor.servicenow.com/news/news-details/2025/ServiceNow-to-acquire-Armis-to-expand-cyber-exposure-and-security-across-the-full-attack-surface-in-IT-OT-and-medical-devices-for-companies-governments-and-critical-infrastructure/)
- [ServiceNow Workflow Strategy](https://ventureinsecurity.net/p/servicenow-is-betting-on-workflow)
- [CrowdStrike FY2025 Results](https://ir.crowdstrike.com/news-releases/news-release-details/crowdstrike-reports-fourth-quarter-and-fiscal-year-2025/)
- [Palo Alto Networks FY2025 Q2 Results](https://www.paloaltonetworks.com/company/press/2025/palo-alto-networks-reports-fiscal-second-quarter-2025-financial-results)
- [Thoma Bravo $34.4B Fundraise](https://www.thomabravo.com/press-releases/thoma-bravo-completes-34-4-billion-fundraise)
- [Vista Equity Partners By the Numbers](https://www.vistaequitypartners.com/by-the-numbers/)
- [Permira 2025 Year in Review](https://www.permira.com/news-and-insights/insights/2025-a-year-in-review/)
- [Insight Partners $12.5B Fund Close](https://www.insightpartners.com/ideas/global-software-investor-insight-partners-closes-on-12-5b-in-capital-to-invest-in-the-next-generation-of-software-leaders/)
- [EQT Portfolio](https://eqtgroup.com/en/about/current-portfolio)
- [Top Strategic Buyers in SaaS 2025 (ClassV Partners)](https://www.classvipartners.com/who-are-the-top-strategic-buyers-in-saas-a-2025-overview/)
- [Top Strategic Buyers (Software Equity Group)](https://softwareequity.com/blog/top-strategic-buyers)
- [10 Big Cybersecurity Acquisitions 2025 (CRN)](https://www.crn.com/news/security/2025/10-big-cybersecurity-acquisition-deals-in-2025)
- [Cloud & SaaS Buyout Acquisitions 2025 (PrivSource)](https://www.privsource.com/acquisitions/activity/buyout/cloud-saas/2025)
- [SaaS M&A Report 2025 (SaaSrise)](https://www.saasrise.com/blog/the-saas-m-a-report-2025)
- [Cybersecurity Market Update May 2026 (Capstone Partners)](https://www.capstonepartners.com/insights/article-cybersecurity-market-update/)
- [Biggest Cybersecurity M&A 2025 (InfoSecurity Magazine)](https://www.infosecurity-magazine.com/news-features/biggest-cybersecurity-mergers/)
- [2025 State of Cybersecurity Market (Return on Security)](https://www.returnonsecurity.com/p/2025-state-of-the-cybersecurity-market)
- [GrowthCap Top Software Investors 2025](https://growthcapadvisory.com/growthcaps-top-software-investors-of-2025/)
- [Palo Alto Networks Q4 FY2025 Earnings (Futurum)](https://futurumgroup.com/insights/palo-alto-networks-q4-fy-2025-earnings-show-16-growth-strong-arr-momentum/)
- [Palo Alto $3.35B Acquisition (Tikr)](https://www.tikr.com/blog/palo-alto-networks-falls-4-as-the-cybersecurity-giant-announces-3-35-billion-acquisition)
- [Enterprise SaaS M&A Q1 2025 (SaaS Affin)](https://www.saasaffin.com/a-quick-cure-for-model/)
