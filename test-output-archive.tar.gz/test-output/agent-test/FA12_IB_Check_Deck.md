# Deck Check Report: CloudPeak Technologies — M&A Sell-Side Pitch Deck

**[DATA SOURCE: 实际市场数据来源 — SaaS Capital (saas-capital.com), PitchBook (pitchbook.com), QuantPillar (quantpillar.com), SaasRise (saasrise.com), Goldman Sachs Style Guide (goldmansachs.papirfly.com), Mergers & Inquisitions (mergersandinquisitions.com), Wall Street Prep (wallstreetprep.com), 10X EBITDA (10xebitda.com), Macabacus (macabacus.com), J.P. Morgan Insights (jpmorgan.com)]**

---

## 模拟审查背景

**目标公司**: CloudPeak Technologies
- **业务模式**: B2B SaaS (企业云基础设施管理平台)
- **ARR**: $143M (年化经常性收入)
- **行业定位**: 企业云基础设施管理软件垂直领域
- **交易类型**: 卖方M&A推介演示文稿 (Sell-Side Pitch Deck)
- **模拟Deck结构**: 18张幻灯片，覆盖执行摘要、公司概况、市场分析、财务表现、估值分析、交易建议

**审查标准参考**:
- Goldman Sachs 客户演示文稿格式规范 (来源: goldmansachs.papirfly.com Style Guide)
- Morgan Stanley / JP Morgan 推介材料质量标准 (来源: jpmorgan.com/insights)
- Wall Street Prep IB Pitchbook 模板与格式指南 (来源: wallstreetprep.com)
- Mergers & Inquisitions 推介文稿结构最佳实践 (来源: mergersandinquisitions.com)
- 10X EBITDA 真实投行演示文稿库 (来源: 10xebitda.com)

---

## Summary (汇总)

- **总问题数**: 14
- **Critical (关键问题)**: 5 (数字不一致、计算错误、数据-叙述矛盾)
- **Important (重要问题)**: 5 (语言规范、术语不一致、缺失来源引用)
- **Minor (次要问题)**: 4 (格式不一致、排版微调)

---

## Critical Issues (关键问题)

### 一、Number Consistency (数字一致性)

#### 1. ARR数字跨幻灯片不一致 (Slides 2, 5, 12)

| 幻灯片 | 显示值 | 上下文 |
|---------|--------|--------|
| Slide 2 (执行摘要) | $143M ARR | 公司核心指标 |
| Slide 5 (财务概览) | $141M ARR | TTM Revenue引用 |
| Slide 12 (估值摘要) | $143M ARR | 估值基础 |

**分析**: Slide 5 将ARR显示为$141M，与其余幻灯片的$143M不一致。在B2B SaaS估值中，ARR是核心指标，$2M差异直接影响EV/Revenue倍数的计算基础。按照Goldman Sachs格式标准，核心财务指标必须在所有页面保持精确一致。

**Action (建议)**:
- 确认公司实际ARR数据来源 (management reporting vs. GAAP revenue)
- 若$143M为management ARR (包含签约但未起效合约)，需在Slide 5注明 "Management ARR: $143M; GAAP Revenue (TTM): $141M"
- 统一所有幻灯片的ARR引用值，或明确标注口径差异

---

#### 2. EBITDA Margin计算错误 (Slide 5, Slide 8)

| 位置 | EBITDA | Revenue | 隐含Margin |
|------|--------|---------|------------|
| Slide 5 (财务概览) | $28.6M | $141M | 20.3% |
| Slide 5 显示的Margin值 | — | — | **22.0%** |
| Slide 8 (利润率趋势) | — | — | 20.3% |

**分析**: Slide 5声称EBITDA Margin为22.0%，但$28.6M / $141M = 20.3%。Slide 8正确显示为20.3%。根据Wall Street Prep和Mergers & Inquisitions的推介材料标准，所有比率必须可以追溯到分子和分母。此差异虽然仅为1.7个百分点，但在估值中，EBITDA Margin是EV/EBITDA倍数法的关键输入。

**Action (建议)**:
- 将Slide 5的EBITDA Margin修正为20.3%
- 或如果22.0%为adjusted EBITDA margin (调整后)，需明确披露调整项目
- 在调整EBITDA时，按投行惯例提供从GAAP EBITDA到Adjusted EBITDA的bridge

---

#### 3. Revenue Growth Rate与绝对数值不匹配 (Slide 4, Slide 5)

- **Slide 4声称**: "CloudPeak实现了32%的年化收入增长率"
- **Slide 5财务数据**: FY2023 Revenue $108M → FY2024 Revenue $141M
- **实际增长率**: ($141M - $108M) / $108M = **30.6%**, 非32%

**分析**: 30.6%与32%相差约140 basis points。投行演示文稿的growth claim必须与底部财务数据精确对应。Macabacus格式指南明确指出，投行材料中的每个百分比声明必须可以追溯到具体数字。

**Action (建议)**:
- 将Slide 4修改为"约31%的年化收入增长率"，或精确表述为30.6%
- 或更新Slide 5的财务数字使growth rate确实达到32%
- 确保growth rate计算口径一致 (YoY vs. CAGR vs. organic growth)

---

#### 4. 估值倍数与市场可比数据不一致 (Slide 12)

**Deck中的估值范围**:
- EV/Revenue: 8.0x - 10.0x (隐含Enterprise Value: $1,144M - $1,430M)
- EV/EBITDA: 45x - 55x (隐含Enterprise Value: $1,287M - $1,573M)

**2025年实际市场可比倍数**:
- Public Enterprise SaaS median EV/Revenue: **3.9x** (PitchBook Q3 2025)
- Public SaaS median EV/Revenue: **4.9x** (QuantPillar, end of 2025)
- Private SaaS median EV/Revenue: **7.0x** (SaaS Capital, early 2025)
- Private SaaS median revenue multiple: **4.1x** (SaasRise 2024)

**分析**: Deck中8.0x-10.0x EV/Revenue倍数远高于当前市场水平。即便考虑到CloudPeak的$143M ARR规模溢价和高增长率，此倍数范围仍需强有力的支撑依据。SaaS Capital报告显示private SaaS中位数为7.0x，即使处于高端区间 (例如前25%分位)，达到8.0x-10.0x也需要卓越的增长率和利润率组合。

**Action (建议)**:
- 提供具体的comparable company名单和各自的倍数
- 说明为何CloudPeak应获得高于市场中位数的溢价
- 考虑将估值范围调整为更保守的6.0x-8.5x，与市场数据更一致
- 在valuation football field chart中加入当前市场倍数作为参照

---

#### 5. 财务摘要中的Total Revenue与ARR混淆 (Slide 2, Slide 15)

- **Slide 2**: "CloudPeak Technologies | $143M ARR | 企业云基础设施管理平台"
- **Slide 15 (财务预测摘要)**: FY2025E Revenue $165M

**分析**: 如果ARR为$143M (FY2024)，而FY2025E Revenue为$165M，则隐含growth rate为 ($165M - $143M) / $143M = 15.4%。然而Slide 4声称growth rate为32%。这意味着：
- 要么FY2025E Revenue预测过低
- 要么32% growth rate的基准年不是FY2024
- 要么ARR与Revenue的口径存在系统性混淆

在SaaS估值中，ARR和GAAP Revenue是两个不同但相关的指标。投行推介材料必须明确定义每一个数字的口径。

**Action (建议)**:
- 在所有出现财务数字的位置标注口径 (ARR vs. GAAP Revenue)
- 提供ARR到Revenue的reconciliation
- 确保growth rate声明的基础数据与预测数据相互一致

---

### 二、Data-Narrative Alignment (数据-叙述一致性)

#### 6. "市场领导者"声明缺乏数据支撑 (Slide 3)

- **Claim (声称)**: "CloudPeak是企业云基础设施管理领域的#1平台"
- **Data shows (数据显示)**: Slide 3中提到TAM为$12B，若CloudPeak为#1，以$143M ARR计算，市场份额仅约1.2%

**分析**: 按$12B TAM和$143M ARR计算，CloudPeak市场份额为1.2%。在如此低的市场份额下声称"#1"需要注明更精确的市场定义 (如特定垂直子领域)。"在$12B市场中以1.2%份额称#1"在逻辑上难以自圆其说，除非限定到极其细分的niche。

根据J.P. Morgan关于pitch deck最佳实践的指南，所有市场定位声明必须与数据完全吻合。Goldman Sachs演示文稿规范同样要求，任何"leading"或"#1"的声明都需要注明具体排名来源。

**Action (建议)**:
- 将表述修改为"CloudPeak在[特定垂直领域]的市场份额领先"，并注明第三方来源 (如Gartner, IDC)
- 缩小TAM定义使其与#1声明一致，或承认CloudPeak为"emerging leader"而非"#1"
- 引用具体的行业报告支持市场定位声明

---

## Important Issues (重要问题)

### 三、Language Polish (语言规范)

#### 7. 非正式用语 (Slide 4, Slide 7)

| 幻灯片 | 原文 | 问题 | 建议修改 |
|---------|------|------|----------|
| Slide 4 | "CloudPeak has seen really strong growth" | "really"为非正式强调 | "CloudPeak has demonstrated strong revenue growth" |
| Slide 7 | "The company has a lot of room to expand margins" | "a lot of"为模糊量化 | "Management has identified significant margin expansion opportunities of [X] bps" |
| Slide 9 | "We think the company is worth" | 第一人称+口语化 | "Based on our analysis, the implied equity value range is" |

**参考标准**: 根据ib-terminology.md参考文件及Goldman Sachs Style Guide，投行材料应使用被动语态或第三人称，避免缩写和口语化表达。所有数量声明必须附带具体数字。

---

#### 8. 术语不一致 (多张幻灯片)

| 术语 | Slide 2 | Slide 5 | Slide 10 | Slide 15 |
|------|---------|---------|----------|----------|
| 收入指标 | ARR | Revenue | Recurring Revenue | ARR |
| 利润指标 | EBITDA | Adjusted EBITDA | EBITDA | EBITDA |

**分析**: "ARR"、"Revenue"、"Recurring Revenue"在不同幻灯片中交替使用，但口径可能不同。同样，"EBITDA"和"Adjusted EBITDA"混用但未提供bridge。

**Action (建议)**:
- 在首次使用时定义所有关键术语
- 如果使用Adjusted EBITDA，提供从报告EBITDA到调整后EBITDA的完整bridge
- 在Deck中增加术语表页或脚注

---

#### 9. 缺失图表来源引用 (Slide 6, Slide 7, Slide 10)

| 幻灯片 | 图表内容 | 来源引用 |
|---------|----------|----------|
| Slide 6 | 市场规模趋势图 | **缺失** |
| Slide 7 | 竞争格局定位图 | **缺失** |
| Slide 10 | DCF敏感性分析图 | **缺失** |

**分析**: 按照Macabacus和Wall Street Prep的IB pitchbook格式标准，每个数据图表必须在底部注明数据来源 (如"Source: Capital IQ, Bloomberg, Management Estimates")。10X EBITDA收录的Goldman Sachs、Morgan Stanley真实演示文稿中，每页均包含来源引用。

**Action (建议)**:
- Slide 6添加: "Source: IDC Cloud Infrastructure Management Market Report 2025, Company Estimates"
- Slide 7添加: "Source: Gartner Magic Quadrant, Company Analysis, Industry Reports"
- Slide 10添加: "Source: Company Filings, Management Projections, Analyst Estimates"

---

#### 10. 缺失估值方法说明 (Slide 10, Slide 11)

**分析**: Deck的估值部分展示了DCF和Comparable Companies分析，但缺少：
- DCF中使用的WACC假设及其分解 (cost of equity, cost of debt, capital structure)
- Terminal Value的计算方法 (exit multiple vs. perpetuity growth) 和具体假设
- Comparable company的筛选标准和最终peer group名单
- Precedent Transactions分析的deal清单

按Mergers & Inquisitions和Wall Street Prep的估值框架，这些是估值展示的必要组成部分。缺少关键假设使估值结果缺乏可审计性。

**Action (建议)**:
- 增加一页WACC assumption breakdown
- 增加comps筛选标准和peer group列表
- 对DCF增加terminal value assumption的敏感性分析
- 如有Precedent Transactions分析，提供deal详情表

---

#### 11. 模糊的战略价值声明 (Slide 9)

- **原文**: "Significant synergy potential for strategic acquirers"
- **问题**: "Significant"为模糊量化，未提供具体数字

**分析**: 投行推介材料中的协同效应声明必须量化。根据IB pitchbook最佳实践，应提供具体来源 (revenue synergies vs. cost synergies) 和估算金额。

**Action (建议)**:
- 修改为: "Estimated synergies of $15M-$25M annually, comprising $10M-$18M in cost synergies (platform consolidation, G&A rationalization) and $5M-$7M in revenue synergies (cross-sell opportunities)"
- 提供协同效应实现的预期时间线

---

## Minor Issues (次要问题)

### 四、Formatting QC (格式质量)

#### 12. 日期格式不一致 (多张幻灯片)

| 位置 | 格式 |
|------|------|
| Slide 2 封面 | "May 2025" |
| Slide 5 财务表 | "FY24" |
| Slide 8 图表 | "Fiscal Year 2024" |
| Slide 15 预测 | "FY2025E" |

**分析**: Goldman Sachs和其他bulge bracket银行的格式规范要求日期格式在整个deck中保持统一。混用"FY24"、"FY2024"、"Fiscal Year 2024"降低专业性。

**Action (建议)**:
- 统一使用 "FY2024" 格式 (推荐)
- 或统一使用 "Fiscal Year 2024" (如篇幅允许)
- 确保预测年份标注方式一致 (FY2025E or FY2025P，选一种)

---

#### 13. 数字格式不一致 (Slide 5, Slide 12)

| 位置 | 格式 | 示例 |
|------|------|------|
| Slide 5 | 百万单位 | $141M, $28.6M |
| Slide 12 | 混合格式 | $1,144M, $1.14B |

**分析**: 在同一deck中混用 "M" 和 "B" 表示法会导致阅读困难。$1,144M和$1.14B实际上很接近，但格式不统一。

**Action (建议)**:
- 选择一种格式 (推荐: 统一使用$M)
- 或在首次使用时注明 "$ in millions" 并在每页header保留此标注

---

#### 14. 缺失保密声明 (部分页面)

**分析**: Slide 1-3包含"CONFIDENTIAL"水印，但Slide 4-18缺失。对于M&A sell-side pitch deck，每页均应包含保密声明。根据10X EBITDA收录的真实Goldman Sachs和Morgan Stanley演示文稿，confidentiality disclaimer通常出现在每页页脚。

**Action (建议)**:
- 在所有幻灯片页脚添加: "CONFIDENTIAL — For Discussion Purposes Only"
- 或在每页底部添加更详细的disclaimer

---

## Final Checklist (最终审查清单)

| 检查项 | 状态 | 备注 |
|--------|------|------|
| 数字跨幻灯片一致 | **不通过** | ARR $143M vs $141M; Growth rate 32% vs 30.6%; EBITDA Margin 22% vs 20.3% |
| 计算准确性验证 | **不通过** | EBITDA Margin计算错误; Growth rate与绝对值不匹配 |
| 估值倍数合理性 | **不通过** | 8-10x EV/Rev显著高于市场可比 (3.9x-7.0x) |
| 叙述与数据匹配 | **不通过** | "#1"声明与1.2%市场份额矛盾 |
| 语言符合IB标准 | **需改进** | 存在非正式用语和模糊量化 |
| 术语一致性 | **需改进** | ARR/Revenue/Recurring Revenue混用 |
| 图表来源引用 | **不通过** | 3个图表缺失来源 |
| 格式一致性 | **需改进** | 日期格式和数字格式不统一 |
| 保密声明完整性 | **需改进** | 部分页面缺失confidential标记 |
| 估值方法透明度 | **需改进** | 缺少WACC假设、comps筛选标准 |

---

## 审查结论

**总体评估**: 本Deck在关键维度存在多个Critical问题，**不建议在当前状态下提交给客户或潜在收购方**。

**关键修复优先级**:
1. **最高优先级**: 修复所有数字不一致问题 (ARR、EBITDA Margin、Growth Rate)
2. **高优先级**: 重新校准估值倍数范围，使其与2025年市场可比数据一致
3. **高优先级**: 修正"市场领导者"声明，确保与实际市场份额数据一致
4. **中优先级**: 统一术语口径，增加图表来源引用
5. **低优先级**: 统一日期和数字格式，添加保密声明

**投行审核流程建议** (参考Wall Street Oasis / Mergers & Inquisitions最佳实践):
- Analyst层: 修复所有Critical问题，重新运行数字核对
- Associate层: 验证修复后的数字一致性，审查叙述逻辑
- VP/Director层: 战略审核 — 估值范围是否合理？叙述是否compelling？
- MD层: 最终签署 — 客户就绪检查

---

## 附录: 2025年SaaS估值市场参考数据

| 指标 | 数值 | 来源 |
|------|------|------|
| Private SaaS median EV/Revenue (early 2025) | 7.0x | SaaS Capital |
| Public Enterprise SaaS median EV/Revenue (Q3 2025) | 3.9x | PitchBook |
| Public SaaS median EV/Revenue (end 2025) | 4.9x | QuantPillar |
| Public SaaS median EV/Revenue (end 2024) | 6.2x | QuantPillar |
| Private SaaS median revenue multiple (2024) | 4.1x | SaasRise |
| Public SaaS median revenue multiple (2024) | 5.6x | SaasRise |

---

## Sources

- [SaaS Capital — 2025 Private SaaS Company Valuations](https://www.saas-capital.com/blog-posts/private-saas-company-valuations-multiples/)
- [PitchBook — Q3 2025 Enterprise SaaS Public Comp Sheet & Valuation Guide](https://pitchbook.com/news/reports/q3-2025-enterprise-saas-public-comp-sheet-and-valuation-guide)
- [QuantPillar — 2025-2026 Private Market Valuation Multiples](https://quantpillar.com/resources/guides/valuation-multiples/)
- [SaasRise — The SaaS M&A Report 2025](https://www.saasrise.com/blog/the-saas-m-a-report-2025)
- [First Page Sage — SaaS Valuation Multiples 2025 Report](https://firstpagesage.com/business/saas-valuation-multiples/)
- [Goldman Sachs Style Guide (Branding Portal)](https://goldmansachs.papirfly.com/readimage.aspx?pubid=3a2048c5-38a9-4977-8c54-0724714a2127&down=1)
- [Mergers & Inquisitions — Investment Banking Pitch Books](https://mergersandinquisitions.com/investment-banking-pitch-books/)
- [Wall Street Prep — Investment Banking Pitchbook](https://www.wallstreetprep.com/knowledge/investment-banking-pitchbook/)
- [10X EBITDA — Investment Banking Presentations](https://www.10xebitda.com/investment-banking-presentations/)
- [Macabacus — How to Create an Investment Banking Pitch Book](https://macabacus.com/blog/investment-banking-pitch-book)
- [J.P. Morgan — Creating an Investor Pitch Deck](https://www.jpmorgan.com/insights/business-planning/creating-an-investor-pitch-deck-for-your-startup)
- [Wall Street Oasis — Investment Banking Pitch Book](https://www.wallstreetoasis.com/resources/skills/valuation/investment-banking-pitch-book)
- [Winning Presentations — Investment Banking PowerPoint Copilot](https://winningpresentations.com/investment-banking-powerpoint-copilot/)
- [IB Interview Questions — Pitch Book Structure](https://ibinterviewquestions.com/blog/pitch-book-structure-sections)
- [CFI — Investment Banking Pitchbook Template](https://corporatefinanceinstitute.com/resources/valuation/investment-banking-pitchbook-template/)
- [M&A Community — CIM Guide](https://mnacommunity.com/insights/ma-confidential-information-memorandum/)
- [Valutico — Understanding the CIM](https://valutico.com/understanding-the-confidential-information-memorandum-cim/)
