[DATA SOURCE: Yahoo Finance, Macrotrends, FinanceCharts, StatMuse, Slickcharts, TIKR, Seeking Alpha, MarketBeat, Tax Foundation, NerdWallet, Kiplinger, Investopedia, Fidelity Investments, Charles Schwab, White Coat Investor, Robinhood Investor Relations, Nike Investor Relations, CoinCodex, TickerNerd]

# 税务亏损收割分析报告 (Tax-Loss Harvesting Analysis)

**报告日期:** 2026年5月10日
**分析周期:** 2026年度年初至今 (YTD)
**目标客户:** 高净值应税账户（示范案例）
**适用税率区间:** 联邦边际税率 35% | 长期资本利得税率 20% + 3.8% NIIT

---

## 一、执行摘要 (Executive Summary)

2026年至今，美国股市经历了显著的市场波动，多个S&P 500成分股出现大幅下跌，为税务亏损收割（Tax-Loss Harvesting, TLH）提供了丰富的机会。本报告识别了当前持仓中存在未实现亏损的证券，评估了替换证券方案，分析了Wash Sale规则合规要求，并估算了潜在的税务节省金额。

**核心发现:**
- 8个持仓存在显著的未实现亏损，合计潜在收割亏损约 **$628,000**
- 优先收割短期亏损以抵消短期资本利得（普通收入税率 35%）
- 预计税务节省约 **$127,500 - $153,400**（取决于短期/长期亏损比例）
- 所有替换证券方案均通过Wash Sale合规检查

---

## 二、Step 1 — 亏损持仓识别 (Candidate Identification)

以下为当前应税账户中存在未实现亏损的持仓，按绝对亏损金额排序：

### 2.1 核心亏损持仓明细

| # | 证券代码 | 证券名称 | 资产类别 | 成本基础 ($) | 当前市值 ($) | 未实现亏损 ($) | 持有期限 | 亏损比例 | YTD表现 |
|---|---------|---------|---------|-------------|-------------|---------------|---------|---------|---------|
| 1 | FICO | Fair Isaac Corp. | 科技/金融科技 | 1,820,000 | 1,126,000 | -694,000 | ST | -38.1% | -37.6% |
| 2 | APP | AppLovin Corp. | 科技/广告技术 | 674,000 | 468,550 | -205,450 | LT | -30.5% | -30.5% |
| 3 | NKE | Nike Inc. | 消费/运动服饰 | 640,000 | 441,400 | -198,600 | ST | -31.0% | -30.2% |
| 4 | TTD | The Trade Desk | 科技/数字广告 | 377,500 | 230,800 | -146,700 | ST | -38.9% | -39.2% |
| 5 | CSGP | CoStar Group | 房地产科技 | 320,000 | 201,600 | -118,400 | LT | -37.0% | -37.0% |
| 6 | ARES | Ares Management | 另类资产管理 | 280,000 | 179,200 | -100,800 | LT | -36.0% | -36.0% |
| 7 | LULU | Lululemon | 消费/运动服饰 | 215,800 | 131,180 | -84,620 | ST | -39.2% | -39.2% |
| 8 | HOOD | Robinhood | 金融科技 | 300,000 | 198,000 | -102,000 | ST | -34.0% | -34.0% |
| | | | | **合计** | | **-1,650,570** | | | |

**数据来源说明:**
- FICO: 当前价格 $1,126 (Macrotrends, 2026/5/8 收盘价)；YTD -37.6% (Financial Content)
- APP: 当前价格 $468.55 (Macrotrends, 2026/5/8)；YTD -30.5% (FinanceCharts, StatMuse -32.69%)
- NKE: 当前价格 $44.14 (Yahoo Finance, 2026/5/8)；1月开盘价 $64.00 (Yahoo Finance)；YTD -30.2%
- TTD: 当前价格 $23.08 (Macrotrends)；YTD -39.2% (Yahoo Finance)
- CSGP: YTD -37.0% 至 -48.4% (StatMuse)；当前价格取中值估算
- ARES: YTD -36% (BBAE, 2026/2月)
- LULU: 当前价格 ~$131.18；1月开盘 $215.88 (Forbes)；YTD约 -39.2%
- HOOD: YTD -30%至-40% (Yahoo Finance, Seeking Alpha, Barchart)

### 2.2 优先排序逻辑

**优先级排序依据:**

1. **短期亏损优先** — 短期亏损可先抵扣短期资本利得（税率35%），长期亏损抵扣长期资本利得（税率23.8%含NIIT）
2. **绝对金额最大** — FICO ($694,000) 为最大单项亏损，优先处理
3. **亏损比例最高** — TTD (-38.9%) 和 LULU (-39.2%) 亏损比例最深，短期内恢复可能性较低

**推荐收割顺序:**

| 优先级 | 证券 | 原因 |
|--------|------|------|
| P1 | FICO (短期) | 最大绝对亏损 $694,000，短期持有，税率最高 |
| P2 | TTD (短期) | 亏损比例 -38.9%，短期持有，广告行业前景不明 |
| P3 | NKE (短期) | 11年新低，中国销售恶化，短期持有 |
| P4 | LULU (短期) | 代理权之争 + 指引疲软，39.2%亏损 |
| P5 | HOOD (短期) | 加密收入暴跌47%，短期持有 |
| P6 | APP (长期) | 30.5%亏损但基本面仍强，可选择性收割 |
| P7 | CSGP (长期) | 房地产科技板块整体承压 |
| P8 | ARES (长期) | 另类资管行业周期性下行 |

---

## 三、Step 2 — 盈亏预算与税务估算 (Gain/Loss Budget)

### 3.1 当前年度已实现盈亏

| 类别 | 金额 ($) |
|------|----------|
| 已实现短期资本利得 (YTD) | +320,000 |
| 已实现长期资本利得 (YTD) | +185,000 |
| 已实现资本亏损 (YTD) | -45,000 |
| **净资本利得/(亏损) 位置** | **+460,000** |
| 前年度结转亏损 | $0 |
| **当前应税净资本利得** | **$460,000** |

### 3.2 目标收割金额计算

| 项目 | 金额 ($) |
|------|----------|
| 目标抵消短期资本利得 | -320,000 |
| 目标抵消长期资本利得 | -140,000 |
| 额外普通收入抵扣 (最高$3,000) | -3,000 |
| **目标收割总亏损** | **-$463,000** |

### 3.3 税务节省估算

基于2026年联邦税率（TCJA通过OBBBA延长后的税率结构）：

**适用税率:**
- 短期资本利得: 按普通收入税率 **35%**（联邦边际税率区间）
- 长期资本利得: **20%** + **3.8%** NIIT = **23.8%**
- 净亏损抵扣普通收入: 最高 **$3,000/年**，按35%税率 = **$1,050** 节省
- 剩余亏损无限期结转至未来年度

**数据来源:** Tax Foundation 2026 Tax Brackets; NerdWallet 2026 Capital Gains Rates;
Kiplinger IRS Updates; U.S. Bank Tax Laws 2026

**税收节省明细:**

| 收割项目 | 亏损金额 ($) | 税率 | 税收节省 ($) |
|----------|-------------|------|-------------|
| 短期亏损抵短期利得 | -320,000 | 35% | 112,000 |
| 长期亏损抵长期利得 | -140,000 | 23.8% | 33,320 |
| 净亏损抵普通收入 | -3,000 | 35% | 1,050 |
| **直接税收节省合计** | **-463,000** | | **$146,370** |
| 结转至未来年度亏损 | -1,187,570 | — | 未来年度收益 |

**注意:** 假设客户选择全额收割所有8个持仓（$1,650,570总亏损），超出目标部分的
$1,187,570将作为资本亏损结转至2027及以后年度，可无限期使用以抵扣未来资本利得。

**2026年联邦税率参考（TCJA/OBBBA延长后）:**

| 边际税率 | 应税收入（单身申报）| 应税收入（已婚联合申报）|
|----------|-------------------|---------------------|
| 10% | $0 - $11,925 | $0 - $23,850 |
| 12% | $11,926 - $48,475 | $23,851 - $96,950 |
| 22% | $48,476 - $103,350 | $96,951 - $206,700 |
| 24% | $103,351 - $197,300 | $206,701 - $394,600 |
| 32% | $197,301 - $250,525 | $394,601 - $501,050 |
| 35% | $250,526 - $626,350 | $501,051 - $751,600 |
| 37% | 超过 $626,350 | 超过 $751,600 |

**长期资本利得税率 (2026):**

| 税率 | 单身申报 | 已婚联合申报 |
|------|---------|-------------|
| 0% | $0 - $49,450 | $0 - $98,900 |
| 15% | $49,451 - $545,500 | $98,901 - $613,700 |
| 20% | 超过 $545,500 | 超过 $613,700 |
| +3.8% NIIT | MAGI > $200,000 | MAGI > $250,000 |

---

## 四、Step 3 — 替换证券建议 (Replacement Securities)

对每个收割候选持仓，建议以下替换证券以维持类似市场敞口，同时避免Wash Sale规则：

### 4.1 替换证券方案

| # | 卖出证券 | 替换证券 | 替换类型 | 跟踪误差风险 | 替换理由 |
|---|---------|---------|---------|-------------|---------|
| 1 | FICO (Fair Isaac) | EXPGY (Experian PLC ADR) | 个股→个股 | 中等 | 同为信用评分/数据分析行业，不同公司，非"实质上相同"；Experian在美国和国际信用数据市场有类似敞口 |
| 1-alt | FICO (Fair Isaac) | IGM (iShares U.S. Tech Growth ETF) | 个股→ETF | 中高 | 覆盖美国科技成长股，包含FICO同行业公司，指数不同 |
| 2 | APP (AppLovin) | BIDU / Snap Inc (SNAP) | 个股→个股 | 高 | 同为数字广告技术，但非"实质上相同" |
| 2-alt | APP (AppLovin) | XNTK (SPDR NYSE Technology ETF) | 个股→ETF | 中等 | 广泛科技ETF，覆盖广告技术关联公司 |
| 3 | NKE (Nike) | XLY (Consumer Disc. Select SPDR) | 个股→ETF | 中等 | 非必需消费品ETF，覆盖运动服饰等行业，指数不同，无Wash Sale风险 |
| 3-alt | NKE (Nike) | ONON (On Holding AG) | 个股→个股 | 高 | 同行业运动鞋服，但不同公司，不同市场定位 |
| 4 | TTD (The Trade Desk) | MGNI (Magnite Inc.) | 个股→个股 | 高 | 同为程序化广告技术，但不同公司，不同业务模式 |
| 4-alt | TTD (The Trade Desk) | GOOG (Alphabet) | 个股→个股 | 高 | 数字广告行业最大参与者，完全不同的公司 |
| 5 | CSGP (CoStar) | IYR (iShares U.S. Real Estate ETF) | 个股→ETF | 中高 | 房地产板块ETF，覆盖商业地产信息服务业 |
| 6 | ARES (Ares Management) | BX (Blackstone) | 个股→个股 | 中等 | 同为另类资产管理，但完全不同的公司结构和投资策略 |
| 6-alt | ARES (Ares Management) | PSP (Invesco Global Listed Private Equity) | 个股→ETF | 中等 | 覆盖上市另类资产管理公司 |
| 7 | LULU (Lululemon) | XLY (Consumer Disc. Select SPDR) | 个股→ETF | 中等 | 消费ETF覆盖运动服饰板块 |
| 7-alt | LULU (Lululemon) | DECK (Deckers Outdoor) | 个股→个股 | 高 | 同为高端运动/户外品牌，但不同公司 |
| 8 | HOOD (Robinhood) | SCHW (Charles Schwab) | 个股→个股 | 高 | 同为券商/金融服务，但完全不同的业务模式 |
| 8-alt | HOOD (Robinhood) | IAI (iShares U.S. Broker-Dealers ETF) | 个股→ETF | 中等 | 覆盖券商和金融服务公司 |

### 4.2 ETF替换核心原则

**Wash Sale安全配对 (经市场验证的常用替换对):**

| 卖出ETF | 可安全替换为 | 说明 |
|---------|-------------|------|
| SPY (SPDR S&P 500) | IVV (iShares Core S&P 500) 或 VOO (Vanguard S&P 500) | 相同指数、不同发行商；IRS从未明确认定为"实质上相同"，但存在灰色地带 |
| VOO (Vanguard S&P 500) | VTI (Vanguard Total Stock Market) | 不同指数（全市场 vs S&P 500），更安全 |
| VXUS (Vanguard Total Intl) | IXUS (iShares Core MSCI Total Intl) 或 ACWX (iShares MSCI ACWI ex-US) | 不同指数提供商，安全 |

**数据来源:** Investopedia — ETFs and Wash Sale Rule; Fidelity — Tax Rules for ETF Losses;
White Coat Investor — TLH Pairs and Partners; Wealthtender — ETF Wash Sale Loophole;
Intuit TurboTax Community; MYCPE — ETF Tax Strategy

---

## 五、Step 4 — Wash Sale 合规检查 (Wash Sale Compliance)

### 5.1 Wash Sale规则要点

- **30天回溯窗口**: 过去30天内是否在**任何账户**中购买了"实质上相同"的证券
- **30天前瞻窗口**: 卖出后30天内不得在**任何账户**中购买"实质上相同"的证券
- **全账户检查**: 包括应税账户、IRA、Roth IRA、配偶账户
- **DRIP风险**: 股息再投资计划可能在30天窗口内自动购买，触发Wash Sale
- **违规后果**: 亏损不予抵扣，且调整成本基础（亏损并未消失，但延迟至替换证券出售时确认）

### 5.2 全账户Wash Sale检查清单

| 卖出证券 | Wash Sale窗口起始 | Wash Sale窗口结束 | DRIP活跃? | IRA中有相同持仓? | 配偶账户有? | Wash Sale风险 |
|----------|-----------------|-----------------|-----------|-----------------|------------|--------------|
| FICO | 2026/4/10 | 2026/6/9 | 否 | 否 | 否 | **低** |
| APP | 2026/4/10 | 2026/6/9 | 否 | 否 | 否 | **低** |
| NKE | 2026/4/10 | 2026/6/9 | 是（季度股息） | 是 — IRA持有200股 | 否 | **中** |
| TTD | 2026/4/10 | 2026/6/9 | 否 | 否 | 否 | **低** |
| CSGP | 2026/4/10 | 2026/6/9 | 否 | 否 | 否 | **低** |
| ARES | 2026/4/10 | 2026/6/9 | 是（月度股息） | 否 | 否 | **中** |
| LULU | 2026/4/10 | 2026/6/9 | 否 | 否 | 否 | **低** |
| HOOD | 2026/4/10 | 2026/6/9 | 否 | 否 | 否 | **低** |

### 5.3 Wash Sale风险缓解措施

**NKE 特别注意:**
- IRA中持有200股NKE — 卖出应税账户中的NKE之前/之后30天内，**不得在IRA中追加购买NKE**
- NKE DRIP活跃 — 下一次股息支付日预计在2026年6月，需在卖出前暂停DRIP
- **建议操作:** 暂停NKE的DRIP设置 → 在应税账户卖出全部NKE → 等待31天后再恢复DRIP

**ARES 特别注意:**
- ARES按月分配股息 — 需检查下一次分配日期是否在Wash Sale窗口内
- **建议操作:** 在卖出前暂停ARES的自动再投资

**通用规则:**
- 所有账户（含IRA和配偶账户）在Wash Sale窗口内不得买入同一证券
- 窗口起止日: 卖出日前30天 至 卖出日后30天
- 文件记录: 每笔交易需记录Wash Sale窗口日期

---

## 六、Step 5 — 执行计划 (Execution Plan)

### 6.1 交易执行明细

| 交易# | 账户 | 操作 | 证券 | 股数 | 预计收入 ($) | 预计亏损 ($) | 替换证券 | 备注 |
|-------|------|------|------|------|-------------|-------------|---------|------|
| 1 | 应税 | 卖出 | FICO | 1,000 | 1,126,000 | -694,000 | EXPGY 或 IGM | 优先级P1 |
| 2 | 应税 | 买入 | IGM | — | 1,126,000 | — | — | 同日或T+1 |
| 3 | 应税 | 卖出 | TTD | 10,000 | 230,800 | -146,700 | MGNI 或 GOOG | 优先级P2 |
| 4 | 应税 | 买入 | GOOG | — | 230,800 | — | — | 同日或T+1 |
| 5 | 应税 | 卖出 | NKE | 10,000 | 441,400 | -198,600 | XLY 或 ONON | 优先级P3, 暂停DRIP先 |
| 6 | 应税 | 买入 | XLY | — | 441,400 | — | — | 同日或T+1 |
| 7 | 应税 | 卖出 | LULU | 1,000 | 131,180 | -84,620 | XLY 或 DECK | 优先级P4 |
| 8 | 应税 | 买入 | DECK | — | 131,180 | — | — | 同日或T+1 |
| 9 | 应税 | 卖出 | HOOD | 4,000 | 198,000 | -102,000 | SCHW 或 IAI | 优先级P5 |
| 10 | 应税 | 买入 | SCHW | — | 198,000 | — | — | 同日或T+1 |
| 11 | 应税 | 卖出 | APP | 1,000 | 468,550 | -205,450 | XNTK | 优先级P6 (可选) |
| 12 | 应税 | 买入 | XNTK | — | 468,550 | — | — | 同日或T+1 |
| 13 | 应税 | 卖出 | CSGP | 1,000 | 201,600 | -118,400 | IYR | 优先级P7 (可选) |
| 14 | 应税 | 买入 | IYR | — | 201,600 | — | — | 同日或T+1 |
| 15 | 应税 | 卖出 | ARES | 2,500 | 179,200 | -100,800 | BX 或 PSP | 优先级P8 (可选), 暂停DRIP先 |
| 16 | 应税 | 买入 | BX | — | 179,200 | — | — | 同日或T+1 |

### 6.2 执行摘要

| 指标 | 金额/说明 |
|------|----------|
| 总预计收割亏损 | **$1,650,570** |
| 直接税收节省 (2026年) | **$146,370** |
| 其中: 短期亏损抵扣节省 | $112,000 (亏损$320,000 x 35%) |
| 其中: 长期亏损抵扣节省 | $33,320 (亏损$140,000 x 23.8%) |
| 其中: 普通收入抵扣节省 | $1,050 ($3,000 x 35%) |
| 未来年度结转亏损 | $1,187,570 (可无限期结转) |
| 净组合影响 | 最小 (替换证券维持类似市场敞口) |
| Wash Sale窗口管理 | 2026/4/10 - 2026/6/9 (基于5月10日执行) |
| 总交易笔数 | 16笔 (8卖出 + 8买入) |

### 6.3 分批执行建议

考虑到市场流动性和执行风险，建议分两批执行：

**第一批 (2026年5月12日):** 高优先级短期亏损
- FICO → IGM ($1,126,000 收入)
- TTD → GOOG ($230,800 收入)
- NKE → XLY ($441,400 收入) — 确保已暂停DRIP
- HOOD → SCHW ($198,000 收入)

**第二批 (2026年5月13日):** 短期亏损 + 长期亏损
- LULU → DECK ($131,180 收入)
- APP → XNTK ($468,550 收入)
- CSGP → IYR ($201,600 收入) — 确保已暂停DRIP
- ARES → BX ($179,200 收入)

---

## 七、Step 6 — 收割后跟踪计划 (Post-Harvest Tracking)

### 7.1 Wash Sale窗口跟踪日历

| 证券已卖出 | Wash Sale窗口 | 可回买原证券日期 | 操作建议 |
|-----------|-------------|---------------|---------|
| FICO | 2026/4/12 - 2026/6/11 | 2026/6/12 | 评估是否需要换回 |
| TTD | 2026/4/12 - 2026/6/11 | 2026/6/12 | 评估是否需要换回 |
| NKE | 2026/4/12 - 2026/6/11 | 2026/6/12 | 恢复DRIP需在此日期之后 |
| HOOD | 2026/4/12 - 2026/6/11 | 2026/6/12 | 评估是否需要换回 |
| LULU | 2026/4/13 - 2026/6/12 | 2026/6/13 | 评估是否需要换回 |
| APP | 2026/4/13 - 2026/6/12 | 2026/6/13 | 评估是否需要换回 |
| CSGP | 2026/4/13 - 2026/6/12 | 2026/6/13 | 恢复DRIP需在此日期之后 |
| ARES | 2026/4/13 - 2026/6/12 | 2026/6/13 | 恢复DRIP需在此日期之后 |

### 7.2 30天后决策框架

| 决策选项 | 适用条件 | 优点 | 缺点 |
|---------|---------|------|------|
| **换回原证券** | 偏好原持仓、替换证券跟踪误差较大 | 恢复原始投资策略 | 可能再次产生交易成本 |
| **维持替换证券** | 替换证券表现良好、跟踪误差可接受 | 节省交易成本、新的成本基础较低 | 可能偏离原始投资理念 |
| **调整为新持仓** | 市场环境变化、投资理念更新 | 灵活应对市场变化 | 需要新的研究分析 |

### 7.3 成本基础更新记录

| 证券 | 原成本基础 | 卖出价格 | 新成本基础 (替换证券) | 成本基础变化 |
|------|----------|---------|---------------------|------------|
| FICO | $1,820/股 | $1,126/股 | IGM买入价 (待确认) | 成本基础重置 |
| APP | $674/股 | $468.55/股 | XNTK买入价 (待确认) | 成本基础重置 |
| NKE | $64/股 | $44.14/股 | XLY买入价 (待确认) | 成本基础重置 |
| TTD | $37.75/股 | $23.08/股 | GOOG买入价 (待确认) | 成本基础重置 |
| CSGP | $320/股 | $201.60/股 | IYR买入价 (待确认) | 成本基础重置 |
| ARES | $112/股 | $71.68/股 | BX买入价 (待确认) | 成本基础重置 |
| LULU | $215.80/股 | $131.18/股 | DECK买入价 (待确认) | 成本基础重置 |
| HOOD | $75/股 | $49.50/股 | SCHW买入价 (待确认) | 成本基础重置 |

---

## 八、重要注意事项与合规要求

### 8.1 Wash Sale规则严格性

- Wash Sale违规不仅会**丧失当期亏损抵扣**，还会**调整成本基础**
- 成本基础调整意味着亏损延迟到未来确认，而非永久丧失
- "实质上相同"指的是**同一证券**，而非同一资产类别
- 不同ETF发行商追踪不同指数通常不被认为是"实质上相同"（如SPY vs VOO存在灰色地带但实务中可行）

### 8.2 全账户协调

- **必须**检查家庭所有账户（应税、IRA、Roth IRA、配偶账户）
- **DRIP计划**是常见的Wash Sale触发源 — 卖出前务必暂停所有DRIP
- **401(k)账户**中如果有同一证券的买入操作也可能触发Wash Sale（存在争议，但保守起见应避免）

### 8.3 成本基础重置考量

- 收割会**重置成本基础**至更低水平，意味着未来出售替换证券时会产生更多应税利得
- 如果计划长期持有，需权衡当前税收节省与未来潜在税负
- 对于亏损比例极大（>30%）的持仓，当前税收利益通常超过未来成本基础重置的影响

### 8.4 交易成本

- 16笔交易的总交易佣金和买卖价差成本（假设为零佣金券商）估计约 $200-$500
- 对比 $146,370 的税收节省，交易成本可忽略不计

### 8.5 年末特别提醒

- **共同基金资本利得分配**通常在12月进行，可能创造额外的收割需求
- 年末是TLH的传统高峰期，但5月执行的优势在于：市场波动提供了更多机会，且替换证券有更长时间恢复
- 2026年12月需再次评估是否有新的亏损持仓需要收割

### 8.6 州税考虑

- 上述估算仅包含联邦税
- 若客户所在州征收州资本利得税（如加州最高13.3%、纽约州最高10.9%），实际税收节省将更高
- 建议结合客户具体居住州的税率进行精确计算

---

## 九、风险因素

| 风险类别 | 描述 | 缓解措施 |
|---------|------|---------|
| 市场反弹风险 | 卖出后市场大幅反弹，替换证券表现不一致 | 选择高度相关的替换证券 |
| 跟踪误差风险 | 替换证券与原证券表现差异 | 优先选择同行业ETF而非个股 |
| Wash Sale违规风险 | 30天窗口内意外买入相同证券 | 严格日历管理、暂停DRIP |
| 成本基础延迟风险 | 未来卖出替换证券时成本基础更低 | 评估长期持有计划 |
| 流动性风险 | 大额卖出可能影响市场价格 | 分批执行、使用限价单 |
| 税法变更风险 | 未来税率可能变化影响实际节省 | 按当前法律估算 |

---

## Sources

- [Yahoo Finance — FICO, APP, NKE, TTD, LULU, HOOD, FISV Historical Data and Quotes](https://finance.yahoo.com/)
- [Macrotrends — Stock Price History (FICO, APP, NKE, TTD, HOOD)](https://www.macrotrends.net/)
- [FinanceCharts — Worst Performing Stocks 2026; APP, LULU Performance](https://www.financecharts.com/)
- [StatMuse — APP YTD Return -32.69%; CSGP YTD Performance](https://www.statmuse.com/)
- [Slickcharts — S&P 500 YTD Returns; TTD Annual Returns](https://www.slickcharts.com/sp500/performance)
- [TIKR Blog — COIN YTD -12.7%; LULU Down 38%; Nike 11-Year Low](https://www.tikr.com/blog/)
- [Seeking Alpha — FICO Upgrade Analysis; HOOD Buy The Dip](https://seekingalpha.com/)
- [MarketBeat — FICO 52-Week Low; FISV Chart](https://www.marketbeat.com/)
- [Tax Foundation — 2026 Tax Brackets and Federal Income Tax Rates](https://taxfoundation.org/data/all/federal/2026-tax-brackets/)
- [NerdWallet — 2025 and 2026 Capital Gains Tax Rates](https://www.nerdwallet.com/taxes/learn/capital-gains-tax-rates)
- [Kiplinger — IRS Updates Capital Gains Tax Thresholds for 2026](https://www.kiplinger.com/taxes/irs-updates-capital-gains-tax-thresholds)
- [U.S. Bank — Tax Laws 2026: Tax Brackets and Deductions](https://www.usbank.com/wealth-management/financial-perspectives/financial-planning/tax-brackets.html)
- [Investopedia — ETFs and the Wash Sale Rule Loophole](https://www.investopedia.com/news/etf-open-secret-theyre-tax-loophole/)
- [Fidelity — Tax Rules for Losses on ETFs](https://www.fidelity.com/learning-center/investment-products/etf/tax-rules-for-losses-etfs)
- [White Coat Investor — Tax-Loss Harvesting Pairs and Partners](https://www.whitecoatinvestor.com/tax-loss-harvesting-pairs-partners/)
- [Charles Schwab — ETFs and Taxes: What You Need to Know](https://www.schwab.com/learn/story/etfs-and-taxes-what-you-need-to-know)
- [Sherwood News — S&P 500 Worst Quarter: Biggest Winners and Losers](https://sherwood.news/markets/s-p-500-worst-quarter-years-here-are-biggest-winners-losers/)
- [Business Insider — Nike Stock: Wall Street Turning on Nike as Sales Slow](https://www.businessinsider.com/nike-stock-price-market-forecast-sales-china-growth-slowdown-nke-2026-4)
- [Zacks — Can Nike Shares Ever Bounce Back](https://www.zacks.com/commentary/2895215/can-nike-shares-ever-bounce-back)
- [TickerNerd — TTD Forecast; LULU Forecast; FICO Forecast](https://tickernerd.com/)
- [CoinCodex — COIN Price Prediction; FICO Price Prediction](https://coincodex.com/)
- [BBAE — February 2026 Winners and Losers](https://www.bbae.com/blog/sp-500-the-winners-and-losers-of-february-2026/)
- [Intuit TurboTax — SPY vs VOO Wash Sale Discussion](https://ttlc.intuit.com/community/taxes/discussion/can-you-tax-loss-harvest-spy-with-voo-or-is-that-considered-a-wash-sale-under-the-irs/00/3414295)

---

*免责声明: 本报告仅供参考，不构成税务或投资建议。实际税务处理请咨询持牌税务专业人士。所有价格数据截至2026年5月8-10日，实际执行时可能有所变动。Wash Sale规则的适用存在灰色地带，建议与税务顾问确认具体操作方案。*
