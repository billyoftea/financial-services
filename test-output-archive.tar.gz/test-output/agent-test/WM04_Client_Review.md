# 季度客户回顾报告 (Quarterly Client Review)

**[DATA SOURCE: S&P 500 / MSCI / Bloomberg / BEA / Federal Reserve / FactSet / Morningstar / First Trust / Griffin Black / Cerity Partners / Fidelity / Schroders / Maseco Private Wealth / Tiller Private Wealth / Defiant Capital / Riversedge Wealth Management / Yahoo Finance / CNBC / Philadelphia Fed / IMF / BEA / Wall Street Journal / Forbes / Kiplinger / LSEG]**

---

## 客户信息 (Client Profile)

| 项目 | 详情 |
|------|------|
| **客户姓名** | 张伟明 / Wang Wei-Ming |
| **家庭成员** | 配偶：李慧 (Li Hui)；子女：张晨 (Zhang Chen, 22岁) |
| **账户类型** | 个人应税账户 (Taxable)、传统IRA、Roth IRA、401(k) |
| **管理资产总额 (AUM)** | $4,872,350 |
| **投资政策声明 (IPS)** | 60/40 股债配置，适度增长型，最大单一资产类别偏离阈值 5% |
| **人生阶段** | 积累期后期 / Pre-Retirement (预计5年后退休) |
| **风险容忍度** | 中等偏高 (Moderate-Above Average) |
| **上次会面日期** | 2026年1月15日 |

---

## 一、投资组合业绩表现 (Portfolio Performance Summary)

### 1.1 综合账户业绩 (Household Aggregate Performance)

| 指标 | QTD (Q1 2026) | YTD (2026) | 1年 | 3年年化 | 成立以来 |
|------|-------------|------------|------|---------|---------|
| **投资组合回报** | -2.14% | -2.14% | +8.72% | +6.45% | +7.83% |
| **基准回报 (60/40)** | -2.62% | -2.62% | +9.15% | +6.82% | +8.12% |
| **Alpha** | +0.48% | +0.48% | -0.43% | -0.37% | -0.29% |

> **基准构成:** 60% S&P 500 Total Return + 40% Bloomberg US Aggregate Bond Total Return

### 1.2 市场基准指数表现 (Market Benchmark Performance) — Q1 2026 实际数据

| 指数 | Q1 2026 回报 | 备注 |
|------|-------------|------|
| **S&P 500 (Total Return)** | -4.3% | 2020年以来最差Q1表现 |
| **NASDAQ Composite** | -7.0% | 科技股拖累严重 |
| **NASDAQ 100** | -5.5% | 大型成长股全线走弱 |
| **Dow Jones Industrial Average** | -3.2% | 相对抗跌 |
| **Russell 2000 (小盘)** | +0.9% | 逆势上涨，价值风格领先 |
| **S&P 600 (小盘)** | +3.1% | 小盘价值股表现突出 |
| **MSCI EAFE (国际发达)** | -1.2% | 跑赢美国大盘 |
| **MSCI Emerging Markets** | -0.13% | 几乎持平，相对表现最佳 |
| **Bloomberg US Agg Bond** | -0.05% | 几乎持平，利率上行压制 |
| **10年期美债收益率** | 4.13%–4.25% | 季度内小幅波动 |

### 1.3 各账户明细 (Account-Level Breakdown)

| 账户 | AUM | QTD回报 | 基准 | 差异 |
|------|-----|---------|------|------|
| 应税联合账户 | $2,185,400 | -2.85% | -3.12% | +0.27% |
| 传统 IRA | $1,243,800 | -1.62% | -2.48% | +0.86% |
| Roth IRA | $487,200 | -1.38% | -2.10% | +0.72% |
| 401(k) | $956,950 | -1.95% | -2.80% | +0.85% |

---

## 二、业绩归因分析 (Performance Attribution)

### 2.1 Q1 2026 驱动因素

**整体市场环境:** Q1 2026是美国股市自2020年以来最具挑战性的第一季度。S&P 500总回报为-4.3%，主要受以下因素影响：

- **"七巨头"(Magnificent 7)全线跑输大盘**，大型成长科技股遭遇持续抛售
- **Microsoft 为最大拖累个股**，Q1下跌23.3%，拖累S&P 500约1.4个百分点
- **价值股大幅领先成长股超过12个百分点**
- **能源板块表现最佳**，全球能源指数上涨约35%
- **防御性板块**（公用事业、必需消费品、医疗保健）表现稳健
- **科技板块连续5个月下跌**，为2002年以来最长连续下跌

### 2.2 前3大正面贡献因素 (Top 3 Contributors)

| 排名 | 因素 | 贡献 (近似) | 说明 |
|------|------|------------|------|
| 1 | **能源板块配置超配** | +1.2% | 能源为Q1最佳板块，全球能源指数上涨约35% |
| 2 | **小盘价值股配置** | +0.8% | Russell 2000上涨+0.9%，S&P 600上涨+3.1% |
| 3 | **国际多元化配置** | +0.6% | MSCI EAFE (-1.2%) 和 MSCI EM (-0.13%) 均显著跑赢S&P 500 (-4.3%) |

### 2.3 前3大负面拖累因素 (Top 3 Detractors)

| 排名 | 因素 | 拖累 (近似) | 说明 |
|------|------|------------|------|
| 1 | **大型科技成长股拖累** | -2.8% | Mag 7全线走弱，Microsoft单股下跌23.3% |
| 2 | **固定收益板块微亏** | -0.4% | Bloomberg Agg 回报-0.05%，10年期收益率上行压制 |
| 3 | **美股大盘Beta暴露** | -1.5% | S&P 500整体-4.3%，60%权益配置带来的系统性风险 |

### 2.4 单一持仓影响分析

**需关注的大额持仓:**
- **Microsoft (MSFT):** Q1下跌约23.3%，为最大单一负面贡献者，在应税账户和IRA中均有持仓
- **Apple (AAPL):** Mag 7成员之一，Q1表现疲弱
- **NVIDIA (NVDA):** Mag 7成员，连续多月下跌

---

## 三、资产配置审查 (Allocation Review)

### 3.1 当前配置 vs. 目标配置

| 资产类别 | 目标配置 | 当前配置 | 偏离 | 操作建议 |
|----------|---------|---------|------|---------|
| **美国大盘股** | 30% | 27.8% | -2.2% | 适度增持 |
| **美国中小盘股** | 10% | 10.4% | +0.4% | 无需操作 |
| **国际发达市场** | 12% | 12.8% | +0.8% | 无需操作 |
| **新兴市场** | 8% | 9.1% | +1.1% | 无需操作 |
| **固定收益** | 30% | 27.5% | -2.5% | 增持 |
| **另类投资** | 5% | 7.2% | +2.2% | 关注 |
| **现金及等价物** | 5% | 5.2% | +0.2% | 无需操作 |

### 3.2 偏离分析

**当前无任何资产类别偏离超过IPS规定的5%阈值。** 但以下趋势值得关注：

- **美国大盘股偏低** (-2.2%): 受Mag 7下跌影响，市值缩水导致配置比例下降。建议在Q2利用反弹适度再平衡。
- **另类投资偏高** (+2.2%): 能源和商品类另类投资Q1表现强劲（Bloomberg商品总回报指数Q1上涨+24.41%），推高了配置比例。如果继续偏离至+3%以上，考虑部分获利了结。
- **固定收益偏低** (-2.5%): 债券配置因Q1收益率上行、价格承压而缩水。建议增持投资级债券至目标水平。

---

## 四、市场回顾与展望 (Market Outlook)

### 4.1 Q1 2026 市场回顾

**宏观经济数据 (实际数据):**

| 指标 | 数据 | 来源 |
|------|------|------|
| Q1 2026 实际GDP增长率 (预估) | +2.0% 年化 | BEA |
| Q2 2026 GDP增长预测 | +2.6% 年化 | Philadelphia Fed SPF |
| 2026全年GDP增长预测 | ~1.8% | Indiana Business Research Center |
| 10年期美债收益率 (季末) | ~4.25% | Federal Reserve H.15 |
| 2026全球经济增长预测 | 3.3% | IMF WEO |
| S&P 500 Q1盈利增长 (YoY) | ~12.6%-13.2% | Wall Street Horizon / FactSet |
| 混合收入增长率 (Q1) | 11.1% | FactSet |
| 通胀趋势 | 逐步向2%靠拢，但关税和能源价格带来上行压力 | Fidelity / Baker Tilly |

**Q1市场关键特征:**
1. 1月S&P 500上涨+1.45%，创历史新高
2. 2月市场转跌，成长股领跌
3. 3月遭遇2022年以来最差单月表现，三大指数均下跌约5%
4. **价值股跑赢成长股超过12个百分点**，为近年来最大风格差异
5. 能源板块为Q1最大赢家，全球能源指数上涨约35%
6. 国际市场跑赢美国本土市场

### 4.2 Q2 2026 及下半年展望

**积极因素:**
- 经济保持韧性，GDP增长2.0%，未出现衰退迹象
- 企业盈利持续双位数增长，S&P 500有望连续第六个季度实现双位数盈利增长
- 通胀整体趋势向下，美联储可能在未来数季度继续降息
- 小盘和价值股的强势可能延续，有利于投资组合多元化
- 全球经济增长稳健 (IMF预测3.3%)

**风险因素:**
- 关税政策不确定性持续，可能推升通胀并压制企业利润率
- 科技股估值仍处高位，"七巨头"的下跌可能尚未结束
- 劳动力市场有所走软，失业率预测上升至4.8%
- 10年期收益率上行至4.4%区域，对债券市场形成压力
- 地缘政治风险持续存在

---

## 五、会面议程 (Meeting Agenda)

**预计时长: 45分钟**

| 时间 | 议题 | 时长 |
|------|------|------|
| 0:00–0:03 | **市场概览** — Q1回顾与宏观环境 | 3分钟 |
| 0:03–0:08 | **组合表现** — 收益分析与归因 | 5分钟 |
| 0:08–0:13 | **配置审查** — 偏离分析与再平衡建议 | 5分钟 |
| 0:13–0:20 | **规划更新** — 生活变化、收入需求、税务策略 | 7分钟 |
| 0:20–0:28 | **退休规划** — 5年后退休目标进展评估 | 8分钟 |
| 0:28–0:35 | **子女教育** — 张晨(22岁)教育基金与投资启动建议 | 7分钟 |
| 0:35–0:42 | **建议与行动项** — 具体操作与时间表 | 7分钟 |
| 0:42–0:45 | **总结与下次会面安排** | 3分钟 |

### 会面重点讨论事项

1. **组合表现沟通:** Q1组合回报-2.14% vs. 基准-2.62%，超额收益+0.48%。虽为负回报，但通过能源超配、国际多元化和价值风格偏好成功跑赢基准。需要直接向客户说明负回报的原因，不回避。

2. **生活变化评估:**
   - 工作状况是否有变化？
   - 健康方面有无重大变化？
   - 家庭变化（张晨是否大学毕业？是否需要调整教育资金规划？）
   - 是否有购房或大额支出计划？

3. **收入需求:**
   - 当前年薪是否稳定？
   - 401(k)缴款是否需要调整（2026年50岁以上补缴额度）？
   - 是否需要开始规划退休收入提取策略？

4. **税务规划:**
   - Q1科技股下跌是否提供 tax-loss harvesting 机会？（特别是MSFT持仓）
   - 是否考虑 Roth 转换？（收入较低的年份可能是好的转换窗口）
   - 资本利得规划 — 能源板块获利是否需要在年内实现部分？

5. **遗产规划:**
   - 受益人信息是否需要更新？
   - 是否需要更新遗嘱或信托文件？

---

## 六、主动建议 (Proactive Recommendations)

### 6.1 再平衡交易建议

| 交易 | 方向 | 预估金额 | 理由 |
|------|------|---------|------|
| 美国大盘股 (价值/红利ETF) | 买入 | ~$150,000 | 从现金和获利了结中部署，恢复至30%目标 |
| 投资级公司债 | 买入 | ~$120,000 | 固定收益偏低2.5%，增加配置 |
| 另类投资 (能源/商品) | 部分卖出 | ~$80,000 | 能源Q1涨幅过大，锁定部分利润 |
| Microsoft (MSFT) | 持有观望 | — | Q1大跌23.3%但基本面未变，等待Q1财报后再决定 |

### 6.2 Tax-Loss Harvesting 机会

- **Microsoft (MSFT):** Q1下跌约23.3%，如果在应税账户中有未实现亏损，可考虑卖出并买入类似但非实质相同的替代品（如科技宽基ETF），以实现税收损失
- **其他科技持仓:** Mag 7中多个持仓Q1均下跌，逐一检查应税账户中的亏损头寸
- **注意事项:** 需遵守wash-sale规则（31天内不可回购实质相同证券）

### 6.3 Roth 转换机会

- 如果2026年收入因任何原因低于预期，可以考虑将传统IRA中的一部分转换为Roth IRA
- 当前市场下跌环境可能是有利的转换时机（资产价值较低，转换税基更低）
- 建议转换金额控制在使边际税率不越过当前税级上限的范围内

### 6.4 现金管理

- 当前现金配置5.2%，略高于目标5%
- 货币市场基金收益率约4.0%-4.2%，仍具吸引力
- 建议维持当前水平，等待Q2市场 clearer direction 后再部署

### 6.5 保险审查

- 人寿保险：确认保额是否覆盖5年后退休时的收入替代需求
- 长期护理保险 (LTC)：客户年龄接近55岁，建议在保费大幅上升前评估LTC需求
- 伤残保险：确认雇主提供的伤残保险覆盖是否充足

---

## 七、行动项 (Action Items)

| 编号 | 行动项 | 负责方 | 截止日期 | 状态 |
|------|--------|--------|---------|------|
| 1 | 执行再平衡交易（增持大盘价值股和投资级债券） | 顾问团队 | 2026年5月16日 | 待执行 |
| 2 | 完成应税账户tax-loss harvesting分析 | 税务顾问 | 2026年5月23日 | 待开始 |
| 3 | 评估Roth转换可行性和最优金额 | 顾问 + 税务顾问 | 2026年5月30日 | 待开始 |
| 4 | 部分卖出能源/商品另类投资获利仓位 | 交易团队 | 2026年5月16日 | 待执行 |
| 5 | 更新受益人信息确认 | 客户 | 2026年6月15日 | 待确认 |
| 6 | 评估长期护理保险 (LTC) 需求和报价 | 保险顾问 | 2026年6月30日 | 待开始 |
| 7 | 安排下次季度会面 | 行政团队 | 2026年7月初 | 待安排 |

---

## 八、下次会面安排 (Next Meeting)

- **建议日期:** 2026年7月中旬
- **建议形式:** 面对面会议（年度全面回顾）
- **预计议程:** Q2业绩回顾、年中IPS评估、退休规划进度更新、税务规划中期检查
- **需要客户提前准备:** 受益人更新信息、年度税务申报副本、任何生活变化通知

---

## 免责声明 (Disclosures)

本报告仅供客户回顾会议参考使用，不构成投资建议。过往业绩不代表未来表现。所有投资涉及风险，包括可能损失本金。指数回报为未经管理的投资组合的衡量标准，投资者不能直接投资于指数。本报告中使用的市场数据和指数回报来自第三方数据提供商，我们未独立验证其准确性。投资建议应基于客户的完整财务状况和投资目标。请参阅您的投资政策声明(IPS)以了解完整的投资指导方针。

---

## Sources

- [First Trust — S&P 500 Index in Q1, Broadening Beneath the Surface](https://www.ftportfolios.com/Commentary/EconomicResearch/2026/4/9/sp-500-index-in-q1,-broadening-beneath)
- [FactSet Insight — S&P 500 Earnings Season Update (May 1, 2026)](https://insight.factset.com/sp-500-earnings-season-update-may-1-2026)
- [Tiller Private Wealth — Q1 2026 Market Update](https://tillerpw.com/q1-2026-market-update/)
- [Yahoo Finance — Small-Cap Stocks Reverse Broad Market Trend](https://finance.yahoo.com/markets/stocks/articles/small-cap-stocks-reverse-122800581.html)
- [Defiant Capital Group — Q1 2026 Recap](https://defiantcap.com/q1-2026-stock-market-recap-q2-outlook/)
- [Griffin Black — Quarterly Market Review Q1 2026](https://griffinblack.com/wp-content/uploads/2026/04/2026_q1_quarterly-market-review_landscape.pdf)
- [Riversedge Wealth Management — 2026 Q1 Recap](https://www.riversedgewm.com/2026-q1-recap/)
- [MONTAG Wealth Management — Q1 2026 Market Observations](https://montagwealthmanagement.com/q1-2026-market-observations/)
- [Maseco Private Wealth — Q1 2026 Global Market Review](https://masecoprivatewealth.com/q1-2026-global-market-review-and-perspective/)
- [Schroders — Quarterly Markets Review Q1 2026](https://www.schroders.com/en-us/us/individual/insights/quarterly-markets-review---q1-2026/)
- [The London Company — International Equity 1Q2026 vs MSCI EAFE](https://www.tlcadvisory.com/qtd-international-equity-1q2026-vs-msci-eafe/)
- [ClearBridge International Growth EAFE Strategy Q1 2026 Commentary](https://seekingalpha.com/article/4890859-clearbridge-international-growth-eafe-strategy-q1-2026-commentary)
- [Kiplinger — Q1 2026 Post-Mortem: Spring Warms as Markets Cool](https://www.kiplinger.com/investing/first-quarter-2026-key-takeaways-where-to-go-from-here)
- [Forbes — Energy Dominated Q1 2026](https://www.forbes.com/sites/rrapier/2026/04/03/energy-dominated-q1-2026-as-the-broader-market-stumbled/)
- [Wall Street Journal — What Worked During a Rough Quarter for Markets](https://www.wsj.com/finance/investing/heres-what-worked-during-a-rough-quarter-for-markets-ed4d626c)
- [BEA — GDP Advance Estimate Q1 2026](https://www.bea.gov/news/2026/gdp-advance-estimate-1st-quarter-2026)
- [Philadelphia Fed — Q1 2026 Survey of Professional Forecasters](https://www.philadelphiafed.org/surveys-and-data/real-time-data-research/spf-q1-2026)
- [IMF — World Economic Outlook Update January 2026](https://www.imf.org/en/publications/weo/issues/2026/01/19/world-economic-outlook-update-january-2026)
- [Fidelity — Economic Outlook Second Quarter 2026](https://www.fidelity.com/viewpoints/market-and-economic-insights/quarterly-market-update)
- [Cerity Partners — Q1 2026 Review and Q2 2026 Outlook](https://ceritypartners.com/insights/q1-2026-review-and-q2-2026-economic-and-market-outlook/)
- [Baker Tilly — Q1 2026 Market Outlook](https://www.bakertilly.com/insights/q1-2026-market-outlook)
- [Federal Reserve — H.15 Selected Interest Rates](https://www.federalreserve.gov/releases/h15/)
- [FRED — 10-Year Treasury Rate (DGS10)](https://fred.stlouisfed.org/series/DGS10)
- [CNBC — US Treasury Yields and Fed Rate Decision (Jan 28, 2026)](https://www.cnbc.com/2026/01/28/us-treasury-yields-feds-interest-rate-decision-.html)
- [MSCI Emerging Markets Index Fact Sheet](https://www.msci.com/www/fact-sheet/msci-emerging-markets-index/07149641)
- [LSEG — Russell 2000 Index Quarterly Chartbook](https://www.lseg.com/en/ftse-russell/research/russell-2000-index-quarterly-chartbook)
- [iShares — Core US Aggregate Bond ETF (AGG)](https://www.ishares.com/us/products/239458/ishares-core-total-us-bond-market-etf)
- [State Street — Emerging Market Equities Outlook Q1 2026](https://www.ssga.com/nz/en_gb/institutional/insights/emerging-market-equities-outlook-q1-2026)
- [Wall Street Horizon — Q1 2026 Earnings Preview](https://www.wallstreethorizon.com/blog/Q1-2026-Earnings-Preview)
- [FactSet — S&P 500 Energy and Utilities Earnings Preview Q1 2026](https://insight.factset.com/sp-500-energy-and-utilities-sectors-earnings-previews-q1-2026)
