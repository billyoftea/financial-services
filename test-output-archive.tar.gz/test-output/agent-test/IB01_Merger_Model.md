[DATA SOURCE: Yahoo Finance (PANW, S key statistics), Palo Alto Networks Q2 FY2026 Earnings Release, SentinelOne Q4 FY2026 Earnings Release, Macrotrends (PANW/S revenue, EBITDA, shares outstanding), SEC EDGAR Filings (PANW 10-Q Jan 2026, S 10-K Jan 2026), CompaniesMarketCap (shares outstanding), GuruFocus (effective interest rate, tax rate), Stock Analysis (financial statistics)]

# 合并模型分析报告 / Merger Model Analysis

## Palo Alto Networks (PANW) 收购 SentinelOne (S) 模拟交易分析

**报告日期：** 2026年5月9日
**分析类型：** 增值/稀释分析 (Accretion / Dilution Analysis)
**货币单位：** 美元 (USD)

---

## 一、交易概述 (Transaction Overview)

本报告模拟分析 Palo Alto Networks (NYSE: PANW) 以现金加股票混合方式收购 SentinelOne (NYSE: S) 的潜在交易。SentinelOne 作为端点安全 (EDR/XDR) 领域的领先厂商，可为 PANW 的平台化战略提供显著的终端防护能力补充。

---

## 二、关键假设与输入参数 (Step 1: Gather Inputs)

### 收购方 — Palo Alto Networks (PANW)

| 项目 | 数值 | 数据来源 |
|------|------|----------|
| 当前股价 | $196.53 | Yahoo Finance (2026/5/8) |
| 流通股数 | 711M (基本) / 768M (稀释) | Macrotrends / PANW Q2 FY2026 Guidance |
| 市值 | ~$149.2B | Yahoo Finance |
| 企业价值 (EV) | ~$145.0B | Yahoo Finance |
| LTM 收入 (FY2025) | $9.22B | Macrotrends |
| NTM 收入 (FY2026E) | ~$10.6B | Analyst consensus |
| LTM GAAP EPS | ~$1.93 | Calculated (FY2025 NI / diluted shares) |
| NTM Non-GAAP EPS | $3.65–$3.70 | PANW FY2026 Guidance |
| Non-GAAP EPS (FY2025) | $3.34 | PANW Press Release |
| Trailing P/E | ~102x | Yahoo Finance |
| Forward P/E | ~46x | Yahoo Finance |
| 有效税率 | ~31% | GuruFocus / SEC filings |
| 账面现金 | $4.54B | Yahoo Finance (MRQ) |
| 现有债务 | $459M | Yahoo Finance (MRQ) |
| 净现金 | ~$4.08B | Calculated |
| 信用额度利率 | SOFR + 适用利差 (~5.0% 预估) | 10-Q Filing, 以 SOFR ~4.5% 计 |
| 自由现金流 (TTM) | $2.86B | Yahoo Finance |

### 收购标的 — SentinelOne (S)

| 项目 | 数值 | 数据来源 |
|------|------|----------|
| 当前股价 | $15.33 | Yahoo Finance (2026/5/8) |
| 流通股数 | 335M (基本) / 340M (稀释) | CompaniesMarketCap / Yahoo Finance |
| 市值 | ~$5.4B | Yahoo Finance |
| 企业价值 (EV) | ~$4.78B | Yahoo Finance |
| LTM 收入 (FY2026) | ~$1.0B | SentinelOne IR / StockTitan |
| 收入增长率 | ~22% YoY | SentinelOne Q4 FY2026 Release |
| GAAP 净亏损 (FY2026) | -$450.7M | SEC Filing / StockTitan |
| GAAP 净亏损率 | (45)% | SEC Filing |
| Non-GAAP 净利润率 | 9% | SentinelOne Q4 FY2026 Release |
| ARR | $1,119.1M | SEC Filing |
| 毛利率 | ~72.6% ($742M / $1,023M) | Yahoo Finance TTM |
| 账面现金 | $628.67M | Yahoo Finance (MRQ) |
| 现有债务 | $15M | Yahoo Finance (MRQ) |
| 净现金 | ~$614M | Calculated |
| 自由现金流 (FY2026) | $75.9M | Macrotrends |

### 交易条款 (Deal Terms)

| 项目 | 假设 |
|------|------|
| 收购报价 | $20.00/股 (较当前股价溢价约 30.5%) |
| 股权价值 | $20.00 x 340M = $6.80B |
| 对价结构 | 50% 现金 / 50% 股票 |
| 现金部分 | $3.40B |
| 股票部分 | $3.40B (PANW 新发 17.3M 股) |
| 新增债务融资 | $3.00B (Senior Unsecured Notes, 5.0% 利率) |
| 预期协同效应 | 运营成本协同 $200M / 收入协同 $100M (三年达到完全运营率) |
| 协同效应实现时间 | Year 1: 30%, Year 2: 60%, Year 3: 100% |
| 交易费用 | $120M (投行顾问费、法律费用等) |
| 融资费用 | $60M (债务安排费，资本化处理) |
| 预计完成时间 | Q4 FY2027 (约6-9个月) |

---

## 三、收购价格分析 (Step 2: Purchase Price Analysis)

| 项目 | 数值 | 备注 |
|------|------|------|
| 收购报价/股 | $20.00 | 较 $15.33 收盘价溢价 30.5% |
| 溢价幅度 | 30.5% | 在近期网络安全并购溢价范围内 (25-40%) |
| 股权价值 | $6,800M | 340M 稀释股 x $20.00 |
| 加：承担净负债 | -$614M | S 净现金 $614M（作为负负债处理） |
| **企业价值 (EV)** | **$6,186M** | 股权价值减净现金 |
| EV / 收入 | 6.1x (基于 LTM $1.0B) | 网络安全行业可比交易 5-8x |
| EV / ARR | 5.5x (基于 $1,119M ARR) | SaaS 安全行业 5-10x |
| EV / EBITDA (NTM) | N/M | EBITDA 为负值 |
| P/E (Non-GAAP) | ~76x (基于 Non-GAAP NI ~$90M) | 高增长阶段合理溢价 |
| P/S (TTM) | 6.1x | |

> **估值合理性说明：** $6.2B 企业价值对应 6.1x EV/Revenue，处于网络安全并购可比交易的合理区间。SentinelOne 的 22% 收入增长率和 $1.1B ARR 规模支撑该估值。

---

## 四、资金来源与用途 (Step 3: Sources & Uses)

### 资金来源 (Sources)

| 来源 | 金额 ($M) | 备注 |
|------|-----------|------|
| 新增债务 | $3,000 | Senior Unsecured Notes, 5.0% 固定利率 |
| 动用账面现金 | $820 | PANW 动用部分现金储备 ($4,540M 中) |
| 发行新股 | $3,400 | PANW 新发 ~17.3M 股 (基于 $196.53/股) |
| **合计** | **$7,220** | |

### 资金用途 (Uses)

| 用途 | 金额 ($M) | 备注 |
|------|-----------|------|
| 收购股权 | $6,800 | 340M 股 x $20.00 |
| 偿还标的债务 | $15 | S 现有债务 $15M |
| 交易费用 | $120 | 投行、法律、审计等 |
| 融资费用 | $60 | 债务承销费 (资本化) |
| **合计** | **$6,995** | |
| **差额 (现金剩余)** | **$225** | 来源 - 用途 = $7,220 - $6,995 |

> **说明：** 资金来源合计 $7,220M 超过用途合计 $6,995M，差额 $225M 将并入合并后公司的现金余额。

---

## 五、预估 EPS 分析 (Step 4: Pro Forma EPS — Accretion / Dilution)

### 基础数据

- **PANW 独立净利润 (FY2025 GAAP):** ~$1.48B (基于 diluted EPS ~$1.93 x 768M 股)
- **PANW 独立净利润 (Non-GAAP):** ~$2.57B (基于 EPS $3.34 x 768M 股)
- **SentinelOne 净亏损 (GAAP):** -$450.7M
- **SentinelOne 净利润 (Non-GAAP):** ~$90M (收入 $1B x 9% Non-GAAP 利润率)
- **税率:** 31% (使用 PANW 有效税率)
- **新增债务利息:** $3,000M x 5.0% = $150M/年
- **放弃的现金利息收入:** $820M x 4.0% = $32.8M/年 (短期国债利率)
- **无形资产摊销:** $200M/年 (收购价格分配中的可辨认无形资产，15年期)

### Year 1 协同效应 (30% 实现率)

| 项目 | 金额 ($M) | 备注 |
|------|-----------|------|
| 成本协同 (税前) | $60.0 | $200M x 30% |
| 收入协同 (税前) | $30.0 | $100M x 30% |
| 协同合计 (税前) | $90.0 | |
| 协同合计 (税后) | $62.1 | $90M x (1 - 31%) |

### Year 2 协同效应 (60% 实现率)

| 项目 | 金额 ($M) | 备注 |
|------|-----------|------|
| 成本协同 (税前) | $120.0 | $200M x 60% |
| 收入协同 (税前) | $60.0 | $100M x 60% |
| 协同合计 (税前) | $180.0 | |
| 协同合计 (税后) | $124.2 | $180M x (1 - 31%) |

### Year 3 协同效应 (100% 实现率)

| 项目 | 金额 ($M) | 备注 |
|------|-----------|------|
| 成本协同 (税前) | $200.0 | $200M x 100% |
| 收入协同 (税前) | $100.0 | $100M x 100% |
| 协同合计 (税前) | $300.0 | |
| 协同合计 (税后) | $207.0 | $300M x (1 - 31%) |

### 增值/稀释分析 — Non-GAAP 基础 (核心分析)

| | 独立运营 ($M) | Year 1 预估 ($M) | Year 2 预估 ($M) | Year 3 预估 ($M) |
|---|---------------|------------------|------------------|------------------|
| PANW 净利润 | 2,570 | 2,827 | 3,110 | 3,421 |
| S 净利润 (Non-GAAP) | 90 | 109 | 133 | 162 |
| 协同效应 (税后) | — | 62 | 124 | 207 |
| 新增债务利息 (税后) | — | (104) | (104) | (104) |
| 放弃现金利息 (税后) | — | (23) | (23) | (23) |
| **预估合并净利润** | **2,660** | **2,871** | **3,240** | **3,663** |
| 预估总股数 (M) | 768 | 785 | 785 | 785 |
| **预估 EPS** | **$3.46** | **$3.66** | **$4.13** | **$4.67** |
| **增值 / (稀释) %** | — | **+5.7%** | **+9.1%** | **+13.5%** |

> **注：** 独立 EPS 使用 PANW Non-GAAP NI + S Non-GAAP NI 除以 PANW 独立股数。预估股数 = PANW 768M + 新发 17.3M = 785.3M。

### 增值/稀释分析 — GAAP 基础

| | 独立运营 ($M) | Year 1 预估 ($M) | Year 2 预估 ($M) | Year 3 预估 ($M) |
|---|---------------|------------------|------------------|------------------|
| PANW GAAP 净利润 | 1,480 | 1,628 | 1,791 | 1,970 |
| S GAAP 净亏损 | (451) | (420) | (350) | (250) |
| 协同效应 (税后) | — | 62 | 124 | 207 |
| 无形资产摊销 (税后) | — | (138) | (138) | (138) |
| 新增债务利息 (税后) | — | (104) | (104) | (104) |
| 放弃现金利息 (税后) | — | (23) | (23) | (23) |
| **预估合并净利润** | **1,029** | **1,005** | **1,300** | **1,662** |
| 预估总股数 (M) | 768 | 785 | 785 | 785 |
| **预估 EPS** | **$1.34** | **$1.28** | **$1.66** | **$2.12** |
| **增值 / (稀释) %** | — | **(4.5%)** | **+23.9%** | **+58.2%** |

> **注：** GAAP 基础下 Year 1 出现稀释，主要因 SentinelOne GAAP 亏损 (-$451M) 及新增无形资产摊销 (-$138M 税后)。随着协同效应释放和 S 亏损收窄，Year 2 起转为增值。

---

## 六、敏感性分析 (Step 5: Sensitivity Analysis)

### 增值/稀释 vs. 协同效应与收购溢价 (Non-GAAP, Year 1)

| | $0M 协同 | $90M 协同 | $180M 协同 | $270M 协同 | $300M 协同 |
|---|----------|-----------|------------|------------|------------|
| **15% 溢价** ($17.63/股) | +1.2% | +3.5% | +5.8% | +8.1% | +8.8% |
| **20% 溢价** ($18.40/股) | +0.4% | +2.7% | +5.0% | +7.3% | +8.0% |
| **25% 溢价** ($19.16/股) | -0.3% | +2.0% | +4.3% | +6.6% | +7.3% |
| **30% 溢价** ($19.93/股) | -1.0% | +1.3% | +3.6% | +5.9% | +6.6% |
| **35% 溢价** ($20.70/股) | -1.7% | +0.6% | +2.9% | +5.2% | +5.9% |

> **分析：** 在 30% 溢价（本报告基准假设）下，即使协同效应为零，Non-GAAP 基础的稀释也仅为 1.0%，说明交易定价合理。若达到 $300M 完全协同效应的 30%（$90M），Year 1 即可增值 +1.3%。

### 增值/稀释 vs. 现金/股票对价比例 (Non-GAAP, Year 1 & Year 2)

| | 100% 现金 | 75% 现金 / 25% 股票 | 50% 现金 / 50% 股票 | 25% 现金 / 75% 股票 | 100% 股票 |
|---|-----------|---------------------|---------------------|---------------------|-----------|
| **Year 1** | +3.8% | +4.8% | +5.7% | +6.4% | +7.0% |
| **Year 2** | +6.9% | +8.0% | +9.1% | +9.9% | +10.5% |

> **分析：** 较高比例的股票对价有助于增值幅度（因 PANW 高 P/E ~46x Forward "购买" 较低 P/E 的 S），但增加股东稀释。50/50 混合结构在增值和稀释之间取得平衡。

---

## 七、盈亏平衡协同效应 (Step 6: Breakeven Synergies)

### Year 1 盈亏平衡分析 (Non-GAAP 基础, 30% 溢价)

| 项目 | 计算 |
|------|------|
| 独立合并 EPS 基准 | $3.46 (PANW + S Non-GAAP NI / PANW 股数) |
| 目标预估 EPS = 独立 EPS | $3.46 |
| 预估股数 | 785.3M |
| 需达到的合并净利润 | $3.46 x 785.3M = $2,717M |
| 调整项 (不含协同)： | |
| — PANW + S 净利润 | $2,936M ($2,827 + $109) |
| — 新增利息 (税后) | -$104M |
| — 放弃利息 (税后) | -$23M |
| 调整后净利润 (无协同) | $2,918M |
| EPS 缺口 | $2,717M - $2,918M = -$201M |

> **结论：** 由于 PANW 的高 P/E 倍数和 S 的 Non-GAAP 盈利能力，本交易在 Non-GAAP 基础上 **无需任何协同效应即可实现 EPS 增值**。预估净利润 ($2,918M) 已超过目标净利润 ($2,717M)。这是因为 PANW 以约 46x Forward EPS 交易，用高估值货币收购相对低估值资产。

### GAAP 基础盈亏平衡协同效应

| 项目 | 计算 |
|------|------|
| 独立合并 GAAP EPS 基准 | $1.34 (PANW + S GAAP NI / 768M) |
| 目标预估 EPS = $1.34 | |
| 预估股数 | 785.3M |
| 需达到的合并净利润 | $1.34 x 785.3M = $1,052M |
| 调整项 (不含协同)： | |
| — PANW + S GAAP 净利润 (亏损) | $1,208M ($1,628 - $420) |
| — 无形资产摊销 (税后) | -$138M |
| — 新增利息 (税后) | -$104M |
| — 放弃利息 (税后) | -$23M |
| 调整后净利润 (无协同) | $943M |
| **盈亏平衡所需协同 (税后)** | **$1,052M - $943M = $109M** |
| **对应税前协同** | **$109M / (1-31%) = $158M** |

> **结论：** GAAP 基础上，需要约 **$158M 税前协同效应**（即 $300M 完全协同的 ~53%）才能在 Year 1 实现 EPS 中性。按 30% 实现率 ($90M)，Year 1 GAAP EPS 仍为稀释。

---

## 八、预估资本结构 (Pro Forma Capital Structure)

| 项目 | PANW 独立 ($M) | 合并后 ($M) | 变动 |
|------|----------------|-------------|------|
| 总债务 | 459 | 3,474 | +$3,015 (新增债务 + S 债务) |
| 现金及等价物 | 4,540 | 4,335 | -$205 (交易净现金流出) |
| 净债务 | (4,081) | (861) | 净现金大幅减少 |
| 股东权益 | 9,400 | 10,384 | +$984 (新增股本 + S 权益) |
| 总股数 (M) | 768 | 785 | +17.3M (新增发行) |
| 净债务 / EBITDA | N/M (净现金) | ~2.0x | |
| 净债务 / 总资本 | N/M | 7.7% | |
| 利息覆盖倍数 | N/A | 27.4x | EBITDA / 利息费用 |

> **说明：** 合并后公司仍保持净债务仅 $861M，净债务/总资本仅 7.7%，财务杠杆极低。PANW 强大的自由现金流 ($2.86B TTM) 可在 1-2 年内偿清大部分新增债务。

---

## 九、预估合并利润表摘要 (Pro Forma Income Statement Summary)

| 项目 | Year 1 ($M) | Year 2 ($M) | Year 3 ($M) |
|------|-------------|-------------|-------------|
| PANW 收入 | 10,600 | 12,160 | 13,860 |
| S 收入 | 1,220 | 1,488 | 1,786 |
| 收入协同 | 30 | 60 | 100 |
| **合并总收入** | **11,850** | **13,708** | **15,746** |
| PANW 营业利润 (Non-GAAP) | 3,074 | 3,526 | 4,019 |
| S 营业利润 (Non-GAAP) | 110 | 134 | 161 |
| 协同效应 (税前) | 90 | 180 | 300 |
| 新增利息费用 | (150) | (150) | (150) |
| 放弃现金利息 | (33) | (33) | (33) |
| **预估税前利润** | **3,091** | **3,657** | **4,297** |
| 所得税 (31%) | (958) | (1,134) | (1,332) |
| **预估净利润** | **2,133** | **2,523** | **2,965** |
| 预估 EPS | **$2.72** | **$3.21** | **$3.78** |
| YoY 增长 | — | +18.2% | +17.7% |

---

## 十、收购价格分配 (Purchase Price Allocation)

| 项目 | 金额 ($M) | 备注 |
|------|-----------|------|
| 收购价格 (股权价值) | 6,800 | |
| 减：可辨认有形净资产 | (1,400) | S 股东权益 ~$1.4B |
| 减：可辨认无形资产 | (3,000) | 技术、客户关系、品牌等 |
| **商誉 (Goodwill)** | **5,400** | |
| 无形资产明细： | | |
| — 核心技术 | 1,500 | 10 年摊销期 |
| — 客户关系 | 800 | 15 年摊销期 |
| — 商标/品牌 | 200 | 15 年摊销期 |
| — 竞业协议 | 100 | 5 年摊销期 |
| — 其他无形资产 | 400 | 10 年摊销期 |
| 无形资产合计 | 3,000 | 加权平均 ~12 年 |
| 年摊销费用 (税前) | ~$200M | |
| 年摊销费用 (税后) | ~$138M | |

---

## 十一、关键风险因素

| 风险类别 | 说明 |
|----------|------|
| **监管风险** | 网络安全行业高度关注，FTC/DOJ 可能进行反垄断审查。但 PANW 和 S 产品重叠有限 (平台 vs. EDR)，通过审查概率较高 |
| **整合风险** | 技术栈整合需要 12-18 个月，关键人才保留是核心挑战 |
| **估值风险** | S GAAP 持续亏损，若收入增速放缓将影响估值支撑 |
| **竞争风险** | CrowdStrike、Microsoft Defender 可能利用整合期抢占市场份额 |
| **稀释风险** | GAAP 基础 Year 1 稀释 4.5%，需向投资者充分沟通长期价值创造路径 |

---

## 十二、交易建议总结 (Recommendation Summary)

| 评估维度 | 结论 |
|----------|------|
| **Non-GAAP EPS 影响** | Year 1 即增值 +5.7%，Year 3 增值 +13.5% |
| **GAAP EPS 影响** | Year 1 稀释 -4.5%，Year 2 转正 +23.9% |
| **盈亏平衡协同** | Non-GAAP: 无需协同即增值；GAAP: 需 $158M 税前协同 |
| **估值合理性** | EV/Revenue 6.1x 处于可比交易合理区间 |
| **资本结构影响** | 合并后净债务/资本仅 7.7%，财务状况稳健 |
| **战略契合度** | 高 — 补强端点安全能力，加速平台化战略 |

> **总体结论：** 建议推进交易。PANW 以 50/50 现金股票对价、30% 溢价收购 SentinelOne，在 Non-GAAP 基础上 Year 1 即实现 EPS 增值。GAAP 基础短期稀释可控，Year 2 即转正。战略上可显著增强终端防护产品组合，与现有云安全和网络安全的领先地位形成协同效应。

---

## 数据来源 (Sources)

1. [Yahoo Finance — PANW Key Statistics](https://finance.yahoo.com/quote/PANW/key-statistics/) — 市值、EV、现金、债务、P/E 比率
2. [Yahoo Finance — S Key Statistics](https://finance.yahoo.com/quote/S/key-statistics/) — SentinelOne 财务统计
3. [Palo Alto Networks Q2 FY2026 Earnings Release](https://www.paloaltonetworks.com/company/press/2026/palo-alto-networks-reports-fiscal-second-quarter-2026-financial-results) — 收入、EPS、ARR、指引
4. [Palo Alto Networks FY2025 Q4 & Full Year Results](https://www.paloaltonetworks.com/company/press/2025/palo-alto-networks-reports-fiscal-fourth-quarter-and-fiscal-year-2025-financial-results) — FY2025 全年 Non-GAAP EPS $3.34
5. [SentinelOne Q4 & FY2026 Results](https://investors.sentinelone.com/press-releases/news-details/2026/SentinelOne-Announces-Fourth-Quarter-and-Fiscal-Year-2026-Financial-Results/default.aspx) — 收入突破 $1B，Non-GAAP 盈利
6. [SEC EDGAR — PANW 10-Q (Jan 2026)](https://www.sec.gov/Archives/edgar/data/1327567/000132756726000005/panw-20260131.htm) — 信用额度条款、债务详情
7. [SEC EDGAR — S Filing (Oct 2025)](https://www.sec.gov/Archives/edgar/data/1583708/000158370825000159/s-20251031.htm) — SentinelOne 季度报告
8. [Macrotrends — PANW Revenue](https://www.macrotrends.net/stocks/charts/PANW/palo-alto-networks/revenue) — 年度收入历史
9. [Macrotrends — S EBITDA](https://www.macrotrends.net/stocks/charts/S/sentinelone/ebitda) — EBITDA 历史数据
10. [CompaniesMarketCap — S Shares Outstanding](https://companiesmarketcap.com/sentinelone/shares-outstanding/) — 335M 股流通股
11. [Macrotrends — PANW Shares Outstanding](https://www.macrotrends.net/stocks/charts/PANW/palo-alto-networks/shares-outstanding) — 711M 股流通股
12. [GuruFocus — PANW Effective Interest Rate](https://www.gurufocus.com/term/effective-interest-rate/PANW) — 有效利率
13. [Stock Analysis — PANW Statistics](https://stockanalysis.com/stocks/panw/statistics/) — 有效税率 ~31%
14. [StockTitan — SentinelOne FY2026](https://www.stocktitan.net/sec-filings/S/8-k-sentinel-one-inc-reports-material-event-d6ac7b1bc0e4.html) — FY2026 GAAP 净亏损 $450.7M

---

*本报告仅供分析参考，不构成投资建议。所有数据基于公开信息，截至2026年5月9日。*
