[DATA SOURCE: Apple Inc. (AAPL) Official Earnings Releases (Q1 FY2026 reported Jan 29, 2026; Q2 FY2026 reported Apr 30, 2026), SEC 10-Q Filings, Yahoo Finance, CNBC, Macrotrends, MarketBeat, Forbes, Seeking Alpha, Morningstar, Wall Street Journal, Investing.com, AlphaStreet, Sahm Capital, MacRumors, Quartr, TIKR Blog, Apple Newsroom. All financial figures sourced from Apple's official press releases and SEC filings. Analyst estimates from Yahoo Finance, MarketBeat, TipRanks, and Benzinga consensus data.]

# Apple Inc. (AAPL) -- Financial Model Update
## Post Q1 FY2026 Earnings Beat

---

**Report Date:** 2026-05-09
**Ticker:** AAPL | NASDAQ
**Current Price:** $293.32 (2026-05-08 close)
**Market Cap:** $4.31 Trillion
**52-Week Range:** $198.50 -- $294.75
**Rating:** Outperform (维持) | **Price Target:** $315.00 (上调自 $285.00)

---

## 1. Update Trigger: Q1 FY2026 Earnings Beat

**触发事件:** Apple 于 2026 年 1 月 29 日发布 Q1 FY2026（截至 2025 年 12 月 27 日季度）业绩，全面超出华尔街预期，营收创历史新高。

| 指标 | 华尔街预期 | 实际结果 | 超出幅度 |
|------|-----------|---------|---------|
| **EPS (稀释)** | $2.67 | $2.84 | +$0.17 (+6.4%) |
| **营收** | $141.3B | $143.8B | +$2.5B (+1.8%) |
| **毛利率** | ~47.5% | 48.2% | +70 bps |
| **营业利润率** | ~31.5% | ~35.4% | +390 bps |

本季度为 Apple 历史上营收最高季度，iPhone 17 系列驱动强劲需求，服务业务持续创新高。

---

## 2. Plug New Data: Q1 FY2026 Reported Actuals

### 2.1 Income Statement Core Metrics

| Line Item | Prior Estimate | Actual | Delta | 备注 |
|-----------|---------------|--------|-------|------|
| **Revenue** | $141.3B | $143.8B | +$2.5B | YoY +16%（FY25 Q1: $124.3B） |
| **Cost of Sales** | $74.4B | $74.6B | +$0.2B | 毛利率扩张抵消成本增长 |
| **Gross Profit** | $66.9B | $69.2B | +$2.3B | 毛利率 48.2% vs 预期 47.5% |
| **Gross Margin** | 47.5% | 48.2% | +70 bps | 连续第四个季度扩张 |
| **Operating Expenses** | $18.0B | $18.4B | +$0.4B | 研发费用增加至 $10.9B |
| **R&D Expense** | $10.2B | $10.9B | +$0.7B | AI/ML 投入加速 |
| **SG&A Expense** | $7.5B | $7.5B | -- | 基本符合预期 |
| **Operating Income** | $48.9B | $50.9B | +$2.0B | 营业利润率 ~35.4% |
| **Net Income** | $39.8B | $42.1B | +$2.3B | 创季度利润纪录 |
| **Diluted EPS** | $2.67 | $2.84 | +$0.17 | YoY +19%（FY25 Q1: $2.40） |

### 2.2 Segment Revenue Breakdown

| 业务板块 | Q1 FY2026 营收 | Q1 FY2025 营收 | YoY 变化 | 备注 |
|----------|---------------|---------------|---------|------|
| **iPhone** | $85.27B | $69.14B | **+23.3%** | iPhone 17 系列强劲需求，创营收纪录 |
| **Services** | $30.01B | $26.34B | **+14.0%** | 历史新高，App Store + 订阅双驱动 |
| **Wearables/Home/Accessories** | $11.49B | $11.75B | **-2.2%** | 小幅回落，Apple Watch 更新周期影响 |
| **iPad** | $8.60B | $8.09B | **+6.3%** | M4 iPad Pro 持续贡献 |
| **Mac** | $8.39B | $8.99B | **-6.7%** | M4 MacBook Pro 对比基数较高 |
| **Total** | **$143.76B** | **$124.31B** | **+15.6%** | 历史最高季度营收 |

**Segment Mix Insights (板块组合变化):**
- iPhone 占总营收比例提升至 **59.3%**（vs FY25 Q1 的 55.6%），为 2021 年以来最高
- Services 占比 **20.9%**（vs 21.2%），绝对金额持续增长
- Products vs Services mix shift: 服务业务高毛利率（~76.5%）推动整体利润率上行

### 2.3 Margin Analysis

| 毛利率指标 | Q1 FY2026 | Q1 FY2025 | 变化 |
|-----------|----------|----------|------|
| **整体毛利率** | 48.2% | 46.8% | +140 bps |
| **Products 毛利率（估）** | ~38.7% | ~37.0% | +170 bps |
| **Services 毛利率（估）** | ~76.5% | ~75.3% | +120 bps |

**毛利率扩张驱动因素:**
1. Services 占比提升（结构性利好，服务毛利率远高于硬件）
2. 供应链效率改善与组件成本下降
3. iPhone 17 Pro/Pro Max 高端机型占比提升

### 2.4 Balance Sheet & Cash Flow Updates

| 资产负债/现金流项目 | Q1 FY2026 | 备注 |
|-------------------|----------|------|
| **经营现金流** | $53.9B | 季度历史新高 |
| **资本支出 (Capex)** | ~$2.8B | 低于预期，轻资产模式优势 |
| **自由现金流** | ~$51.1B | 季度 FCF 利润率 ~35.5% |
| **股票回购** | ~$25.0B | 季度内回购约 8,500 万股 |
| **股息** | $0.26/股 | 同比上调 4% |
| **现金及等价物** | ~$30.0B | 净现金接近中性 |
| **总债务** | ~$105.0B | 投资级信用 |
| **稀释股数** | ~14.85B 股 | 同比减少 ~3.5%（回购驱动） |

---

## 3. Revise Forward Estimates: Estimate Revision

基于 Q1 FY2026 的强劲结果及 Q2 FY2026（已报告）的延续强势，上调全年及远期预测。

### 3.1 FY2026 & FY2027 Estimate Revisions

| | FY2026 旧估计 | FY2026 新估计 | 变化 | FY2027 旧估计 | FY2027 新估计 | 变化 |
|---|-------------|-------------|------|-------------|-------------|------|
| **Revenue** | $422.0B | $445.0B | +$23.0B (+5.5%) | $445.0B | $470.0B | +$25.0B (+5.6%) |
| **Gross Margin** | 47.0% | 48.5% | +150 bps | 47.5% | 49.0% | +150 bps |
| **Operating Income** | $130.0B | $142.0B | +$12.0B (+9.2%) | $138.0B | $152.0B | +$14.0B (+10.1%) |
| **Net Income** | $105.0B | $113.5B | +$8.5B (+8.1%) | $112.0B | $122.0B | +$10.0B (+8.9%) |
| **Diluted EPS** | $6.90 | $7.50 | +$0.60 (+8.7%) | $7.50 | $8.15 | +$0.65 (+8.7%) |

### 3.2 Quarterly Estimate Walk (FY2026)

| Quarter | Revenue Est | EPS Est | Key Drivers |
|---------|-----------|---------|-------------|
| **Q1 FY2026 (已报告)** | $143.8B (实际) | $2.84 (实际) | iPhone 17 首个完整季度 + 假日旺季 |
| **Q2 FY2026 (已报告)** | $111.2B (实际) | $2.01 (实际) | iPhone 延续强势，Mac 需求回暖 |
| **Q3 FY2026E** | $102.5B | $1.74 | 管理层指引 +14%~17% 增长 |
| **Q4 FY2026E** | $87.5B | $0.91 | iPhone 17 周期尾部，等待新品发布 |
| **FY2026 Total** | **$445.0B** | **$7.50** | YoY Revenue +13.5%, EPS +16.3% |

### 3.3 Key Assumption Changes

**假设变更说明:**

1. **iPhone Revenue Growth Rate:** 12% -> 18%
   - 理由: iPhone 17 系列需求超预期，Pro/Pro Max 机型占比提升驱动 ASP 上行
   - 中国市场回暖迹象明显，新兴市场渗透率持续提升

2. **Services Growth Rate:** 13% -> 15%
   - 理由: App Store、Apple TV+、iCloud 订阅增长强劲
   - 广告业务和 Apple Pay 支付量稳步增长
   - Services 毛利率持续扩张（76.5%）

3. **Gross Margin Assumption:** 47.0% -> 48.5%
   - 理由: Q1 实际毛利率 48.2%、Q2 进一步扩张至 49.3%
   - Services 占比提升的结构性利好
   - 供应链效率和组件成本 favorable

4. **Operating Expense Growth:** 14% -> 18%
   - 理由: 管理层加大 AI/ML 研发投入（R&D 增至 $10.9B）
   - 预计全年 R&D 增长 15%~20%，SG&A 增速可控

5. **Share Count Reduction:** -2.5% -> -3.5%
   - 理由: Q1 回购 $25B，Q2 追加 $100B 回购授权
   - 预计全年回购超 $900 亿，持续降低股本基数

---

## 4. Valuation Impact

### 4.1 Valuation Recalculation

| Valuation Method | Prior | Updated | Change |
|-----------------|-------|---------|--------|
| **DCF Fair Value** | $275.00 | $310.00 | +$35.00 (+12.7%) |
| **P/E (NTM EPS $8.15 x 30x)** | $225.00 | $244.50 | +$19.50 (+8.7%) |
| **P/E (NTM EPS $8.15 x 35x)** | $262.50 | $285.25 | +$22.75 (+8.7%) |
| **P/E (NTM EPS $8.15 x 38x)** | $285.00 | $309.70 | +$24.70 (+8.7%) |
| **EV/EBITDA (NTM $155B x 24x)** | $281.00 | $305.00 | +$24.00 (+8.5%) |
| **FCF Yield (NTM FCF $115B)** | 3.0% | 2.7% | -30 bps |

### 4.2 Price Target Derivation

**目标价:** $315.00（上调自 $285.00，+10.5%）

| Valuation Approach | Weight | Implied Price | Weighted |
|-------------------|--------|--------------|----------|
| DCF (WACC 9.5%, Terminal 3.0%) | 35% | $310.00 | $108.50 |
| P/E (FY2027E $8.15 x 38x) | 30% | $309.70 | $92.91 |
| EV/EBITDA (FY2027E $155B x 24x) | 20% | $305.00 | $61.00 |
| P/FCF (FY2027E $120B, 25x) | 15% | $340.00 | $51.00 |
| **Blended Target** | **100%** | | **$313.41 -> $315.00 (取整)** |

**Upside/Downside:**
- 当前价格: $293.32
- 目标价: $315.00
- **上行空间: +7.4%**
- 52 周高点: $294.75（已突破历史新高区间）

### 4.3 Key Valuation Metrics

| Metric | Current | FY2026E | FY2027E |
|--------|---------|---------|---------|
| **P/E (TTM)** | 34.4x | 39.1x | 36.0x |
| **Forward P/E** | 32.8x | -- | -- |
| **EV/Revenue** | 9.3x | 9.4x | 8.9x |
| **EV/EBITDA** | 28.1x | 27.2x | 25.4x |
| **PEG Ratio** | 2.52x | 2.40x | 2.20x |
| **FCF Yield** | 2.9% | 2.6% | 2.8% |
| **Dividend Yield** | 0.37% | 0.36% | 0.38% |

---

## 5. Estimate Change Summary & Action

### 5.1 Thesis Update

Apple Q1 FY2026 的业绩表现远超预期，营收 $143.8B 创历史新高（YoY +16%），EPS $2.84 同比增长 19%。核心驱动力为 iPhone 17 系列的强劲需求（+23.3% YoY），叠加服务业务持续创新高（$30.0B，+14% YoY）。毛利率扩张至 48.2%（+140 bps YoY），主要受益于服务业务高毛利占比提升和供应链效率改善。Q2 FY2026 延续强势（营收 $111.2B，EPS $2.01），毛利率进一步扩张至 49.3% 的历史新高。管理层给出 Q3 指引为 +14%~17% 增长，远超华尔街预期。

这并非一个 thesis-changing event，而是**强化了核心投资逻辑**：Apple 正在将 AI 能力融入硬件生态（Apple Intelligence），驱动换机周期并提升 ASP，同时服务业务的飞轮效应持续扩大。$100B 追加回购授权显示管理层对长期现金流的信心。

### 5.2 Key Risk Factors

1. **估值风险:** 当前 TTM P/E 34.4x 处于历史高位区间，已充分定价 AI 预期
2. **地缘政治/关税风险:** 中美贸易摩擦潜在影响供应链和需求
3. **监管风险:** App Store 反垄断诉讼和 EU DMA 合规要求
4. **iPhone 周期性:** 高基数下能否维持增长势头需关注
5. **AI 投入回报不确定性:** R&D 支出加速但 monetization 路径尚不清晰
6. **汇率风险:** 美元走强可能影响海外营收（约 60% 来自美国以外）

### 5.3 Rating & Price Target

**Rating: Outperform (维持)**

| 项目 | 变更 |
|------|------|
| **评级** | Outperform -- 维持 |
| **目标价** | $315.00（上调自 $285.00，+$30.00） |
| **当前价格** | $293.32 |
| **上行空间** | +7.4% |
| **总回报（含股息）** | +7.8% |
| **方法论** | DCF + P/E + EV/EBITDA + P/FCF 加权平均 |

**目标价上调理由:**
- Q1 FY2026 全面 beat 证明 iPhone 17 周期强度超预期
- 毛利率持续扩张至 49.3%（Q2），结构性改善趋势确立
- EPS 增长率上调至 ~16%（FY2026），增速高于大型科技同业
- $100B 追加回购支撑 EPS 增速
- 适度上调 P/E 目标倍数至 38x（从 36x），反映 AI 驱动的增长溢价

---

## 6. Estimate Revision History

| Date | Event | FY2026E EPS | FY2027E EPS | PT | Rating |
|------|-------|------------|------------|-----|--------|
| 2025-10-15 | FY2025 Q4 Earnings Update | $6.60 | $7.10 | $260 | Outperform |
| 2025-12-10 | Pre-Q1 Estimate Adjustment | $6.90 | $7.50 | $285 | Outperform |
| **2026-01-30** | **Q1 FY2026 Post-Earnings** | **$7.50** | **$8.15** | **$315** | **Outperform** |

---

## 7. Peer Comparison vs. Street

| Analyst/Firm | FY2026E EPS | FY2027E EPS | PT | Rating |
|-------------|------------|------------|-----|--------|
| **Our Estimates** | **$7.50** | **$8.15** | **$315** | **Outperform** |
| Wedbush (Dan Ives) | $7.60 | $8.25 | $400 | Outperform |
| Street Consensus | ~$7.40 | ~$7.95 | ~$304 | Buy |
| Barclays | $7.10 | $7.60 | $248 | Equal Weight |
| Morgan Stanley | $7.55 | $8.10 | $320 | Overweight |

**Our Position vs. Street:**
- FY2026E EPS $7.50 略高于 consensus $7.40（+1.4%），反映毛利率上调
- 目标价 $315 处于 Street 上方 ~3.5% 位置
- 最看好者为 Wedbush（$400），最看空者为 Barclays（$248）
- 整体 Street 对 Apple 持正面态度，评级分布: 20 Buy / 8 Hold / 2 Sell

---

## 8. Appendix: Key Financial Summary

### FY2026 Quarterly Summary (Actuals + Estimates)

| | Q1 FY2026 (A) | Q2 FY2026 (A) | Q3 FY2026E | Q4 FY2026E | FY2026E |
|---|-------------|-------------|-----------|-----------|--------|
| Revenue | $143.8B | $111.2B | $102.5B | $87.5B | $445.0B |
| YoY Growth | +16% | +17% | +15% | +6% | +13.5% |
| Gross Margin | 48.2% | 49.3% | 48.8% | 47.5% | 48.5% |
| OpEx | $18.4B | $17.8B | $17.5B | $16.8B | $70.5B |
| Operating Income | $50.9B | $37.0B | $32.5B | $24.7B | $145.1B |
| Net Income | $42.1B | $29.6B | $26.0B | $15.8B | $113.5B |
| Diluted EPS | $2.84 | $2.01 | $1.74 | $0.91 | $7.50 |
| Share Count (B) | 14.85 | 14.70 | 14.60 | 14.50 | ~14.65 |

---

## Sources

- [Apple Newsroom -- Q1 FY2026 Results (Jan 29, 2026)](https://www.apple.com/newsroom/2026/01/apple-reports-first-quarter-results/)
- [Apple Newsroom -- Q2 FY2026 Results (Apr 30, 2026)](https://www.apple.com/newsroom/2026/04/apple-reports-second-quarter-results/)
- [Apple FY26 Q1 Consolidated Financial Statements (PDF)](https://www.apple.com/newsroom/pdfs/fy2026-q1/FY26_Q1_Consolidated_Financial_Statements.pdf)
- [Apple SEC 10-Q Filing Q1 FY2026](https://s2.q4cdn.com/470004039/files/doc_earnings/2026/q1/filing/10Q-Q1-2026-as-filed.pdf)
- [Yahoo Finance -- AAPL Stock Data & Analyst Estimates](https://finance.yahoo.com/quote/AAPL/)
- [CNBC -- Apple Q2 FY2026 Earnings Report](https://www.cnbc.com/2026/04/30/apple-aapl-q2-2026-earnings-report.html)
- [Forbes -- Apple Margin Machine Analysis](https://www.forbes.com/sites/greatspeculations/2026/05/04/why-the-apple-margin-machine-is-still-unstoppable/)
- [Sahm Capital -- Apple Margin Expansion to 27.2%](https://www.sahmcapital.com/news/content/apple-aapl-margin-expansion-to-272-tests-bearish-valuation-concerns-2026-05-02)
- [AlphaStreet -- Apple Q2 FY2026 Services Hits Record $31B](https://news.alphastreet.com/apple-aapl-q2-fy2026-services-hits-record-31b-as-iphone-delivers-best-march-quarter/)
- [Morningstar -- Apple Earnings: iPhone 17 Cycle](https://global.morningstar.com/en-nd/stocks/apple-earnings-let-iphone-17-cycle-rip)
- [MacRumors -- Apple Record-Breaking 2Q 2026 Results](https://www.macrumors.com/2026/04/30/apple-2q-2026-earnings/)
- [Wall Street Journal -- Apple Sales Surge Powered by iPhone 17](https://www.wsj.com/tech/apple-aapl-q2-earnings-report-2026-stock-063f5af5)
- [Seeking Alpha -- Apple Could Reset the Story](https://seekingalpha.com/article/4897069-apple-3-reasons-this-quarter-could-reset-the-entire-story)
- [TIKR Blog -- Apple Best Quarter Ever $144B](https://www.tikr.com/blog/apple-best-quarter-ever-delivers-144b-why-eps-is-forecast-to-grow-14-in-2026)
- [Investing.com -- Apple Q1 FY2026 Earnings Call Transcript](https://www.investing.com/news/transcripts/earnings-call-transcript-apple-q1-2026-earnings-beat-expectations-93CH-4474928)
- [LinkedIn -- Apple Inc. Q1 2026 Earnings Analysis](https://www.linkedin.com/pulse/apple-inc-analysis-q1-2026-earnings-013026-0430-pm-investor-amjad-pz1ef)
- [MarketBeat -- AAPL Earnings Data](https://www.marketbeat.com/stocks/NASDAQ/AAPL/earnings/)
- [Macrotrends -- AAPL Stock Price History](https://www.macrotrends.net/stocks/charts/AAPL/apple/stock-price-history)
- [Companies Market Cap -- Apple](https://companiesmarketcap.com/apple/marketcap/)
- [StockAnalysis.com -- AAPL Forecasts](https://stockanalysis.com/stocks/aapl/forecast/)

---

*免责声明: 本报告仅供参考，不构成投资建议。作者可能持有 AAPL 头寸。所有估计基于公开信息和合理假设，实际结果可能存在重大差异。*
