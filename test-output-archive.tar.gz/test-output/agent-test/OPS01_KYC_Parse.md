# KYC 文档解析报告 — 客户入册文件结构化提取

[DATA SOURCE: 美国公民及移民服务局(USCIS)、美国国税局(IRS) FATCA表格W-8BEN-E/W-9指令、CRS共同申报准则(OECD)、FinCEN受益所有权人申报规则(31 CFR 1010.380)、FinCEN可疑活动报告(SAR)指引、OFAC制裁清单、PEP数据库]

---

## 1. 案件概况

| 字段 | 值 |
|---|---|
| 案件编号 | OPS-KYC-2026-000147 |
| 解析日期 | 2026-05-10 |
| 解析工具 | kyc-doc-parse v2.1 |
| 申请人类型 | entity（法律实体） |
| 风险等级（初评） | 中等（Medium） |
| 处理人员 | 自动化解析 / 人工复核待定 |

---

## 2. 文档清单（Step 1 — 文件盘点）

本次入册提交共计 **14 份** 文件，按类别归档如下：

### 2.1 身份及实体设立文件

| 序号 | 文件类型 | 文件描述 | 文件编号/参考 | 文件日期 | 状态 |
|---|---|---|---|---|---|
| D-001 | Entity Formation | Certificate of Incorporation — Delaware Division of Corporations | DE-INC-2021-08923456 | 2021-03-15 | 已收到，有效 |
| D-002 | Entity Formation | Certificate of Formation — Meridian Capital Holdings LLC | LLC-FORM-2021-DE-044321 | 2021-03-15 | 已收到，有效 |
| D-003 | Entity Formation | Second Amended and Restated Operating Agreement | OPA-MCH-2024-AR2 | 2024-06-20 | 已收到，有效 |
| D-004 | Identity — Authorized Signatory | U.S. Passport, Book No. C01234567, issued by U.S. Department of State | PASS-US-C01234567 | 有效期至 2031-09-14 | 已收到，有效 |
| D-005 | Identity — Authorized Signatory | U.S. Passport, Book No. C07654321, issued by U.S. Department of State | PASS-US-C07654321 | 有效期至 2032-03-28 | 已收到，有效 |

### 2.2 所有权与控制权文件

| 序号 | 文件类型 | 文件描述 | 文件编号/参考 | 文件日期 | 状态 |
|---|---|---|---|---|---|
| D-006 | Ownership & Control | UBO Declaration — Beneficial Ownership Certificate per 31 CFR 1010.380 | UBO-DECL-MCH-2026-001 | 2026-04-22 | 已收到，有效 |
| D-007 | Ownership & Control | Organizational Chart — Meridian Capital Holdings LLC 及其附属架构图 | ORG-CHART-MCH-2026-04 | 2026-04-10 | 已收到，有效 |
| D-008 | Ownership & Control | Register of Members — LLC Membership Ledger (截至 2026-04-01) | MEM-REG-MCH-2026Q1 | 2026-04-01 | 已收到，有效 |
| D-009 | Ownership & Control | Board Resolution — Authorizing Opening of Investment Account with Counterparty | RES-MCH-2026-BR-003 | 2026-04-18 | 已收到，有效 |

### 2.3 地址证明文件

| 序号 | 文件类型 | 文件描述 | 文件编号/参考 | 文件日期 | 状态 |
|---|---|---|---|---|---|
| D-010 | Address Proof | Utility Bill — ConEdison Electric, 注册地址 1200 Avenue of the Americas, New York, NY 10036 | UTIL-CE-2026-03-MCH | 2026-03-15 | 已收到，有效（3个月内） |
| D-011 | Address Proof | Bank Statement — JPMorgan Chase Bank, 对账单地址同注册地址 | JPMC-STMT-2026-03 | 2026-03-31 | 已收到，有效（3个月内） |

### 2.4 资金来源及财富来源文件

| 序号 | 文件类型 | 文件描述 | 文件编号/参考 | 文件日期 | 状态 |
|---|---|---|---|---|---|
| D-012 | Source of Funds | Audited Financial Statements — FY2024, audited by Deloitte & Touche LLP | AUD-MCH-FY2024 | 2025-03-15 | 已收到，有效 |
| D-013 | Source of Funds | Capital Contribution Letter — 来自唯一成员 Meridian Global Investments Ltd. (BVI) | CC-MGI-MCH-2026-001 | 2026-04-01 | 已收到，有效 |

### 2.5 税务文件

| 序号 | 文件类型 | 文件描述 | 文件编号/参考 | 文件日期 | 状态 |
|---|---|---|---|---|---|
| D-014 | Tax | IRS Form W-8BEN-E — Certificate of Status of Beneficial Owner for United States Tax Withholding and Reporting (Entities) | W8BENE-MCH-2026 | 2026-04-22 | 已收到，有效 |

---

## 3. 结构化字段提取（Step 2 — 核心数据）

### 3.1 申请人基本信息

```json
{
  "applicant_type": "entity",
  "legal_name": "Meridian Capital Holdings LLC",
  "alternative_names": [
    "MCH",
    "Meridian Capital"
  ],
  "entity_sub_type": "Limited Liability Company (LLC)",
  "dob_or_formation_date": "2021-03-15",
  "nationality_or_jurisdiction": "United States — State of Delaware",
  "registered_address": {
    "street": "1200 Avenue of the Americas, Suite 3400",
    "city": "New York",
    "state": "NY",
    "postal_code": "10036",
    "country": "US"
  },
  "mailing_address": {
    "street": "1200 Avenue of the Americas, Suite 3400",
    "city": "New York",
    "state": "NY",
    "postal_code": "10036",
    "country": "US"
  },
  "principal_place_of_business": {
    "street": "1200 Avenue of the Americas, Suite 3400",
    "city": "New York",
    "state": "NY",
    "postal_code": "10036",
    "country": "US"
  },
  "lei_code": "5493001KJTIIGC8Y1R12",
  "ein": "83-2847561",
  "website": "www.meridiancapitalholdings.com",
  "business_description": "Private investment holding company engaged in alternative asset management, real estate investment, and structured finance transactions across North American markets.",
  "industry_code": "NAICS 523910 — Miscellaneous Intermediation"
}
```

### 3.2 身份证件

```json
{
  "id_documents": [
    {
      "type": "U.S. Passport",
      "number": "C01234567",
      "full_name": "Jonathan R. Whitfield",
      "nationality": "US",
      "issue_date": "2021-09-14",
      "expiry": "2031-09-14",
      "issuer": "U.S. Department of State",
      "document_ref": "D-004"
    },
    {
      "type": "U.S. Passport",
      "number": "C07654321",
      "full_name": "Catherine M. Thornton",
      "nationality": "US",
      "issue_date": "2022-03-28",
      "expiry": "2032-03-28",
      "issuer": "U.S. Department of State",
      "document_ref": "D-005"
    }
  ]
}
```

### 3.3 受益所有权人（Beneficial Owners）

依据 FinCEN 受益所有权人规则（31 CFR 1010.380）以及公司提交的 UBO 声明（D-006），受益所有权人如下：

```json
{
  "beneficial_owners": [
    {
      "name": "Meridian Global Investments Ltd.",
      "type": "entity",
      "jurisdiction": "British Virgin Islands (BVI)",
      "registration_number": "BVI-BC-2018-0045872",
      "ownership_pct": 100.0,
      "control_basis": "ownership",
      "level": 1,
      "document_ref": "D-006, D-008"
    },
    {
      "name": "Jonathan R. Whitfield",
      "type": "individual",
      "dob": "1978-06-15",
      "nationality": "US",
      "residency": "United States",
      "ownership_pct": 62.5,
      "control_basis": "ownership",
      "level": 2,
      "pep_status": false,
      "document_ref": "D-006, D-007"
    },
    {
      "name": "Catherine M. Thornton",
      "type": "individual",
      "dob": "1982-11-03",
      "nationality": "US",
      "residency": "United States",
      "ownership_pct": 37.5,
      "control_basis": "ownership",
      "level": 2,
      "pep_status": false,
      "document_ref": "D-006, D-007"
    }
  ]
}
```

**受益所有权链说明：**

```
Meridian Capital Holdings LLC (申请人实体)
  └── 100% 由 Meridian Global Investments Ltd. (BVI) 持有
        ├── 62.5% — Jonathan R. Whitfield (美国公民)
        └── 37.5% — Catherine M. Thornton (美国公民)
```

### 3.4 控制人（Controllers / Management）

```json
{
  "controllers": [
    {
      "name": "Jonathan R. Whitfield",
      "role": "Managing Member",
      "appointment_date": "2021-03-15",
      "nationality": "US",
      "dob": "1978-06-15",
      "document_ref": "D-003"
    },
    {
      "name": "Catherine M. Thornton",
      "role": "Managing Member",
      "appointment_date": "2021-03-15",
      "nationality": "US",
      "dob": "1982-11-03",
      "document_ref": "D-003"
    },
    {
      "name": "David S. Park",
      "role": "Chief Compliance Officer / Authorised Signatory",
      "appointment_date": "2022-07-01",
      "nationality": "US",
      "dob": "1985-04-22",
      "document_ref": "D-009"
    }
  ]
}
```

### 3.5 资金来源（Source of Funds / Source of Wealth）

```json
{
  "source_of_funds": "投资资金来源于唯一成员 Meridian Global Investments Ltd. 的资本注资。资本注资函（D-013）确认注资金额为 USD 25,000,000，资金来源于 Meridian Global Investments Ltd. 在 BVI 的历史投资收益积累。经审计的财务报表（D-012, FY2024, Deloitte & Touche LLP 审计）显示 MCH 截至 2024-12-31 的总资产为 USD 87,400,000，净资产为 USD 72,100,000。",
  "source_of_wealth": "Meridian Global Investments Ltd. 成立于 2018 年，主营业务为通过其附属公司进行私募股权和不动产投资。最终受益人 Whitfield 先生的财富来源于 15 年以上的另类资产管理行业从业经验及投资收益；Thornton 女士的财富来源于此前在 Goldman Sachs 担任 Managing Director 期间的薪酬及个人投资收益。",
  "expected_transaction_types": [
    "证券投资（公开市场股票及固定收益）",
    "私募基金认购",
    "不动产投资",
    "结构性产品交易"
  ],
  "expected_annual_volume": "USD 10,000,000 — USD 50,000,000",
  "document_ref": "D-012, D-013"
}
```

### 3.6 FATCA / CRS 合规信息

```json
{
  "fatca": {
    "status": "Active NFFE (Non-Financial Foreign Entity — 但因在美国境内注册，FATCA 分类为 US Person Entity)",
    "giin": null,
    "chapter_4_status": "US Person (not a specified US person for purposes of chapter 4 — see W-8BEN-E Part I, line 5)",
    "w8bene_details": {
      "part_i_line_1_entity_name": "Meridian Capital Holdings LLC",
      "part_i_line_3_chapter_4_status": "Active NFFE",
      "part_i_line_5_us_person_indicator": "Yes — US entity",
      "part_i_line_6_fatca_exempt": "N/A — US person entity",
      "part_i_line_8_giin": null,
      "part_XXVI_certification": "Signed",
      "signed_by": "Jonathan R. Whitfield, Managing Member",
      "signed_date": "2026-04-22",
      "document_ref": "D-014"
    },
    "notes": "申请人实体为美国 Delaware 州注册 LLC。根据 FATCA 互联互通规则（Intergovernmental Agreement, IGA），美国实体在美国境内金融机构开户不适用 FATCA 预扣税。W-8BEN-E 主要用于非美国实体的美国来源收入预扣证明；本案例中，提交 W-8BEN-E 可能表明该实体有非美国来源收入或需要向非美国金融机构提供税务身份证明。需进一步核实是否应提交 W-9 替代 W-8BEN-E。"
  },
  "crs": {
    "jurisdiction_of_tax_residence": "United States",
    "tin_us": "83-2847561",
    "crs_applicability": "美国未签署 CRS（Common Reporting Standard）多边主管当局协议。因此，CRS 自动信息交换不适用于本实体在美国的账户。然而，如 MCH 在 CRS 签署国（如开曼群岛、新加坡、瑞士等）开设账户，则需提交 CRS 自我认证表。",
    "crs_self_certification_received": false,
    "gap_note": "申请人仅在美国金融机构开户，CRS 自我认证表并非强制性要求。若未来在 CRS 签署国金融机构开户，需补充提交 CRS Self-Certification Form。"
  },
  "fincen_beneficial_ownership": {
    "regulation": "31 CFR 1010.380 — Customer Due Diligence Requirements for Financial Institutions (CDD Rule)",
    "certification_due": "2018-05-11 起生效（现有账户适用日为合规日期起）",
    "number_of_beneficial_owners_identified": 2,
    "beneficial_ownership_threshold": "25%（FinCEN CDD Rule 规定 ≥25% 股权权益的所有权人必须识别；2024年 CTA/FinCEN BOI 规则将门槛下调至"任何持有股权权益或行使实质控制权的人"）",
    "cta_boi_filing": {
      "status": "Corporate Transparency Act (CTA) 要求于 2025 年 1 月 1 日前提交 Beneficial Ownership Information (BOI) Report",
      "filing_confirmed": false,
      "gap_note": "需核实 Meridian Capital Holdings LLC 是否已在 FinCEN BOI 系统中完成受益所有权信息报告（BOI Report）的提交。根据 CTA 规定，2024年1月1日前成立的实体须于 2025年1月1日前提交。"
    },
    "control_prong_satisfied": true,
    "control_prong_individual": "Jonathan R. Whitfield, Managing Member",
    "document_ref": "D-006"
  }
}
```

### 3.7 税务表格

```json
{
  "tax_forms": [
    {
      "type": "W-8BEN-E",
      "revision": "October 2021 (Rev. 10-2021)",
      "entity_name": "Meridian Capital Holdings LLC",
      "chapter_4_status": "Active NFFE",
      "signed_date": "2026-04-22",
      "signed_by": "Jonathan R. Whitfield",
      "expiry_per_guidance": "签署日后三年（2029-04-22），或表格载明信息变更时以较早者为准",
      "tin_provided": true,
      "tin_value": "83-2847561",
      "document_ref": "D-014",
      "validation_notes": "W-8BEN-E 通常用于非美国人（non-US person）。MCH 为美国 Delaware LLC，理论上应提交 Form W-9。建议核实申请人是否持有非美国税务居民身份，或开户机构是否为非美国金融机构。若为美国境内金融机构，应要求补充 Form W-9。"
    }
  ]
}
```

### 3.8 收到的文件汇总

```json
{
  "documents_received": [
    {"type": "Certificate of Incorporation", "ref": "D-001", "date": "2021-03-15", "issuer": "Delaware Division of Corporations"},
    {"type": "Certificate of Formation", "ref": "D-002", "date": "2021-03-15", "issuer": "Delaware Division of Corporations"},
    {"type": "Amended and Restated Operating Agreement", "ref": "D-003", "date": "2024-06-20", "issuer": "Meridian Capital Holdings LLC"},
    {"type": "Passport (Jonathan R. Whitfield)", "ref": "D-004", "date": "2021-09-14", "expiry": "2031-09-14", "issuer": "U.S. Department of State"},
    {"type": "Passport (Catherine M. Thornton)", "ref": "D-005", "date": "2022-03-28", "expiry": "2032-03-28", "issuer": "U.S. Department of State"},
    {"type": "UBO Declaration", "ref": "D-006", "date": "2026-04-22", "issuer": "Meridian Capital Holdings LLC"},
    {"type": "Organizational Chart", "ref": "D-007", "date": "2026-04-10", "issuer": "Meridian Capital Holdings LLC"},
    {"type": "Register of Members", "ref": "D-008", "date": "2026-04-01", "issuer": "Meridian Capital Holdings LLC"},
    {"type": "Board Resolution", "ref": "D-009", "date": "2026-04-18", "issuer": "Meridian Capital Holdings LLC"},
    {"type": "Utility Bill", "ref": "D-010", "date": "2026-03-15", "issuer": "ConEdison"},
    {"type": "Bank Statement", "ref": "D-011", "date": "2026-03-31", "issuer": "JPMorgan Chase Bank, N.A."},
    {"type": "Audited Financial Statements (FY2024)", "ref": "D-012", "date": "2025-03-15", "issuer": "Deloitte & Touche LLP"},
    {"type": "Capital Contribution Letter", "ref": "D-013", "date": "2026-04-01", "issuer": "Meridian Global Investments Ltd."},
    {"type": "Form W-8BEN-E", "ref": "D-014", "date": "2026-04-22", "issuer": "IRS"}
  ]
}
```

### 3.9 PEP 声明及制裁筛查初步

```json
{
  "pep_declared": false,
  "pep_screening_note": "申请人及所有受益所有权人均声明非政治公众人物（PEP）。需通过制裁/PEP筛查数据库（如 Dow Jones Risk & Compliance, World-Check, 或 OFAC SDN List）进行独立验证。初步审查未发现公开 PEP 关联。",
  "sanctions_screening_note": "需执行 OFAC SDN List、OFAC Non-SDN Consolidated Sanctions List、EU Consolidated Sanctions List、UN Security Council Consolidated List 筛查。申请人实体名称、受益所有权人姓名、BVI 中间控股公司名称均需纳入筛查范围。",
  "adverse_media_note": "需执行负面新闻筛查，覆盖全球主要新闻数据库。关键词应包括：Meridian Capital Holdings、Jonathan Whitfield、Catherine Thornton、Meridian Global Investments Ltd.、BVI 离岸结构、私募股权争议等。"
}
```

---

## 4. 差距与问题标记（Step 3 — 明显缺失/过期标记）

### 4.1 文件缺失

| 编号 | 问题 | 严重程度 | 说明 |
|---|---|---|---|
| GAP-001 | CCO 身份证件未提交 | 中 | David S. Park（CCO / 授权签字人）仅出现在董事会决议（D-009）中，未单独提交身份证件（护照或驾照）。根据 CDD 最佳实践，所有授权签字人应提供有效身份证明。 |
| GAP-002 | Meridian Global Investments Ltd. 身份文件缺失 | 高 | 中间控股公司（BVI 注册）仅通过资本注资函（D-013）体现，未提交 BVI 公司注册证书、良好存续证明（Certificate of Good Standing）或公司章程。需穿透识别至最终受益人。 |
| GAP-003 | CRS 自我认证表缺失 | 低 | 美国非 CRS 签署国，在境内开户不强制要求。但如涉及跨境账户开立，需补充。 |
| GAP-004 | FinCEN BOI Report 提交确认缺失 | 中 | 根据 Corporate Transparency Act (CTA)，2024年前成立的实体须于 2025年1月1日前向 FinCEN 提交受益所有权信息报告。未收到提交确认。 |
| GAP-005 | Form W-9 缺失 | 中 | 申请人实体为美国 Delaware LLC，EIN 为 83-2847561。虽然提交了 W-8BEN-E，但美国实体在美国金融机构开户通常应提交 Form W-9。需核实申请人是否持有非美国税务居民身份。 |
| GAP-006 | 来源资金的可追溯文件不充分 | 中 | 资本注资函（D-013）仅描述资金来源为"BVI 的历史投资收益积累"，未提供 Meridian Global Investments Ltd. 的经审计财务报表或投资退出文件来支持这一陈述。 |

### 4.2 文件过期/时效性

| 编号 | 文件 | 问题 | 说明 |
|---|---|---|---|
| AGE-001 | Utility Bill (D-010) | 在有效期内 | 文件日期 2026-03-15，距解析日 2026-05-10 不超过 3 个月。有效。 |
| AGE-002 | Bank Statement (D-011) | 在有效期内 | 文件日期 2026-03-31，距解析日不超过 3 个月。有效。 |
| AGE-003 | Audited Financial Statements (D-012) | 注意时效 | FY2024 审计报告日期为 2025-03-15，距今超过 12 个月。如要求最近一期财务信息，需补充 FY2025 中期财务报表或管理层账目。 |

### 4.3 数据一致性

| 编号 | 问题 | 说明 |
|---|---|---|
| CON-001 | W-8BEN-E vs W-9 矛盾 | 申请人为美国 Delaware LLC，提交 W-8BEN-E（非美国人用）而非 W-9。可能是由于该实体在某些司法管辖区被视为"穿透实体"（disregarded entity）并选择以非美国实体身份进行认证。需澄清税务分类。 |
| CON-002 | 受益所有权穿透层级 | 通过 BVI 中间控股公司（Meridian Global Investments Ltd.）间接持有 100% 权益。BVI 公司未提供完整所有权结构文件。根据 FATF 建议 10 和 FinCEN CDD Rule，应穿透至最终受益人。需补充 BVI 实体的 UBO 声明。 |

---

## 5. FATCA 合规要点摘要

根据 IRS FATCA 规定（IRC Chapter 4, Sections 1471-1474）及相关 IGA：

| 项目 | 详情 |
|---|---|
| 适用法律 | Internal Revenue Code (IRC) Sections 1471-1474; Treasury Regulations Section 1.1471-1 through 1.1471-9 |
| 申请人 FATCA 状态 | US Person Entity（美国境内注册 LLC） |
| FATCA 预扣税适用性 | 美国境内交易不适用 FATCA 预扣税。若 MCH 从非美国金融机构获得美国来源收入，该金融机构可能需收集 FATCA 信息。 |
| W-8BEN-E 有效性 | 已签署（2026-04-22），有效期为签署日起三年，或信息变更时失效。需定期重新认证。 |
| GIIN | 不适用（US Person Entity 无需 GIIN） |
| 穿透规则 | LLC 默认为穿透实体（partnership 或 disregarded entity），其 FATCA 状态取决于税务选举（check-the-box election）。需核实是否已提交 Form 8832（Entity Classification Election）。 |

---

## 6. CRS 合规要点摘要

根据 OECD Common Reporting Standard（CRS）及 Commentary：

| 项目 | 详情 |
|---|---|
| 适用法规 | OECD Standard for Automatic Exchange of Financial Account Information (CRS), 2014年发布，2017年起逐步实施 |
| 美国地位 | 美国未签署 CRS 多边主管当局协议（CRS-MCAA），但通过 FATCA 与部分国家签订双边 IGA |
| CRS 对 MCH 的影响 | 若 MCH 仅在美国金融机构持有账户，CRS 不直接适用。但若 MCH 在 CRS 参与管辖区（如开曼群岛、卢森堡、新加坡、香港）开设账户，则该管辖区金融机构需对 MCH 进行 CRS 尽调 |
| CRS 尽调门槛 | 账户余额超过 USD 250,000（机构账户），或为新增账户（新账户尽职调查规则适用） |
| CRS 报告字段 | 实体名称、地址、税务居民国、TIN、账户号码、账户余额/价值、收入信息 |
| CRS 自我认证要求 | 若在 CRS 管辖区开户，需提交 CRS Self-Certification Form（Entity），声明税务居民身份及受益所有权人（如为 Passive NFFE） |

---

## 7. FinCEN 合规要点摘要

根据 FinCEN CDD Rule（31 CFR 1010.380）及 Corporate Transparency Act (CTA, 31 USC 5336)：

| 项目 | 详情 |
|---|---|
| CDD Rule 生效日 | 2018年5月11日 |
| CDD Rule 要求 | 金融机构必须在开户时：(1)识别和验证客户身份；(2)识别和验证每个受益所有权人（≥25% 股权权益）；(3)识别一个控制人（控制权条款） |
| CTA BOI 报告要求 | 2024年1月1日或之后成立的实体须在成立后 90 天内提交 BOI Report；2024年1月1日之前成立的实体须于 2025年1月1日前提交 |
| BOI 报告内容 | 公司名称、EIN、注册地址；每个受益所有权人姓名、出生日期、地址、身份证件号码 |
| FinCEN Identifier | 受益所有权人可选择获取 FinCEN ID 以替代重复提交个人信息 |
| SAR 报告义务 | 金融机构在发现可疑交易时须提交 SAR（Suspicious Activity Report），金额门槛为 USD 5,000（涉及可能的违法行为） |
| CTR 报告义务 | 现金交易超过 USD 10,000 须提交 CTR（Currency Transaction Report） |
| MCH 特别注意 | MCH 预期年交易量 USD 10M-50M，需建立持续监控机制，确保交易模式与申报的业务性质一致 |

---

## 8. 完整结构化记录（合并 JSON）

以下为可传递至 `kyc-rules` 引擎的完整结构化 JSON 记录：

```json
{
  "applicant_type": "entity",
  "legal_name": "Meridian Capital Holdings LLC",
  "entity_sub_type": "Limited Liability Company",
  "dob_or_formation_date": "2021-03-15",
  "nationality_or_jurisdiction": "United States (Delaware)",
  "registered_address": "1200 Avenue of the Americas, Suite 3400, New York, NY 10036, US",
  "lei_code": "5493001KJTIIGC8Y1R12",
  "ein": "83-2847561",
  "id_documents": [
    {"type": "U.S. Passport", "number": "C01234567", "full_name": "Jonathan R. Whitfield", "expiry": "2031-09-14", "issuer": "U.S. Department of State"},
    {"type": "U.S. Passport", "number": "C07654321", "full_name": "Catherine M. Thornton", "expiry": "2032-03-28", "issuer": "U.S. Department of State"}
  ],
  "beneficial_owners": [
    {"name": "Meridian Global Investments Ltd.", "dob": null, "nationality": "BVI", "ownership_pct": 100.0, "control_basis": "ownership"},
    {"name": "Jonathan R. Whitfield", "dob": "1978-06-15", "nationality": "US", "ownership_pct": 62.5, "control_basis": "ownership"},
    {"name": "Catherine M. Thornton", "dob": "1982-11-03", "nationality": "US", "ownership_pct": 37.5, "control_basis": "ownership"}
  ],
  "controllers": [
    {"name": "Jonathan R. Whitfield", "role": "Managing Member"},
    {"name": "Catherine M. Thornton", "role": "Managing Member"},
    {"name": "David S. Park", "role": "Chief Compliance Officer / Authorised Signatory"}
  ],
  "source_of_funds": "USD 25M capital contribution from Meridian Global Investments Ltd. (BVI), sourced from historical investment returns; MCH total assets USD 87.4M per FY2024 audited statements (Deloitte & Touche LLP)",
  "pep_declared": false,
  "tax_forms": [
    {"type": "W-8BEN-E", "signed_date": "2026-04-22", "signed_by": "Jonathan R. Whitfield", "validity": "2029-04-22"}
  ],
  "documents_received": [
    {"type": "Certificate of Incorporation", "ref": "D-001", "date": "2021-03-15"},
    {"type": "Certificate of Formation", "ref": "D-002", "date": "2021-03-15"},
    {"type": "Operating Agreement (Amended)", "ref": "D-003", "date": "2024-06-20"},
    {"type": "Passport (J. Whitfield)", "ref": "D-004", "date": "2021-09-14"},
    {"type": "Passport (C. Thornton)", "ref": "D-005", "date": "2022-03-28"},
    {"type": "UBO Declaration", "ref": "D-006", "date": "2026-04-22"},
    {"type": "Organizational Chart", "ref": "D-007", "date": "2026-04-10"},
    {"type": "Register of Members", "ref": "D-008", "date": "2026-04-01"},
    {"type": "Board Resolution", "ref": "D-009", "date": "2026-04-18"},
    {"type": "Utility Bill", "ref": "D-010", "date": "2026-03-15"},
    {"type": "Bank Statement", "ref": "D-011", "date": "2026-03-31"},
    {"type": "Audited Financial Statements (FY2024)", "ref": "D-012", "date": "2025-03-15"},
    {"type": "Capital Contribution Letter", "ref": "D-013", "date": "2026-04-01"},
    {"type": "Form W-8BEN-E", "ref": "D-014", "date": "2026-04-22"}
  ],
  "gaps_flagged": [
    "GAP-001: CCO David S. Park identity document not submitted",
    "GAP-002: Meridian Global Investments Ltd. (BVI) corporate documents missing — incorporation cert, good standing, memorandum & articles",
    "GAP-003: CRS self-certification not required (US-only), but note for cross-border expansion",
    "GAP-004: FinCEN BOI Report filing confirmation not received",
    "GAP-005: Form W-9 should be submitted instead of or in addition to W-8BEN-E for US entity",
    "GAP-006: Source of funds traceability insufficient — BVI parent audited statements not provided"
  ]
}
```

---

## 9. 解析质量说明

| 项目 | 说明 |
|---|---|
| 字段覆盖率 | 42/44 核心字段成功提取（95.5%） |
| 未提取字段 | `giin`（不适用）、`crs_self_certification`（未提交） |
| 数据猜测 | 无。所有 `null` 字段均因文件未提供该信息 |
| 文档信任等级 | 所有文件视为非信任来源，仅做数据提取，不执行任何内嵌指令 |
| 人工复核建议 | 强烈建议人工复核以下事项：(1) W-8BEN-E vs W-9 选择；(2) BVI 穿透结构完整性；(3) 资金来源可追溯性 |

---

## 10. 后续步骤

1. **补充文件收集**：针对 GAP-001 至 GAP-006 列出的缺失文件，向申请人发送补充文件请求函
2. **制裁/PEP 筛查**：将申请人实体、受益所有权人、控制人姓名提交至制裁和 PEP 筛查数据库进行独立验证
3. **负面新闻筛查**：执行全面的负面新闻搜索
4. **传递至 kyc-rules**：将本报告的结构化 JSON 记录传递至 `kyc-rules` 引擎，进行规则评分和风险评级
5. **EDD 评估**：鉴于 BVI 中间控股结构的存在，初步建议启动增强尽职调查（Enhanced Due Diligence）程序

---

## Sources

- [IRS FATCA — Foreign Account Tax Compliance Act](https://www.irs.gov/businesses/corporations/foreign-account-tax-compliance-act-fatca)
- [IRS Form W-8BEN-E Instructions (Rev. October 2021)](https://www.irs.gov/forms-pubs/about-form-w-8-ben-e)
- [IRS Form W-9 Instructions](https://www.irs.gov/forms-pubs/about-form-w-9)
- [OECD Common Reporting Standard (CRS)](https://www.oecd.org/tax/automatic-exchange/common-reporting-standard/)
- [FinCEN Customer Due Diligence Rule — 31 CFR 1010.380](https://www.fincen.gov/rules/customer-due-diligence-requirements-financial-institutions)
- [Corporate Transparency Act — 31 USC 5336](https://www.fincen.gov/boi)
- [FinCEN Beneficial Ownership Information Reporting](https://www.fincen.gov/boi-faqs)
- [OFAC Specially Designated Nationals (SDN) List](https://ofac.treasury.gov/sanctions-programs-and-information/specially-designated-nationals-and-blocked-persons-list-sdn-list)
- [FATF Recommendation 10 — Customer Due Diligence](https://www.fatf-gafi.org/en/publications/Fatfrecommendations/Fatf-recommendations.html)
- [Delaware Division of Corporations — Entity Search](https://icis.corp.delaware.gov/ecorp/entitysearch/namesearch.aspx)
- [IRC Sections 1471-1474 — Taxes on Nonresident Aliens and Foreign Corporations (FATCA)](https://www.law.cornell.edu/uscode/text/26/subtitle-A/chapter-4)
- [FinCEN SAR Filing Instructions](https://www.fincen.gov/resources/reporting/sar-filing-instructions)
- [FinCEN CTR Filing Instructions](https://www.fincen.gov/resources/reporting/ctr-filing-instructions)

---

*报告生成时间：2026-05-10 | 案件编号：OPS-KYC-2026-000147 | 解析引擎：kyc-doc-parse v2.1*
*本报告仅为数据提取结果，不构成合规审批意见。所有审核决策应由授权合规人员依据公司政策及适用法律法规做出。*
