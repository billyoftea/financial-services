# Earnings Preview: Microsoft Corporation (MSFT) - Q4 FY2025

> TEST OUTPUT - Generated for S&P Global skill validation

## Overview

Microsoft reports Q4 FY2025 results on **July 22, 2025** (after market close). This is a critical quarter with AI monetization remaining the central narrative. Investors will focus on Azure growth re-acceleration and Copilot adoption metrics.

## Consensus Estimates

| Metric | Consensus | Year-Ago | YoY Change |
|--------|-----------|----------|------------|
| Revenue | $70.1B | $64.7B | +8.3% |
| EPS (GAAP) | $3.12 | $2.95 | +5.8% |
| EPS (Non-GAAP) | $3.18 | $2.99 | +6.4% |
| Operating Margin | 45.2% | 44.1% | +110 bps |

## Key Metrics to Watch

| Metric | Consensus Expectation | Why It Matters |
|--------|----------------------|----------------|
| Azure Revenue Growth | 31-33% YoY (cc) | Cloud demand signal; AI workload contribution |
| Microsoft Cloud Gross Margin | ~72% | Pricing power and scale efficiency |
| Copilot Revenue | ~$2.8B run-rate | AI monetization proof point |
| Capital Expenditure | ~$18-20B | AI infrastructure build-out pace |
| Commercial Bookings | +25% YoY | Forward demand indicator |

## Segment Breakdown

### Intelligent Cloud
- **Revenue Est**: $29.5B (+17% YoY)
- Azure growth the primary driver; server products stable
- Watch for AI services contribution (~15 pts of Azure growth)

### Productivity & Business Processes
- **Revenue Est**: $21.2B (+10% YoY)
- Office 365 commercial revenue growth ~14%
- LinkedIn and Dynamics steady contributors

### More Personal Computing
- **Revenue Est**: $19.4B (+2% YoY)
- Windows OEM recovery; Devices still soft
- Gaming segment facing tough comparisons post-Activision

## Scenario Analysis

### Bull Case ($35+ EPS) - Probability: 20%
- Azure growth re-accelerates to 34%+
- Copilot exceeds expectations with enterprise wins
- Operating margin expands 150+ bps on operating leverage

### Base Case ($3.12 EPS) - Probability: 55%
- Azure delivers at 31-33% growth
- Copilot adoption on track but no blowout
- Capex commentary measured; margin improvement steady

### Bear Case ($2.90 EPS) - Probability: 25%
- Azure growth decelerates below 30%
- AI spend concerns weigh on margin outlook
- Enterprise IT budget caution from macro uncertainty

## Key Questions for Management

1. What is the Azure AI services contribution to cloud growth?
2. How is Copilot impacting Office 365 attach rates?
3. Commentary on forward Capex plans and ROI timeline?
4. Any change in enterprise deal cadence or budget sentiment?

## Price Target Implications

| Scenario | Implied EPS (FY25) | Target Multiple | Price Target |
|----------|--------------------|-----------------|--------------|
| Bull | $13.80 | 38x | $524 |
| Base | $13.25 | 35x | $464 |
| Bear | $12.60 | 30x | $378 |

---
*TEST OUTPUT - S&P Global Partner Skill Validation*
