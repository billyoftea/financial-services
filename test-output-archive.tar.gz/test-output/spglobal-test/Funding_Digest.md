# Funding Digest - Weekly Round Summary

> TEST OUTPUT - Generated for S&P Global skill validation

## Week of May 5, 2026

### Notable Funding Rounds

| # | Company | Amount | Stage | Sector | Lead Investors |
|---|---------|--------|-------|--------|----------------|
| 1 | Nexus AI | $450M | Series D | AI/ML Infrastructure | Andreessen Horowitz, Thrive Capital |
| 2 | Greenfield Energy | $280M | Series C | Clean Energy | Breakthrough Energy, Temasek |
| 3 | VaultPay | $120M | Series B | Fintech/Payments | Sequoia Capital, Ribbit Capital |
| 4 | Meridian Health | $95M | Series B | HealthTech | General Catalyst, Oak HC/FT |
| 5 | DataForge | $65M | Series A | Enterprise SaaS | Bessemer Venture Partners, IVP |
| 6 | QuantumLeap | $200M | Series C | Quantum Computing | Tiger Global, DST Global |
| 7 | Autoblox | $85M | Series B | Autonomous Vehicles | Lux Capital, Highland Europe |
| 8 | CyberShield | $55M | Series A | Cybersecurity | Accel, CrowdStrike Falcon Fund |

## Summary Statistics

| Metric | Value |
|--------|-------|
| **Total Capital Raised** | $1.35B |
| **Number of Rounds** | 8 |
| **Median Round Size** | $90M |
| **Largest Round** | Nexus AI ($450M) |
| **Most Active Sector** | AI/ML & Infrastructure |
| **Most Active Investor** | Sequoia Capital (2 deals) |

## Sector Breakdown

- **AI/ML Infrastructure**: $450M (33%) - Continues to dominate funding activity
- **Clean Energy**: $280M (21%) - Strong institutional interest in energy transition
- **Quantum Computing**: $200M (15%) - Growing confidence in near-term applications
- **Fintech**: $120M (9%) - Payments and embedded finance remain attractive
- **HealthTech**: $95M (7%) - Value-based care and AI diagnostics leading
- **Autonomous Vehicles**: $85M (6%) - Steady capital for L4 autonomy
- **Enterprise SaaS / Cybersecurity**: $120M (9%) - AI-native tools driving new rounds

## Key Trends

1. **AI infrastructure rounds are outsized** - The $450M Nexus AI round signals continued appetite for compute, model training, and deployment platforms
2. **Series B median hit $90M** - Late-stage rounds are swelling as companies stay private longer
3. **Crossover investors returning** - Tiger Global and DST re-engaging after a cautious 2025
4. **Corporate venture activity rising** - CrowdStrike Falcon Fund participation reflects strategic CVC interest in cybersecurity

---
*TEST OUTPUT - S&P Global Partner Skill Validation*
