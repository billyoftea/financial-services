# Tear Sheet: Apple Inc. (AAPL)

> TEST OUTPUT - Generated for S&P Global skill validation

## Company Overview

| Field | Detail |
|-------|--------|
| **Ticker** | AAPL |
| **Exchange** | NASDAQ |
| **Sector** | Technology |
| **Industry** | Consumer Electronics |
| **Market Cap** | ~$3.4T |
| **Employees** | ~164,000 |
| **Headquarters** | Cupertino, CA |

Apple Inc. designs, manufactures, and markets smartphones, personal computers, tablets, wearables, and accessories. The company also offers a range of services including advertising, AppleCare, cloud, digital content, payment, and licensing services.

## Three-Year Financial Summary

| Metric ($B) | FY2022 | FY2023 | FY2024 |
|-------------|--------|--------|--------|
| Revenue | 394.3 | 383.3 | 391.0 |
| Gross Profit | 170.8 | 169.1 | 181.0 |
| Operating Income | 119.4 | 114.7 | 124.3 |
| Net Income | 99.8 | 97.0 | 93.7 |
| Free Cash Flow | 111.4 | 110.5 | 108.8 |
| Total Debt | 120.1 | 112.7 | 105.0 |
| Cash & Equivalents | 48.3 | 29.9 | 29.9 |

## Valuation Metrics

| Metric | Current | 5-Year Avg | Peer Median |
|--------|---------|------------|-------------|
| P/E (TTM) | 36.2x | 28.1x | 25.5x |
| EV/EBITDA | 29.8x | 22.4x | 20.1x |
| P/S | 8.7x | 7.1x | 5.3x |
| P/B | 55.4x | 42.3x | 8.2x |
| Dividend Yield | 0.5% | 0.7% | 1.2% |
| FCF Yield | 3.2% | 4.1% | 4.5% |

## Peer Comparison

| Company | Market Cap | P/E | EV/EBITDA | Rev Growth |
|---------|-----------|-----|-----------|------------|
| Apple (AAPL) | $3.4T | 36.2x | 29.8x | 2.0% |
| Microsoft (MSFT) | $3.1T | 35.8x | 26.1x | 15.7% |
| Google (GOOGL) | $2.1T | 24.3x | 17.8x | 13.5% |
| Samsung (005930) | $380B | 14.2x | 8.5x | -3.1% |

## Ownership Structure

- **Institutional**: ~62% (Vanguard 8.1%, BlackRock 6.8%, Berkshire Hathaway 5.8%)
- **Insiders**: ~0.6%
- **Retail/Other**: ~37.4%

## Key Takeaways

1. Premium valuation supported by ecosystem lock-in and Services growth
2. Margin expansion driven by Services mix shift (gross margin ~46%)
3. Capital return program remains aggressive ($110B buyback authorized FY2024)
4. Risk: China exposure, regulatory pressure, AI competition

---
*TEST OUTPUT - S&P Global Partner Skill Validation*
