# GL Reconciliation Break Report

**Report Date:** 2026-05-08
**Fund:** Meridian Capital Partners, L.P.
**Reconciliation Period:** April 2026
**Prepared By:** Fund Administration

---

## Summary Statistics

| Metric | Value |
|---|---|
| Total Line Items | 1,247 |
| Matched Items | 1,184 |
| Unmatched Breaks | 63 |
| Match Rate | 94.9% |
| Prior Period Match Rate | 96.2% |

---

## Break Summary by Category

| Category | Count | Gross Amount ($) | Net Amount ($) |
|---|---|---|---|
| Pricing | 22 | 4,385,200 | 1,212,500 |
| Quantity | 18 | 2,741,600 | 890,300 |
| Timing | 15 | 1,058,400 | 1,058,400 |
| FX Rate | 8 | 632,750 | 318,400 |
| **Total** | **63** | **8,817,950** | **3,479,600** |

---

## Sample Breaks

### Pricing Breaks

| Break ID | Security | GL Value ($) | Subledger Value ($) | Difference ($) | Root Cause |
|---|---|---|---|---|---|
| BRK-0041 | AAPL US Equity | 18,245,000 | 18,231,500 | 13,500 | Stale pricing feed at cutoff |
| BRK-0042 | MSFT US Equity | 42,108,000 | 42,095,200 | 12,800 | Vendor price delay (>T+1) |
| BRK-0043 | TSLA US Equity | 9,876,400 | 9,842,100 | 34,300 | Illiquid close - bid/ask spread |
| BRK-0044 | AMZN US Equity | 31,500,000 | 31,489,600 | 10,400 | Adjusted close not applied |
| BRK-0045 | GOOGL US Equity | 22,670,000 | 22,658,300 | 11,700 | Mid-price vs last-price mismatch |

### Quantity Breaks

| Break ID | Security | GL Qty | Subledger Qty | Difference | Root Cause |
|---|---|---|---|---|---|
| BRK-0101 | NVDA US Equity | 125,000 | 124,500 | 500 | Partial fill not booked |
| BRK-0102 | META US Equity | 80,000 | 81,200 | (1,200) | Corporate action reversal |
| BRK-0103 | JPM US Equity | 200,000 | 199,400 | 600 | Trade break unsettled |
| BRK-0104 | V US Equity | 150,000 | 150,750 | (750) | Dividend reinvestment lag |
| BRK-0105 | SPY US ETF | 500,000 | 498,500 | 1,500 | Allocation rounding |

### Timing Breaks

| Break ID | Security | GL Date | Subledger Date | Amount ($) | Root Cause |
|---|---|---|---|---|---|
| BRK-0201 | US Treasury 4.25% 2034 | 2026-04-30 | 2026-05-01 | 412,500 | Settlement lag (T+1) |
| BRK-0202 | CD JP Morgan 5.15% | 2026-04-29 | 2026-04-30 | 285,000 | Trade date vs settle date |
| BRK-0203 | Interest Income - P&L | 2026-04-28 | 2026-04-30 | 178,200 | Accrual posting delay |
| BRK-0204 | FX Settlement USD/EUR | 2026-04-30 | 2026-05-02 | 96,400 | Cross-border settlement |
| BRK-0205 | Broker Fee Payable | 2026-04-29 | 2026-04-30 | 86,300 | Invoice receipt timing |

### FX Rate Breaks

| Break ID | Currency Pair | GL Rate | Subledger Rate | Difference ($) | Root Cause |
|---|---|---|---|---|---|
| BRK-0301 | USD/EUR | 1.0845 | 1.0862 | 85,200 | Spot vs WM Reuters close |
| BRK-0302 | USD/GBP | 1.2630 | 1.2655 | 72,400 | Forward rate misapplied |
| BRK-0303 | USD/JPY | 0.00642 | 0.00639 | 58,600 | Bank of Japan cutoff diff |
| BRK-0304 | USD/CHF | 0.8910 | 0.8935 | 44,800 | Intraday vs EOD rate |
| BRK-0305 | USD/CAD | 0.7280 | 0.7265 | 57,400 | Hedged vs unhedged rate |

---

## Aging Analysis

| Aging Bucket | Count | Net Amount ($) |
|---|---|---|
| 1-3 Days | 38 | 1,842,300 |
| 4-7 Days | 15 | 985,100 |
| 8-14 Days | 7 | 412,600 |
| 15+ Days | 3 | 239,600 |

---

## Action Items

1. **Pricing:** Escalate stale feed issue to data vendor; target resolution by 2026-05-12.
2. **Quantity:** Confirm corporate action reversal with prime broker for META position.
3. **Timing:** Align trade-date/settle-date booking policy across custodian and GL.
4. **FX:** Standardize on WM Reuters 4PM London close for all currency pairs.
5. **Aging:** Investigate 3 aged breaks exceeding 15 days; escalate to CFO if unresolved by 2026-05-15.
