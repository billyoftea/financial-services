# Accounts Receivable Roll-Forward Report

**Fund:** Meridian Capital Partners, L.P.
**Period:** April 2026
**Prepared By:** Fund Administration

---

## AR Roll-Forward Summary

| Line Item | Amount ($) |
|---|---|
| **Beginning AR Balance (2026-04-01)** | **50,000,000** |
| + Billings | 20,000,000 |
| - Collections | (18,000,000) |
| +/- Adjustments | 500,000 |
| **Ending AR Balance (2026-04-30)** | **52,500,000** |
| **Net Change** | **+2,500,000** |

---

## Detailed Roll-Forward

| Component | Detail | Amount ($) | Subtotal ($) |
|---|---|---|---|
| **Beginning Balance** | Per prior period agreed balance | | 50,000,000 |
| **Billings** | | | **20,000,000** |
| | Management Fees - Q1 2026 | 12,500,000 | |
| | Performance Fee Accrual Invoice | 5,000,000 | |
| | Expense Reimbursement Invoice | 2,500,000 | |
| **Collections** | | | **(18,000,000)** |
| | ABC Pension Fund - Mgmt Fee | (6,250,000) | |
| | XYZ Endowment - Mgmt Fee | (4,375,000) | |
| | DEF Foundation - Perf Fee | (3,750,000) | |
| | GHI Insurance - Mgmt Fee | (2,500,000) | |
| | JKL Family Office - Expense Reimb | (1,125,000) | |
| **Adjustments** | | | **500,000** |
| | FX Translation - EUR LPs | 325,000 | |
| | Prior Period Correction - JKL | 125,000 | |
| | Write-off (uncollectible) | (50,000) | |
| | Late Fee Reversal | 100,000 | |
| **Ending Balance** | | | **52,500,000** |

---

## Aging Schedule

| Aging Bucket | Amount ($) | % of Total |
|---|---|---|
| Current (0-30 days) | 31,500,000 | 60.0% |
| 31-60 days | 12,750,000 | 24.3% |
| 61-90 days | 5,250,000 | 10.0% |
| 91+ days | 3,000,000 | 5.7% |
| **Total** | **52,500,000** | **100.0%** |

---

## Collections by LP

| LP Name | Invoice Date | Amount ($) | Days Outstanding | Status |
|---|---|---|---|---|
| ABC Pension Fund | 2026-04-15 | 6,250,000 | 23 | Collected |
| XYZ Endowment | 2026-04-15 | 4,375,000 | 23 | Collected |
| DEF Foundation | 2026-04-01 | 3,750,000 | 37 | Outstanding |
| GHI Insurance | 2026-04-10 | 2,500,000 | 28 | Collected |
| JKL Family Office | 2026-03-20 | 1,125,000 | 49 | Outstanding |

---

## Reconciliation Check

| Check | Expected ($) | Actual ($) | Variance ($) |
|---|---|---|---|
| Beg AR + Billings - Collections + Adj | 52,500,000 | 52,500,000 | 0 |
| GL Account 1200 Balance | 52,500,000 | 52,480,000 | 20,000 |
| Subledger Total | 52,500,000 | 52,500,000 | 0 |

**Note:** GL variance of $20,000 identified as a timing difference in FX posting. Expected to clear in the next period.

---

## Action Items

1. Follow up on DEF Foundation invoice ($3,750,000 outstanding 37 days); contact CFO by 2026-05-10.
2. Investigate JKL Family Office aging (49 days); schedule call with LP by 2026-05-12.
3. Resolve $20,000 GL variance with general ledger team.
4. Confirm write-off of $50,000 with compliance; obtain CFO approval.
