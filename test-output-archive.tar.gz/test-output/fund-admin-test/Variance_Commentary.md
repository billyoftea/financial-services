# P&L Variance Commentary - Period over Period Flux Analysis

**Fund:** Meridian Capital Partners, L.P.
**Comparison:** April 2026 vs March 2026
**Prepared By:** Fund Administration

---

## Executive Summary

Total fund expenses decreased by $142,500 (-1.8%) month-over-month. The net variance is driven by a $275,000 increase in management fees, offset by a $385,000 decrease in operating expenses and a $32,500 increase in G&A costs.

---

## Variance Summary

| Line Item | March 2026 ($) | April 2026 ($) | Change ($) | Change (%) | Classification |
|---|---|---|---|---|---|
| Management Fees | 5,500,000 | 5,775,000 | +275,000 | **+5.0%** | Recurring |
| Operating Expenses | 12,833,333 | 12,448,333 | (385,000) | **-3.0%** | Mixed |
| G&A Expenses | 1,625,000 | 1,657,500 | +32,500 | **+2.0%** | Recurring |
| **Total Expenses** | **19,958,333** | **19,880,833** | **(142,500)** | **-0.7%** | -- |

---

## Management Fees (+5.0%, +$275,000)

| Sub-Component | Variance ($) | Driver |
|---|---|---|
| Base Management Fee | +250,000 | AUM increased from $1.10B to $1.15B (mid-April capital call) |
| Performance Fee Accrual | +25,000 | Higher unrealized gains in April |

**Root Cause:** The $50M capital call from ABC Pension Fund on April 10 increased average AUM for the month. Performance fee accrual rose due to stronger equity returns in technology positions.

**Classification:** Recurring. AUM-based fees will persist at the higher level. Expect continued uplift in May.

---

## Operating Expenses (-3.0%, -$385,000)

| Sub-Component | Variance ($) | Driver | Type |
|---|---|---|---|
| Brokerage Commissions | (125,000) | Lower notional traded | Recurring |
| Market Data & Research | (50,000) | Annual subscription renewed at lower rate | One-time |
| Technology & Systems | (85,000) | No disaster recovery test in April | One-time |
| Legal & Professional | (100,000) | March included one-time restructuring advice | One-time |
| Travel & Entertainment | (25,000) | Fewer investor conferences in April | Recurring |

**Root Cause:** March included a $100,000 one-time legal expense for fund restructuring advice and a $85,000 disaster recovery testing charge. April had lower trading activity, reducing commissions.

**Classification:** Mixed. The legal and DR expenses are non-recurring. Commission reduction may persist if trading volumes remain low.

---

## G&A Expenses (+2.0%, +$32,500)

| Sub-Component | Variance ($) | Driver | Type |
|---|---|---|---|
| Staff Compensation | +20,000 | Annual merit increase effective April 1 | Recurring |
| Office & Occupancy | +7,500 | Lease escalation clause | Recurring |
| Insurance | +5,000 | D&O premium adjustment | Recurring |

**Root Cause:** Annual compensation adjustments (3.5% average merit increase) took effect April 1. Office lease escalation of 2% per annum kicked in. Minor D&O insurance premium adjustment due to increased AUM tier.

**Classification:** Recurring. All three components will persist going forward and should be reflected in forward budget estimates.

---

## One-Time vs Recurring Summary

| Classification | Amount ($) | % of Total Variance |
|---|---|---|
| Recurring | +255,000 | 179% (gross) |
| One-Time | (235,000) | 165% (gross) |
| Mixed | (162,500) | 114% (gross) |
| **Net Variance** | **(142,500)** | -- |

---

## Forward Outlook

| Item | May 2026 Estimate ($) | Commentary |
|---|---|---|
| Management Fees | 5,800,000 | Full-month impact of higher AUM |
| Operating Expenses | 12,600,000 | Normalized trading volumes |
| G&A Expenses | 1,660,000 | Run-rate with new compensation |
| **Total Projected** | **20,060,000** | +0.9% vs April |
