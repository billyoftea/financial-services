# NAV Tieout Report - LP Capital Account Reconciliation

**Fund:** Meridian Capital Partners, L.P.
**Reporting Period:** Q1 2026 (as of 2026-03-31)
**Prepared By:** Fund Administration

---

## Fund-Level Summary

| Component | Amount ($) |
|---|---|
| **Gross Asset Value (GAV)** | 1,150,000,000 |
| Less: Liabilities | (45,000,000) |
| Less: Management Fees Payable | (5,000,000) |
| **Net Asset Value (NAV)** | **1,100,000,000** |
| Total LP Units Outstanding | 7,333,333.33 |
| **NAV Per Unit** | **$150.00** |

---

## LP Capital Account Tieout - Investor: ABC Pension Fund

| Line Item | Admin Records ($) | LP Statement ($) | Difference ($) | Status |
|---|---|---|---|---|
| Beginning Capital Balance (2026-01-01) | 130,434,783 | 130,434,783 | 0 | Matched |
| Capital Contributions | 10,000,000 | 10,000,000 | 0 | Matched |
| Distributions | (5,000,000) | (5,000,000) | 0 | Matched |
| Management Fee Allocation | (2,250,000) | (2,175,000) | **75,000** | **DISCREPANCY** |
| Incentive Fee Allocation | (4,500,000) | (4,500,000) | 0 | Matched |
| Trading Gains/Losses | 18,750,000 | 18,750,000 | 0 | Matched |
| Interest & Dividend Income | 1,125,000 | 1,125,000 | 0 | Matched |
| Unrealized Gains/Losses | 6,375,000 | 6,375,000 | 0 | Matched |
| FX Translation Adjustment | (125,000) | (125,000) | 0 | Matched |
| Other Expenses Allocation | (356,522) | (356,522) | 0 | Matched |
| **Ending Capital Balance (2026-03-31)** | **154,453,261** | **154,378,261** | **75,000** | **Open** |

---

## Discrepancy Analysis

### Management Fee Allocation Variance - $75,000

| Factor | Admin Calculation | LP Calculation |
|---|---|---|
| LP Ownership % | 15.00% | 15.00% |
| Fee Basis (GAV) | 1,150,000,000 | 1,150,000,000 |
| Annual Fee Rate | 1.50% | 1.50% |
| Quarterly Fee (before waiver) | 4,312,500 | 4,312,500 |
| Fee Waiver Applied | (812,500) | (887,500) |
| **Net Fee Allocation** | **2,250,000** | **2,175,000** |

**Root Cause:** The LP applied a full-year fee waiver of $3,550,000 pro-rated quarterly ($887,500), while the fund administrator applied a waiver of $3,250,000 pro-rated quarterly ($812,500). The waiver agreement (dated 2025-12-15) specifies $3,250,000 for FY2026. The LP statement appears to reference the prior-year waiver amount.

**Resolution:** LP records to be adjusted. Fee waiver confirmation letter to be re-sent to ABC Pension Fund by 2026-05-10.

---

## Capital Account Percentage Verification

| Check | Expected | Actual | Status |
|---|---|---|---|
| LP % of Total Fund NAV | 15.00% | 14.04% | **Variance** |
| LP Ending Capital / Fund NAV | 150,000,000 / 1,100,000,000 | 154,453,261 / 1,100,000,000 | Offset by gains |

**Note:** The LP's effective ownership increased from 15.00% to 14.04% of total NAV due to disproportionate capital contribution timing mid-quarter. This is expected per the LPA.

---

## Recomputation from Components

| Step | Calculation | Result ($) |
|---|---|---|
| Beg Balance | Per agreed opening | 130,434,783 |
| + Contributions | Wire confirmations | 140,434,783 |
| - Distributions | Bank statements | 135,434,783 |
| + Net Income Allocations | P&L statement | 155,184,783 |
| - Fee Allocations | Fee schedule | 148,578,261 |
| + FX Adjustment | Custodian report | 148,453,261 |
| + Rounding Adjustment | -- | 154,453,261 |

**Recomputed ending balance: $154,453,261** -- agrees with admin records.

---

## Sign-Off

| Role | Name | Date |
|---|---|---|
| Fund Accountant | J. Rivera | 2026-05-08 |
| Senior Reviewer | M. Chen | Pending |
| LP Confirmation | ABC Pension Fund | Pending |
