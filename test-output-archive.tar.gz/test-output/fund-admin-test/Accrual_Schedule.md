# Period-End Accrual Schedule

**Fund:** Meridian Capital Partners, L.P.
**Period:** Q2 2026 (April - June)
**Prepared By:** Fund Administration

---

## Accrual Summary

| Accrual Category | Annual Amount ($) | Quarterly Amount ($) | Monthly Amount ($) | Payment Frequency |
|---|---|---|---|---|
| Management Fees | 8,000,000 | 2,000,000 | 666,667 | Quarterly (in arrears) |
| Audit Fees | 500,000 | 125,000 | 41,667 | Annual (Q4 billing) |
| Legal Fees | 200,000 | 50,000 | 16,667 | As incurred |
| Insurance (D&O/E&O) | 150,000 | 37,500 | 12,500 | Annual (Q1 billing) |
| **Total** | **8,850,000** | **2,212,500** | **737,500** | -- |

---

## Monthly Accrual Detail

### Management Fees

| Month | Accrual ($) | YTD Accrued ($) | Paid ($) | Accrued Balance ($) |
|---|---|---|---|---|
| April 2026 | 666,667 | 666,667 | 0 | 666,667 |
| May 2026 | 666,667 | 1,333,333 | 0 | 1,333,333 |
| June 2026 | 666,667 | 2,000,000 | (2,000,000) | 0 |
| **Q2 Total** | **2,000,000** | **2,000,000** | **(2,000,000)** | **0** |

*Basis: 1.50% annual rate on average GAV of $1.133B. Paid quarterly in arrears.*

### Audit Fees

| Month | Accrual ($) | YTD Accrued ($) | Paid ($) | Accrued Balance ($) |
|---|---|---|---|---|
| April 2026 | 41,667 | 208,334 | 0 | 208,334 |
| May 2026 | 41,667 | 250,001 | 0 | 250,001 |
| June 2026 | 41,667 | 291,668 | 0 | 291,668 |
| **Q2 Total** | **125,000** | **291,668** | **0** | **291,668** |

*Basis: Annual audit engagement $500,K (Big Four). Billed in Q4 upon delivery. YTD includes Q1 accrual of $125,000 + Q2 $125,000 = $250K; rounded to $291,668 including Q2-end true-up of $41,668.*

### Legal Fees

| Month | Accrual ($) | YTD Accrued ($) | Paid ($) | Accrued Balance ($) |
|---|---|---|---|---|
| April 2026 | 16,667 | 16,667 | 0 | 16,667 |
| May 2026 | 16,667 | 33,333 | 0 | 33,333 |
| June 2026 | 16,667 | 50,000 | (50,000) | 0 |
| **Q2 Total** | **50,000** | **50,000** | **(50,000)** | **0** |

*Basis: Retainer $200K/year. Actual invoices reviewed quarterly. April includes $5K additional for regulatory inquiry.*

### Insurance (D&O / E&O)

| Month | Accrual ($) | YTD Accrued ($) | Paid ($) | Accrued Balance ($) |
|---|---|---|---|---|
| April 2026 | 12,500 | 150,000 | 0 | 0 |
| May 2026 | 12,500 | 162,500 | 0 | 12,500 |
| June 2026 | 12,500 | 175,000 | 0 | 25,000 |
| **Q2 Total** | **37,500** | **175,000** | **0** | **25,000** |

*Basis: Annual premium $150K paid in Q1. Monthly amortization recognized over 12 months.*

---

## Consolidated Accrual Roll-Forward

| Category | Beg Balance Q2 ($) | Q2 Accrual ($) | Q2 Payments ($) | End Balance Q2 ($) |
|---|---|---|---|---|
| Management Fees | 2,000,000 | 2,000,000 | (2,000,000) | 2,000,000 |
| Audit Fees | 166,667 | 125,000 | 0 | 291,667 |
| Legal Fees | 0 | 50,000 | (50,000) | 0 |
| Insurance | 0 | 37,500 | 0 | 37,500 |
| **Total** | **2,166,667** | **2,212,500** | **(2,050,000)** | **2,329,167** |

---

## Notes & Action Items

1. **Management Fees:** Q1 payment of $2M confirmed on April 3. Q2 accrual runs at full rate.
2. **Audit Fees:** Year-end audit fieldwork scheduled July 2026. Interim review complete; no adjustments.
3. **Legal Fees:** Monitor regulatory inquiry costs; may exceed budget by $25K-$50K.
4. **Insurance:** Annual renewal quote expected June 15. Budget assumes 5% premium increase.
