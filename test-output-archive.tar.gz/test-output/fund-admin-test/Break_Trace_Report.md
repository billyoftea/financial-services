# Break Trace Report - Root Cause Analysis

**Fund:** Meridian Capital Partners, L.P.
**Break ID:** BRK-0106
**Security:** AAPL US Equity (Apple Inc.)
**Date Identified:** 2026-05-08
**Analyst:** Fund Administration

---

## Break Summary

| Field | GL (General Ledger) | Subledger (Prime Broker) | Difference |
|---|---|---|---|
| Security | AAPL US Equity | AAPL US Equity | -- |
| Quantity | 1,000 shares | 1,050 shares | **50 shares** |
| Price ($) | 198.50 | 198.50 | 0 |
| Market Value ($) | 198,500 | 208,425 | **9,925** |

---

## Trace Timeline

| Step | Date | Event | GL Impact | Subledger Impact | Status |
|---|---|---|---|---|---|
| 1 | 2026-03-15 | Initial Purchase: 1,000 shares AAPL @ $185.00 | +1,000 shares | +1,000 shares | Matched |
| 2 | 2026-04-01 | Corporate Action: 5-for-1 Stock Split announced | No entry | No entry | Pending |
| 3 | 2026-04-07 | Ex-Date: Stock Split effective | No entry | +50 shares (adjusted) | **Break Origin** |
| 4 | 2026-04-07 | Subledger auto-adjustment for split (5% fractional) | -- | +50 shares | Mismatch begins |
| 5 | 2026-04-30 | Month-end reconciliation | 1,000 shares | 1,050 shares | Break identified |

---

## Root Cause Analysis

### Primary Cause: Stock Split Adjustment Not Posted to GL

Apple Inc. executed a 5-for-1 stock split with an ex-date of April 7, 2026. The prime broker's subledger automatically adjusted positions to reflect the split: 1,000 shares became 1,050 shares (the 50-share difference represents the fractional adjustment from the 5% distribution ratio applied to the existing position).

The general ledger system did not receive or post the corresponding corporate action journal entry. The GL still reflects the pre-split quantity of 1,000 shares.

### Contributing Factors

| Factor | Detail |
|---|---|
| Corporate Action Notification | Custodian notice received April 3 but auto-filed, not routed to GL team |
| GL System Config | Corporate action module requires manual journal entry approval |
| Reconciliation Timing | Break first appeared on April 7 but was not flagged until April 30 month-end |
| Split Ratio | 5-for-1 split with fractional share entitlement created non-round adjustment |

---

## Resolution Steps

| Step | Action | Responsible | Target Date | Status |
|---|---|---|---|---|
| 1 | Post GL journal: DR Investment in AAPL 50 shares, CR Unrealized Gain $9,925 | GL Team | 2026-05-09 | In Progress |
| 2 | Update cost basis: original $185.00/share adjusted to $176.19/share post-split | Fund Accountant | 2026-05-09 | Pending |
| 3 | Verify subledger matches post-adjustment | Reconciliation | 2026-05-09 | Pending |
| 4 | Re-run April month-end recon for AAPL position | Senior Reviewer | 2026-05-10 | Pending |
| 5 | Configure corporate action alerts in GL system | IT / Operations | 2026-05-15 | Scheduled |

---

## Correcting Journal Entry

| Account | Debit ($) | Credit ($) |
|---|---|---|
| Investment in AAPL (Quantity Adjustment) | 9,925 | |
| Unrealized Gain on Securities | | 9,925 |

*Adjusts GL from 1,000 to 1,050 shares at current market price of $198.50/share.*

---

## Impact Assessment

| Area | Impact |
|---|---|
| NAV Impact | $9,925 understatement (immaterial, <0.001% of NAV) |
| Fee Impact | Negligible; no performance fee threshold breached |
| Tax Impact | Cost basis adjustment required for lot tracking |
| Regulatory | No filing implications given immateriality |

---

## Preventive Controls

1. Implement automated corporate action feed from custodian to GL system.
2. Add daily corporate action validation check to reconciliation process.
3. Create escalation rule: any corporate action notification triggers same-day GL review.
4. Include split/merger/distribution events in monthly reconciliation checklist.
