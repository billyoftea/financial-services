# Option Volatility Analysis - S&P 500 (SPX)

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08 | SPX Level: 5,425 | VIX: 16.8*

---

## ATM Implied Volatility Surface

| Tenor | ATM IV (%) | 1W Chg | 1M Chg | Realized Vol (Matched) | IV-RV Spread |
|-------|-----------|--------|--------|----------------------|--------------|
| 1W | 14.5 | -2.1 | -3.5 | 12.8 | +1.7 |
| 2W | 15.2 | -1.8 | -3.0 | 13.5 | +1.7 |
| 1M | 16.0 | -1.5 | -2.8 | 14.2 | +1.8 |
| 2M | 16.8 | -1.2 | -2.5 | 14.8 | +2.0 |
| 3M | 17.5 | -1.0 | -2.2 | 15.2 | +2.3 |
| 6M | 18.2 | -0.8 | -1.5 | 15.8 | +2.4 |
| 1Y | 19.0 | -0.5 | -1.0 | 16.5 | +2.5 |

**Key Observation:** IV exceeds realized vol across all tenors by 1.7-2.5 vol points. The term structure is upward sloping, suggesting the market prices increased uncertainty over time rather than near-term event risk.

## Volatility Skew (3M Tenor)

| Delta | Put IV (%) | Call IV (%) | Skew (25d Put - ATM) |
|-------|-----------|-------------|---------------------|
| 10d Put | 24.5 | -- | +7.0 |
| 25d Put | 21.2 | -- | +3.7 |
| 50d (ATM) | 17.5 | 17.5 | 0.0 |
| 25d Call | -- | 15.2 | -2.3 |
| 10d Call | -- | 14.0 | -3.5 |

| Skew Metric | Value | Percentile (2Y) |
|-------------|-------|-----------------|
| 25d Put Skew | +3.7 vol | 55th |
| 10d Put Skew | +7.0 vol | 48th |
| 25d Call Skew | -2.3 vol | 40th |
| Put-Call Skew (RR) | 6.0 vol | 52nd |

Skew is near median -- no extreme fear or complacency embedded in OTM put pricing.

## Term Structure Analysis

| Metric | Value |
|--------|-------|
| 1M / 6M Ratio | 0.88 |
| 1M / 1Y Ratio | 0.84 |
| Contango (1M to 3M) | +1.5 vol points |
| Contango (3M to 1Y) | +1.5 vol points |
| Term Structure Shape | Steady contango |

The upward-sloping term structure is typical for low-vol environments. There is no event-driven kink (no earnings, elections, or Fed meetings creating a bump).

## Implied vs. Realized Volatility

| Metric | 1M | 3M | 6M |
|--------|-----|-----|-----|
| Implied Vol (ATM) | 16.0% | 17.5% | 18.2% |
| Realized Vol (historical match) | 14.2% | 15.2% | 15.8% |
| Variance Risk Premium | +1.8% | +2.3% | +2.4% |
| VRP Percentile (2Y) | 62nd | 65th | 60th |
| Vol of Vol (1M) | 85 | 72 | 65 |

**Variance risk premium** (IV minus RV) is positive across tenors and slightly above median, indicating moderate overpricing of vol. This favors short-vol strategies on a risk-adjusted basis.

## Vol Cone (1Y Historical)

| Percentile | 1M IV | 3M IV |
|------------|-------|-------|
| 95th | 28.5 | 26.0 |
| 75th | 21.0 | 20.5 |
| 50th | 17.2 | 17.8 |
| 25th | 14.5 | 15.5 |
| 5th | 11.0 | 12.5 |
| **Current** | **16.0** | **17.5** |

Current 1M IV sits near the 40th percentile and 3M IV near the 45th percentile of the 1-year range. Vol is priced below median -- neither cheap nor expensive in absolute terms.

## Trade Ideas

### Trade 1: Short 1M ATM Straddle (Income)

| Parameter | Detail |
|-----------|--------|
| Structure | Sell 1M 5425 straddle |
| Premium Received | ~$145 SPX points (~2.67% of spot) |
| Breakeven Range | 5,280 - 5,570 (+/- 2.7%) |
| IV Sold | 16.0% |
| Expected P&L (if held to exp) | +$45 (net of expected move of ~$100) |
| Risk | Unlimited beyond breakevens |
| Management | Close at 50% max profit or 21 days to expiry |

**Rationale:** VRP of +1.8% at the 1M tenor offers edge. Combined with steady contango and no near-term catalysts, theta decay should exceed gamma risk.

### Trade 2: 3M Put Spread (Hedge / Cheap Protection)

| Parameter | Detail |
|-----------|--------|
| Structure | Buy 5300 put / Sell 5100 put (3M) |
| Debit | ~$35 SPX points |
| Max Payout | $165 (4.7:1) |
| IV Paid | 19.2% (weighted) |
| Probability of Profit | ~25% (estimate) |

**Rationale:** 25d put skew is only at the 55th percentile -- OTM puts are not excessively expensive. This provides cheap downside protection for a long equity portfolio.

### Trade 3: Calendar Spread (Term Structure)

| Parameter | Detail |
|-----------|--------|
| Structure | Sell 1M 5425 straddle / Buy 3M 5425 straddle |
| Net Debit | ~$165 (3M) - $145 (1M) = $20 |
| IV Sold | 16.0% |
| IV Bought | 17.5% |
| Advantage | Selling 1.5 vol points of contango |

**Rationale:** Capitalize on the steep term structure. The front month decays faster; if spot remains near 5425, the short front straddle profits while the long back straddle retains value.

## Summary

SPX implied volatility is in a low-to-moderate regime (VIX 16.8, 1M IV at 40th percentile). The positive variance risk premium across tenors (1.7-2.5 vol points) favors systematic short-vol strategies. Skew is neutral. The upward-sloping term structure supports calendar and time-spread strategies. Key risk: any geopolitical or macro surprise would spike the VIX 5-8 points, creating sharp MTM losses on short-vol positions. Position sizing should account for 2x current vol as a stress scenario.
