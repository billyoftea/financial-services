# Swap Curve Strategy - US Interest Rate Swaps

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08*

---

## Swap Curve Snapshot

| Tenor | Swap Rate (%) | 1W Chg (bp) | 1M Chg (bp) | 3M Chg (bp) |
|-------|--------------|-------------|-------------|-------------|
| 1Y | 4.10 | -12 | -25 | +8 |
| 2Y | 4.18 | -10 | -22 | +12 |
| 3Y | 4.14 | -8 | -20 | +10 |
| 5Y | 4.08 | -6 | -18 | +8 |
| 7Y | 4.18 | -5 | -16 | +6 |
| 10Y | 4.32 | -5 | -15 | +5 |
| 15Y | 4.42 | -4 | -12 | +4 |
| 30Y | 4.55 | -3 | -10 | +3 |

## Swap-Treasury Spreads (Asset Swap Levels)

| Tenor | Swap Spread (bp) | 6M Z-Score | Direction |
|-------|-----------------|------------|-----------|
| 2Y | -10 | -0.8 | Rich |
| 5Y | -4 | -0.3 | Fair |
| 10Y | -3 | -0.1 | Fair |
| 30Y | -3 | +0.2 | Slightly Cheap |

Swap spreads are tight across the curve, reflecting ample liquidity and limited bank balance sheet stress. The 2Y stands out as rich (tight) relative to history.

## Forward Swap Rates

| Contract | Rate (%) | Implied 10Y in 1Y | Implied 10Y in 5Y |
|----------|----------|-------------------|-------------------|
| 1Yx10Y | 4.40 | -- | -- |
| 5Yx5Y | 4.55 | -- | -- |
| 10Yx10Y | 4.68 | -- | -- |

**Forward curve interpretation:** The market prices gradual steepening, with the 5Yx5Y at 4.55% vs spot 5Y at 4.08%, implying +47bp of normalization over 5 years.

## Curve Shape Analysis

| Spread | Current (bp) | 5Y Median (bp) | Z-Score | Signal |
|--------|-------------|----------------|---------|--------|
| 2Y-5Y | -10 | +5 | -1.5 | Inverted (unusual) |
| 5Y-10Y | +24 | +18 | +0.6 | Steep |
| 10Y-30Y | +23 | +25 | -0.1 | Fair |
| 2Y-10Y | +14 | +10 | +0.4 | Mildly steep |
| 5Y-30Y | +47 | +42 | +0.3 | Fair |

The 2Y-5Y segment is notably inverted, offering the most anomalous point on the curve. This is driven by the front-end rallying on Fed cut expectations while the 5Y remains anchored by term premium.

## Recommended Strategy

### Primary Trade: 2Y/5Y Steepener via Swaps

| Parameter | Detail |
|-----------|--------|
| Trade | Receive 2Y / Pay 5Y (steepener) |
| Entry Spread | -10 bp (inverted) |
| Target Spread | +5 bp (normalization to median) |
| Stop-Loss | -18 bp |
| Risk/Reward | 15 bp / 8 bp = 1.9:1 |
| Duration | DV01-neutral |
| Holding Period | 6-10 weeks |

**Rationale:** The 2Y-5Y segment is 1.5 standard deviations below its 5-year median. As the Fed begins cutting, the 2Y swap rate should decline faster than the 5Y, but the market has already priced significant easing into the 2Y. The more likely catalyst is a re-pricing of the 5Y lower as term premium compresses with confirmed disinflation. The -10bp inversion is historically rare and unsustainable.

### Secondary Trade: 10Y Swap Spread Widener

| Parameter | Detail |
|-----------|--------|
| Trade | Pay 10Y swap / Short 10Y Treasury (spread widener) |
| Entry | -3 bp |
| Target | +5 bp |
| Stop-Loss | -8 bp |
| Risk/Reward | 8 bp / 5 bp = 1.6:1 |

**Rationale:** 10Y swap spreads at -3bp are near cycle tights. Any uptick in issuance, bank hedging demand, or credit concerns could widen spreads to positive territory.

## Risk Factors

- **Upside risk to front-end:** If inflation re-accelerates, the 2Y sells off hard, steepening the 2Y-5Y in the wrong direction for the trade.
- **Structural demand:** Persistent receiver interest in 5Y from corporate hedgers may cap steepening.
- **Liquidity:** Swap spreads can dislocate sharply during risk-off events.
