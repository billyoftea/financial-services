# Equity Research Snapshot - Apple Inc. (AAPL)

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08 | Price: $198.50 | Mkt Cap: $3.04T | Sector: Technology*

---

## Analyst Consensus

| Metric | Value |
|--------|-------|
| Number of Analysts | 48 |
| Strong Buy | 22 |
| Buy | 15 |
| Hold | 8 |
| Sell | 2 |
| Strong Sell | 1 |
| Consensus Rating | **Buy** (4.15 / 5.0) |
| Mean Target Price | $215.00 |
| Median Target Price | $218.00 |
| Target Price Range | $165 - $260 |
| Upside to Mean Target | +8.3% |

## EPS Estimates

| Period | Consensus EPS | High | Low | YoY Growth |
|--------|-------------|------|-----|------------|
| FY2025E (Sep) | $7.85 | $8.20 | $7.40 | +10.4% |
| FY2026E (Sep) | $8.65 | $9.10 | $8.10 | +10.2% |
| FY2027E (Sep) | $9.50 | $10.05 | $8.80 | +9.8% |
| Q3 FY2025E (Jun) | $1.52 | $1.60 | $1.42 | +6.3% |

## Revenue Estimates

| Period | Consensus Rev ($B) | YoY Growth |
|--------|-------------------|------------|
| FY2025E | $408.5 | +5.8% |
| FY2026E | $435.2 | +6.5% |
| FY2027E | $462.8 | +6.3% |

## Fundamental Valuation

| Metric | AAPL | Peer Median | Premium/Discount |
|--------|------|-------------|------------------|
| P/E (NTM) | 25.3x | 22.8x | +11% premium |
| P/E (TTM) | 32.5x | 28.1x | +16% premium |
| EV/EBITDA (NTM) | 20.8x | 18.5x | +12% premium |
| P/S (NTM) | 7.4x | 5.2x | +42% premium |
| P/B | 52.1x | 8.3x | Premium |
| FCF Yield | 3.2% | 3.8% | -60bp discount |

## Profitability & Returns

| Metric | Value | Peer Median |
|--------|-------|-------------|
| Gross Margin | 46.8% | 44.2% |
| EBIT Margin | 32.1% | 25.5% |
| Net Margin | 25.4% | 19.8% |
| ROE | 160.5% | 38.2% |
| ROIC | 58.3% | 25.1% |
| Dividend Yield | 0.5% | 0.9% |

## Price Target Distribution

| Quartile | Target Price | Upside |
|----------|-------------|--------|
| 25th | $198.00 | -0.3% |
| 50th | $218.00 | +9.8% |
| 75th | $235.00 | +18.4% |

## Key Takeaways

AAPL trades at a premium to peers on nearly every metric, justified by best-in-class margins, massive free cash flow generation ($110B+ annually), and an expanding services segment (24% of revenue, 70%+ gross margin). Consensus leans bullish with 77% buy-side ratings. Near-term catalysts include the iPhone 18 cycle, AI features driving upgrade demand, and services monetization. Key risks include regulatory headwinds (EU DMA, App Store), China demand uncertainty, and hardware cyclicality.

**Earnings Date:** Q3 FY2025 estimated late July 2026.
