# FX Carry Trade Analysis - USD vs EM Currencies

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08 | Base Currency: USD*

---

## Carry Universe Overview

| Pair | Spot Rate | 3M Carry (annualized) | 1Y Carry (annualized) | 3M Vol (%) | 1Y Vol (%) |
|------|-----------|----------------------|----------------------|-------------|-------------|
| USD/BRL | 5.28 | +5.85% | +5.20% | 14.2 | 13.5 |
| USD/ZAR | 18.15 | +4.90% | +4.55% | 15.8 | 14.9 |
| USD/MXN | 19.42 | +3.75% | +3.40% | 11.5 | 10.8 |
| USD/TRY | 38.50 | +12.50% | +11.80% | 18.2 | 17.5 |

*Carry is calculated as the interest rate differential (short USD, long EM currency).*

## Risk-Adjusted Carry Metrics

| Pair | Carry (%) | 3M Vol (%) | Carry/Vol (Sharpe) | Max Drawdown (1Y) | Sortino Ratio |
|------|-----------|-------------|-------------------|-------------------|---------------|
| USD/BRL | 5.85 | 14.2 | **0.41** | -8.2% | 0.58 |
| USD/ZAR | 4.90 | 15.8 | 0.31 | -11.5% | 0.42 |
| USD/MXN | 3.75 | 11.5 | **0.33** | -6.8% | 0.48 |
| USD/TRY | 12.50 | 18.2 | 0.69 | -15.2% | 0.72 |

## Interest Rate Differentials

| Currency | Policy Rate (%) | US Fed Funds (%) | Differential (bp) | Forward Points (3M) |
|----------|----------------|-------------------|-------------------|---------------------|
| BRL | 10.50 | 4.75 | +575 | -758 |
| ZAR | 8.25 | 4.75 | +350 | -455 |
| MXN | 8.50 | 4.75 | +375 | -488 |
| TRY | 17.50 | 4.75 | +1275 | -1,650 |

## Correlation Matrix (3M returns, weekly)

| | BRL | ZAR | MXN | TRY |
|---|-----|-----|-----|-----|
| BRL | 1.00 | 0.62 | 0.48 | 0.22 |
| ZAR | 0.62 | 1.00 | 0.55 | 0.18 |
| MXN | 0.48 | 0.55 | 1.00 | 0.15 |
| TRY | 0.22 | 0.18 | 0.15 | 1.00 |

**Key Insight:** TRY is the most diversifying EM carry currency due to its low correlation with LatAm carry (BRL, MXN). A basket combining BRL + MXN + TRY offers better diversification than BRL + ZAR + MXN.

## Portfolio Optimization (Equal Volatility Weighted)

| Allocation | BRL | ZAR | MXN | TRY |
|------------|-----|-----|-----|-----|
| Weight | 25% | 20% | 30% | 25% |
| Notional per $10M | $2.5M | $2.0M | $3.0M | $2.5M |

**Basket Statistics:**

| Metric | Value |
|--------|-------|
| Blended Carry | 6.25% annualized |
| Portfolio Vol | 10.2% annualized |
| Sharpe Ratio | 0.61 |
| VaR (95%, 1M) | 4.8% |
| CVaR (95%, 1M) | 6.2% |

## Risk Assessment

### Country-Specific Risks

| Risk | BRL | ZAR | MXN | TRY |
|------|-----|-----|-----|-----|
| Political Risk | Medium | High | Low-Medium | High |
| Capital Controls | Low | Low | Low | Medium |
| Fiscal Concern | Medium | High | Medium | Very High |
| External Balance | Moderate | Fragile | Solid | Fragile |
| Election Cycle | None (2026) | None (2026) | None (2028) | None (2028) |

### Scenario Analysis

| Scenario | Probability | BRL Impact | ZAR Impact | MXN Impact | TRY Impact |
|----------|------------|------------|------------|------------|------------|
| Risk-off (VIX > 30) | 20% | -6% to -10% | -8% to -14% | -5% to -8% | -10% to -18% |
| USD Strength | 25% | -3% to -7% | -4% to -8% | -3% to -6% | -5% to -10% |
| EM Rally | 30% | +4% to +8% | +5% to +10% | +3% to +6% | +6% to +12% |
| Status Quo | 25% | +1.5% (carry) | +1.2% (carry) | +0.9% (carry) | +3.1% (carry) |

## Trade Recommendation

**Recommended:** Establish a diversified EM carry basket with 30% MXN, 25% BRL, 25% TRY, 20% ZAR.

- **Entry:** Scale in over 2 weeks to average entry levels.
- **Hedge:** Buy 3M USD-strength protection via MXN puts (10-delta) costing ~40bp.
- **Target:** 6-month holding, targeting 3-4% total return (carry + spot).
- **Stop-Loss:** Close basket if cumulative loss exceeds 5%.

**Avoid:** Standalone TRY position -- carry is attractive but tail risk is extreme. Only include within a diversified basket.
