# Fixed Income Portfolio Review

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08 | Portfolio Value: $50,000,000*

---

## Portfolio Holdings

| Bond | Cusip | Coupon | Maturity | Face ($M) | Price | Yield (%) | Mod. Duration | Convexity |
|------|-------|--------|----------|-----------|-------|-----------|---------------|-----------|
| US Treasury 4.50% 2027 | 91282CKS5 | 4.50% | 15-Mar-2027 | 10.0 | 100.84 | 4.22 | 1.65 | 3.2 |
| US Treasury 4.25% 2029 | 91282CKP1 | 4.25% | 15-Jun-2029 | 10.0 | 99.52 | 4.30 | 3.40 | 14.8 |
| US Treasury 4.375% 2032 | 91282CJZ8 | 4.375% | 15-Nov-2032 | 10.0 | 99.85 | 4.38 | 5.55 | 37.2 |
| US Treasury 4.375% 2036 | 91282CKA6 | 4.375% | 15-Feb-2036 | 10.0 | 99.28 | 4.45 | 8.05 | 78.5 |
| US Treasury 4.50% 2046 | 912810TL0 | 4.50% | 15-Aug-2046 | 10.0 | 100.50 | 4.48 | 14.20 | 312.4 |

## Portfolio Summary Statistics

| Metric | Value |
|--------|-------|
| Market Value | $49,998,500 |
| Weighted Average Yield | 4.37% |
| Weighted Average Duration | 6.57 years |
| Weighted Average Convexity | 89.2 |
| Average Coupon | 4.40% |
| Average Price | 99.997 |

## Total Return Attribution (YTD)

| Source | Return (bp) | Contribution |
|--------|------------|-------------|
| Coupon Income | +148 | +74% |
| Price Change (rates) | -42 | -21% |
| Roll-Down Return | +45 | +23% |
| **Total YTD Return** | **+151 bp** | **100%** |

## Scenario Analysis

### Parallel Rate Shifts

| Scenario | Portfolio P&L ($) | Return (%) | New Yield (%) |
|----------|-------------------|------------|---------------|
| Rates -100bp | +$6,570,000 | +13.1% | 3.37% |
| Rates -50bp | +$3,285,000 | +6.6% | 3.87% |
| Rates -25bp | +$1,642,500 | +3.3% | 4.12% |
| **Base Case** | **$0** | **0.0%** | **4.37%** |
| Rates +25bp | -$1,642,500 | -3.3% | 4.62% |
| Rates +50bp | -$3,285,000 | -6.6% | 4.87% |
| Rates +100bp | -$6,570,000 | -13.1% | 5.37% |

### Non-Parallel Shifts (Curve)

| Scenario | Portfolio P&L ($) | Return (%) |
|----------|-------------------|------------|
| Bull Flatten (-50bp 2Y, -10bp 30Y) | +$1,890,000 | +3.8% |
| Bear Flatten (+10bp 2Y, +50bp 30Y) | -$3,510,000 | -7.0% |
| Bull Steepen (-10bp 2Y, -50bp 30Y) | -$3,510,000 | -7.0% |
| Bear Steepen (+50bp 2Y, +10bp 30Y) | +$1,890,000 | +3.8% |

## Key Risk Metrics

| Risk Metric | Value |
|-------------|-------|
| DV01 | $32,850 |
| VaR (95%, 1M) | $1,245,000 |
| Tracking Error (vs. Bloomberg Agg) | 45bp ann. |
| Max Drawdown (3Y historical) | -8.2% |

## Recommendations

1. **Duration:** Portfolio duration of 6.57 is neutral vs. benchmark. Maintain given mixed signals on Fed path.
2. **Convexity:** Underweight convexity at the long end -- the 30Y position dominates risk. Consider trimming to 7.5M face.
3. **Roll-down:** The 5Y sector offers the best roll-down (approximately 18bp over 3 months). Overweight recommended.
4. **Reinvestment:** $10M maturing March 2027 should be reinvested in the 5Y sector to capture favorable roll-down.
