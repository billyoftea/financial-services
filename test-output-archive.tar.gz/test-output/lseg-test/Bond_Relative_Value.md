# Bond Relative Value Analysis - 10Y vs 30Y US Treasury

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08*

---

## Current Market Snapshot

| Security | Yield (%) | Price | Duration | OAS (bp) |
|----------|-----------|-------|----------|----------|
| 10Y Treasury (4.375% Nov-2035) | 4.35 | 100.20 | 8.25 | -- |
| 30Y Treasury (4.50% Aug-2046) | 4.58 | 100.50 | 19.10 | -- |
| **10Y-30Y Spread** | **23 bp** | -- | -- | -- |

## Spread Analysis

| Metric | Current | 6M Average | 1Y Average | 5Y Average |
|--------|---------|------------|------------|------------|
| 10Y-30Y Spread | 23 bp | 28 bp | 25 bp | 42 bp |
| Z-Score (1Y) | -0.4 | -- | -- | -- |
| Z-Score (5Y) | -1.2 | -- | -- | -- |
| Percentile (5Y) | 15th | -- | -- | -- |

## Historical Spread Range

| Period | Min (bp) | Max (bp) | Median (bp) |
|--------|----------|----------|-------------|
| Last 6 months | 15 | 55 | 28 |
| Last 1 year | 12 | 65 | 25 |
| Last 5 years | -10 | 110 | 42 |
| Last 10 years | -15 | 130 | 48 |

## Rich/Cheap Assessment

The 10Y-30Y spread at 23bp sits in the **15th percentile** of the 5-year historical range, indicating the long end is **rich** relative to the belly. The spread is 19bp below the 5-year median of 42bp.

**Decomposition:**

| Factor | Contribution |
|--------|-------------|
| Term premium compression | -12 bp |
| Demand (pension/insurance duration) | -8 bp |
| Lower expected long-run rates | -5 bp |
| Supply pressure (30Y auctions) | +6 bp |
| **Net** | **-19 bp vs median** |

## Relative Value Metrics

| Metric | 10Y | 30Y | RV Signal |
|--------|-----|-----|-----------|
| Real Yield (TIPS) | 2.05% | 2.15% | 30Y slightly cheap on real |
| Break-even Inflation | 2.30% | 2.43% | 30Y inflation premium high |
| Roll-Down (3M) | 10 bp | 4 bp | 10Y superior roll |
| Carry vs Funding | +12 bp | +8 bp | 10Y better carry |
| Total Return (3M est.) | 2.8% | 2.1% | 10Y outperforms |

## Trade Recommendation

**Trade:** Receive 30Y / Pay 10Y (flattener via swaps) or equivalently **overweight 10Y vs 30Y** in cash bonds.

| Parameter | Value |
|-----------|-------|
| Direction | Long 10Y / Short 30Y (duration-neutral) |
| Entry Spread | 23 bp |
| Target Spread | 35 bp |
| Stop-Loss | 15 bp |
| Risk/Reward | 12 bp target / 8 bp risk = 1.5:1 |
| Holding Period | 4-8 weeks |
| DV01-Neutral Ratio | 2.32x (long more 10Y face) |

## Rationale

The 30Y is trading rich on the back of strong insurance and pension demand for long-duration assets. However, upcoming 30Y auction supply and a potential steepening catalyst (persistent fiscal deficits, term premium normalization) should widen the spread toward the median. The 10Y offers better roll-down and carry, providing positive carry while waiting for the spread to normalize. Risk is limited to further flight-to-duration flows compressing the long end further.

**Confidence:** Medium-High. Position sizing should be moderate given the persistent structural demand for long duration.
