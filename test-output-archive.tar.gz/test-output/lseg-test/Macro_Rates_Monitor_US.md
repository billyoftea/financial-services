# Macro Rates Monitor - United States

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08*

---

## Key Macro Indicators

| Indicator | Latest | Prior | QoQ/YoY Change |
|-----------|--------|-------|-----------------|
| Real GDP (QoQ ann.) | 2.1% | 2.4% | -0.3pp |
| CPI (YoY) | 3.2% | 3.4% | -0.2pp |
| Core CPI (YoY) | 3.6% | 3.8% | -0.2pp |
| PCE Core (YoY) | 2.9% | 3.1% | -0.2pp |
| Unemployment Rate | 4.1% | 4.0% | +0.1pp |
| Nonfarm Payrolls (K) | 185 | 210 | -25K |
| ISM Manufacturing | 49.8 | 50.2 | -0.4 |
| ISM Services | 52.1 | 52.6 | -0.5 |

## Treasury Yields

| Tenor | Yield (%) | 1W Chg (bp) | 1M Chg (bp) | 3M Chg (bp) |
|-------|-----------|-------------|-------------|-------------|
| 2Y | 4.28 | -8 | -22 | +15 |
| 5Y | 4.12 | -6 | -18 | +10 |
| 10Y | 4.35 | -5 | -15 | +8 |
| 30Y | 4.58 | -3 | -10 | +5 |

## Yield Curve Shape

| Spread | Current (bp) | 1M Ago (bp) | Assessment |
|--------|-------------|-------------|------------|
| 2Y-10Y | +7 | +2 | Mildly positive |
| 2Y-30Y | +30 | +20 | Positively sloped |
| 5Y-30Y | +46 | +42 | Steepening |
| 10Y-30Y | +23 | +25 | Stable |

**Curve Classification:** The 2Y-10Y spread has normalized to modest positive territory after 18 months of inversion. The curve is bull-steepening as front-end rates decline faster on easing expectations.

## Swap Spreads

| Tenor | Swap Rate (%) | Swap Spread (bp) | Z-Score (6M) |
|-------|--------------|-------------------|---------------|
| 2Y | 4.18 | -10 | -0.8 |
| 5Y | 4.08 | -4 | -0.3 |
| 10Y | 4.32 | -3 | -0.1 |
| 30Y | 4.55 | -3 | +0.2 |

## Forward Rates

| Contract | Rate (%) | Implied Policy Rate |
|----------|----------|-------------------|
| SOFR 3M (3M fwd) | 4.15 | ~4.25 |
| SOFR 3M (6M fwd) | 3.95 | ~3.90 |
| SOFR 3M (1Y fwd) | 3.60 | ~3.50 |

## Summary & Outlook

The US macro picture shows gradual cooling: GDP growth decelerating, inflation trending lower but still above target, and labor markets softening. Treasury yields have declined 15-22bp over the past month as markets price in 75-100bp of Fed cuts over the next 12 months. The yield curve has bull-steepened with front-end led rally. Swap spreads remain tight across the curve, suggesting limited credit stress in rates markets. Forward pricing implies the first Fed cut is fully priced for Q3 2026.

**Key Risk:** Services inflation remains sticky above 4%; a repricing of easing expectations would hit the front end hardest.
