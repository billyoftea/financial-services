# Bond Futures Basis Analysis - 10Y US Treasury Note

> **TEST OUTPUT - LSEG MCP required for live data**

*Report Date: 2026-05-08 | Contract: TYM6 (Jun 2026 10Y T-Note Futures)*

---

## Contract Overview

| Parameter | Value |
|-----------|-------|
| Contract | TYM6 (10Y T-Note, Jun-26) |
| Last Price | 110-16+ (110.5078) |
| Implied Yield | 4.28% |
| Conversion Factor | 0.8426 |
| Delivery Date | 30-Jun-2026 |
| Days to Delivery | 53 |
| Open Interest | 3,842,000 |

## Cheapest-to-Deliver (CTD) Identification

| Bond | Coupon | Maturity | Price | Gross Basis | Implied Repo | Net Basis |
|------|--------|----------|-------|-------------|-------------|-----------|
| **4.375% Nov-2035** | **4.375%** | **15-Nov-2035** | **100.20** | **12.5 ticks** | **4.85%** | **-2.1 ticks** |
| 4.25% Aug-2035 | 4.25% | 15-Aug-2035 | 99.45 | 14.8 ticks | 4.62% | +0.8 ticks |
| 4.00% May-2035 | 4.00% | 15-May-2035 | 98.10 | 18.2 ticks | 4.38% | +3.5 ticks |
| 4.50% Feb-2036 | 4.50% | 15-Feb-2036 | 101.80 | 16.0 ticks | 4.55% | +1.2 ticks |

**CTD: 4.375% Nov-2035** -- lowest net basis at -2.1 ticks, highest implied repo rate at 4.85%.

## Basis Decomposition

| Component | Value (ticks) | Description |
|-----------|--------------|-------------|
| Gross Basis | +12.5 | Futures price vs. CTD invoice price |
| Carry to Delivery | +14.6 | Coupon income - financing cost over 53 days |
| Net Basis | -2.1 | Gross basis minus carry (cheap to cash) |
| Optionality Value | +1.5 | Embedded delivery option / end-of-month option |

## Basis Analysis

The net basis of **-2.1 ticks** indicates the basis is **cheap** relative to carry -- the future trades at a slight discount to fair value. This creates a positive carry opportunity for basis traders.

| Metric | Value | Interpretation |
|--------|-------|----------------|
| Implied Repo Rate | 4.85% | Above term GC repo (4.20%) -- positive carry |
| Term GC Repo (53d) | 4.20% | Financing cost |
| Carry Advantage | +65 bp | IRR exceeds repo by 65bp |
| BV (Basis Point Value) | $72.50/contract | DV01 per contract |

## Trade Recommendation

### Primary: Long Basis (Buy CTD, Sell Futures)

| Parameter | Detail |
|-----------|--------|
| Trade | Buy 4.375% Nov-2035 cash / Sell TYM6 futures |
| Entry Net Basis | -2.1 ticks |
| Target | +2.0 ticks (mean reversion) |
| Stop-Loss | -5.0 ticks |
| Risk/Reward | 4.1 / 2.9 = 1.4:1 |
| Carry Earned | +65 bp annualized over 53 days |
| Capital Efficiency | financing via repo |

**P&L Estimate (per $100M face):**

| Scenario | Basis P&L | Carry P&L | Total |
|----------|-----------|-----------|-------|
| Delivery at 0 net basis | +$6,562 | +$9,583 | +$16,145 |
| Mean reversion (+2 ticks) | +$12,812 | +$9,583 | +$22,395 |
| Adverse (-5 ticks) | -$9,063 | +$9,583 | +$520 |

### CTD Switch Risk

| Condition | Probability | Impact |
|-----------|------------|--------|
| Yield stays < 4.50% | 75% | Nov-2035 remains CTD -- no switch |
| Yield rises to 4.80% | 20% | Possible switch to 4.25% Aug-2035 |
| Yield rises above 5.00% | 5% | Likely switch, basis widens |

## Key Observations

1. **Positive carry trade:** The IRR of 4.85% exceeds financing by 65bp, making this a carry-positive basis trade even if the net basis does not converge.
2. **Low optionality:** With only 53 days to delivery and a clear CTD, the delivery option is worth approximately 1.5 ticks -- relatively cheap.
3. **CTD stability:** The 4.375% Nov-2035 has a strong hold on CTD status; a yield move of 40-50bp higher would be needed to trigger a switch.
4. **Liquidity:** Open interest of 3.8M contracts provides ample liquidity for execution.

**Overall Assessment:** Attractive risk-adjusted basis trade with positive carry, stable CTD, and limited downside. Recommend establishing positions in size over the next week.
